@extends('layout.master')
@section('title', 'MODULE')
@section('content')
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Team Master
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Team Master</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="box">
         <!-- <div class="box-header">
            <h3 class="box-title">Data Table With Full Features</h3>
          </div>-->
          <!-- /.box-header -->
          <div class="box-body">
          	<div id="demo">
                  <div class="search-field">
                      <div class="row">
                          <div class="col-md-2">
                              <div class="org-name">Member Name</div>
                          </div>
                          <div class="col-md-2">
                              <input class="form-control" type="text" placeholder="" name="param1" id="param1">
                          </div>

                          <div class="col-md-2">
                              <div class="form-group">
                                  <button class="btn btn-primary" onClick="searchData()">Search</button>
                              </div>
                          </div>
                           <div class="col-md-2">
                              <div class="form-group pull-right">
                                  <a href="{{ url('team/showAddTeamMember')}}"><button class="btn btn-primary">Add Member</button></a>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
              <!--<a data-toggle="collapse" data-target="#demo"
                  class="showhideangelbg"><i class="fa fa-angle-double-down"></i>
              </a>-->
            <table id="listAllCountry" class="table table-bordered table-striped">
              <thead>
              <tr>
                <th>Member Photo</th>
                <th>Name</th>
                <th>Designation</th>
                <th>Mobile Number</th>
                <th>Email</th>
                <th>Action</th>
              </tr>
              </thead>
              <tbody>
            
              </tbody>
            </table>
          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
@push('styles')
<!--Extra styles can written here -->
@endpush  
@push('scripts')

<script>
  $(function () {
	$('#listAllCountry').DataTable({
		'processing' : true,
		'serverSide' : true,
		'searching' : false,
		'ordering' : false,
		"ajax" : {
			'url' : "{{url('team/viewTeamthroughAjax')}}",
			'data' : function(d) {
				d.param1 = $('#param1').val();
				d.param2 = $('#param2').val();

			}
		},
		'dataSrc' : "",
		'columns' : [ {
			'data' : 'TTM_TeamMember_Image'
		}, {
      'data' : 'TTM_TeamMemberName'
    }, {
			'data' : 'TTM_TeamMemberDesignation'
		}, {
      'data' : 'TTM_Member_mobile'
    },{
      'data' : 'TTM_Member_Email'
    },{
			'data' : 'action'
		}

		]
	});
	
  });
  //Method For Searching Records In The List
	function searchData() {
		$('#listAllCountry').DataTable().draw();
	}
	//Deleting the Country

	function deleteMember(id){
       $.ajaxSetup({
        headers: {
                'X-CSRF-TOKEN': '{{csrf_token()}}'
                 }
                });
		swal.fire({
			  title: "Are you sure want to Delete?",
			  text: "Once Deleted,Can't revert back !",
			  type: "warning",
			  showCancelButton: true,
			  confirmButtonColor: '#d33',
			  cancelButtonColor: '#e7b63a',
			  confirmButtonText: 'Delete',
			  reverseButtons : true
			  
			}).then((result) => {
				if(result.value){
				 $.ajax({
					    type: "POST",
					    url:"{{url('Team/deleteMemberthroughAjax')}}",
              data:{"id":id},
					    success: function(response) {
						console.log(response);
						//return false;
					        if (response.message == "success") {
					        	swal({
					        		title: "Record Deleted Successfully.",
					        		type: "success"
					        	}).then(function(){
					        		 location.reload();
					        	})
					        
					        	
					        } else {
					            swal({
					                title: 'Unsuccess',
					                text: response.code
					            })
					        }
					    },
					    error: function(data) {
				       
					    }
					})
				}
			  
			});
	} 
	

</script>
@endpush
@endsection