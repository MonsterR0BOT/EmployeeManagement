@extends('layout.master')
@section('title', 'REPORT')
@section('content')
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Team Master
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Report</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="box">
         <!-- <div class="box-header">
            <h3 class="box-title">Data Table With Full Features</h3>
          </div>-->
          <!-- /.box-header -->
          <div class="box-body">
          	<div id="demo">
                  <div class="search-field">
                      <div class="row">
                          <div class="col-md-2">
                              <div class="org-name">Date</div>
                          </div>
                          <div class="col-md-2">
                              <input class="form-control" type="text" placeholder="" name="param1" id="param1">
                          </div>

                          <div class="col-md-2">
                              <div class="form-group">
                                  <button class="btn btn-primary" >Search</button>
                              </div>
                          </div>

                      </div>
                  </div>
              </div>

            <table  class="table table-bordered table-striped">
              <thead>
              <tr>
                <th>Date</th>
                <th>In Time</th>
                <th>Out Time</th>
              </tr>
              </thead>
              <tbody>
                @foreach($data as $val)
                <tr>
                <td>{{$val->TEA_date}}</td>
                <td>{{$val->TEA_intime}}</td>
                <td>{{$val->TEA_outtime}}</td> 
              </tr>
                @endforeach  
              </tbody>
            </table>
          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
@push('styles')
<!--Extra styles can written here -->
@endpush  
@push('scripts')

<script>
  


	
	

</script>
@endpush
@endsection