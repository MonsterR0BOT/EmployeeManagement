@extends('layout.master')
@section('title', 'COUNTRY')
@section('content')
  <!-- Content Wrapper. Contains page content --> 
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Add TeamMember</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Add TeamMember</li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">
      <!-- Default box -->
      <div class="box">
       <!-- <div class="box-header">
          <h3 class="box-title">Quick Example</h3>
        </div>-->
        <!-- /.box-header -->
        <!-- form start -->
        <form role="form" enctype="multipart/form-data" method="post" action="{{ url('team/addTeam')}}"  onsubmit="return validateForm()" autocomplete="off">
          @csrf
          <div class="box-body">
            <div class="row">
                <div class="col-md-6">
                <?php //print "<pre>"; print_r($data);exit;?>
                  @php
                    if(!empty($data)){
                      $teamMemberId = $data[0]->TTM_Team;
                        $TTM_TeamMemberName = $data[0]->TTM_TeamMemberName;
                        $TTM_Member_mobile = $data[0]->TTM_Member_mobile;
                        $TTM_Member_Email = $data[0]->TTM_Member_Email;
                        $TTM_TeamMemberDesignation = $data[0]->TTM_TeamMemberDesignation;
                        $TTM_TeamMember_Image = $data[0]->TTM_TeamMember_Image;
                        $TTM_DOB = date("Y-m-d",strtotime($data[0]->TTM_DOB)) ;
                        $TTM_Member_Address = $data[0]->TTM_Member_Address;
                        
                        
                    }else{
                       $teamMemberId = '';
                        $TTM_TeamMemberName = '';
                        $TTM_Member_mobile = '';
                        $TTM_Member_Email = '';
                        $TTM_TeamMemberDesignation = '';
                        $TTM_TeamMember_Image = '';
                        $TTM_DOB = '';
                        $TTM_Member_Address = '';
                        
            
                    }
                    @endphp
                    <input type="hidden" name="hidteamMemberId" value="{{$teamMemberId}}"/>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Name</label>
                      <input type="text" class="form-control" onkeyup="checkAlphabet(this.id)" onblur="checkAlphabet(this.id)" name="Name" id="Name" value="{{$TTM_TeamMemberName}}">
                    </div>
                    
                    <div class="form-group">
                      <label for="exampleInputPassword1">Email</label>
                      <input type="text" class="form-control" name="email" id="email" value="{{$TTM_Member_Email}}">
                    </div>
                    @if($teamMemberId='')
                    <div class="form-group">
                      <label for="exampleInputPassword1">Password</label>
                      <input type="password" class="form-control" name="password" id="password" value="">
                    </div>
                    @endif
                    <div class="form-group">
                      <label for="exampleInputPassword1">Mobile Number</label>
                      <input  class="form-control" onkeyup="checkNum(this.id)" onblur="checkNum(this.id)" name="mobile" id="mobile" value="{{$TTM_Member_mobile}}" maxlength="10">
                    </div>
                    <div class="form-group">
                    <label class="custom-file-upload mrt-27" for="memberImage"><i class="fa fa-cloud-upload"></i> Upload Photo</label>
                    <input id="memberImage" name="memberImage" onchange ="checkImageFormat(this)" type="file" class="form-control" accept="image/*"  >
                    </div>

                </div>
                
                <div class="col-md-6">
                    <div class="form-group">
                      <label for="exampleInputPassword1">Designation</label>
                      <input type="text" class="form-control" name="designation" id="designation" value="{{$TTM_TeamMemberDesignation}}">
                    </div>
                  
                    <div class="form-group">
                      <label for="exampleInputPassword1">Date Of Birth</label>
                      <input type="date"  class="form-control" id="" placeholder="Date Of Birth" name="dob" value="{{$TTM_DOB}}">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Address</label>
                      <input  class="form-control" name="address" id="address" value="{{$TTM_Member_Address}}" >
                    </div>

                </div>
                
            </div>
          </div>
          <!-- /.box-body -->
          <div class="box-footer">
            
            <button type="submit" class="btn btn-primary">Submit</button>
            <a href="{{url('team/viewAllTeam')}}"><button type="button" class="btn btn-warning">Cancel</button></a>
          </div>
        </form>
      </div>
      <!-- /.box -->
      
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
@push('scripts') 
<script type="text/javascript">
   function validateForm(){  
    if (!blankValidation("Name","TextField", "Name can not be left blank"))
     return false;

    if (!blankValidation("designation","TextField", "Designation can not be left blank"))
      return false;

    if (!blankValidation("email","TextField", "Email  can not be left blank"))
      return false; 
    if (!blankValidation("dob","TextField", "DOB  can not be left blank"))
      return false;
    if (!blankValidation("mobile","TextField", "Mobile Number  can not be left blank"))
      return false;
    if (!blankValidation("address","TextField", "Address  can not be left blank"))
      return false;
   
   }

  
</script>

@endpush
@endsection