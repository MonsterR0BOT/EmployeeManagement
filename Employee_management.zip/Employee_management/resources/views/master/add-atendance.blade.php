@extends('layout.master')
@section('title', 'Applay Attendance')
@section('content')

@php
$userId=Session::get("userId");
$data=(isset($data)) ? $data : array();
@endphp
  <!-- Content Wrapper. Contains page content --> 
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Applay Attendance</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Applay Attendance</li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">
      <!-- Default box -->
      <div class="box">
       <!-- <div class="box-header">
          <h3 class="box-title">Quick Example</h3>
        </div>-->
        <!-- /.box-header -->
        <!-- form start -->
        <form role="form" enctype="multipart/form-data" method="post" action="{{ url('team/addAttendance')}}"  onsubmit="return validateForm()" autocomplete="off">
          @csrf
          <div class="box-body">
            <div class="row">
                <div class="col-md-6">
                <?php 
               // print "<pre>"; print_r($data);exit;
                ?>
                  @php
                    if(!empty($data)){
                      
                        $TEA_intime = $data[0]->TEA_intime;
                        $TEA_outtime = $data[0]->TEA_outtime;
                        
                        
                    }else{
                       
                        $TEA_intime = '';
                        $TEA_outtime = '';
                    }
                    
                    @endphp

                   <h3>{{date("D/d/M/Y") }} </h3> <br>
                  
                    <div class="form-group">
                      <button type="button" <?php if($TEA_intime!=''){echo 'disabled';} ?> onclick="addinTime();" class="btn btn-success">Present IN</button>
                    </div>
                    <label for="exampleInputEmail1">IN TIME</label>
                    <input type="text" readonly  name="inTime" id="inTime" value="{{$TEA_intime}}">

                    <div class="form-group">
                      <button type="button" <?php if($TEA_outtime!=''){echo 'disabled';} ?> onclick="addOutTime();" class="btn btn-danger">Present OUT</button>
                    </div>
                    <label for="exampleInputEmail1">OUT TIME</label>
                    <input type="text" readonly  name="outTime" id="outTime" value="{{$TEA_outtime}}">                    

                </div>
                
            </div>
          </div>

        </form>
      </div>
      <!-- /.box -->
      
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
@push('scripts') 
<script type="text/javascript">
   function validateForm(){  
 
   }

 function addOutTime(){
  swal.fire({
           title: "Do you want to Out Attendance?",
           text: "",
           type: "warning",
           showCancelButton: true,
           confirmButtonColor: '#d33',
           cancelButtonColor: '#e7b63a',
           confirmButtonText: 'Submit',

           reverseButtons : true
           
         }).then((result) => {
           if(result.value){

                       swal({
                         title: "Record submitted successfully.",
                         type: "success"
                       }).then(function(){
                          window.location.href="{{url('Team/outAttendance')}}";
                       })

           }
           
         }); 
     }

     function addinTime(){
       swal.fire({
           title: "Do you want to Start Attendance?",
           text: "",
           type: "warning",
           showCancelButton: true,
           confirmButtonColor: '#d33',
           cancelButtonColor: '#e7b63a',
           confirmButtonText: 'Submit',

           reverseButtons : true
           
         }).then((result) => {
           if(result.value){

                       swal({
                         title: "Record submitted successfully.",
                         type: "success"
                       }).then(function(){
                          window.location.href="{{url('Team/addAttendance')}}";
                       })

           }
           
         });
     }    
</script>


@endpush
@endsection