@extends('layout.master')
@section('title', 'PASSWORD')
@section('content')
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Password Policy</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Set Password Policy</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      
      <!-- Default box -->
      <div class="box"> 
        <!-- form start -->
        
        <form role="form" method="post" action="{{ url('email/savePassPolicy')}}"  onsubmit="return validateForm()" autocomplete="off">
          @csrf
              <div class="box-body">
                 @if (Session::has('errors'))
                    <div class="col-md-12 alert alert-warning">
                        @foreach ($errors->all() as $error)
                            {{ $error }}<br/>
                        @endforeach
                    </div>
                @endif

                @if (session()->exists('success'))
                    <div  class="col-md-12 alert alert-success">Password policy Updated Successfully.</div>
                @endif
                <div class="col-md-6">
                <div class="row">
                  <div class="col-md-12">
                   
                    <div class="row">

                       <?php //print "<pre>"; print_r($data);exit;?>
                        @php
                          if(!empty($data)){
                              $passId = $data[0]->TPPM_Password;
                              $TPPM_Password_Length = $data[0]->TPPM_Password_Length;
                              $TPPM_Password_IsUppercase = $data[0]->TPPM_Password_IsUppercase;
                              $TPPM_Password_IsLowercase = $data[0]->TPPM_Password_IsLowercase;
                              $TPPM_Password_IsNumber = $data[0]->TPPM_Password_IsNumber;
                              $TPPM_Password_IsSpecialChars = $data[0]->TPPM_Password_IsSpecialChars;
                              $TPPM_Password_Encryption = $data[0]->TPPM_Password_Encryption;
                              $TPPM_Password_Reuse = $data[0]->TPPM_Password_Reuse;
                              $TPPM_Password_Validity = $data[0]->TPPM_Password_Validity; 
                              
                          }else{
                             $passId = '';
                              $TPPM_Password_Length = '';
                              $TPPM_Password_IsUppercase = '';
                              $TPPM_Password_IsLowercase = '';
                              $TPPM_Password_IsNumber = '';
                              $TPPM_Password_IsSpecialChars = '';
                              $TPPM_Password_Encryption = '';
                              $TPPM_Password_Reuse = '';
                              $TPPM_Password_Validity = '';                           }
                          @endphp
                     <div class="col-md-6">
                       <label for="exampleInputEmail1">Password Length</label>
                       <span class="text-danger">*</span>
                     </div>
                     <div class="col-md-6">
                        <div class="form-group">
                           <input type="text" class="form-control" name="passLength" id="passLength" value="{{$TPPM_Password_Length}}">
                        </div>
                        <!-- <span class="text-danger">{{ $errors->first('passLength') }}</span> -->
                     </div> 
                   </div>
                  </div>
                   <div class="col-md-12">
                    <div class="row">
                     <div class="col-md-6">
                       <label for="exampleInputEmail1">Is UpperCase Required</label>
                     </div>
                     <div class="col-md-6">
                        <div class="form-group">
                            <div class="row">
                             <div class="col-md-6">
                               <input type="radio" name="IsUp" value="1" {{ ($TPPM_Password_IsUppercase=="1")? "checked" : "" }} >

                                 Yes
                             </div>
                             <div class="col-md-6">
                                <input type="radio" name="IsUp" value="0" {{ ($TPPM_Password_IsUppercase=="0")? "checked" : "" }} >
                                  No
                             </div>
                           </div>
                        </div>
                     </div> 
   
                   </div>
                  </div>
                  <div class="col-md-12">
                    <div class="row">
                     <div class="col-md-6">
                       <label for="exampleInputEmail1">Is LowerCase Required</label>
                     </div>
                     <div class="col-md-6">
                        <div class="form-group">
                            <div class="row">
                             <div class="col-md-6">
                                <input type="radio" name="IsLow" value="1" {{ ($TPPM_Password_IsLowercase=="1")? "checked" : "" }} >
                                 Yes
                             </div>
                             <div class="col-md-6">
                                <input type="radio" name="IsLow" value="0" {{ ($TPPM_Password_IsLowercase=="0")? "checked" : "" }} >
                                  No
                             </div>
                           </div>
                        </div>
                     </div> 
                   </div>
                  </div>
                  <div class="col-md-12">
                    <div class="row">
                     <div class="col-md-6">
                       <label for="exampleInputEmail1">Is Special Chars Required</label>
                     </div>
                     <div class="col-md-6">
                        <div class="form-group">
                            <div class="row">
                             <div class="col-md-6">
                                <input type="radio" name="IsSpec" value="1" {{ ($TPPM_Password_IsSpecialChars=="1")? "checked" : "" }} >
                                 Yes
                             </div>
                             <div class="col-md-6">
                                <input type="radio" name="IsSpec" value="0" {{ ($TPPM_Password_IsSpecialChars=="0")? "checked" : "" }} >
                                  No
                             </div>
                           </div>
                        </div>
                     </div> 
                   </div>
                  </div>
                  <div class="col-md-12">
                    <div class="row">
                     <div class="col-md-6">
                       <label for="exampleInputEmail1">Is Number Required</label>
                     </div>
                     <div class="col-md-6">
                        <div class="form-group">
                            <div class="row">
                             <div class="col-md-6">
                                <input type="radio" name="IsNum" value="1" {{ ($TPPM_Password_IsNumber=="1")? "checked" : "" }} >
                                 Yes
                             </div>
                             <div class="col-md-6">
                                <input type="radio" name="IsNum" value="0" {{ ($TPPM_Password_IsNumber=="0")? "checked" : "" }} >
                                  No
                             </div>
                           </div>
                        </div>
                     </div>
                     </div> 
                  </div>
                  <div class="col-md-12">
                    <div class="row">
                     <div class="col-md-6">
                       <label for="exampleInputEmail1">Encryption Method</label>
                       <span class="text-danger">*</span>
                     </div>
                     <div class="col-md-6">
                        <div class="form-group">
                           <select class="form-control" name="encrypMethod" id="encrypMethod">
                              <option value="">--Select--</option>
                              <option value="Hash" @if($TPPM_Password_Encryption == "Hash") selected="selected" @endif >Hash</option>
                              <option value="Blowfish" @if($TPPM_Password_Encryption == "Blowfish") selected="selected" @endif>Blowfish</option>
                              <option value="md5" @if($TPPM_Password_Encryption == "md5") selected="selected" @endif>MD5</option>
                           </select>
                          <!--  <span class="text-danger">{{ $errors->first('encrypMethod') }}</span> -->
                        </div>
                     </div>
                     </div> 
                  </div>
                   <div class="col-md-12">
                    <div class="row">
                     <div class="col-md-6">
                       <label for="exampleInputEmail1">Password Validity</label>
                       <span class="text-danger">*</span>
                     </div>
                     <div class="col-md-6">
                        <div class="form-group">
                           <input type="text" class="form-control" name="passValidity" id="passValidity" value="{{$TPPM_Password_Validity}}">
                        </div>
                         <!-- <span class="text-danger">{{ $errors->first('passValidity') }}</span> -->
                     </div> 
                   </div>
                  </div>

                  <div class="col-md-12">
                    <div class="row">
                     <div class="col-md-6">
                       <label for="exampleInputEmail1">Password Reuse</label>
                       <span class="text-danger">*</span>
                     </div>
                     <div class="col-md-6">
                        <div class="form-group">
                           <input type="text" class="form-control" name="passReuse" id="passReuse" value="{{$TPPM_Password_Reuse}}">
                        </div>
                        <!--  <span class="text-danger">{{ $errors->first('passReuse') }}</span> -->
                     </div> 
                   </div>
                  </div>

                     <div class="col-md-12">
                        <a href="{{url('dashboard')}}" class="btn btn-danger">Cancel</a>
                        <button class="btn btn-primary">Update</button> 
                     </div>
                  </div>
                </div>
             </div>
        </form>
      </div>
      <!-- /.box -->
      
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
@push('scripts') 
<script type="text/javascript">
   function validateForm(){
    //alert("alert");return false;
    
    if (!blankValidation("passLength","TextField", "Password length can not be left blank"))
      return false;

    if (!blankValidation("encrypMethod","SelectBox", "Please select encryption Method"))
      return false;
    if (!blankValidation("passValidity","TextField", "Password validity can not be left blank"))
      return false;
    if (!blankValidation("passReuse","TextField", "Password reused can not be left blank"))
      return false; 
     
   }  

</script>  
@endpush
@endsection