@extends('layout.master')
@section('title', 'USER TYPE')
@section('content')
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Add User Type</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">User</a></li>
        <li class="active">Add User Type</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
    	
      <!-- Default box -->
      <div class="box">
       <!-- <div class="box-header">
          <h3 class="box-title">Quick Example</h3>
        </div>-->
        <!-- /.box-header -->
        <!-- form start -->
        <form role="form" method="post" action="{{ url('post-user-type')}}"  onsubmit="return validateForm()" autocomplete="off">
        	@csrf
          <div class="box-body">
            <div class="row">
                <div class="col-md-6">
                	@php
                    if(!empty($data)){
                    	$userTypeId = $data[0]->TUT_UserType;
                        $TUT_UserTypeName  = $data[0]->TUT_UserTypeName ;
                        $TUT_UserType_Descrptn = $data[0]->TUT_UserType_Descrptn;
                        $TUT_UserType_Active = $data[0]->TUT_UserType_Active;
                    }else{
                    	$userTypeId = '';
                        $TUT_UserTypeName  = '';
                        $TUT_UserType_Descrptn = '';
                        $TUT_UserType_Active = 1;
                    }
                    @endphp
                    <div class="form-group">
                      <label for="exampleInputEmail1">Name</label>
                      <input type="text" class="form-control" name="userTypeName" id="userTypeName" value="{{$TUT_UserTypeName}}">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Description</label>
                      <textarea class="form-control" name="userTypeDescription" id="userTypeDescription">{{$TUT_UserType_Descrptn}}</textarea>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputFile">Status</label>
                      <select class="form-control" name="userTypeActive" id="userTypeActive">
                      	<option value="">--Select--</option>
                        <option value="1" @if($TUT_UserType_Active ==1) selected="selected" @endif>Active</option>
                        <option value="0" @if($TUT_UserType_Active ==0) selected="selected" @endif>Inactive</option>
                      </select>
                    </div>
                </div>
            </div>
          </div>
          <!-- /.box-body -->
          <div class="box-footer">
          	<input type="hidden" name="hidUserType" value="{{$userTypeId}}"/>
            <button type="submit" class="btn btn-primary">Submit</button>
            <button type="button" class="btn btn-warning" onclick="window.location.href='manage-user-type'">Cancel</button>
          </div>
        </form>
      </div>
      <!-- /.box -->
      
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  @push('scripts') 
	<script type="text/javascript">
         function validateForm(){
            //alert("alert");return false;
          if (!blankValidation("userTypeName","TextField", "User Type Name can not be left blank"))
              return false;
          if (!blankValidation("userTypeDescription","TextArea", "Description can not be left blank"))
              return false;
          if (!blankValidation("userTypeActive","TextField", "Status  can not be left blank"))
              return false;
         }  
    
    </script>  
    @endpush
@endsection