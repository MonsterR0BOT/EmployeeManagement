@extends('layout.master')
@section('title', 'CHANGE PASSWORD')
@section('content')
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Change Password</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Dashboard</a></li>
        <li class="active">Change Password</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      
      <!-- Default box -->
      <div class="box">
        @if (Session::has('errors'))
          <div class="col-md-12 alert alert-warning">
              @foreach ($errors->all() as $error)
                  {{ $error }}<br/>
              @endforeach
          </div>
        @endif
       @if (Session::has('warning'))
         <div class="alert alert-warning">                        
             <i class="fa fa-check"></i> {{ Session::get('warning') }} 
         </div>
         @endif
         @if (Session::has('message'))
           <div class="alert alert-warning">
              <h5>{{ Session::get('message') }}</h5>
           </div>
           <div class="alert alert-warning">
              <h5>Your password must be have at least</h5>
              <div>
                 <p>
                    -Password should be minimum of 6 characters and maximum 16 charaters.<br>
                    -must have at least one uppercase ,one lowercase one numeric and one special character.<br>
                    -special characters  allowed ! @$ # & * ().<br>
                    -password should not contain you first name.<br>
                    -password should not start with a special character.
                 </p>
              </div>
           </div>
           @endif
       <!-- <div class="box-header">
          <h3 class="box-title">Quick Example</h3>
        </div>-->
        <!-- /.box-header -->
        <!-- form start -->
        <form role="form" action="{{url('modify-password')}}" method="post" autocomplete="off" onsubmit="return validateForm();">
        {{csrf_field()}}
          <div class="box-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                      <label for="newPassword">Old Password</label>
                      <input type="password" class="form-control" name="oldPassword" id="oldPassword" value="" >
                    </div>
                     <div class="form-group">
                      <label for="newPassword">New Password</label>
                      <input type="password" class="form-control" name="newPassword" id="newPassword" value="" >
                    </div>
                    <div class="form-group">
                      <label for="confirmPassword">Confirm Password</label>
                      <input type="password" class="form-control" name="confirmPassword" id="confirmPassword" value="" >
                    </div>
                    
                </div>
            </div>
          </div>
          <!-- /.box-body -->
          <div class="box-footer">
            <button type="submit" class="btn btn-primary">Submit</button>
            <a href="{{ url('dashboard') }}"><button type="button" class="btn btn-warning" >Cancel</button></a>
          </div>
        </form>
      </div>
      <!-- /.box -->
      
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
@push('scripts') 
<script type="text/javascript">
  function validateForm(){ //alert("here"); return false;
      if (!blankValidation("oldPassword", "TextField","Enter old password"))
        return false;
      if (!blankValidation("newPassword", "TextField","Enter new password"))
        return false;
      if (!blankValidation("confirmPassword", "TextField","Enter confirm password"))
        return false;

      if($('#newPassword').val() != $('#confirmPassword').val()){
        swal("Sorry !! Password mismatch");
        return false;
      }      
  }

</script>  
@endpush
@endsection