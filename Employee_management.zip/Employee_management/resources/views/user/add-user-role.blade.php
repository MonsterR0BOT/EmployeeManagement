@extends('layout.master')
@section('title', 'USER ROLE')
@section('content')
 @push('styles')
 	<style type="text/css">
     /*admin tree structure menu css starts*/
    
    .treev, .treev ul {
        margin:0;
        padding:0;
        list-style:none
    }
    .treev ul {
        margin-left:1em;
        position:relative
    }
    .treev ul ul {
        margin-left:.5em
    }
    .treev ul:before {
        content:"";
        display:block;
        width:0;
        position:absolute;
        top:0;
        bottom:0;
        left:0;
        border-left:1px solid
    }
    .treev li {
        margin:0;
        padding:0 1em;
        line-height:2em;
        color:#4270af;
        font-weight:700;
        position:relative
    }
    .treev ul li:before {
        content:"";
        display:block;
        width:10px;
        height:0;
        border-top:1px solid;
        margin-top:-1px;
        position:absolute;
        top:1em;
        left:0
    }
    .treev ul li:last-child:before {
        background:#fff;
        height:auto;
        top:1em;
        bottom:0
    }
    .indicator {
        margin-right:5px;
    }
    .treev li a {
        text-decoration: none;
        color:#4270af;
    }
    .treev li button, .treev li button:active, .treev li button:focus {
        text-decoration: none;
        color:#4270af;
        border:none;
        background:transparent;
        margin:0px 0px 0px 0px;
        padding:0px 0px 0px 0px;
        outline: 0;
    }
    /*admin  tree structure menu css end*/
	</style>
 @endpush
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Add User Role</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">User</a></li>
        <li class="active">Add User Role</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
    	
      <!-- Default box -->
      <div class="box">
       <!-- <div class="box-header">
          <h3 class="box-title">Quick Example</h3>
        </div>-->
        <!-- /.box-header -->
        <!-- form start -->
        <form role="form" autocomplete="off">
        	@csrf
          <div class="box-body">
            <div class="row">
                <div class="col-md-6">
                	@php
                    if(!empty($data)){
                    	$userRoleId = $data[0]->TURM_UserRole;
                        $TURM_URole_Name = $data[0]->TURM_URole_Name;
                        $TURM_CostCenter = $data[0]->TURM_CostCenter;
                        $TURM_URole_Description = $data[0]->TURM_URole_Description;
                        $TURM_ParentUserRole = $data[0]->TURM_ParentUserRole;
                        $TURM_URole_Status = $data[0]->TURM_URole_Status;
                        
                    }else{
                    	$userRoleId = '';
                        $TURM_URole_Name = '';
                        $TURM_CostCenter = '';
                        $TURM_URole_Description = '';
                        $TURM_ParentUserRole = '';
                        $TURM_URole_Status = 1;
                    }
                    @endphp
                    <div class="form-group">
                      <label for="exampleInputEmail1">User Role Name</label>
                      <input type="text" class="form-control" name="userRoleName" id="userRoleName" value="{{$TURM_URole_Name}}">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Parent User Role</label>
                       <select class="form-control" name="userParentUserRole" id="userParentUserRole" >
                      	<option value="">--Select--</option>
                        @foreach($parent_role_list as $val)
                        <option value="{{$val->TURM_UserRole}}" @if($TURM_ParentUserRole == $val->TURM_UserRole) selected="selected" @endif >{{$val->TURM_URole_Name}}</option>
                        @endforeach
                      </select>
                    </div>
                   
                    <div class="form-group">
                      <label for="exampleInputFile">Status</label>
                       <select class="form-control" name="userRoleStatus" id="userRoleStatus">
                      	<option value="">--Select--</option>
                        <option value="1" @if($TURM_URole_Status ==1) selected="selected" @endif>Active</option>
                        <option value="0" @if($TURM_URole_Status ==0) selected="selected" @endif>Inactive</option>
                      </select>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Description</label>
                      <textarea class="form-control" name="userDescription" id="userDescription">{{$TURM_URole_Description}}</textarea>
                    </div>
                    
                </div>
                
                <div class="col-md-6">
                    <div class="form-group">
                     <label>Module</label>
                     <div class="col-md-12">
                        <ul id="tree1" >
                         @foreach($module_list as $module)
                            @php($keys = array_search($module->TMM_Module, array_column($module_chk_list, 'TMM_Module')))
                           <li>
                              <input type="checkbox"  class="pc-box" style="width: 16px;" {{($keys !== false) ? 'checked="checked" ' : '' }} >
                              <a id ="{{$module->TMM_Module}}"> {{$module->TMM_Modl_Name}}</a>
                              <ul>
                               @foreach($function_list as $function)
                               	@if($function->parentIdForFunction == $module->TMM_Module)
                                	@php($funs = array_search($function->TFM_Function, array_column($function_chk_list, 'TFM_Function')))
                                 <li>
                                    <input type="checkbox" class="pc1-box" style="width: 16px;" {{($funs !== false) ? 'checked="checked" ' : '' }} >
                                   
                                    <a id ="{{$function->TFM_Function}}">{{$function->functionName}}</a>
                                    <ul class="treeActivity">
                                    @foreach($activity_list as $activity)
                               			@if($activity->parentIdForActitvity == $function->TFM_Function)
                                        	@php($funs = array_search($activity->activityId, array_column($activity_chk_list, 'TAM_Activity')))
                                       <li>
                                          <input type="checkbox"  class="activityCls" data-functionId="{{$function->TFM_Function}}" data-moduleId="{{$module->TMM_Module}}" data-activityId="{{$activity->activityId}}"value="{{$activity->activityId}}"  style="width: 16px;" {{($funs !== false) ? 'checked="checked" ' : '' }} >
                                          <a id ="{{$activity->activityId}}">{{$activity->activityName}}</a>
                                       </li>
                                        @endif
                                	@endforeach <!--Function loop end--> 
                                    </ul>
                                 </li>
                                 @endif
                                @endforeach <!--Function loop end--> 
                              </ul>
                           </li>
                          @endforeach <!--Module loop end--> 
                        </ul>
                     </div>
                  </div>
                    
                </div>
                
            </div>
          </div>
          <!-- /.box-body -->
          <div class="box-footer">
          	<input type="hidden" name="userRoleId" id="userRoleId" value="{{$userRoleId}}"/>
            <button type="button" class="btn btn-primary" id="sbmtdata">Submit</button>
            <a href="{{url('UserRole/viewAllUserRole')}}"><button type="button" class="btn btn-warning" >Cancel</button></a>
          </div>
        </form>
      </div>
      <!-- /.box -->
      
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
   @push('scripts')
   <script>
         function validateForm(){
         	    if (!blankValidation("userRoleName","TextField", "User role name can not be left blank"))
                 	return false;
         	    if (!blankValidation("userParentUserRole","SelectBox", "Please select parent role"))
                     return false;
                // if (!blankValidation("userCostCenter","SelectBox", "Please Select Cost Center"))
                //      return false;
           
             	if (!blankValidation("userRoleStatus","SelectBox", "Please select status"))
                     return false;
                if (!blankValidation("userDescription","TextField", "Discription can not be blank!."))
                     return false;
            	var checkedActivity = false;
                $(".activityCls:checkbox:checked").each(function () {
					checkedActivity = true;
					return false;
             	});
             	if(!checkedActivity){
					swal("Please check at least one activity of a module");
					return false;
             	}
             return true;
         }
     
         $(function() {
         	//For tree structure of Module,Function and Activity Tree structure
         $.fn.extend({
                treed: function(o) {
         
                    var openedClass = 'fa-minus-circle';
                    var closedClass = 'fa-plus-circle';
         
                    if (typeof o != 'undefined') {
                        if (typeof o.openedClass != 'undefined') {
                            openedClass = o.openedClass;
                        }
                        if (typeof o.closedClass != 'undefined') {
                            closedClass = o.closedClass;
                        }
                    };
         
                    //initialize each of the top levels
                    var tree = $(this);
                    tree.addClass("treev");
                    tree.find('li').has("ul").each(function() {
                        var branch = $(this); //li with children ul
                        branch.prepend("<i class='indicator fa " + closedClass + "'></i>");
                        branch.addClass('branch');
                        branch.on('click', function(e) {
                            if (this == e.target) {
                                var icon = $(this).children('i:first');
                                icon.toggleClass(openedClass + " " + closedClass);
                                $(this).children().children().toggle();
                            }
                        })
                        branch.children().children().toggle();
                    });
                    //fire event from the dynamically added icon
                    tree.find('.branch .indicator').each(function() {
                        $(this).on('click', function() {
                            $(this).closest('li').click();
                        });
                    });
                    //fire event to open branch if the li contains an anchor instead of text
                    tree.find('.branch>a').each(function() {
                        $(this).on('click', function(e) {
                            $(this).closest('li').click();
                            e.preventDefault();
                        });
                    });
                    //fire event to open branch if the li contains a button instead of text
                    tree.find('.branch>button').each(function() {
                        $(this).on('click', function(e) {
                            $(this).closest('li').click();
                            e.preventDefault();
                        });
                    });
                }
            });
         
            //Initialization of treeviews
         
            $('#tree1').treed();
            $('#tree2').treed();
            //$('#tree2').treed({openedClass:'glyphicon-folder-open', closedClass:'glyphicon-folder-close'});
         
            $('#tree3').treed({ openedClass: 'glyphicon-chevron-right', closedClass: 'glyphicon-chevron-down' });
         
            //End of Tree structure
         })    
         
            
             $(document).ready(function() {        
                $(".pc-box").click(function() {
                    if (this.checked) {
                    	$(this).closest("li").find(".pc-box").prop("checked", true);
                    	$(this).closest("li").find(".pc1-box").prop("checked", true);
                        $(this).closest("li").find(".activityCls").prop("checked", true);
                        $(this).parent();
                    }  
                });
                $(".pc-box").click(function() {
                    if (!this.checked) {
                    	$(this).closest("li").find(".pc1-box").prop("checked", false);
                        $(this).closest("li").find(".activityCls").prop("checked", false);
                        $(this).parent();
                    }  
                });
                $(".pc1-box").click(function() {
                    if (this.checked) {
                    	$(this).closest("li").find(".pc1-box").prop("checked", true);
                        $(this).closest("li").find(".activityCls").prop("checked", true);
                        $(this).parent();
                    }  
                });
                $(".pc1-box").click(function() {
                    if (!this.checked) {
                        $(this).closest("li").find(".activityCls").prop("checked", false);
                        $(this).parent();
                    }  
                });
                
                $(".activityCls").click(function() {
                    if (!this.checked)
                        $(this).closest("ul").prev().find(".pc-box").prop("checked", false);
                });
            });
         	
         	
         	/*$(function () {
         		 var hiddendata=$("#userRoleId").val();
         		 if(hiddendata != ""){
         			  if(!window.location.hash) {
         			        //setting window location
         			        window.location = window.location + '#valid';
         			        //using reload() method to reload web page
         			        window.location.reload();
         			        
         			    }     
         		   }	 
         	 });*/
         	 
         
         		 
         	 $(function () {	
         	//submit button function
         		const ipAPI = 'https://api.ipify.org?format=json';
         		$("#sbmtdata").click(function(){
                    if(validateForm()){
             			var dataset = [];
             			$(".activityCls:checkbox:checked").each(function () {
             				
             				item = {};
             				item['userRoleId']= $("#userRoleId").val();
             				item['userRoleName']= $("#userRoleName").val();
             				item['userRoleStatus']= $("#userRoleStatus").val();
             				item['userDescription']= $("#userDescription").val();
             				item['userParentUserRole']= $("#userParentUserRole").val();
             				item['userCostCenter']= $("#userCostCenter").val();
             				 
             				
             				item['moduleId']	=	$(this).attr("data-moduleId");
             				item['functionId']	=	$(this).attr("data-functionId");
             				item['activityId']	=	$(this).attr("data-activityId");
             				
             				
             				dataset.push(item);
             			});//table tbody tr loop ends
             			console.log(dataset);
             			submitUserRole(dataset);	
         			}else{
                        return false;
                    }
         			 
         		})
         		function submitUserRole(dataset){
					$.ajaxSetup({
						headers: {
							'X-CSRF-TOKEN': '{{csrf_token()}}'
						}
					});
         			//alert(dataset);return false;
         			swal.fire({
         				title				: "Are you sure want to Submit?",
         				text				: "Once Submited,Can't revert back !",
         				type 				: "warning",
         				
         				showCancelButton	: true,
         				confirmButtonColor	: "#DD6BB5",
         				confirmButtonText	:"Submit",
         				showLoaderOnConfirm	: true,
         				preConfirm: () => {
							return new Promise((resolve) => {
								setTimeout(() => {
									console.log("Doing async operation");
									resolve()
								}, 3000)
							})
						},
         				reverseButtons : true,
         				confirmButtonAriaLabel : 'Thumbs up, great!',
         				cancelButtonText : 'Cancel',
         				cancelButtonAriaLabel : 'Thumbs down',
         				
         				 preConfirm: () => {
         				    return fetch(ipAPI)
         				      .then(response => response.json())
         				      .then(data => Swal.insertQueueStep(data.ip))
         				      .catch(() => {
         				        Swal.insertQueueStep({
         				          type: 'error',
         				          title: 'Unable to get your public IP'
         				,        })
         				      })
         				 }   
         			}).then((result) => {
         				if(result.value){
         					$.ajax({
         					type		: "POST",
         					url 		: "{{ url('UserRole/AddUserRole')}}",
         					dataType	: "json",
         					//contentType	: "application/json",
         					data		: JSON.stringify(dataset),
         					success		: function(response){
         						console.log(response);
         						if(response.message=="success"){
         							swal({
         									title:"Data Saved Successfully.",
         									type: "success",
         							}).then(function(){
         								window.location.href="{{url('UserRole/viewAllUserRole')}}";
         							})
         						}else{
         							//$("#errorMsg").html(response.message);
         							swal({
         								title:response.code,
         								text: response.message,
         								type:"warning"
         							})
         						}
         					},error	: function(response){
         						swal(response.code);	
         					}
         				}) //ajax ends
         			}
         			})//swal function block ends
         		}//submit function ends
         	});
         
      </script> 
   @endpush
@endsection