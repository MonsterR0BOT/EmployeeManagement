@extends('layout.master')
@section('title', 'DASHBOARD')
@section('content')
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        User Profile
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">User</a></li>
        <li class="active">User profile</li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <?php //print "<pre>"; print_r($data);exit;?>
        @php
          if(!empty($data)){
            $userId = $data[0]->TUM_User;
              $TUM_User_Name = $data[0]->TUM_User_Name;
              $TUM_User_Lname = $data[0]->TUM_User_Lname;
              $TUM_User_Mobile = $data[0]->TUM_User_Mobile;
              $TUM_User_Email = $data[0]->TUM_User_Email;
              $TUM_User_Desig = $data[0]->TUM_User_Desig;
              $TUM_User_Dept = $data[0]->TUM_User_Dept;
              $TUM_User_Status = $data[0]->TUM_User_Status;
              $TUM_User_Image = $data[0]->TUM_User_Image;
              $TUM_User_AltEmail = $data[0]->TUM_User_AltEmail;
              $TUM_User_AltMobile = $data[0]->TUM_User_AltMobile;
              $TURA_UserRole = $data[0]->TURA_UserRole;
              //$roleArr = explode(",",$TURA_UserRole);
              $TUM_User_CreatedOn = $data[0]->TUM_User_CreatedOn;
              
          }else{
             $userId = '';
              $TUM_User_Name = '';
              $TUM_User_Lname = '';
              $TUM_User_Mobile = '';
              $TUM_User_Email = '';
              $TUM_User_Desig = '';
              $TUM_User_Dept = '';
              $TUM_User_Status = 1;
              $TUM_User_Image = '';
              $TUM_User_AltEmail = '';
              $TUM_User_AltMobile = '';
              $TURA_UserRole = '';
              //$roleArr = array();
              $TUM_User_CreatedOn ='';
          }
          @endphp
          @php( $profileOrgImg = ($TUM_User_Image !='')? 'storage/'.$TUM_User_Image : 'dist/img/user2-160x160.jpg' )
        <div class="col-md-3">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body box-profile">
              <img class="profile-user-img img-responsive img-circle" src="{{ asset($profileOrgImg)}}" alt="User profile picture" id="userProfilePhoto">

              <h3 class="profile-username text-center">{{$TUM_User_Name.' '.$TUM_User_Lname}}</h3>

           

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b>Status</b> <a class="pull-right">{{($TUM_User_Status==1)?'Active':'Inactive'}}</a>
                </li>
              
                <li class="list-group-item">
                  <b>Role</b> <a class="pull-right">{{$TURA_UserRole}}</a>
                </li>
                <li class="list-group-item">
                  <b>Created On</b> <a class="pull-right">{{($TUM_User_CreatedOn !='')? date('d M Y h:i:s', strtotime($TUM_User_CreatedOn)):''}}</a>
                </li>
              </ul>
               <label for="profileimage" class="btn btn-primary btn-block">
                <i class="fa fa-upload"></i> Change Profile Photo
               </label>
               <input type="file" name="profileimage" id="profileimage" style="display:none;" onchange="saveUserProfileImage('{{$TUM_User_Image}}')">
              
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
        <div class="col-md-9">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#settings" data-toggle="tab">Profile</a></li>
              <!-- <li><a href="#timeline" data-toggle="tab">Timeline</a></li>
              <li><a href="#settings" data-toggle="tab">Settings</a></li> -->
            </ul>
            <div class="tab-content">

              <div class="tab-pane active" id="settings">
                <form role="form" method="post" action="{{ url('post-user-profile')}}"  onsubmit="return validateForm()" autocomplete="off" enctype="multipart/form-data">
                @csrf
                <div class="box-body">
                    @if (session()->exists('success'))
                        <div class="col-md-12 alert alert-success">Profile updated successfully.</div>
                    @endif
                  @if (Session::has('errors'))
                      <div class="col-md-12 alert alert-warning">
                          @foreach ($errors->all() as $error)
                              {{ $error }}<br/>
                          @endforeach
                      </div>
                  @endif
                  <div class="row">
                      <div class="col-md-6">
                      
                          <div class="form-group">
                            <label for="exampleInputEmail1">First Name</label>
                            <input type="text" class="form-control" name="userName" id="userName" value="{{$TUM_User_Name}}">
                          </div>
                          
                          <div class="form-group">
                            <label for="exampleInputPassword1">Email</label>
                            <input type="text" class="form-control" name="userEmail" id="userEmail" value="{{$TUM_User_Email}}">
                          </div>
                          <div class="form-group">
                            <label for="exampleInputPassword1">Mobile Number</label>
                            <input  class="form-control" name="userMobile" id="userMobile" value="{{$TUM_User_Mobile}}" maxlength="10">
                          </div>
                      </div>
                      
                      <div class="col-md-6">
                          <div class="form-group">
                            <label for="exampleInputEmail1">Last Name</label>
                            <input type="text" class="form-control" name="userLastName" id="userLastName" value="{{$TUM_User_Lname}}">
                          </div>
                          <div class="form-group">
                            <label for="exampleInputPassword1">Alt Mobile Number</label>
                            <input  class="form-control" name="userAltMobile" id="userAltMobile" value="{{$TUM_User_AltMobile}}" maxlength="10">
                          </div>
                          <div class="form-group">
                            <label for="exampleInputPassword1">Alt Email</label>
                            <input  class="form-control" name="userAltEmail" id="userAltEmail" value="{{$TUM_User_AltEmail}}">
                          </div>
                         
                      </div>
                      
                  </div>
                </div>
                <!-- /.box-body -->
                <div class="box-footer">
                  <input type="hidden" name="hidUser" value="{{$userId}}"/>
                  <button type="submit" class="btn btn-primary">Submit</button>
                  <button type="button" class="btn btn-warning" onclick="window.location.href='dashboard'">Cancel</button>
                </div>
              </form>
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<!--For showing loading image on 28thJune2017 -->
@push('scripts') 
<script type="text/javascript">
   function validateForm(){
    //alert('hello');
      if (!blankValidation("userName","TextField", "First name can not be left blank"))
          return false;
      if (!blankValidation("userLastName","TextField", "Last name can not be left blank")) 
          return false; 
      if (!blankValidation("userEmail","TextField", "Email can not be left blank"))
          return false;
      if (!blankValidation("userMobile","TextField", "Mobile number can not be left blank")) 
          return false; 
      if (!blankValidation("userAltEmail","TextField", "Alternate email can not be left blank"))
          return false;
      if (!blankValidation("userAltMobile","TextField", "Alternate mobile can not be left blank")) 
          return false;     
      $('#editPForm').submit();
   } 
 
  function saveUserProfileImage(olduserphoto){ 
    //alert('here');
    $("#maskid").show();
    var URL = '{{url("post-user-profile-image")}}';
    var data = new FormData();
    /*jQuery.each(jQuery('#profile_image')[0].files, function(i, file) {
        data.append('imgfile', file);
    });*/
    data.append('imgfile', jQuery('#profileimage')[0].files[0]);
    //data.append('user_id', userid);
    data.append('old_userphoto', olduserphoto);
    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': '{{csrf_token()}}'
      }
    });
    $.ajax({
        type: 'POST',
        url: URL ,
        data:data,
        success: function(results) { //alert(results);return false;
            $("#maskid").hide();
            if(results =="0"){
                swal("Invalid image extension");
            }else if(results =="1"){
                swal("File size exceeds 3 MB");
            }else{
               // $("#userProfilePhoto").attr('src',url+'/public/storage/preview_images/'+results);
                $("#userProfilePhoto").attr('src','{{asset("storage")}}/'+results);
                swal("Profile image changed successfully");
            }
        },
        /*error: function (jqXHR, textStatus, errorThrown) { // What to do if we fail
            console.log(JSON.stringify(jqXHR));
            console.log("AJAX error: " + textStatus + ' : ' + errorThrown);
        },*/
        cache: false,
        contentType: false,
        processData: false
    }); // close
  }
 </script>
   @endpush
@endsection