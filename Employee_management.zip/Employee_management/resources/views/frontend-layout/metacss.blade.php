<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>@yield('title') || {{ Config::get('app.site_title') }}</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">-->
<link href="{{ asset('css/bootstrap.css')}}" rel="stylesheet">
<link href="{{ asset('css/style.css')}}" rel="stylesheet">
<link href="{{ asset('css/responsive.css')}}" rel="stylesheet">
<link href="{{ asset('css/jquery-ui.css')}}" rel="stylesheet">
<link href="{{ asset('css/jquery.bootstrap-touchspin.css')}}" rel="stylesheet">
<link href="{{ asset('css/jquery.fancybox.min.css')}}" rel="stylesheet">
<link href="{{ asset('css/owl.css')}}" rel="stylesheet">
<link href="{{ asset('css/jquery.mCustomScrollbar.min.css')}}" rel="stylesheet">
<link href="{{ asset('css/owl.css')}}" rel="stylesheet">
<link href="{{ asset('css/animate.css')}}" rel="stylesheet">
<link href="{{ asset('css/flaticon.css')}}" rel="stylesheet">
<link href="{{ asset('css/fontawesome-all.css')}}" rel="stylesheet">
<!-- <link href="css/font-awesome.min.css" rel="stylesheet"> -->
<link href="{{ asset('css/css.css')}}" rel="stylesheet">
<link href="{{ asset('css/css1.css')}}" rel="stylesheet">
<link href="{{ asset('css/color-switcher-design.css')}}" rel="stylesheet">
<link id="theme-color-file" href="{{ asset('css/default-theme.css')}}" rel="stylesheet">
<!-- Responsive -->
</head>