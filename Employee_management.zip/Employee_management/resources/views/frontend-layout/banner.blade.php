<?//php print_r($banner_list); exit;
?>
 <section class="banner-section">
        <div class="carousel-column">
            <div class="carousel-outer">
                <ul class="banner-carousel owl-carousel owl-theme">

                    <!-- Slide Item -->
                    @foreach($banner_list as $val)  
                     @php 
                        $filename = asset('banner_image/orig/'.$val->TBM_Banner_Image); 
                     @endphp
                    <li class="slide-item">
                    	<img src="{{$filename}}">
                        
                    </li>
                    @endforeach

                </ul>
                <ul class="thumbs-carousel owl-carousel owl-theme">
                    @foreach($banner_list as $val)  
                     @php 
                        $filename = asset('banner_image/orig/'.$val->TBM_Banner_Image); 
                     @endphp
                    <li class="thumb-box">
                        <figure><img src="{{$filename}}" alt=""></figure>
                    </li>

                   @endforeach
                </ul>
            </div>
        </div>

        <div class="social-links">
            <ul class="social-icon-three">
                 @foreach($social_list as $val)
                <li><a href="{{$val->TSM_Social_Link}}"><i class="{{$val->TSM_Social_Icon}}"></i></a></li>
                 @endforeach
            </ul>
        </div>
    </section>