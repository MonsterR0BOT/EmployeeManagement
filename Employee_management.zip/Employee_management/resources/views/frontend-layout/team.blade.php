 <?php //print_r($teamDetiles); exit;
?> <section class="team-section">
        <div class="auto-container">
            <div class="sec-title text-center">
                <h2>Expert Team Person</h2>
            </div>

            <div class="row clearfix">
                <!-- Team Block -->
            @foreach($teamDetiles as $val)  
            @php 
            $filename = asset('teamMember_image/orig/'.$val->TTM_TeamMember_Image); 
            @endphp
                <div class="team-block col-lg-3 col-md-6 col-sm-12">
                    <div class="inner-box">
                        <div class="image-box">
                            <div class="image"><a href="#"><img src="{{$filename}}" alt="" class="img-thumbnail"></a></div>
                            <ul class="social-links">
                                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fab fa-skype"></i></a></li>
                                <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                            </ul>
                        </div>
                        <div class="info-box">
                            <h3 class="name"><a href="team.html">{{$val->TTM_TeamMemberName}}</a></h3>
                            <span class="designation">{{$val->TTM_TeamMemberDesignation}}</span>
                        </div>
                    </div>
                </div>

             @endforeach

            </div>
        </div>
    </section>