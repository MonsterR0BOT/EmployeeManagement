@include('frontend-layout.metacss')
<body>
<div class="page-wrapper">
    <!-- Preloader -->
    <div class="preloader"></div>
    <!-- Main Header-->
    @include('frontend-layout.header')
    <!--End Main Header -->
    
    <!--Form Back Drop-->
    <div class="form-back-drop"></div>
    <!-- Hidden Bar -->
    @include('frontend-layout.sidebar')
    <!--End Hidden Bar -->

    @yield('content')

  
</div>

<!-- End Color Switcher -->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-arrow-up"></span></div>
<script src="{{ asset('js/jquery.js')}}"></script> 
<script src="{{ asset('js/popper.min.js')}}"></script>
<script src="{{ asset('js/bootstrap.min.js')}}"></script>
<script src="{{ asset('js/jquery.fancybox.js')}}"></script>
<script src="{{ asset('js/owl.js')}}"></script>
<script src="{{ asset('js/wow.js')}}"></script>
<script src="{{ asset('js/appear.js')}}"></script>
<script src="{{ asset('js/jquery.mCustomScrollbar.concat.min.js')}}"></script>
<script src="{{ asset('js/jquery-ui.js')}}"></script>
<script src="{{ asset('js/mixitup.js')}}"></script>
<script src="{{ asset('js/script.js')}}"></script>
<script src="{{ asset('js/appear.js')}}"></script>
<!-- Color Setting -->
<script src="{{ asset('js/color-settings.js')}}"></script>

<script src="{{ asset('js/sweetalert2.all.min.js') }}"></script>
<script src="{{ asset('js/validate.js') }}"></script> 
@stack('scripts')
</body>
</html>
