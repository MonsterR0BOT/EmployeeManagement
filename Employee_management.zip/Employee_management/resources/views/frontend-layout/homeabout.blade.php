 <?//php print_r($about_list); exit;
?>
 <section class="about-section">

        <div class="auto-container">
            @foreach($about_list as $val)  
            @php 
            $filename = asset('images/'.$val->TCM_Content_Image); 
            @endphp
            
            <div class="row">
                <!-- Image Column -->
                <div class="image-column col-lg-6 col-md-12 col-sm-12">
                    <div class="inner-column">
                        <div class="image-box">
                            <figure class="image wow fadeInLeft" data-wow-delay='600ms'><img src="{{$filename}}" alt=""></figure>
                        </div>
                    </div>
                </div>

                <!-- Content Column -->
                <div class="content-column col-lg-6 col-md-12 col-sm-12">
                    <div class="inner-column wow fadeInLeft">
                        <div class="content-box">
                            <!-- <div class="sec-title">
                                <h2 data-animation-child class="title-fill" data-animation="title-fill-anim" data-text="About Company"></h2>
                            </div> -->
                            
                            <h5>{{$val->TCM_Content_Name}}</h5>
                            <div class="text">{{$val->TCM_Content_Description}}</div>
                            <div class="link-box"><a href="#" class="theme-btn btn-style-three">Read More<i class="fa fa-chevron-right"></i></a></div>
                            
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </section>