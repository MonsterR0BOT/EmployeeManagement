@extends('frontend-layout.frontend-master')
@section('title', 'Employee Management')
@section('content')
     <!--Page Title-->
     <section class="page-title" style="background-image:url('../public/images/innerbanner.jpg');">
        <div class="auto-container">
            <div class="inner-container clearfix">
                <div class="title-box">
                    <h1>Login</h1>
                </div>
                <ul class="bread-crumb clearfix">
                    <li><a href="index.html"><span class="fas fa-home"></span> Home</a></li>
                    <li><span class="far fa-arrow-alt-circle-right"></span>Login</li>
                </ul>
            </div>
        </div>
    </section>
    <!--End Page Title-->    
<section id="" class="ls section_padding_top_40 columns_padding_30 bg-img">
  <div class="container">
      <div class="row">
          <div class="col-md-4 offset-md-4 login-bg" data-animation="fadeInUp" data-delay="600">
             @if (Session::has('errors'))
              <div class="col-md-12 alert alert-warning">
                  @foreach ($errors->all() as $error)
                      {{ $error }}<br/>
                  @endforeach
              </div>
            @endif
            @if (Session::has('message'))
            <div class="alert alert-warning">                        
                <i class="fa fa-check"></i> {{ Session::get('message') }} 
            </div>
            @endif
            <h2> Admin Login</h2>
              
            <form action="{{ url('post-login')}}" method="post" onSubmit="return validateForm()" autocomplete="off"> 
              @csrf
              <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
              </div>
              <div class="form-group">
                <label for="pwd">Password:</label>
                <input type="password" class="form-control" id="password" placeholder="Enter password" name="password">
              </div>

              <div class="row">
              <div class="col-md-4 col-md-offset-4">
              <button type="submit" class="btn btn-default" >Submit</button>
             </div>
            </div>
   </br>
           </from>

          </div>
        </div>
  </section> 

 @push('scripts')  
  <script>
     function validateForm(){ //alert("here"); return false;
         if (!blankValidation("email", "TextField","Email is required"))
           return false;
         if (!RemoveSQLCharacter("email"))
           return false;
         if (!checkEmailId("email","Invalid email id !!!"))
           return false;
         if (!blankValidation("password", "TextField","Password is required"))
           return false; 
        if (!blankValidation("captchCode", "TextField","Captcha code is required"))
           return false; 
     }
    
  </script>
  @endpush

 @push('scripts')
 <!-- Write down javascript here -->
 @endpush   
@endsection   