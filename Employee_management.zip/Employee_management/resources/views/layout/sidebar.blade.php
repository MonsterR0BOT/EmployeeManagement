<!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <?php 
      if(!Session::has("userRoles")){
        Session::put("userRoles",array());
      }
      // print "<pre>";
      // print_r(Session::get("userRoles"));
      // echo in_array('rol001', Session::get("userRoles"));
      // exit;
    ?>
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->

      <?php if(in_array('rol001', Session::get("userRoles"))) { ?>
            <div class="user-panel">
        <div class="pull-left image">
          <img src="{{ asset(Helper::getAdminPhoto())}}" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p>{{Helper::getUserType()}}</p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <?php } ?>
      <?php if(in_array('rol005', Session::get("userRoles"))) { ?>
        <div class="user-panel">
        <div class="pull-left image">
          <img src="{{ asset(Helper::getUserPhoto())}}" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p>{{Helper::getUserType()}}</p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <?php } ?>
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
       <!--  <li>
          <a href="{{url('dashboard')}}"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
        </li> -->
        <li class="treeview">
          <a href="#">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <?php if(in_array('rol003', Session::get("userRoles")) || in_array('rol001', Session::get("userRoles"))){ ?>
            <li><a href="{{ url('dashboard')}}"><i class="fa fa-circle-o"></i>Dashboard</a></li>
            <?php }?>
          </ul>
        </li>
         <?php if(in_array('rol001', Session::get("userRoles")) ){ ?>


        <li class="treeview">
          <a href="#">
            <i class="fa fa-table"></i> <span>Master</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">

            <li><a href="{{ url('team/viewAllTeam')}}"><i class="fa fa-circle-o"></i>Manage Team</a></li>
            <!-- <li><a href="{{ url('team/showAttendance')}}"><i class="fa fa-circle-o"></i>Attendance Report</a></li> -->
            

          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-user"></i> <span>Profile</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            
            <li><a href="{{ url('logout') }}"><i class="fa fa-circle-o"></i>Sign Out</a></li>
          </ul>
        </li>

        <?php } ?>

        <?php if(in_array('rol005', Session::get("userRoles")) ){ ?>


        <li class="treeview">
          <a href="#">
            <i class="fa fa-table"></i> <span>Master</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">

            <li><a href="{{ url('team/viewAtendance')}}"><i class="fa fa-circle-o"></i>Manage Attendance</a></li>
            <li><a href="{{ url('#')}}"><i class="fa fa-circle-o"></i>Apply Leave</a></li>
            

          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-user"></i> <span>Profile</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            
            <li><a href="{{ url('logoutuser') }}"><i class="fa fa-circle-o"></i>Sign Out</a></li>
          </ul>
        </li>

        <?php } ?>
   
       
        
       
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>
