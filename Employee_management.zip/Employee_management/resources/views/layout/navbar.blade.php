	<!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          
          <!-- User Account: style can be found in dropdown.less -->

          <?php if(in_array('rol005', Session::get("userRoles")) ){ ?>
                      <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="{{ asset(Helper::getUserPhoto())}}" class="user-image" alt="User Image">
              <span class="hidden-xs">{{Helper::getNewUserName()}}</span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="{{ asset(Helper::getUserPhoto())}}" class="img-circle" alt="User Image">

                <p>
                  {{Helper::getNewUserName()}} - {{Helper::getUserType()}}
                  <small>Registered since {{Helper::getUserRegDate()}}</small>
                </p>
              </li>
              <!-- Menu Body -->
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="#" class="btn btn-primary btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="{{ url('logoutuser') }}" class="btn btn-primary btn-flat">Sign Out</a>
                </div>
              </li>
            </ul>
          </li>

            <?php } else { ?>
                        <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="{{ asset(Helper::getAdminPhoto())}}" class="user-image" alt="User Image">
              <span class="hidden-xs">{{Helper::getUserName()}}</span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="{{ asset(Helper::getAdminPhoto())}}" class="img-circle" alt="User Image">

                <p>
                  {{Helper::getUserName()}} - {{Helper::getUserType()}}
                  <small>Registered since {{Helper::getUserRegDate()}}</small>
                </p>
              </li>
              <!-- Menu Body -->
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="#" class="btn btn-primary btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="{{ url('logout') }}" class="btn btn-primary btn-flat">Sign Out</a>
                </div>
              </li>
            </ul>
          </li>

            <?php } ?>
          <!-- Control Sidebar Toggle Button -->
          <li>
            <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
          </li>
        </ul>
      </div>

    </nav>
    

  