<?php

/* * ******************************************
  File Name	: DashboardController.php
  Description	: Controller file for Master
  Created By	: Subharam
  Created On	: 23-DEC-2019

  ======================================================================
  |Update History                                                      |
  ======================================================================
  |<Updated by>                 |<Updated On> |<Remarks>
  ----------------------------------------------------------------------
  |Name Goes Here               |23-DEC-2019  |Remark goes here
  ----------------------------------------------------------------------
  |                             |             |
  ----------------------------------------------------------------------

 * ****************************************** */

  
namespace App\Http\Controllers;
use App\Http\Controllers\AppController;
/*use Illuminate\Support\Facades\Storage; 
use App\Models\ProcessModel;
use App\Models\ApprovalActionModel;*/

use Illuminate\Support\Facades\Crypt;
use Illuminate\Contracts\Encryption\DecryptException;
use App\Helpers\Helper;
use DB;
use Session; 
use Redirect;
use Validator;
use Illuminate\Http\Request;
 
class MasterController extends AppController {

  public function setPageLabel($params) {
    $pageDetails = DB::select("CALL Get_Lang('getPageName','')");
    $data['page_list']=$pageDetails;

    return view('master.add-page-label-master',$data);
  }
  public function AddPageLabel($params) {
    $dataListArr=$this->request->all();
    $parmArray = array(
      'pageId' =>  $dataListArr[0]['pageName']

      );
    #################Server side validation##########################

    $valid=1;
     for($i=0; $i< count($dataListArr); $i++){
        if($dataListArr[$i]['pageName'] ==''){
          $valid=0;
          break;
        }
        if($dataListArr[$i]['levelSeq'] ==''){
          $valid=0;
          break;
        }
        if($dataListArr[$i]['language'] ==''){
          $valid=0;
          break;
        }
        if($dataListArr[$i]['pageLevel'] ==''){
          $valid=0;
          break;
        }
      }
      if($valid ==0){
         $data['message'] = "fail"; 
        return response()->json($data);
      }
    #################Server side validation##########################
    $insertparam = Helper::makeProcedureCall($parmArray);
    $str = "";
      for($i=0; $i< count($dataListArr); $i++){
        $str.="(\\\"".$dataListArr[$i]['pageName']."\\\",\\\"".$dataListArr[$i]['levelSeq']."\\\",\\\"".$dataListArr[$i]['language']."\\\",\\\"".$dataListArr[$i]['pageLevel']."\\\"),";
      }
      $str = rtrim($str,',');
      if($str !=""){
        $insertparam .= ",@p_pageLabelList='".$str."'";
        $resultArr = DB::select("CALL Get_Lang('AddPageLabel',\"".$insertparam."\")");
      } 
      $data['message'] = "success"; 
      return response()->json($data); 
     //return view('master.add-page-label-master');
  }
  public function getPageLabel($params) {
    $pageId =$this->request->id;
    $parmArray = array("pageId"=>$pageId);
    $requestparam = Helper::makeProcedureCall($parmArray);
    $langDetails = DB::select("CALL Get_Lang('editPageLabel',\"".$requestparam."\")"); 
    $data['lang_data']=$langDetails;
    $data['html'] = view('master.ajax-add-page-label-master',$data)->render();
    $data['message']="success";
     return response()->json($data);
  }
  /* For Demo of view all Processes  */
  public function viewProcess($params) {
      $objLocation = new ProcessModel();
      return view('master.view-process-master', $this->viewVars);
  }
  /* For Demo of add  Processes  */
  public function addProcess($params) {
      $objLocation = new ProcessModel();
      return view('master.add-process-master', $this->viewVars);
  }

  /* For Demo of adding Activity  */
  public function addApprovalAction($params) {
     // $objLocation = new ApprovalActionModel();
      return view('master.add-approvalaction-master');
  }
  ############################View Refrence
  public function viewAprvlthroughAjax($params) {
    //echo "aaa";die();
    $start = $this->request->start;
    $length = $this->request->length;

    $draw = $this->request->draw;
    $param1 = $this->request->param1;
    $param2 = $this->request->param2;
    
    $parmArray = array("param1"=>$param1, "param2" => $param2, "start"=>$start, "length"=>$length);
    $requestparam = Helper::makeProcedureCall($parmArray); //exit;
    $appDetails = DB::select("CALL manage_ApprovalRoutines('viewAllApp',\"".$requestparam."\")");
    //print_r($appDetails); exit();
    //$subData = array();
    foreach($appDetails as $key=>$val){
      if($val->TAM_Approval_Active ==1)
        $active = "Active";
      else
        $active = "Inactive";
        
      $appDetails[$key]->TAM_Approval_Active = $active;
        
      $appDetails[$key]->action =  
      "<a href='editApprovalAction/".Crypt::encryptString($val->TAM_Approval)."'><i class='fa fa-edit'></i></a>";  
    } 
    $data['data']=$appDetails;
    $data['recordsTotal']= !empty($appDetails)? $appDetails[0]->total:0;
    $data['recordsFiltered']=!empty($appDetails)? $appDetails[0]->total:0;
    $data['draw']=$draw;
    //print "<pre>"; print_r(response()->json($data));exit;
        return response()->json($data);
  } 

  ############################Save Refrence   
 public function saveApproval($params) {
   $validator = Validator::make($this->request->all(), [
        'actionName' => 'required|max:255',
        'actionNameOdia' => 'required|max:255',
        'actionDescription' => 'required|max:255',
          
       ]);

        if ($validator->fails()) {
            return redirect()
                  ->back()
                  ->withErrors($validator)
                  ->withInput();
        }
    $userId = session()->get('userId');
    $actionName =$this->request->actionName;
    $actionNameOdia =$this->request->actionNameOdia;
    $actionDescription =  $this->request->actionDescription;
 
    $hidActId = $this->request->hidActId; 
     
    if($hidActId == ""){
       
       
      $parmArray = array(
            "actionName" => $actionName,
            "actionNameOdia" => $actionNameOdia,
            "actionDescription" => $actionDescription); 
       $insertparam = Helper::makeProcedureCall($parmArray);//exit;
       
       DB::select("CALL manage_ApprovalRoutines('addAct',\"".$insertparam."\")");
     }else{
      #condition for modify 
      $parmArray = array(
            "actionName" => $actionName,
            "actionNameOdia" => $actionNameOdia,
            "actionDescription" => $actionDescription, 
            "dataId" => $hidActId);
       $insertparam = Helper::makeProcedureCall($parmArray);//exit;
       
       DB::select("CALL manage_ApprovalRoutines('modifyApproval',\"".$insertparam."\")"); 
     }
     return Redirect::to('master/viewApprovalAction')->with('success', true);
  }

  /* For Demo of view all Activity  */
  public function viewApprovalAction($params) {
   //   $objLocation = new ProcessModel();

      return view('master.view-approvalaction-master', $this->viewVars);
  }


  ############################Edit Refrence  
  public function editApprovalAction($params) { 
    //exception handel here
    try {
       $dataId =   Crypt::decryptString($params);
    } catch (DecryptException $e) {
       return Redirect::to('master/viewApprovalAction');
    } 
    
    $userId = session()->get('userId');
    $parmArray = array("dataId"=>$dataId);
    $requestparam = Helper::makeProcedureCall($parmArray);
    $approvalDetails = DB::select("CALL manage_ApprovalRoutines('editAppAct',\"".$requestparam."\")");  
    $data['data']=$approvalDetails;
    //print "<pre>"; print_r($delete);exit;
        return view('master.add-approvalaction-master',$data);
  }
    ############################Delete Refrence
  public function deleteApprovalActionAjax($params) {
   
    $dataId = $this->request->id;
    $userId = session()->get('userId');
    //update query
    $parmArray = array("dataId"=>$dataId);
    $requestparam = Helper::makeProcedureCall($parmArray);
    $delet = DB::select("CALL manage_ApprovalRoutines('delApprvAction',\"".$requestparam."\")");
    $data['message']="success";
    //print "<pre>"; print_r($delete);exit;
        return response()->json($data);
  }


  /* For Demo of View setauthority  */
  public function setAuthorityAction($params) {
    $wingDetails = DB::select("CALL master_Document_Routines('getWingList','')");
    $data['wing_list']=$wingDetails;
    $parentRoleDetails = DB::select("CALL user_userroleRoutines('getParentName','')");
    $data['parent_role_list']=$parentRoleDetails;
    $approvalDetails = DB::select("CALL manage_DropDownRoutines('getApprovaAction','')");
    $data['approval_list']=$approvalDetails;
    return view('master.add-setauthority-master', $data);
  }

  public function getUserName($params) {
    $roleID =$this->request->id;
    $parmArray = array("roleID"=>$roleID);
    $requestparam = Helper::makeProcedureCall($parmArray);
    $userDetails = DB::select("CALL manage_DropDownRoutines('getRoleUsernames',\"".$requestparam."\")"); 
    $data['userDetails']=$userDetails;
    //$data['html'] = view('master.ajax-user-name-master',$data)->render();
    $data['message']="success";
     return response()->json($data);
  }
 /* For Demo of adding setauthority  */
  public function AddSetAuthority($params) {
    $dataListArr=$this->request->all();
    $parmArray = array(
      'wingId' =>  $dataListArr[0]['wingName']

      );
    $str = "";
    #################Server side validation##########################
    $valid=1;
     for($i=0; $i< count($dataListArr); $i++){ //echo "here";exit;
        if(count($dataListArr[$i]['userNameId'])==0){
           $valid=0;
        }
        for ($k = 0; $k< count($dataListArr[$i]['userNameId']); $k++){
         if($dataListArr[$i]['wingName'] ==''){
            $valid=0;
            break;
         }
         if($dataListArr[$i]['userRole'] ==''){
            $valid=0;
            break;
         }
         if($dataListArr[$i]['userNameId'][$k] ==''){
            $valid=0;
            break;
         }
         $approvalId = $dataListArr[$i]['approvalId'];
         $approval = implode(',', $approvalId);
         if($approval ==''){
            $valid=0;
            break;
         }
          if($dataListArr[$i]['pageLevel'] ==''){
            $valid=0;
            break;
         }
        }
      }
      if($valid ==0){
         $data['message'] = "fail"; 
        return response()->json($data);
      }
      #################Server side validation##########################

      for($i=0; $i< count($dataListArr); $i++){

        for ($k = 0; $k< count($dataListArr[$i]['userNameId']); $k++){
         $wingName = $dataListArr[$i]['wingName'];
         $userRole = $dataListArr[$i]['userRole'];
         $userNameId = $dataListArr[$i]['userNameId'][$k];
         $approvalId = $dataListArr[$i]['approvalId'];
         $approval = implode(',', $approvalId);
         $pageLevel = $dataListArr[$i]['pageLevel'];
         $number = $dataListArr[$i]['number'];

        $str.="(\\\"".$wingName."\\\",\\\"".$userRole."\\\",\\\"".$userNameId."\\\",\\\"".$approval."\\\",\\\"".$pageLevel."\\\",\\\"".$number."\\\"),";
        }
      }
      $insertparam = Helper::makeProcedureCall($parmArray);
     
      $str = rtrim($str,',');
      if($str !=""){
        $insertparam .= ",@p_WorkSubQuery='".$str."'";
      $resultArr = DB::select("CALL user_setauthorityRoutines('addSetAuthority',\"".$insertparam."\")");
      }
      $data['message'] = "success"; 
      return response()->json($data);
  }

  public function getWorkFlow($params) {
    //print_r($this->request->all());exit;
    $parentRoleDetails = DB::select("CALL user_userroleRoutines('getParentName','')");
    $data['parent_role_list']=$parentRoleDetails;

    $approvalDetails = DB::select("CALL manage_DropDownRoutines('getApprovaAction','')");
    $data['approval_list']=$approvalDetails;

    $wingID =$this->request->id;
    $parmArray = array("wingId"=>$wingID);
    $requestparam = Helper::makeProcedureCall($parmArray);
    $workDetails = DB::select("CALL user_setauthorityRoutines('getWorkFlow',\"".$requestparam."\")"); 
    $data['work_data']=$workDetails;

    $roleUserArray= array();
    if(!empty($workDetails)){
      $str = "";
       foreach($workDetails as $key=>$val){
        $str.="\'".$val->TSA_UserRole."\',";
      }
      $str = rtrim($str,',');
      $requestparam = 'SET @p_roleID="('. $str.')"';
      $userDetails = DB::select("CALL manage_DropDownRoutines('getAllRoleUsernames','".$requestparam."')"); 
     
      foreach($userDetails as $key=>$val){
        $roleUserArray[$val->TURA_UserRole][]=$val;

      }
    }
    $data['user_data']=$roleUserArray;
    $data['html'] = view('master.ajax-setauthority-master',$data)->render();
    $data['message']="success";
    return response()->json($data);
  }
 
}
