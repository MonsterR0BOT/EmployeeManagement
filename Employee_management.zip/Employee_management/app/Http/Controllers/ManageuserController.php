<?php

namespace App\Http\Controllers;
use App\Http\Controllers\AppController;
use Redirect;
use Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Contracts\Encryption\DecryptException;
use App\Helpers\Helper;
use DB;
use Session; 
use Image;


class ManageuserController extends AppController
{  
	#################dindayal View content Start
	public function viewAllMemberList($params) {
		//$stateDetails = DB::select("CALL user_ManageRoutines('getStateName','')");
	    //$data['state_list']=$stateDetails;
	    return view('manageuser.manage-member');
	}
	public function viewMemberthroughAjax($params) {

		$start = $this->request->start;
		$length = $this->request->length;
		$draw = $this->request->draw;
		$param1 = $this->request->param1;
		$param2 = $this->request->param2;
		$param3 = $this->request->param3;
		
		$parmArray = array("param1"=>$param1,"param2"=>$param2,"param3"=>$param3, "start"=>$start, "length"=>$length);
		$requestparam = Helper::makeProcedureCall($parmArray); //exit;

		//fetch user login settings from db
		//$userSettingsArray = Helper::getUserLoginsetting();
		//echo $requestparam;exit;
		$userDetails = DB::select("CALL member_ManageRoutines('viewAllMList',\"".$requestparam."\")");
		//echo $userDetails;exit;
		//$subData = array();
		foreach($userDetails as $key=>$val){
			if($val->TMM_Member_Status ==1)
				$active = "Active";
			else
				$active = "Inactive";

			$userDetails[$key]->TMM_Member_Status = $active;

			if($val->TMM_MemberType ==1)
				$member = "Main Member";
			else if($val->TMM_MemberType ==2)
				$member = "Business Member";
			else
				$member = "Student Member";

			$userDetails[$key]->TMM_MemberType = $member;
			//block status
			if($val->TMM_Member_Approve == 0)
				$block = "<a href='javascript:void(0)' onclick='unblockMember(\"".  $val->TMM_Member."\")'>Unapproved</a>";
			else
				$block = "Approved";

			$userDetails[$key]->TMM_Member_Approve = $block;

			$userDetails[$key]->action = "<a href='".url('manageuser/viewIndividualMember')."/".Crypt::encryptString($val->TMM_Member)."'><i class='fa fa-user'></i></a> &nbsp;&nbsp;  <a href='javascript:void(0)' onclick='deleteMember(\"".  $val->TMM_Member."\")'><i class='fa fa-trash'></i></a>";
			
		}
        
		$data['data']=$userDetails;
	    $data['recordsTotal']= !empty($userDetails)? $userDetails[0]->total:0;
		$data['recordsFiltered']=!empty($userDetails)? $userDetails[0]->total:0;
		$data['draw']=$draw;
      //print "<pre>"; print_r(response()->json($data));exit;
        return response()->json($data);
	}
	public function deleteMemberthroughAjax($params) {
		$memberId = $this->request->id;
		$userId = session()->get('userId');
		$parmArray = array("member"=>$memberId, "createdBy" => $userId);
		$requestparam = Helper::makeProcedureCall($parmArray);
		$delet = DB::select("CALL member_ManageRoutines('deleteMData',\"".$requestparam."\")");
		
		$data['message']="success";
		//print "<pre>"; print_r($delete);exit;
        return response()->json($data);
	}
	public function approveMemberthroughAjax($params) {
		$memberId = $this->request->id;
		$userId = session()->get('userId');
		$parmArray = array("member"=>$memberId, "createdBy" => $userId);
		$requestparam = Helper::makeProcedureCall($parmArray);
		$delet = DB::select("CALL member_ManageRoutines('approvedMData',\"".$requestparam."\")");
		
		$data['message']="success";
		//print "<pre>"; print_r($delete);exit;
        return response()->json($data);
	}
	public function viewIndividualMember($params) {
		try {
		   $memberId =   Crypt::decryptString($params);
		} catch (DecryptException $e) {
		   return Redirect::to('manageuser/viewAllMemberList');
		}
		//$memberId = $this->request->memberId;
		$parmArray = array("member"=>$memberId);
		$requestparam = Helper::makeProcedureCall($parmArray);
		//print($requestparam);exit;
		$userDetails = DB::select("CALL member_ManageRoutines('memberData',\"".$requestparam."\")");
		$data['data']=$userDetails[0];
		
		$memberDetails = DB::select("CALL member_ManageRoutines('memberReferenceData',\"".$requestparam."\")");
		//print "<pre>";print_r($memberDetails);exit;
		$data['memberDetails']=$memberDetails;

        return view('manageuser.view-member',$data);
	}
	public function ViewMemberModal($params) {
		$memberId = $this->request->memberId;
		$parmArray = array("member"=>$memberId);
		$requestparam = Helper::makeProcedureCall($parmArray);
		//print($requestparam);exit;
		$userDetails = DB::select("CALL member_ManageRoutines('memberData',\"".$requestparam."\")");
		$data['userData']=$userDetails[0];
		$data['message']="success";
		//print "<pre>"; print_r($delete);exit;
        return response()->json($data);
	}
}

