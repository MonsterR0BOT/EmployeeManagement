<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Helpers\Helper;
use DB;
use Session;
use Redirect;

class UserTypeController extends Controller
{
    public function addUserType(Request $request) {
		//print "<pre>"; print_r($request->input('countryName'));exit;
		$userId = session()->get('userId');
        $userTypeName = $request->userTypeName;
		$userTypeDescription = $request->userTypeDescription;
        $userTypeActive = $request->userTypeActive;
		$hidUserTypeId = $request->hidUserType;
		#condition for insert
		if($hidUserTypeId == ""){
			$parmArray = array(
								"userTypeName" => $userTypeName,
								"userTypeDescrptn" => $userTypeDescription,
								"userTypeActive" => $userTypeActive,
								"createdBy" => $userId );
			
			 $insertparam = Helper::makeProcedureCall($parmArray);//exit;
			 
			 DB::select("CALL user_typeRoutines('addUserType',\"".$insertparam."\")");
		 }else{
		 	#condition for modify
			$parmArray = array(
					"userTypeName" => $userTypeName,
					"userTypeDescrptn" => $userTypeDescription,
					"userTypeActive" => $userTypeActive,
					"createdBy" => $userId,
					"userType" => $hidUserTypeId);
			 $insertparam = Helper::makeProcedureCall($parmArray);//exit;
			 
			 DB::select("CALL user_typeRoutines('modifyUserType',\"".$insertparam."\")");

		 }
		 return Redirect::to('manage-user-type');
	}
	
	public function viewUserTypethroughAjax(Request $request) {
		$start = $request->start;
		$length = $request->length;
		$draw = $request->draw;
		$param1 = $request->param1;
		$param2 = $request->param2;
		
		$parmArray = array("param1"=>$param1, "start"=>$start, "length"=>$length);
		$requestparam = Helper::makeProcedureCall($parmArray); //exit;
		$userTypeDetails = DB::select("CALL user_typeRoutines('viewAlluserType',\"".$requestparam."\")");
		//$subData = array();
		foreach($userTypeDetails as $key=>$val){
			if($val->TUT_UserType_Active ==1)
				$active = "Active";
			else
				$active = "Inactive";
				
			$userTypeDetails[$key]->TUT_UserType_Active = $active;
			$userTypeDetails[$key]->action = "<a href='edit-user-type?id=".$val->TUT_UserType."'><span class='glyphicon glyphicon-edit'></span></a> &nbsp;&nbsp; <a href='javascript:void(0)' onclick='deleteUserType(\"".  $val->TUT_UserType."\")'><span class='glyphicon glyphicon-trash'></span></a>";
			
		}
        
		$data['data']=$userTypeDetails;
	    $data['recordsTotal']= !empty($userTypeDetails)? $userTypeDetails[0]->total:0;
		$data['recordsFiltered']=!empty($userTypeDetails)? $userTypeDetails[0]->total:0;
		$data['draw']=$draw;
		//print "<pre>"; print_r(response()->json($data));exit;
        return response()->json($data);
	}
	public function deleteUserTypethroughAjax(Request $request) {
		$userTypeId = $request->id;
		$userId = session()->get('userId');
		$parmArray = array("userType"=>$userTypeId, "createdBy" => $userId);
		$requestparam = Helper::makeProcedureCall($parmArray);
		$delet = DB::select("CALL user_typeRoutines('deleteUserType',\"".$requestparam."\")");
		
		$data['message']="success";
		//print "<pre>"; print_r($delete);exit;
        return response()->json($data);
	}
	public function editUserType(Request $request) {
		$userTypeId = $request->id;
		$userId = session()->get('userId');
		$parmArray = array("userType"=>$userTypeId);
		$requestparam = Helper::makeProcedureCall($parmArray);
		$userTypeDetails = DB::select("CALL user_typeRoutines('editUserType',\"".$requestparam."\")");
		
		$data['data']=$userTypeDetails;
		//print "<pre>"; print_r($delete);exit;
        return view('user.add-user-type',$data);
	}
}
