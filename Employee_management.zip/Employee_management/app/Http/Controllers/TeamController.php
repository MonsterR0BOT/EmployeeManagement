<?php

namespace App\Http\Controllers;
use App\Http\Controllers\AppController;
use Redirect;
use Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Contracts\Encryption\DecryptException;
use App\Helpers\Helper;
use DB;
use Session; 
use Image;

class TeamController extends AppController
{
	public function viewAllTeam($params) {
    	return view('master.team-master');
	}
	public function showAddTeamMember($params) {
    	return view('master.add-team-master');
	}

    public function addTeam($params) {
		$data=$this->request->all();
		
		//print "<pre>"; print_r($data);exit;

		$memberId = session()->get('userId');
		$Name = $this->request->Name;
		$email = $this->request->email;
		$password= hash('sha256',$this->request->password);
		$mobile = $this->request->mobile;
		$dob = $this->request->dob;
		$memberImage = $this->request->memberImage;
		$designation= $this->request->designation;
		$address = $this->request->address;

		$hidteamMemberId = $this->request->hidteamMemberId;

		if($hidteamMemberId ==''){
			$validator = Validator::make($this->request->all(), [
			'Name' => 'required|max:255',
			'email' => 'required',
			'password' => 'required',
			'mobile' => 'required',
			'dob' => 'required',
			'memberImage' => 'required',
			'designation' => 'required',
			'address' => 'required'
			
			]);

			if ($validator->fails()) {
				return redirect()
				->back()
				->withErrors($validator)
				->withInput();
			}
			//echo $bannerTitle;
			// exit;
			if($this->request->memberImage !=''){
				$ext = strtolower($this->request->memberImage->getClientOriginalExtension());
				if($this->request->memberImage != "" && $ext != "png" && $ext != "jpg" && $ext != "jpeg"){
				$this->request->session()->flash('message', 'Sorry!! Invalid image file upload.');
				return Redirect::to('team/showAddTeamMember');
				}


				#condition for insert

				//Check for certificate image copy from preview folder and unlink
				$imageName = time().'.'.$this->request->memberImage->getClientOriginalExtension();
				//echo $imageName;
				//exit;

				if ($imageName != "") {
					//Original Photo Uploading
					$orig_img = Image::make($this->request->memberImage->getRealPath())->fit(750, 500);
					$orig_img->save(public_path('teamMember_image/orig').'/'.$imageName,80);

					//Thumb Photo Uploading
					$thumb_img = Image::make($this->request->memberImage->getRealPath())->fit(40, 40);
					$thumb_img->save(public_path('teamMember_image/thumb').'/'.$imageName,80);
				}
			}else{
				$imageName ='';
			}

			$parmArray = array(
			"Name" => $Name,
			"memberId" => $memberId,
			"email" => $email,
			"password" => $password,
			"mobile" => $mobile,
			"dob" => $dob,
			"memberImage" => $imageName,
			"designation" => $designation,
			"address" => $address,
			"currentTime" => now() );

			$insertparam = Helper::makeProcedureCall($parmArray);
			//echo $insertparam;die();//exit;
			DB::select("CALL master_teamRoutines('addTeamMember',\"".$insertparam."\")");

		}else{
			$validator = Validator::make($this->request->all(), [
			'Name' => 'required|max:255',
			'email' => 'required',		
			'mobile' => 'required',
			'dob' => 'required',
			'designation' => 'required',
			'address' => 'required'
			]);


			if ($validator->fails()) {
				return redirect()
				->back()
				->withErrors($validator)
				->withInput();
			}
			#condition for modify
			if($this->request->memberImage !=''){
				$ext = strtolower($this->request->memberImage->getClientOriginalExtension());
				if($this->request->memberImage != "" && $ext != "png" && $ext != "jpg" && $ext != "jpeg"){
				$this->request->session()->flash('message', 'Sorry!! Invalid image file upload.');
				return Redirect::to('manage-member');
				}
				//delete previous image from folder
				$serviceDetails = DB::table('tbl_team_mstr')
				->select('TTM_TeamMember_Image')
				->where('TTM_Team', '=', $hidteamMemberId)
				->get();
				if($serviceDetails[0]->TTM_TeamMember_Image !=''){
				@unlink(public_path('member_image/orig').'/'.$serviceDetails[0]->TTM_TeamMember_Image);
				@unlink(public_path('member_image/thumb').'/'.$serviceDetails[0]->TTM_TeamMember_Image);
				}
				//Check for certificate image copy from preview folder and unlink
				$imageName = time().'.'.$this->request->memberImage->getClientOriginalExtension();

				if ($imageName != "") {
					//Original Photo Uploading
					$orig_img = Image::make($this->request->memberImage->getRealPath())->fit(750, 500);
					$orig_img->save(public_path('member_image/orig').'/'.$imageName,80);

					//Thumb Photo Uploading
					$thumb_img = Image::make($this->request->memberImage->getRealPath())->fit(40, 40);
					$thumb_img->save(public_path('member_image/thumb').'/'.$imageName,80);
				}
			}
			else{
				$serviceDetails = DB::table('tbl_team_mstr')
				->select('TTM_TeamMember_Image')
				->where('TTM_Team', '=', $hidteamMemberId)
				->get();
				if($serviceDetails[0]->TTM_TeamMember_Image !=''){
					$imageName =$serviceDetails[0]->TTM_TeamMember_Image;
				}
				else{
					$imageName ='';
				}
			}
			$parmArray = array(
				"Name" => $Name,
				"memberId" => $hidteamMemberId,
				"email" => $email,
				"mobile" => $mobile,
				"dob" => $dob,
				"memberImage" => $imageName,
				"designation" => $designation,
				"address" => $address,
				"currentTime" => now() );
				$insertparam = Helper::makeProcedureCall($parmArray);//exit;
				//echo $insertparam;die();
				DB::select("CALL master_teamRoutines('saveEditTeam',\"".$insertparam."\")");

		}
		 //$this->request->session()->flash('message', 'Member Edited successfully');
		return Redirect::to('team/viewAllTeam');
	}

	public function viewTeamthroughAjax($params) {
		$start = $this->request->start;
		$length = $this->request->length;
		$draw = $this->request->draw;
		$param1 = $this->request->param1;
		//$param2 = $this->request->param2;
		
		$parmArray = array("param1"=>$param1, "start"=>$start, "length"=>$length);
		$requestparam = Helper::makeProcedureCall($parmArray); //exit;
		$teamMemberDetails = DB::select("CALL master_teamRoutines('viewAllTeam',\"".$requestparam."\")");
		//$subData = array();<i class="far fa-file-alt"></i>
		foreach($teamMemberDetails as $key=>$val){
		    $teamMemberDetails[$key]->TTM_TeamMember_Image="<img class='img-circle' src='". asset('teamMember_image/thumb/'.$val->TTM_TeamMember_Image)."' alt=''/>";

			$teamMemberDetails[$key]->action = "<a href='".url('Team/report')."/".Crypt::encryptString($val->TTM_Team)."'><i class='fa fa-file'></i></a> &nbsp;&nbsp;<a href='".url('Team/editMember')."/".Crypt::encryptString($val->TTM_Team)."'><i class='fa fa-edit'></i></a> &nbsp;&nbsp; <a href='javascript:void(0)' onclick='deleteMember(\"".  $val->TTM_Team."\")'><i class='fa fa-trash'></i></a> &nbsp;&nbsp; ";
			
		}
        
		$data['data']=$teamMemberDetails;
	    $data['recordsTotal']= !empty($teamMemberDetails)? $teamMemberDetails[0]->total:0;
		$data['recordsFiltered']=!empty($teamMemberDetails)? $teamMemberDetails[0]->total:0;
		$data['draw']=$draw;
		//print "<pre>"; print_r(response()->json($data));exit;
        return response()->json($data);
	}
	public function deleteMemberthroughAjax($params) {
		$userId = $this->request->id;

		$parmArray = array("userId"=>$userId);
		$requestparam = Helper::makeProcedureCall($parmArray);
		$delet = DB::select("CALL master_teamRoutines('deleteMember',\"".$requestparam."\")");
		
		$data['message']="success";
		//print "<pre>"; print_r($delete);exit;
        return response()->json($data);
	}
	public function viewAtendance($params) {
		 $userId=Session::get("userId");
		 $date=date("Y-m-d");

			$parmArray = array(
			"userId" => $userId,
			"date" => $date
			);

			$insertparam = Helper::makeProcedureCall($parmArray);
			//echo $insertparam;die();//exit;
			$info=DB::select("CALL master_teamRoutines('fetchAttendance',\"".$insertparam."\")");
			//print_r($data);exit;
			$data['data']=$info;
      return view('master.add-atendance',$data);
	}
	public function addAttendance($params) {
	 $userId=Session::get("userId");	
     $intime=date("h:i:sa");
     $date=date("Y-m-d");
     // echo $intime; 
     // echo $userId;exit;
     $parmArray = array(
			"userId" => $userId,
			"intime" => $intime,
			"date" => $date
			);

			$insertparam = Helper::makeProcedureCall($parmArray);
			//echo $insertparam;die();//exit;
			DB::select("CALL master_teamRoutines('addAttendance',\"".$insertparam."\")");
   
      return Redirect::to('team/viewAtendance');
	}
	public function outAttendance($params) {
	 $userId=Session::get("userId");	
     $outTime=date("h:i:sa");
     $date=date("Y-m-d");
     // echo $intime; 
     // echo $userId;exit;
     $parmArray = array(
			"userId" => $userId,
			"outTime" => $outTime,
			"date" => $date
			);

			$insertparam = Helper::makeProcedureCall($parmArray);
			//echo $insertparam;die();//exit;
			DB::select("CALL master_teamRoutines('outAttendance',\"".$insertparam."\")");
      return Redirect::to('team/viewAtendance');
	}
	public function report($params) {

		try {
		   $userId =   Crypt::decryptString($params);
		} catch (DecryptException $e) {
		   return Redirect::to('Team/viewAllTeam');
		}

		$parmArray = array("userId"=>$userId);
		$requestparam = Helper::makeProcedureCall($parmArray);
		$resArr = DB::select("CALL master_teamRoutines('fetchOneAttendance',\"".$requestparam."\")");

		$data['data']=$resArr;
        return view('master.view-attendance',$data);
	}
	public function editMember($params) {
		try {
		   $userId =   Crypt::decryptString($params);
		} catch (DecryptException $e) {
		   return Redirect::to('Team/viewAllTeam');
		}

		$parmArray = array("userId"=>$userId);
		$requestparam = Helper::makeProcedureCall($parmArray);
		$resArr = DB::select("CALL master_teamRoutines('viewEditMember',\"".$requestparam."\")");

		$data['data']=$resArr;
        return view('master.add-team-master',$data);
	}
	
}
