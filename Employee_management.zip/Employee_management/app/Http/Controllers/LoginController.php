<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Helpers\Helper;
use DB;
use Session;
use Redirect;
use Image;
use Illuminate\Support\Facades\Storage;
use Validator;
use Mail;
use App\Mail\MailBuilder;

class LoginController extends Controller
{
    public function showLogin(Request $request) {
     	
     	return view('login');
     }
     
    public function showUserLogin(Request $request) {
     	
     	return view('user_login');
     }
    public function refreshCaptcha(){
        return response()->json(['captcha'=> captcha_img()]);
    }
    public function doAdminLogin(Request $request) {
    	//echo "here";exit;
  //   	$data= $request->all();
  //       print'<pre>';
		// print_r($data); exit;
        $validator = Validator::make($request->all(), [
        'email' => 'required|max:255',
        'password' => 'required|max:255'
        
   		 ]);

        if ($validator->fails()) {
            return redirect()
            			->back()
                        ->withErrors($validator)
                        ->withInput();
        }
        $data= $request->all();
        //print'<pre>';
		//print_r($data); exit;
        if (!empty($data)) {
        	$serverIP = $request->server('SERVER_ADDR');
			//print "<pre>";print_r($data);exit;
			$email = Helper::checkXss($data['email'],true, false);
			//$password = sha1($data['password']);
			$password = hash('sha256',$data['password']);
			//echo $password;exit;
			$arrRes = DB::table('tbl_user_mstr')->where('TUM_User_Email', '=', $email)->where('TUM_User_DeletedFlag','=','0')->get();  
			//print "<pre>";print_r($arrRes);exit;
			if(count($arrRes)>0){
				//fetch user login settings from db
				$userSettingsArray = Helper::getUserLoginsetting();

				$IsFirstTimeLogin = $arrRes[0]->TUM_IsFirstTime_Login;
				//check block status
				if($arrRes[0]->TUM_User_Status == 0){
					//insert into user log table
					DB::table('tbl_user_login_history')
							->insert(array('TULH_User'=>$arrRes[0]->TUM_User,'TULH_LogHistory_IPAddress'=>$serverIP,'TULH_LogHistory_LoginTime'=>now(),'TULH_LogHistory_Success'=>0));
					$request->session()->flash('message', 'Sorry !! You are inactive.Please contact adminstrator');
					//return view('login');
					return redirect('login');
				}
				//check block status
				if($arrRes[0]->TUM_User_LoginAttempt >= $userSettingsArray->TULS_Login_Attempt){
					//insert into user log table
					DB::table('tbl_user_login_history')
							->insert(array('TULH_User'=>$arrRes[0]->TUM_User,'TULH_LogHistory_IPAddress'=>$serverIP,'TULH_LogHistory_LoginTime'=>now(),'TULH_LogHistory_Success'=>0));
					$request->session()->flash('message', 'Sorry !! You are blocked.Please contact adminstrator');
					//return view('login');
					return redirect('login');
				}
				//matching password
				if($arrRes[0]->TUM_User_Password == $password){

					$userRoles = DB::table('tbl_userrole_assign')
						->where('TURA_User', '=', $arrRes[0]->TUM_User)
						->groupBy('TURA_User')
                		->select(DB::raw("(GROUP_CONCAT(TURA_UserRole)) as assignedRoles"))
						->get(); 

					$request->session()->flush();

					if(count($userRoles)){
						$request->session()->put('userRoles', explode(',',$userRoles[0]->assignedRoles));
					}else{
						$request->session()->put('userRoles', array());
					}		
					
					$request->session()->put('userId', $arrRes[0]->TUM_User);
					$request->session()->put('userType', $arrRes[0]->TUM_User_UserType);
					
					//update login attempt
					DB::table('tbl_user_mstr')
			                    ->where('TUM_User','=',$arrRes[0]->TUM_User)
								->update(array('TUM_User_LoginAttempt'=>0 , 'TUM_User_UpdatedOn'=>now()));
					//insert into user log table
					DB::table('tbl_user_login_history')
						->insert(array('TULH_User'=>$arrRes[0]->TUM_User ,'TULH_LogHistory_IPAddress'=>$serverIP,'TULH_LogHistory_LoginTime'=>now(),'TULH_LogHistory_Success'=>1));
					
					return redirect('dashboard');
					 	
				}else{
					//update login attempt
					DB::table('tbl_user_mstr')
			                    ->where('TUM_User','=',$arrRes[0]->TUM_User)
								->update(array('TUM_User_LoginAttempt'=>DB::raw('TUM_User_LoginAttempt+1') , 'TUM_User_UpdatedOn'=>now()));
					
					//insert into user log table
					DB::table('tbl_user_login_history')
							->insert(array('TULH_User'=>$arrRes[0]->TUM_User,'TULH_LogHistory_IPAddress'=>$serverIP,'TULH_LogHistory_LoginTime'=>now(),'TULH_LogHistory_Success'=>0));
					$request->session()->flash('message', 'Sorry !! Invalid password');
					//return view('login');
					return redirect('login');
				}
				
			}else{
				//insert into user log table
				DB::table('tbl_user_login_history')
						->insert(array('TULH_LogHistory_IPAddress'=>$serverIP,'TULH_LogHistory_LoginTime'=>now(),'TULH_LogHistory_Success'=>0));
				$request->session()->flash('message', 'Sorry !! Invalid login ID');
				//return view('login');
				return redirect('login');
			}

        }
        return redirect('login');
    }
    



    public function doUserLogin(Request $request) {
    	//echo "here";exit;
  //   	$data= $request->all();
  //       print'<pre>';
		// print_r($data); exit;
        $validator = Validator::make($request->all(), [
        'email' => 'required|max:255',
        'password' => 'required|max:255'
        
   		 ]);

        if ($validator->fails()) {
            return redirect()
            			->back()
                        ->withErrors($validator)
                        ->withInput();
        }
        $data= $request->all();
        //print'<pre>';
		//print_r($data); exit;
        if (!empty($data)) {
        	$serverIP = $request->server('SERVER_ADDR');
			//print "<pre>";print_r($data);exit;
			$email = Helper::checkXss($data['email'],true, false);
			//$password = sha1($data['password']);
			$password = hash('sha256',$data['password']);
			//echo $password;exit;
			$arrRes = DB::table('tbl_team_mstr')->where('TTM_Member_Email', '=', $email)->get();  
			//print "<pre>";print_r($arrRes);exit;
			if(count($arrRes)==1){
				
				//matching password
				if($arrRes[0]->TTM_Password == $password){
                    
					$userRoles=array('0' =>'rol005' ); 
					$request->session()->flush();
					$request->session()->put('userRoles', $userRoles);
					$request->session()->put('userId', $arrRes[0]->TTM_Team);
					$request->session()->put('userType', 'Employee');
					

					
					return redirect('dashboard');
					 	
				}else{
					
					$request->session()->flash('message', 'Sorry !! Invalid password');
					//return view('login');
					return redirect('login');
				}
				
			}else{
				
				$request->session()->flash('message', 'Sorry !! Invalid login ID');
				//return view('login');
				return redirect('login');
			}

        }
        return redirect('login');
    }

	
	

    public function showUserProfile(Request $request) {
		
		//$usrId = $request->id;
		$usrId = session()->get('userId');
		$parmArray = array("user"=>$usrId);
		$requestparam = Helper::makeProcedureCall($parmArray);
		//echo $requestparam;exit;
		$userDetails = DB::select("CALL user_ManageRoutines('editUserData',\"".$requestparam."\")");
		
		$data['data']=$userDetails;

        return view('user.edit-profile',$data);
	}
	

	public function logout(Request $request) {
		
		if(session()->has('userId')){
			$userId = session()->get('userId');
			//update login history table by fetching last id
			$lastHistory = DB::table('tbl_user_login_history')
						->where('TULH_User', '=', $userId)
						->where('TULH_LogHistory_Success', '=',1)
						->select('TULH_LoginHistory')->orderby('TULH_LoginHistory','DESC')
						->limit('1')
						->get(); 
			if(!empty($lastHistory)){
				$lastHistoryId = $lastHistory[0]->TULH_LoginHistory;
				DB::table('tbl_user_login_history')
				   ->where('TULH_LoginHistory','=',$lastHistoryId)
				   ->update(array('TULH_LogHistory_LogoutTime'=>now()));
			}
		}

		\Auth::logout();
		$request->session()->flush();
		$request->session()->regenerate(true);
		$laravelcookie = \Cookie::forget('laravel_session');
		return redirect('/');
	}
	public function logoutuser(Request $request) {
		
		if(session()->has('userId'))
			$userId = session()->get('userId');

		$request->session()->flush();
		$request->session()->regenerate(true);
		$laravelcookie = \Cookie::forget('laravel_session');
		return redirect('/');
	
	}

	public function forgotPassword() {
		return view('forgot-password');
	}
	
	
	

	public function showUserDashboard(Request $request) {
		if(!session()->has('userRoles')){
			return redirect('logout');
		}
		//print_r(Session::get("userRoles"));exit;
		if(in_array('rol001', Session::get("userRoles"))){ 
        	$dashboard = 'dashboard.dashboard-user';
        }
      	else{
      		$dashboard ='dashboard.dashboard-user';	
      	}
      	return view($dashboard);

	}

	
}
