<?php
 /**
 * The base AppController file for other controllers to extend and use
 * Created On   : 23-DEC-2019
 * Note         : Do not modify code in this file without the consent of the author
 * 
 * ======================================================================
 * |Update History                                                      |
 * ======================================================================
 * |<Updated by>            |<Updated On> |<Remarks>                    |
 * ----------------------------------------------------------------------
 * |Name Goes Here          |23-DEC-2019 |Remark goes here        
 * ----------------------------------------------------------------------
 * |                        |             |                  
 * ----------------------------------------------------------------------
 * 
 * @package AppController
 * @author  @m@n
 */

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Components\FlashMessages;

use Illuminate\Routing\Controller as BaseController;

class AppController extends BaseController
{
    /**
     * The request object
     *
     * @var object
     */
    protected $request;

    /**
     * The variable to store variables to be passed to the view
     *
     * @var array
     */
    protected $viewVars = ['intPageNo' => 1, 'intRecsPerPage' => 10, 'arrPaging' => [], 'openFlag' => 'C', 'arrRecs' => []];

    /**
     * Stores the search conditions (in list view pages)
     *
     * @var array
     */
    protected $conditions = [];

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(Request $objRequest)
    {

        $this->request = $objRequest;

        $arrControllerParts = explode('\\', get_class($this));
        $strControllerName = array_pop($arrControllerParts);

        $strModelClass = 'App\Models\\' . str_replace('Controller', 'Model', $strControllerName);

        if (class_exists($strModelClass)) {
            $this->model = new $strModelClass;
        }

        if (request('hdn_PageNo')) {

            $this->viewVars['intPageNo'] = request('hdn_PageNo');

        }

    }

}
