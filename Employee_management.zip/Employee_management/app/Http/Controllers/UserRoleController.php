<?php

namespace App\Http\Controllers;
use App\Http\Controllers\AppController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Contracts\Encryption\DecryptException;
use App\Helpers\Helper;
use DB;
use Session;
use Redirect;
use Validator;
class UserRoleController extends AppController
{
     public function showAddUserRole($params) {
		// $costCenterDetails = DB::select("CALL user_userroleRoutines('getCostCenterName','')");
  //       $data['costcenter_list']=$costCenterDetails;
		
		$parentRoleDetails = DB::select("CALL user_userroleRoutines('getParentName','')");
        $data['parent_role_list']=$parentRoleDetails;
		
		$moduleDetails = DB::select("CALL user_userroleRoutines('getModuleDetails','')");
        $data['module_list']=$moduleDetails;
		
		$functionDetails = DB::select("CALL user_userroleRoutines('getFunctionDetails','')");
        $data['function_list']=$functionDetails;
		
		$activityDetails = DB::select("CALL user_userroleRoutines('getActivityDetails','')");
        $data['activity_list']=$activityDetails;

        $data['module_chk_list']=array();
        $data['function_chk_list']=array();
        $data['activity_chk_list']=array();
		
		//print "<pre>"; print_r($stateDetails);exit;
        return view('user.add-user-role',$data);
	}
	public function AddUserRole($params) {
		//print "<pre>"; print_r($request->json());exit;
		$dataArr = $this->request->json();
		//print "<pre>"; print_r($dataArr);
		$firstArr = $dataArr->get(0);
		$userId = session()->get('userId');
        $userRoleName = $firstArr['userRoleName'];
		$userParentUserRole = $firstArr['userParentUserRole'];
        //$userCostCenter = $firstArr['userCostCenter'];
		$userRoleStatus = $firstArr['userRoleStatus'];
		$userDescription = $firstArr['userDescription'];
		$userRoleId = $firstArr['userRoleId'];
		#condition for insert
		if($userRoleId == ""){
			$parmArray = array(
								"userRoleName" => $userRoleName,
								"userParentUserRole" => $userParentUserRole,
								"userRoleStatus" => $userRoleStatus,
								"userDescription" => $userDescription,
								"createdBy" => $userId );
			
			 $insertparam = Helper::makeProcedureCall($parmArray);//exit;
			 
			 if(count($dataArr)>0){
				 $str = "";
				 //for($i=0; $i< count($dataArr); $i++){
				 foreach($dataArr as $val){
					$str.="(@p_roleMasterId,\\\"".$val['moduleId']."\\\",\\\"".$val['functionId']."\\\",\\\"".$val['activityId']."\\\"),";
				 }
				 $str = rtrim($str,',');
				 if($str !=""){
					$insertparam .= ",@p_childSubquery='".$str."'";
				 }
			 }
			 //echo $insertparam;exit;
			 DB::select("CALL user_userroleRoutines('addUserRole',\"".$insertparam."\")");
		 }else{
		 	#condition for modify
			$parmArray = array(
								"userRoleName" => $userRoleName,
								"userParentUserRole" => $userParentUserRole,
								"userRoleStatus" => $userRoleStatus,
								"userDescription" => $userDescription,
								"createdBy" => $userId,
								"userroleId" => $userRoleId);
			
			 $insertparam = Helper::makeProcedureCall($parmArray);//exit;
			 if(count($dataArr)>0){
				 $str = "";
				 //for($i=0; $i< count($dataArr); $i++){
				 foreach($dataArr as $val){
					$str.="(@p_roleMasterId,\\\"".$val['moduleId']."\\\",\\\"".$val['functionId']."\\\",\\\"".$val['activityId']."\\\"),";
				 }
				 $str = rtrim($str,',');
				 if($str !=""){
					$insertparam .= ",@p_childSubquery='".$str."'";
				 }
			 }
			 //echo $insertparam;exit;
			 
			 DB::select("CALL user_userroleRoutines('modifyUserRole',\"".$insertparam."\")");

		 }
		 //return Redirect::to('manage-user');
		$data['message']="success";
		//print "<pre>"; print_r($delete);exit;
        return response()->json($data);
	}
	public function viewAllUserRole($params) {
        return view('user.manage-user-role');
	}
	public function viewUserRolethroughAjax($params) {
		$start = $this->request->start;
		$length = $this->request->length;
		$draw = $this->request->draw;
		$param1 = $this->request->param1;
		$param2 = $this->request->param2;
		//$param3 = $request->param3;
		
		$parmArray = array("param1"=>$param1,"param2"=>$param2, "start"=>$start, "length"=>$length);
		$requestparam = Helper::makeProcedureCall($parmArray); //exit;
		$userRoleDetails = DB::select("CALL user_userroleRoutines('viewUserData',\"".$requestparam."\")");
		//$subData = array();
		foreach($userRoleDetails as $key=>$val){
			if($val->TURM_URole_Status ==1)
				$active = "Active";
			else
				$active = "Inactive";
				
			$userRoleDetails[$key]->TURM_URole_Status = $active;
			$userRoleDetails[$key]->action = "<a href='javascript:void(0)' onclick='viewInModel(\"".  $val->TURM_UserRole."\")'><i class='fa fa-search'></i></a>&nbsp;&nbsp;<a href='".url('UserRole/editUserRole')."/".Crypt::encryptString($val->TURM_UserRole)."'><i class='fa fa-edit'></i></a> &nbsp;&nbsp; <a href='javascript:void(0)' onclick='deleteUserRole(\"".  $val->TURM_UserRole."\")'><i class='fa fa-trash'></i></a>";
			
		}
        
		$data['data']=$userRoleDetails;
	    $data['recordsTotal']= !empty($userRoleDetails)? $userRoleDetails[0]->total:0;
		$data['recordsFiltered']=!empty($userRoleDetails)? $userRoleDetails[0]->total:0;
		$data['draw']=$draw;
		//print "<pre>"; print_r(response()->json($data));exit;
        return response()->json($data);
	}
	public function deleteUserRolethroughAjax($params) {
		$userRoleId = $this->request->userRoleId;
		$userId = session()->get('userId');
		$parmArray = array("userroleId"=>$userRoleId, "createdBy" => $userId);
		$requestparam = Helper::makeProcedureCall($parmArray);
		$delet = DB::select("CALL user_userroleRoutines('deleteUserRole',\"".$requestparam."\")");
		
		$data['message']="success";
		//print "<pre>"; print_r($delete);exit;
        return response()->json($data);
	}
	public function ViewUserRoleModal($params) {
		$roleId = $this->request->roleId;
		$parmArray = array("userroleId"=>$roleId);
		$requestparam = Helper::makeProcedureCall($parmArray);
		$userRoleDetails = DB::select("CALL user_userroleRoutines('ModelView',\"".$requestparam."\")");
		$data['userRoleData']=$userRoleDetails[0];
		$data['message']="success";
		//print "<pre>"; print_r($delete);exit;
        return response()->json($data);
	}
	public function editUserRole($params) {
		//exception handel here
		try {
		   $usrRoleId =   Crypt::decryptString($params);
		} catch (DecryptException $e) {
		   return Redirect::to('UserRole/viewAllUserRole');
		}
		//$usrRoleId = $request->id;
		$userId = session()->get('userId');
		$parmArray = array("userroleId"=>$usrRoleId);
		$requestparam = Helper::makeProcedureCall($parmArray);
		
		$userRoleDetails = DB::select("CALL user_userroleRoutines('viewEditUserRole',\"".$requestparam."\")");
		
		$data['data']=$userRoleDetails;
		
		$parentRoleDetails = DB::select("CALL user_userroleRoutines('getParentName','')");
        $data['parent_role_list']=$parentRoleDetails;
		
		$moduleDetails = DB::select("CALL user_userroleRoutines('getModuleDetails','')");
        $data['module_list']=$moduleDetails;
		
		$functionDetails = DB::select("CALL user_userroleRoutines('getFunctionDetails','')");
        $data['function_list']=$functionDetails;
		
		$activityDetails = DB::select("CALL user_userroleRoutines('getActivityDetails','')");
        $data['activity_list']=$activityDetails;
		
		$moduleChkDetails = DB::select("CALL user_userroleRoutines('getModuleCheckDtls',\"".$requestparam."\")");
        $data['module_chk_list']=$moduleChkDetails;
		
		$functionChkDetails = DB::select("CALL user_userroleRoutines('getFunctionCheckDtls',\"".$requestparam."\")");
        $data['function_chk_list']=$functionChkDetails;
		
		$activityChkDetails = DB::select("CALL user_userroleRoutines('getActivityCheckDtls',\"".$requestparam."\")");
        $data['activity_chk_list']=$activityChkDetails;
		
		
		//print "<pre>"; print_r($data);exit;
        return view('user.add-user-role',$data);
	}
}
