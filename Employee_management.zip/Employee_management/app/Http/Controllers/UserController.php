<?php

namespace App\Http\Controllers;
use App\Http\Controllers\AppController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Contracts\Encryption\DecryptException;
use App\Helpers\Helper;
use DB;
use Session;
use Redirect;
use Mail;
use App\Mail\MailBuilder;
use Validator;

class UserController extends AppController
{
    public function showAddUser($params) {
		/*$desigDetails = DB::select("CALL manage_DropDownRoutines('getUserDesignation','')");
        $data['designation_list']=$desigDetails;
		
		$departDetails = DB::select("CALL manage_DropDownRoutines('getUserDepartment','')");
        $data['department_list']=$departDetails;*/
		
		$userRoleDetails = DB::select("CALL manage_DropDownRoutines('getUserRoleList','')");
        $data['user_role_list']=$userRoleDetails;
		
		//print "<pre>"; print_r($stateDetails);exit;
        return view('user.add-user',$data);
	}
	public function addUser($params) {
		//print "<pre>"; print_r($this->request->all());exit;
		$userId = session()->get('userId');
        $userName = $this->request->userName;
		$userLastName = $this->request->userLastName;
        $userMobile = $this->request->userMobile;
        $userEmail = $this->request->userEmail;
		$userPassword = hash('sha256',$this->request->userPassword);
		$userDesignation = $this->request->userDesignation;
		$userDepartment = $this->request->userDepartment;
        $userStatus = $this->request->userStatus;
        $userAltMobile = $this->request->userAltMobile;
        $userAltEmail = $this->request->userAltEmail;

		$userRoles = $this->request->userRoles;
		$hidUserId = $this->request->hidUser;
		$password = $this->request->userPassword;

		#condition for insert
		if($hidUserId == ""){
			$validator = Validator::make($this->request->all(), [
		        'userName' => 'required|max:255',
		        'userLastName' => 'required|max:255',
		        'userEmail' => 'required',  
		        'userPassword' => 'required',
		        'userMobile' => 'required',
		        'userRoles' => 'required',
		   		 ]);

		        if ($validator->fails()) {
		            return redirect()
		        			->back()
		                    ->withErrors($validator)
		                    ->withInput();
		        }
			$parmArray = array(
								"userName" => $userName,
								"userMobile" => $userMobile,
								"userLastName" => $userLastName,
								"userDesignation" => $userDesignation,
								"userPassword" => $userPassword,
								"userEmail" => $userEmail,
								"userDepartment" => $userDepartment,
								"userAltEmail" => $userAltEmail,
								"userAltMobile" => $userAltMobile,
								"userStatus" => $userStatus,
								"createdBy" => $userId );
			
			 $insertparam = Helper::makeProcedureCall($parmArray);//exit;
			 //$roleArr = ($userRoles !='')?explode(',',$userRoles) :array();
			 //print_r($userRoles);
			 
			 $str = "";
			 for($i=0; $i< count($userRoles); $i++){
			 	$str.="(@p_userId,\\\"".$userRoles[$i]."\\\"),";
			 }
			 $str = rtrim($str,',');
			 if($str !=""){
			 	$insertparam .= ",@p_userRole='".$str."'";
			 }
			 //echo $insertparam;exit;
			$resultArr = DB::select("CALL user_ManageRoutines('saveAddUser',\"".$insertparam."\")");
			//echo $resultArr[0]->recordCount;
			//print_r($resultArr);exit;
			$recordCount = !empty($resultArr)?$resultArr[0]->recordCount:'';
			if($recordCount >0){
				$request->session()->flash('message', 'Sorry! This email is already used.');
				return Redirect::to('add-user');
			}
			 //Mail sending starts here 
			  if(config('app.EMAIL_FLAG')=='LIVE'){
				//$userEmail = $data['email'];
				  // Get records from tbl_email_template table
				  $email_details = DB::table('tbl_email_mstr')->where('TEM_Email', '=', 2)->get();
				  $body = str_replace(array('%NAME%','%EMAILID%','%PASSWORD%'), array($userName, $userEmail, $password), $email_details[0]->TEM_Email_Body);
				  $content = [
						  'title'=> $email_details[0]->TEM_Email_Name,
						  'subject'=> $email_details[0]->TEM_Email_Subject,
						  'body'=> $body,
						  'email_template' => 'emails.common_mail',
						  'from_email' => $email_details[0]->TEM_Email_FromEmail,
						  'from_name' => $email_details[0]->TEM_Email_FromName
						  ];
				   //print_r($content);exit;       
				  //$email = 'ranasinghsukanta@gmail.com';
				  Mail::to($userEmail)->send(new MailBuilder($content));
				  
			  }
			  //End of mail sending

		 }else{
		 	$validator = Validator::make($this->request->all(), [
		        'userName' => 'required|max:255',
		        'userLastName' => 'required|max:255',
		        'userEmail' => 'required',  
		        'userMobile' => 'required',
		        'userRoles' => 'required',
		   		 ]);

		        if ($validator->fails()) {
		            return redirect()
		        			->back()
		                    ->withErrors($validator)
		                    ->withInput();
		        }
		 	#condition for modify
			$parmArray = array(
								"userName" => $userName,
								"userMobile" => $userMobile,
								"userLastName" => $userLastName,
								"userDesignation" => $userDesignation,
								"userEmail" => $userEmail,
								"userDepartment" => $userDepartment,
								"userAltEmail" => $userAltEmail,
								"userAltMobile" => $userAltMobile,
								"userStatus" => $userStatus,
								"createdBy" => $userId ,
								"user" => $hidUserId);

			 $insertparam = Helper::makeProcedureCall($parmArray);//exit;
			 //$roleArr = ($userRoles !='')?explode(',',$userRoles) :array();
			 //print_r($userRoles);
			 
			 $str = "";
			 for($i=0; $i< count($userRoles); $i++){
			 	$str.="(@p_userId,\\\"".$userRoles[$i]."\\\"),";
			 }
			 $str = rtrim($str,',');
			 if($str !=""){
			 	$insertparam .= ",@p_userRole='".$str."'";
			 }
			 //echo $insertparam;exit;
			 
			 DB::select("CALL user_ManageRoutines('updateUserData',\"".$insertparam."\")");

		 }
		 return Redirect::to('user/viewAllUserList');
	}
	public function viewAllUserList($params) {
		//$stateDetails = DB::select("CALL user_ManageRoutines('getStateName','')");
        //$data['state_list']=$stateDetails;
        return view('user.manage-user-master');
	}
	public function viewUserthroughAjax($params) {
		$start = $this->request->start;
		$length = $this->request->length;
		$draw = $this->request->draw;
		$param1 = $this->request->param1;
		$param2 = $this->request->param2;
		$param3 = $this->request->param3;
		
		$parmArray = array("param1"=>$param1,"param2"=>$param2,"param3"=>$param3, "start"=>$start, "length"=>$length);
		$requestparam = Helper::makeProcedureCall($parmArray); //exit;

		//fetch user login settings from db
		$userSettingsArray = Helper::getUserLoginsetting();
		//echo $requestparam;exit;
		$userDetails = DB::select("CALL user_ManageRoutines('viewAllUserList',\"".$requestparam."\")");
		//$subData = array();
		foreach($userDetails as $key=>$val){
			if($val->TUM_User_Status ==1)
				$active = "Active";
			else
				$active = "Inactive";
			$userDetails[$key]->TUM_User_Status = $active;
			//block status
			if($val->TUM_User_LoginAttempt >= $userSettingsArray->TULS_Login_Attempt)
				$block = "<a href='javascript:void(0)' onclick='unblockUser(\"".  $val->TUM_User."\")'>Blocked</a>";
			else
				$block = "Unblocked";
			$userDetails[$key]->TUM_User_LoginAttempt = $block;

			$userDetails[$key]->action = "<a href='".url('user/editUser')."/".Crypt::encryptString($val->TUM_User)."'><i class='fa fa-edit'></i></a> &nbsp;&nbsp; <a href='javascript:void(0)' onclick='deleteUser(\"".  $val->TUM_User."\")'><i class='fa fa-trash'></i></a>";
			
		}
        
		$data['data']=$userDetails;
	    $data['recordsTotal']= !empty($userDetails)? $userDetails[0]->total:0;
		$data['recordsFiltered']=!empty($userDetails)? $userDetails[0]->total:0;
		$data['draw']=$draw;
		//print "<pre>"; print_r(response()->json($data));exit;
        return response()->json($data);
	}
	public function deleteUserthroughAjax($params) {
		$usrId = $this->request->id;
		$userId = session()->get('userId');
		$parmArray = array("user"=>$usrId, "createdBy" => $userId);
		$requestparam = Helper::makeProcedureCall($parmArray);
		$delet = DB::select("CALL user_ManageRoutines('deleteUserData',\"".$requestparam."\")");
		
		$data['message']="success";
		//print "<pre>"; print_r($delete);exit;
        return response()->json($data);
	}
	public function unblockUserthroughAjax($params) {
		$usrId = $this->request->id;
		$userId = session()->get('userId');
		$parmArray = array("user"=>$usrId, "createdBy" => $userId);
		$requestparam = Helper::makeProcedureCall($parmArray);
		$delet = DB::select("CALL user_ManageRoutines('unblockUserData',\"".$requestparam."\")");
		
		$data['message']="success";
		//print "<pre>"; print_r($delete);exit;
        return response()->json($data);
	}
	public function editUser($params) {
		//exception handel here
		try {
		   $usrId =   Crypt::decryptString($params);
		} catch (DecryptException $e) {
		   return Redirect::to('user/viewAllUserList');
		}
		//$usrId = $request->id;
		$userId = session()->get('userId');
		$parmArray = array("user"=>$usrId);
		$requestparam = Helper::makeProcedureCall($parmArray);
		//echo $requestparam;exit;
		$userDetails = DB::select("CALL user_ManageRoutines('editUserData',\"".$requestparam."\")");
		
		$data['data']=$userDetails;
		
		/*$desigDetails = DB::select("CALL manage_DropDownRoutines('getUserDesignation','')");
        $data['designation_list']=$desigDetails;
		
		$departDetails = DB::select("CALL manage_DropDownRoutines('getUserDepartment','')");
        $data['department_list']=$departDetails;*/
		
		$userRoleDetails = DB::select("CALL manage_DropDownRoutines('getUserRoleList','')");
        $data['user_role_list']=$userRoleDetails;
		//print "<pre>"; print_r($data);exit;
        return view('user.add-user',$data);
	}
	public function AddUserStateList($params) {
		$countryId = $this->request->countryId;
		//$userId = session()->get('userId');
		$parmArray = array("countryId"=>$countryId);
		$requestparam = Helper::makeProcedureCall($parmArray);
		//$data['requestparam']=$request->all();
		$stateList = DB::select("CALL manage_DropDownRoutines('getStateNameListData',\"".$requestparam."\")");
		$data['stateList']=$stateList;
		$data['message']="success";
		//print "<pre>"; print_r($delete);exit;
        return response()->json($data);
	}
	public function AddUserDistrictList($params) {
		$stateId = $this->request->stateId;
		//$userId = session()->get('userId');
		$parmArray = array("stateId"=>$stateId);
		$requestparam = Helper::makeProcedureCall($parmArray);
		$districtList = DB::select("CALL manage_DropDownRoutines('getDistrictNameListData',\"".$requestparam."\")");
		$data['districtList']=$districtList;
		$data['message']="success";
		//print "<pre>"; print_r($delete);exit;
        return response()->json($data);
	}
	public function ViewUserModal($params) {
		$userId = $this->request->userId;
		$parmArray = array("user"=>$userId);
		$requestparam = Helper::makeProcedureCall($parmArray);
		$userDetails = DB::select("CALL user_ManageRoutines('editUserData',\"".$requestparam."\")");
		$data['userData']=$userDetails[0];
		$data['message']="success";
		//print "<pre>"; print_r($delete);exit;
        return response()->json($data);
	}
	public function getDesignationList($params) {
		$deptId = $this->request->deptId; 
		$parmArray = array("deptId"=>$deptId);
		$requestparam = Helper::makeProcedureCall($parmArray); 
		$desigList = DB::select("CALL manage_DropDownRoutines('getDesigListData',\"".$requestparam."\")");
		$data['desigList']=$desigList;
		$data['message']="success"; 
        return response()->json($data);
	} 
}
