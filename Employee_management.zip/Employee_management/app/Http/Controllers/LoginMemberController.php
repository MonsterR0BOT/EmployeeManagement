<?php

namespace App\Http\Controllers;
use App\Http\Controllers\AppController;
use Illuminate\Http\Request;
use App\Helpers\Helper;
use DB;
use Session;
use Redirect;
use Image;
use Illuminate\Support\Facades\Storage;
use Validator;
use Mail;
use App\Mail\MailBuilder;

class LoginMemberController extends Controller
{
    public function showMemberLogin(Request $request) {
//alert('hi');exit;
     	return view('loginMember');
     }
    public function refreshCaptcha(){
        return response()->json(['captcha'=> captcha_img()]);
    }
    public function doMemberLogin(Request $request) {
    	//echo "here";exit;
        $validator = Validator::make($request->all(), [
        'email' => 'required|max:255',
        'password' => 'required|max:255',
   		 ]);

        if ($validator->fails()) {
            return redirect()
            			->back()
                        ->withErrors($validator)
                        ->withInput();
        }
        $data= $request->all();
		
        if (!empty($data)) {
        	$serverIP = $request->server('SERVER_ADDR');
			//print "<pre>";print_r($data);exit;
			$email = Helper::checkXss($data['email'],true, false);
			//$password = sha1($data['password']);
			$password = hash('sha256',$data['password']);
			//echo $password;exit;
			$arrRes = DB::table('tbl_member_mstr')->where('TMM_Member_Email', '=', $email)->where('TMM_Member_DeletedFlag','=','0')->get();  
			//print "<pre>";print_r($arrRes);exit;
			if(count($arrRes)>0){
				//fetch user login settings from db
				$userSettingsArray = Helper::getUserLoginsetting();

				$IsFirstTimeLogin = $arrRes[0]->TMM_IsFirstTime_Login;
				//check block status
				if($arrRes[0]->TMM_Member_Status == 0){
					//insert into user log table
					DB::table('tbl_user_login_history')
							->insert(array('TULH_User'=>$arrRes[0]->TMM_Member,'TULH_LogHistory_IPAddress'=>$serverIP,'TULH_LogHistory_LoginTime'=>now(),'TULH_LogHistory_Success'=>0));
					$request->session()->flash('message', 'Sorry !! You are inactive.Please contact adminstrator');
					return view('loginMember');
					//return redirect('showMemberLogin');
				}
				//check block status
				if($arrRes[0]->TMM_Member_Approve == 0){
					//insert into user log table
					DB::table('tbl_user_login_history')
							->insert(array('TULH_User'=>$arrRes[0]->TMM_Member,'TULH_LogHistory_IPAddress'=>$serverIP,'TULH_LogHistory_LoginTime'=>now(),'TULH_LogHistory_Success'=>0));
					$request->session()->flash('message', 'Sorry !! You are blocked.Please contact adminstrator');
					return view('loginMember');
					//return redirect('showMemberLogin');
				}
				//matching password
				if($arrRes[0]->TMM_Member_Password == $password){

					/*$userRoles = DB::table('tbl_userrole_assign')
						->where('TURA_User', '=', $arrRes[0]->TUM_User)
						->groupBy('TURA_User')
                		->select(DB::raw("(GROUP_CONCAT(TURA_UserRole)) as assignedRoles"))
						->get(); */

					$request->session()->flush();

					/*if(count($userRoles)){
						$request->session()->put('userRoles', explode(',',$userRoles[0]->assignedRoles));
					}else{
						$request->session()->put('userRoles', array());
					}		*/
					
					$request->session()->put('memberId', $arrRes[0]->TMM_Member);
					/*$request->session()->put('userType', $arrRes[0]->TUM_User_UserType);*/
					//$request->session()->put('userModules', $arrRes[0]->TUM_User_Modules);
					//update login attempt
					DB::table('tbl_member_mstr')
			                    ->where('TMM_Member','=',$arrRes[0]->TMM_Member)
								->update(array('TMM_Member_LoginAttempt'=>0 , 'TMM_Member_UpdatedOn'=>now()));
					//insert into user log table
					DB::table('tbl_user_login_history')
						->insert(array('TULH_User'=>$arrRes[0]->TMM_Member ,'TULH_LogHistory_IPAddress'=>$serverIP,'TULH_LogHistory_LoginTime'=>now(),'TULH_LogHistory_Success'=>1));

					
       
		//print_r($memberDetails);exit();	
		                 // return view('dashboard1');
						return Redirect::to('member-dashboard');
						
					 	
				}else{
					//update login attempt
					DB::table('tbl_member_mstr')
			                    ->where('TMM_Member','=',$arrRes[0]->TMM_Member)
								->update(array('TMM_Member_LoginAttempt'=>DB::raw('TMM_Member_LoginAttempt+1') , 'TMM_Member_UpdatedOn'=>now()));
					
					//insert into user log table
					DB::table('tbl_user_login_history')
							->insert(array('TULH_User'=>$arrRes[0]->TMM_Member,'TULH_LogHistory_IPAddress'=>$serverIP,'TULH_LogHistory_LoginTime'=>now(),'TULH_LogHistory_Success'=>0));
					$request->session()->flash('message', 'Sorry !! Invalid password');
					return view('loginMember');
					//return redirect('showMemberLogin');
				}
				
			}else{
				//insert into user log table
				DB::table('tbl_user_login_history')
						->insert(array('TULH_LogHistory_IPAddress'=>$serverIP,'TULH_LogHistory_LoginTime'=>now(),'TULH_LogHistory_Success'=>0));
				$request->session()->flash('message', 'Sorry !! Invalid login ID');
				return view('loginMember');
				//return redirect('showMemberLogin');
			}

        }
        return view('loginMember');
    }

    public function showDashboard(){
		$memberId=Session::get('memberId');
		$parmArray = array(
			"memberId" => $memberId
		);
		$requestparam = Helper::makeProcedureCall($parmArray);
		//print_r($insertparam); exit;
		$matrimonyDetails= DB::select("CALL master_matrimonyRoutines('viewMatrimony',\"".$requestparam."\")");
		$data['matrimony_list']=$matrimonyDetails;

		$blogDetails = DB::select("CALL master_blogRoutines('viewMemberBlog',\"".$requestparam."\")");
		$data['member_blog_list']=$blogDetails;

		//print_r($data);exit();
		return view('matrimonylisting',$data);
	}

	public function changePassword() {
	    return view('change-password');
	}
	public function modifyMPassword(Request $request) {
		$validator = Validator::make($request->all(), [
        'oldPassword' => 'required|max:255',
        'newPassword' => 'required|max:255',
        'confirmPassword' => 'required|max:255',
   		 ]);

        if ($validator->fails()) {
            return redirect()
            			->back()
                        ->withErrors($validator)
                        ->withInput();
        }
		$data= $request->all();
		$memberId = session()->has('memberId') ? session()->get('memberId'):0;
		if (!empty($data)) {
			$serverIP = $request->server('SERVER_ADDR');
			$oldPassword = hash('sha256',$data['oldPassword']);
			$password = $data['newPassword'];
			//$password1 = sha1(time());
			$password1 = hash('sha256',$password);
			
			$arrResChk = DB::table('tbl_member_mstr')
						->select('TMM_Member_Name','TMM_Member_Password')->where('TMM_Member', '=', $memberId)->get();  
			//print "<pre>";print_r($arrResChk);exit;
			
			if(count($arrResChk) >0){
				$firstname = $arrResChk[0]->TMM_Member_Name;
				if($arrResChk[0]->TMM_Member_Password != $oldPassword){
				  	$request->session()->flash('warning', 'Sorry old password is not matching !');
				   	return view('change-password');
				}else if(stripos($password, $firstname) !== false){
					$request->session()->flash('message', 'Enter password is invalid .Please enter a valid password');
					return view('change-password');
				}/*else{
					
					//fetch password policy from db
					$passwordPolicyArray = Helper::getResetPasswordPolicy();
					$TPPM_Password_Encryption = $passwordPolicyArray->TPPM_Password_Encryption ? $passwordPolicyArray->TPPM_Password_Encryption:'';
			     	//print "<pre>";print_r($passwordPolicyArray);
			     	$TPPM_Password_Length=$passwordPolicyArray->TPPM_Password_Length;
					// Validate password strength
					if($passwordPolicyArray->TPPM_Password_IsUppercase ){
						$uppercase = preg_match('@[A-Z]@', $password);
					}else{
						$uppercase = true;
					}
					if($passwordPolicyArray->TPPM_Password_IsLowercase ){
						$lowercase = preg_match('@[a-z]@', $password);
					}else{
						$lowercase = true;
					}
					if($passwordPolicyArray->TPPM_Password_IsNumber ){
						$number    = preg_match('@[0-9]@', $password);
					}else{
						$number    = true;
					}
					if($passwordPolicyArray->TPPM_Password_IsSpecialChars ){
						$specialChars = preg_match('@[^\w]@', $password);
					}else{
						$specialChars = true;
					}


					if(!$uppercase || !$lowercase || !$number || !$specialChars || strlen($password) < $TPPM_Password_Length) {
						//echo $password.'<br/>';
					    //echo 'Password should be at least 8 characters in length and should include at least one upper case letter, one number, and one special character.';
					    $request->session()->flash('message', 'Enter password is invalid .Please enter a valid password');
				   		return redirect('change-password');
					}*/else{
					    //echo 'Strong password.';

						//update query
						DB::table('tbl_member_mstr')
			                    ->where('TMM_Member','=',$memberId)
								->update(array('TMM_Member_Password'=>$password1, 'TMM_Member_UpdatedOn'=>now()));
						//insert into user log table
						/*DB::table('tbl_user_password_history')
								->insert(array('TUPH_User'=>$memberId, 'TUPH_User_Password'=>$password1, 'TUPH_PwdHistory_IPAddress'=>$serverIP,'TUPH_PwdHistory_CreatedOn'=>now(),'TUPH_PwdHistory_Encryption'=> $TPPM_Password_Encryption));*/
						return redirect('member-dashboard'); 
					}
				}
	
			}else{
				$request->session()->flash('warning', 'Sorry invalid login !');
				return view('change-password'); 
			}
			
		}

	public function logout(Request $request) {
		
		if(session()->has('memberId')){
			$memberId = session()->get('memberId');
			//update login history table by fetching last id
			$lastHistory = DB::table('tbl_user_login_history')
						->where('TULH_User', '=', $memberId)
						->where('TULH_LogHistory_Success', '=',1)
						->select('TULH_LoginHistory')->orderby('TULH_LoginHistory','DESC')
						->limit('1')
						->get(); 
			if(!empty($lastHistory)){
				$lastHistoryId = $lastHistory[0]->TULH_LoginHistory;
				DB::table('tbl_user_login_history')
				   ->where('TULH_LoginHistory','=',$lastHistoryId)
				   ->update(array('TULH_LogHistory_LogoutTime'=>now()));
			}
		}

		\Auth::logout();
		$request->session()->flush();
		$request->session()->regenerate(true);
		$laravelcookie = \Cookie::forget('laravel_session');
		return redirect('/');
	}
}