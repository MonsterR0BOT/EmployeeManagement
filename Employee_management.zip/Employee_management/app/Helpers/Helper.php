<?php
namespace App\Helpers;
use DB;
use Session;
class Helper

{
    # To prepare statement for procedure call.
	public static function makeProcedureCall($arrVals,$debug=0){
		$parmaset="SET ";
		if(!empty($arrVals)) {
			foreach($arrVals as $key => $val) {
				$parmaset .= '@p_' . $key . "='" . str_replace(array("'", "\\", '"'), array("''", "\\\\\\\\", '\"'), $val) . "',";
			}
			if($debug) {
				$parmaset .= "@p_debug=1";
			}
			
			$parmaset = rtrim($parmaset, ',');
		
		}else{
			$parmaset .= "@p_empty='1'";
		}
		return $parmaset; 
	}	
	# To prepare statement for procedure call.
	public static function makeProcedureCallArr($arrVals,$debug=0){
		$parmaset="SET ";
		if(!empty($arrVals)) {
			foreach($arrVals as $key => $val) {
				if($val[0]){
					$parmaset .= '@p_' . $key . "='" . str_replace(array("'", "\\", '"'), array("''", "\\\\\\\\", '\"'), $val[1]) . "',";
				}else{
					$parmaset .= '@p_' . $key . "=" . str_replace(array("'", "\\", '"'), array("''", "\\\\\\\\", '\"'), $val[1]) . ",";
				}
			}
			if($debug) {
				$parmaset .= "@p_debug=1";
			}
			
			$parmaset = rtrim($parmaset, ',');
		
		}else{
			$parmaset .= "@p_empty='1'";
		}
		return $parmaset; 
	}	
	# To cut the string to a specific length.
    public static function cut($string, $max_length) {
        if (strlen($string) > $max_length) {
            $string = substr($string, 0, $max_length);
            $pos = strrpos($string, " ");
            if ($pos === false) {
                return substr($string, 0, $max_length) . "...";
            }
            return substr($string, 0, $pos) . "...";
        } else {
            return $string;
        }
    }
    public static function formatDateForMySqlDB($date,$time=0) {
    	$formatdate='';
    	if($time==1){
    		$formatdate = date("Y-m-d h:i:s", strtotime($date));
    	}else{
    		$formatdate = date("Y-m-d", strtotime($date));
    	}
        return $formatdate;
    }
    public static function getAdminPhoto() {
        $loginUserId = session()->has('userId') ? session()->get('userId'):0;
        $result = DB::table('tbl_user_mstr')->select('TUM_User_Image')->where('TUM_User', '=', $loginUserId)->get();
        if(!empty($result[0])){
            $profileOrgImg = ($result[0]->TUM_User_Image !='')? 'storage/'.$result[0]->TUM_User_Image : 'dist/img/user2-160x160.jpg';
        }else{
            $profileOrgImg = 'asset("public/dist/img/user2-160x160.jpg")';
        }
        return $profileOrgImg;
    }
    public static function getUserPhoto() {
       // echo "asdssdf";exit;
        $loginUserId = Session::get("userId");
        
        $result = DB::table('tbl_team_mstr')->select('TTM_TeamMember_Image')->where('TTM_Team', '=', $loginUserId)->get();
        if(!empty($result[0])){
            $profileOrgImg = ($result[0]->TTM_TeamMember_Image !='')? '/teamMember_image/thumb/'.$result[0]->TTM_TeamMember_Image : 'dist/img/user2-160x160.jpg';
        }else{
            $profileOrgImg = 'asset("public/dist/img/user2-160x160.jpg")';
        }
        return $profileOrgImg;
    }
    public static function getUserName() {
        $loginUserId = session()->has('userId') ? session()->get('userId'):0;
        $result = DB::table('tbl_user_mstr')->select('TUM_User_Name','TUM_User_Lname')->where('TUM_User', '=', $loginUserId)->get();
        echo !empty($result[0]) ? $result[0]->TUM_User_Name.' '.$result[0]->TUM_User_Lname :'';
    }
    public static function getNewUserName() {
        $loginUserId = session()->has('userId') ? session()->get('userId'):0;
        $result = DB::table('tbl_team_mstr')->select('TTM_TeamMemberName')->where('TTM_Team', '=', $loginUserId)->get();
        echo !empty($result[0]) ? $result[0]->TTM_TeamMemberName:'';
    }
    public static function getMemberName() {
        $loginUserId = session()->has('memberId') ? session()->get('memberId'):0;
        $result = DB::table('tbl_member_mstr')->select('TMM_Member_Name')->where('TMM_Member', '=', $loginUserId)->get();
        echo !empty($result[0]) ? $result[0]->TMM_Member_Name:'';
    }
    public static function getUserType() {
       $loginUserId = session()->has('userId') ? session()->get('userId'):0;
       $loginUserType = session()->has('userType') ? session()->get('userType'):'';
       $result = DB::table('tbl_user_mstr as tum')
                ->leftJoin('tbl_user_type_mstr as utm','utm.TUT_UserType','=','tum.TUM_User_UserType')
                ->select('utm.TUT_UserTypeName')
                ->where('tum.TUM_User', '=', $loginUserId)->get();
    
       $usertype= (!empty($result[0])) ? $result[0]->TUT_UserTypeName :'';
       echo $usertype;
    }
    public static function getUserRegDate() {
        $loginUserId = session()->has('userId') ? session()->get('userId'):0;
        $result = DB::table('tbl_user_mstr')->select('TUM_User_CreatedOn')->where('TUM_User', '=', $loginUserId)->get();
        echo !empty($result[0]) ? date('M, Y',strtotime($result[0]->TUM_User_CreatedOn)) :'';
    }

    public static function getUserLoginsetting() {
        $result = DB::table('tbl_user_login_setting')->get();
        return !empty($result[0]) ? $result[0] :array();
    }



    //Check security for hacking
    public static function checkSecurity($server){    
		if(isset($server['REQUEST_METHOD']) && $server['REQUEST_METHOD']=='POST'){
			if(false !== strpos($server['SERVER_NAME'],SERVER_NAME)){      
				return true;
			}else{
				return false;
			}
			
		}else{
			return false;
		}
	}
	//Protect form XSS
	public static function checkXss($string='',$stripTag=true,$htmlspecialcharacter=true){
		if($stripTag){
			$string=strip_tags($string);
			$string = str_ireplace( '%3Cscript', '', $string );
		}		
		if($htmlspecialcharacter){
			$string=htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
		}		
		return $string;
	}
	//Check from XSS and SQL Injection
	public static function checkXssSqlInjection($string='',$stripTag=true,$htmlspecialcharacter=true,$mysql_real_escape=true){
		
		if($stripTag){
			$string=strip_tags($string);
		}
		if($htmlspecialcharacter){
			$string=htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
		}
		if($mysql_real_escape){
			//$string=mysqli_real_escape_string($this->connection_db,$string);
			$string= str_replace(array('\\', "\0", "\n", "\r", "'", '"', "\x1a"), array('\\\\', '\\0', '\\n', '\\r', "\\'", '\\"', '\\Z'), $string); 
		}
		return $string;
	}
	//Check sqlinjection
	public static function checkSqlInjection($string='',$mysql_real_escape=true){		
		if($mysql_real_escape){
			//$string=mysqli_real_escape_string($this->connection_db,$string);
			$string= str_replace(array('\\', "\0", "\n", "\r", "'", '"', "\x1a"), array('\\\\', '\\0', '\\n', '\\r', "\\'", '\\"', '\\Z'), $string); 
		}
		return $string;
	}	
	
	//Clean xss
	public static function xss_clean($data){
        // Fix &entity\n;
        $data = str_replace(array('&amp;','&lt;','&gt;'), array('&amp;amp;','&amp;lt;','&amp;gt;'), $data);
        $data = preg_replace('/(&#*\w+)[\x00-\x20]+;/u', '$1;', $data);
        $data = preg_replace('/(&#x*[0-9A-F]+);*/iu', '$1;', $data);
        $data = html_entity_decode($data, ENT_COMPAT, 'UTF-8');
        // Remove any attribute starting with "on" or xmlns
        $data = preg_replace('#(<[^>]+?[\x00-\x20"\'])(?:on|xmlns)[^>]*+>#iu', '$1>', $data);
        // Remove javascript: and vbscript: protocols
        $data = preg_replace('#([a-z]*)[\x00-\x20]*=[\x00-\x20]*([`\'"]*)[\x00-\x20]*j[\x00-\x20]*a[\x00-\x20]*v[\x00-\x20]*a[\x00-\x20]*s[\x00-\x20]*c[\x00-\x20]*r[\x00-\x20]*i[\x00-\x20]*p[\x00-\x20]*t[\x00-\x20]*:#iu', '$1=$2nojavascript...', $data);
        $data = preg_replace('#([a-z]*)[\x00-\x20]*=([\'"]*)[\x00-\x20]*v[\x00-\x20]*b[\x00-\x20]*s[\x00-\x20]*c[\x00-\x20]*r[\x00-\x20]*i[\x00-\x20]*p[\x00-\x20]*t[\x00-\x20]*:#iu', '$1=$2novbscript...', $data);
        $data = preg_replace('#([a-z]*)[\x00-\x20]*=([\'"]*)[\x00-\x20]*-moz-binding[\x00-\x20]*:#u', '$1=$2nomozbinding...', $data);
        // Only works in IE: <span style="width: expression(alert('Ping!'));"></span>
        $data = preg_replace('#(<[^>]+?)style[\x00-\x20]*=[\x00-\x20]*[`\'"]*.*?expression[\x00-\x20]*\([^>]*+>#i', '$1>', $data);
        $data = preg_replace('#(<[^>]+?)style[\x00-\x20]*=[\x00-\x20]*[`\'"]*.*?behaviour[\x00-\x20]*\([^>]*+>#i', '$1>', $data);
        $data = preg_replace('#(<[^>]+?)style[\x00-\x20]*=[\x00-\x20]*[`\'"]*.*?s[\x00-\x20]*c[\x00-\x20]*r[\x00-\x20]*i[\x00-\x20]*p[\x00-\x20]*t[\x00-\x20]*:*[^>]*+>#iu', '$1>', $data);
        // Remove namespaced elements (we do not need them)
        $data = preg_replace('#</*\w+:\w[^>]*+>#i', '', $data);
        do{
		// Remove really unwanted tags
		$old_data = $data;
		$data = preg_replace('#</*(?:applet|b(?:ase|gsound|link)|embed|frame(?:set)?|i(?:frame|layer)|l(?:ayer|ink)|meta|object|s(?:cript|tyle)|title|xml)[^>]*+>#i', '', $data);
        }while ($old_data !== $data);
        // we are done...
        return $data;
	}
	
	//Genrate Key for url passing
	public static function keyMaker($id){ 
		//generate the secret key anyway you like. It could be a simple string like in this example or a database 
		//look up of info unique to the user or id. It could include date/time to timeout keys. 
		$secretkey='1HutysK98UuuhDasdfafdCrackThisBeeeeaaaatchkHgjsheIHFH44fheo1FhHEfo2oe6fifhkhs'; 
		$key=md5($id.$secretkey); 
		return $key; 
	} 

    public static function getLoginUserInfo() {
        $loginUserId = session()->has('userId') ? session()->get('userId'):0;
        $result = DB::table('tbl_user_mstr as tum')
        		->leftjoin('tbl_userrole_assign as tua','tum.TUM_User', '=', 'tua.TURA_User')  
        		->select('tum.TUM_User_Name','tum.TUM_User_Lname','tum.TUM_User_Dept', DB::raw("(GROUP_CONCAT(tua.TURA_UserRole)) as assignedRoles"))
        		->where('tum.TUM_User', '=', $loginUserId)
        		->groupBy('tua.TURA_User')
        		->get();
        		//print_r($result[0]->TUM_User_Dept);
          // echo !empty($result[0]) ? $result[0]->TUM_User_Name.' '.$result[0]->TUM_User_Lname.'</br>'.$result[0]->TUM_User_Dept.'</br>'.$result[0]->assignedRoles :'';
        return !empty($result[0]) ? $result[0] :array();
    }
}
