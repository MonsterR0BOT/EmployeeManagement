<?php
/********************************************
  File Name	: ManageMasterModel.php
  Description	: Model file for managing all the schema type
  Created By	: Subharam
  Created On	: 20-Dec-2019
  ======================================================================
  |Update History                                                      |
  ======================================================================
  |<Updated by>                 |<Updated On> |<Remarks>         
  ----------------------------------------------------------------------
  |Name Goes Here               |20-Dec-2019 |Remark goes here        
  ----------------------------------------------------------------------
  |                             |             |                  
  ----------------------------------------------------------------------
 ********************************************/
namespace App\Models;
//use App\Models\AppModel;
class  ProcessModel extends AppModel {
    protected $tables = array('d' => 'tbl_process_mstr');
    protected $procs  = array('d' => 'USP_PROCESS_MASTER');
    
    protected $fields = [
       
    ];
}