<?php
/********************************************
  File Name	: ManageMasterModel.php
  Description	: Model file for managing all the schema type
  Created By	: @m@n
  Created On	: 10-Aug-2019
  ======================================================================
  |Update History                                                      |
  ======================================================================
  |<Updated by>                 |<Updated On> |<Remarks>         
  ----------------------------------------------------------------------
  |Name Goes Here               |13-Aug-2019 |Remark goes here        
  ----------------------------------------------------------------------
  |                             |             |                  
  ----------------------------------------------------------------------
 ********************************************/
namespace App\Models;
//use App\Models\AppModel;
class  LocationModel extends AppModel {
    protected $tables = array('d' => 'tbl_location_mstr');
    protected $procs  = array('d' => 'USP_LOCATION_MASTER');
    
    protected $fields = [
       
    ];
}