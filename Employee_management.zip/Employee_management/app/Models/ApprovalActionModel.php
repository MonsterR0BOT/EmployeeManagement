<?php
/********************************************
  File Name	: ApprovalActionModel.php
  Description	: Model file for managing all the schema type
  Created By	: subharam
  Created On	: 20-Dec-2019
  ======================================================================
  |Update History                                                      |
  ======================================================================
  |<Updated by>                 |<Updated On> |<Remarks>         
  ----------------------------------------------------------------------
  |Name Goes Here               |20-Dec-2019 |Remark goes here        
  ----------------------------------------------------------------------
  |                             |             |                  
  ----------------------------------------------------------------------
 ********************************************/
namespace App\Models;
//use App\Models\AppModel;
class  ApprovalActionModel extends AppModel {
    protected $tables = array('d' => 'tbl_approvalaction_mstr');
    protected $procs  = array('d' => 'USP_APPROVALACTION_MASTER');
    
    protected $fields = [
       
    ];
}