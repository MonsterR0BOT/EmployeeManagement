<?php
/**
 * The base AppModel file for other models to extend and use
 * Created On   : 09-Aug-2018
 * Note         : Do not modify code in this file without the consent of the author
 *
 * ======================================================================
 * |Update History                                                      |
 * ======================================================================
 * |<Updated by>             |<Updated On> |<Remarks>                   |
 
 *
 * @package AppModel
 * @author  Nirmalya Labs
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Validator;

class AppModel extends Model
{

    /**
     * The database manager instance
     *
     * @var object
     */
    public $db = null;

    /**
     * The database connection instance
     *
     * @var object
     */
    public $dbc = null;

    /**
     * The underlying pdo instance
     *
     * @var object
     */
    public $pdo = null;

    /**
     * The AppModel constructor. Assigns db connection to member property.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();

        $database = app('db');
        $this->db = $database;
        $this->dbc = $this->db->connection();
        $this->pdo = $this->dbc->getPdo();

    }

   
    /**
     * The function validates the fields and returns errors if any
     * @param $arrData The field data to be validated
     * @return array
     */
    protected function getValidationErrors($arrData)
    {

        $validation_errors = [];

        $validator = Validator::make($arrData, $this->getRules());

        if ($validator->fails()) {

            unset($GLOBALS['validation_errors']);

            foreach ($validator->messages()->getMessages() as $field_name => $messages) {
                // Go through each message for this field.
                foreach ($messages as $message) {

                    $field_name_trimmed = preg_replace('/([\.0-9]+)?/i', '', $field_name);

                    if ($field_name_trimmed == $field_name) { //for normal field cases (e.g. vchFileName)

                        if (strpos($field_name, '_')) {

                            $msg_field_name = strtolower(str_replace('_', ' ', $field_name));

                        } else {
                            $msg_field_name = strtolower(implode(' ', preg_split('/(?=[A-Z])/', $field_name)));
                        }

                        $validation_errors[] = str_replace($msg_field_name, '<strong>' . $this->labels[$field_name_trimmed] . '</strong>', $message); // $message; //$message;

                    } else { //for array field cases (e.g. vchFileName[])
                        $validation_errors[] = str_replace($field_name, '<strong>' . $this->labels[$field_name_trimmed] . '</strong>', $message); // $message; //$message;

                    }

                }
            }

        }

        return $GLOBALS['validation_errors'] = $validation_errors;

    }

    

    /**
     * Calls the procedure with provided action and values
     *
     * @param $strProcName The record IDs to be unpublished
     * @param $strProcAction The action parameter of the procedure
     * @param $arrVals The value parameter of the procedure
     * @return array
     */
    public function callProc($strProcName, $strProcAction, $arrVals)
    {

        $pdo = $this->pdo;
        $parmaset = '';
        $debug = debug_enabled();

        if (debug_enabled()) {
            $debug = 1;
        }
        
        if (!empty($arrVals)) {

            foreach ($arrVals as $key => $val) {
                $parmaset .= '@p_' . $key . "='" . str_replace(array("'", "\\", '"'), array("''", "\\\\\\\\", '\"'), $val) . "',";
            }

            if ($debug) {
                $parmaset .= "@p_debug=1";
            }

            $parmaset = rtrim($parmaset, ',');

        } else {
            $parmaset .= "@p_empty='1'";
        }
        
         $sql = "CALL $strProcName('$strProcAction', \"$parmaset\")";
            //echo $sql;EXIT; 
            /*if($strProcAction == 'addticket'){
            echo $sql;EXIT; 
            }*/
    
         dbgl('sqls', $sql);

         $result_set = $this->execQuery($sql);
        // print_r($result_set);exit;

        if(!empty($result_set['error'])){
            return array('errors' => $pdo->errorInfo(), 'result' => []);  
        }

        if ($debug) {
            if (!empty($result_set)) {
                $result_set_copy = $result_set;
                $result = array_pop($result_set_copy);
                if(!empty($result))
                dbgl('sqls', '>> ' . $result[0][0]);
            }
            dbgl('sqls', '>> SQL Error: ' . $pdo->errorInfo()[1]);
        }
        //print "<pre>";print_r($result_set);exit;

        /*if ($debug) {
            array_pop($result_set);
        }*/
        //print_r($result_set);exit;

        if (empty($result_set)) {
            return array('errors' => $pdo->errorInfo()[1], 'result' => []);
        } else {
            return array('errors' => $pdo->errorInfo()[1], 'result' => $result_set[0]);
        }

    }

    /**
     * Executes the given sql query and returns the result set
     *
     * @param $strSql The sql query to be executed
     * @return array
     */
    public function execQuery($strSql)
    {
        $pdo = $this->pdo;
        try {

            $stmt = $pdo->prepare($strSql, [\PDO::ATTR_CURSOR => \PDO::CURSOR_SCROLL]);
            $exec = $stmt->execute();

        } catch (\Exception $ex) {
            echo vd('Error occured in query: <strong style="color:#f8ac59;">' . $strSql . '</strong>');
            return ['error'=>true, 'msg'=> $pdo->errorInfo()];

        }

        //if (!$exec) dd( $pdo->errorInfo());

        $result_set = [];
        do {
            try {
                $result_set[] = $stmt->fetchAll(\PDO::FETCH_BOTH);
            } catch (\Exception $ex) {

            }
        } while ($stmt->nextRowset());

        return $result_set;
    }
    
    public function insertMultipleRowData($arrData,$action) {
        $keys_length = count($arrData);
        $values_length = count($arrData[0]);
        $qry_total = '';
        for ($i = 0; $i < $keys_length; $i++) {
            $qry_total .= '(';
            $qry_vals = '';
            for ($j = 0; $j < $values_length; $j++) {
                $qry_vals .= "'" . $arrData[$i][$j] . "',";
            }
            $qry_vals = rtrim($qry_vals, ',');
            $qry_total .= $qry_vals . '),';
        }
        $qry_total = rtrim($qry_total, ',');
        unset($GLOBALS['db_success']);
        $GLOBALS['db_success'] = array('Record was successfully saved.');
        $sqlData['values'] = $qry_total;
        return $this->callProc($this->procs['d'], $action, $sqlData);
    }

    //Call any store procedure 

    public function callStoreProcedureWithParam($action, $arrConditions){
        return $this->callProc($this->procs['d'], $action, $arrConditions);
    }
}
