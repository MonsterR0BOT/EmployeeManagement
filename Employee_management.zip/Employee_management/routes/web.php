<?php

/*Route::get('/', function () {
    return view('welcome');
});*/
/*Route::get('dashboard', function () {
    return view('dashboard');
});*/
Route::match(['get', 'post'],'/', 'LoginController@showUserLogin');
###################ADMIN ROUTEDS#############################################
Route::get('dashboard', 'LoginController@showUserDashboard');
Route::get('member-dashboard', 'LoginMemberController@showDashboard');

Route::match(['get', 'post'],'adminpanel', 'LoginController@showLogin');
Route::match(['get', 'post'],'userlogin', 'LoginController@showUserLogin');

//login and change password
Route::match(['get', 'post'],'/login', 'LoginController@showLogin');
Route::post('post-login', 'LoginController@doAdminLogin');
Route::post('postuser-login', 'LoginController@doUserLogin');
Route::match(['get', 'post'],'/login-member', 'LoginMemberController@showMemberLogin');

Route::post('post-member-login', 'LoginMemberController@doMemberLogin');
//logout
Route::match(['get', 'post'],'/logout', 'LoginController@logout');
Route::match(['get', 'post'],'/logoutuser', 'LoginController@logoutuser');

Route::match(['get', 'post'],'/addAttendance', 'TeamController@addAttendance');

Route::match(['get', 'post'],'/member-logout', 'LoginMemberController@logout');
//Route::match(['get', 'post'],'set-language', 'LoginController@saveLanguage');
###################ADMIN ROUTEDS#############################################



Route::match(['get', 'post'], '{controller}/{action?}/{params1?}/{params2?}', function ($controller, $action = 'index', $params1 = '',$params2 = '') {
    $params = explode('/', $params1);
    $params[1] = $params2;
    $app = app();
    $controller = $app->make("\App\Http\Controllers\\" . ucwords($controller) . 'Controller');
    return $controller->callAction($action, $params);
});

