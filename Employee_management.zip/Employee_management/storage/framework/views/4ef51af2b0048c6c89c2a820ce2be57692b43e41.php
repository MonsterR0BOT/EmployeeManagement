<?php $__env->startSection('title', 'EMAIL'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Edit Email</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Edit Email</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      
      <!-- Default box -->
      <div class="box">
        <form role="form" id="emailForm" method="post" autocomplete="off" action="<?php echo e(url('email/saveEmail')); ?>">
          <?php echo e(csrf_field()); ?>

          <div class="box-body">
            <div class="row">
                <div class="col-md-6">
                  <?php
                    if(!empty($data)){
                        $emailId = $data[0]->TEM_Email;
                        $TEM_Email_Name  = $data[0]->TEM_Email_Name;
                        $TEM_Email_FromEmail = $data[0]->TEM_Email_FromEmail;
                        $TEM_Email_FromName = $data[0]->TEM_Email_FromName;
                        $TEM_Email_Subject = $data[0]->TEM_Email_Subject;
                        $TEM_Email_Body = $data[0]->TEM_Email_Body;
                    }else{
                        $emailId = '';
                        $TEM_Email_Name  = '';
                        $TEM_Email_FromEmail = '';
                        $TEM_Email_FromName = '';
                        $TEM_Email_Subject = '';
                        $TEM_Email_Body = '';
                    }
                    ?>
                   
                    <div class="form-group">
                      <label for="name">Email Name</label>
                      <input type="text" class="form-control" name="emailName" id="emailName" value="<?php echo!empty($TEM_Email_Name) ? $TEM_Email_Name : ''; ?>">
                    </div>

                    <div class="form-group">
                      <label for="name">From Email</label>
                      <input type="text" class="form-control" name="fromEmail" id="fromEmail" value="<?php echo!empty($TEM_Email_FromEmail) ? $TEM_Email_FromEmail : ''; ?>">
                    </div>

                    <div class="form-group">
                      <label for="name">From Name</label>
                      <input type="text" class="form-control" name="fromName" id="fromName" value="<?php echo!empty($TEM_Email_FromName) ? $TEM_Email_FromName : ''; ?>">
                    </div>

                    <div class="form-group">
                      <label for="name">Email Subject</label>
                      <input type="text" class="form-control" name="emailSubject" id="emailSubject" value="<?php echo!empty($TEM_Email_Subject) ? $TEM_Email_Subject : ''; ?>">
                    </div>
                </div>
                <div class="col-md-12">    
                    <div class="form-group">
                      <label for="description">Email Body</label>
                      <textarea class="form-control" name="emailBody" id="emailBody"><?php echo!empty($TEM_Email_Body) ? $TEM_Email_Body : ''; ?></textarea> 
                    </div>
                </div>
            </div>
          </div>
          <!-- /.box-body -->
          <div class="box-footer">
            <input type="hidden" name="hidEmail" value="<?php echo e($emailId); ?>"/>
            <button type="button" class="btn btn-primary" onclick="validateForm();">Submit</button>
             <a href="<?php echo e(url('email/viewEmail')); ?>"><button type="button" class="btn btn-warning" >Cancel</button></a>
          </div>
        </form>
      </div>
      <!-- /.box -->
      
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('scripts'); ?> 
<script type="text/javascript">
   function validateForm(){
      if (!blankValidation("emailName","TextField", "Email name can not be left blank"))
          return false;
      if (!blankValidation("fromEmail","TextField", "From email can not be left blank"))
          return false; 
      if (!blankValidation("fromName","TextField", "From name can not be left blank"))
          return false;   
      if (!blankValidation("emailSubject","TextField", "Email subject can not be left blank"))
          return false;  
     /* if (!blankValidation("emailBody","TextField", "Email Body can not be left blank"))
          return false; */
      $('#emailForm').submit();
   }  
   $(function () {
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    CKEDITOR.replace('emailBody')
    
  })
</script>  
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\wethefamily\resources\views/master/add-email-template.blade.php ENDPATH**/ ?>