<?php $__env->startSection('title', 'COUNTRY'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Add Country</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Add Country</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
    	
      <!-- Default box -->
      <div class="box">
       <!-- <div class="box-header">
          <h3 class="box-title">Quick Example</h3>
        </div>-->
        <!-- /.box-header -->
        <!-- form start -->
        <form role="form" method="post" action="<?php echo e(url('post-country')); ?>"  onsubmit="return validateForm()" autocomplete="off">
        	<?php echo csrf_field(); ?>
          <div class="box-body">
            <div class="row">
                <div class="col-md-6">
                	<?php
                    if(!empty($data)){
                    	$countryId = $data[0]->TCM_Country;
                        $TCM_Country_Name  = $data[0]->TCM_Country_Name ;
                        $TCM_Country_Code = $data[0]->TCM_Country_Code;
                        $TCM_Country_Active = $data[0]->TCM_Country_Active;
                    }else{
                    	$countryId = '';
                        $TCM_Country_Name  = '';
                        $TCM_Country_Code = '';
                        $TCM_Country_Active = 1;
                    }
                    ?>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Country Name</label>
                      <input type="text" class="form-control" name="countryName" id="countryName" value="<?php echo e($TCM_Country_Name); ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Country Code</label>
                      <input type="text" class="form-control" name="countryCode" id="countryCode" value="<?php echo e($TCM_Country_Code); ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputFile">Status</label>
                      <select class="form-control" name="countryActive" id="countryActive">
                      	<option value="">--Select--</option>
                        <option value="1" <?php if($TCM_Country_Active ==1): ?> selected="selected" <?php endif; ?>>Active</option>
                        <option value="0" <?php if($TCM_Country_Active ==0): ?> selected="selected" <?php endif; ?>>Inactive</option>
                      </select>
                    </div>
                </div>
            </div>
          </div>
          <!-- /.box-body -->
          <div class="box-footer">
          	<input type="hidden" name="hidCountry" value="<?php echo e($countryId); ?>"/>
            <button type="submit" class="btn btn-primary">Submit</button>
            <button type="button" class="btn btn-warning" onclick="window.location.href='manage-country-master'">Cancel</button>
          </div>
        </form>
      </div>
      <!-- /.box -->
      
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('scripts'); ?> 
<script type="text/javascript">
	 function validateForm(){
	 	//alert("alert");return false;
	  if (!blankValidation("countryName","TextField", "Country Name can not be left blank"))
		  return false;
	  if (!blankValidation("countryCode","TextField", "Country Code can not be left blank"))
		  return false;
	  if (!blankValidation("countryActive","TextField", "Status  can not be left blank"))
		  return false;
	 }  

</script>  
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opscautomation\resources\views/master/add-country-master.blade.php ENDPATH**/ ?>