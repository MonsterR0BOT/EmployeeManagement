    <footer class="footer">
            <div class="copy-right_text">
                <div class="container">
                    <div class="row" align="center">
                       <div class="footer-menu-all text-center" align="center">
                        <div class="row footer-menu">
                           <div class="col-md-3">
                            <a href="<?php echo e(url('department-list')); ?>">Departmenta</a>
                            </div>
                            <div class="col-md-3">
                            <a href="<?php echo e(url('order-notification')); ?>">Notifications</a>
                            </div>
                            <div class="col-md-3">
                            <a href="<?php echo e(url('faq')); ?>">FAQ</a>
                           </div>
                            <div class="col-md-3">
                            <a href="<?php echo e(url('contact-us')); ?>">Contact</a>
                        </div>
                        </div>
                    </div>
                </div>
                    <div class="row">
                        <div class="col-xl-12">
                            <p class="copy_right text-center">Copyright &copy;All rights reserved  by <a href="#" target="_blank">OPSC</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </footer><?php /**PATH D:\xampp\htdocs\opsc-demo\resources\views/frontend-layout/frontend-footer.blade.php ENDPATH**/ ?>