<?php $__env->startSection('title', 'CHANGE PASSWORD'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Change Password</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Dashboard</a></li>
        <li class="active">Change Password</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      
      <!-- Default box -->
      <div class="box">
        <?php if(Session::has('message')): ?>
        <div class="alert alert-success">                        
            <i class="fa fa-check"></i> <?php echo e(Session::get('message')); ?> 
        </div>
        <?php endif; ?>
       <!-- <div class="box-header">
          <h3 class="box-title">Quick Example</h3>
        </div>-->
        <!-- /.box-header -->
        <!-- form start -->
        <form role="form" action="<?php echo e(url('modify-password')); ?>" method="post" autocomplete="off" onsubmit="return validateForm();">
        <?php echo e(csrf_field()); ?>

          <div class="box-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                      <label for="newPassword">New Password</label>
                      <input type="password" class="form-control" name="newPassword" id="newPassword" value="" >
                    </div>
                    <div class="form-group">
                      <label for="confirmPassword">Confirm Password</label>
                      <input type="password" class="form-control" name="confirmPassword" id="confirmPassword" value="" >
                    </div>
                    
                </div>
            </div>
          </div>
          <!-- /.box-body -->
          <div class="box-footer">
            <button type="submit" class="btn btn-primary">Submit</button>
            <a href="<?php echo e(url('dashboard')); ?>"><button type="button" class="btn btn-warning" >Cancel</button></a>
          </div>
        </form>
      </div>
      <!-- /.box -->
      
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('scripts'); ?> 
<script type="text/javascript">
  function validateForm(){ //alert("here"); return false;
      if (!blankValidation("newPassword", "TextField","Give New Password"))
        return false;
      if (!blankValidation("confirmPassword", "TextField","Type Confirm Password"))
        return false;

      if($('#newPassword').val() != $('#confirmPassword').val()){
        swal("Sorry !! Mismatch Password");
        return false;
      }      
  }

</script>  
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-demo\resources\views/user/change-password.blade.php ENDPATH**/ ?>