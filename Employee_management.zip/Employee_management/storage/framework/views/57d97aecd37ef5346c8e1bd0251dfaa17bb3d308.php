  
  <?php $__env->startSection('title', 'SetAuthority'); ?>
  <?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h1>Add Page Labels</h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
          <li><a href="#">Master</a></li>
          <li class="active">Add Page Label</li>
        </ol>
      </section>

      <!-- Main content -->
      <section class="content">
      	
        <!-- Default box -->
        <div class="box">
         <!-- <div class="box-header">
            <h3 class="box-title">Quick Example</h3>
          </div>-->
          <!-- /.box-header -->
          <!-- form start -->
          <form role="form" method="post" action="<?php echo e(url('master/add-setauthority-master')); ?>"  onsubmit="return validateForm()" autocomplete="off">
            <?php echo csrf_field(); ?>
            <div class="box-body">
            <div class="row">
                <div class="col-md-6">
                  
                    <div class="form-group">
                      <label for="exampleInputEmail1">Page Name</label>
                     <input type="text" name="" class="form-control">
                    </div>
                                        
                </div>
            </div>
          </div>
          	<?php echo csrf_field(); ?>
            <table class="table" id="myTable" width="100%" border="0" cellspacing="2" cellpadding="5">
              <thead>
                <tr>
                  <th>Label Seq. No.</th>
                  <th>Language</th>
                  <th>Label Value</th>
                  <th>Action</th>
                </tr>
              </thead>
              <!-- for edit -->
              <tbody id="tbodyData">
                <tr class="tr_clone" 
                  th:each="a,iter:${userSetAuthority}">
                  <td valign="top">
                   <input type="text" name="" id="" class="form-control" size="2">
                  </td>
                  <td valign="top">
                    <select class="form-control userRoleNameCls" name="txtuserrole">
                      <option value="">--Select--</option>
                      <option value="1">English</option>
                      <option value="2">Odia</option>
                    </select>
                  </td>
                  <td valign="top">
                   <textarea name="" id="" class="form-control"></textarea>
                  </td>
                  <td valign="top">
                    <button type="button" class="btn btn-primary button-add tr_clone_add" name="add" onclick="addMore();">
                      <i class="fa fa-plus"></i>
                    </button>&nbsp;
                    <button style="display: none" type="button" class="btn btn-warning button-remove rmv" name="Remove">
                      <i class="fa fa-minus"></i>
                    </button>
                  </td>
                </tr>
                <!-- for add  -->
                
              </tbody>
            </table>

            <div class="box-footer">
            <button type="submit" class="btn btn-primary">Submit</button>
            <a href="<?php echo e(url('dashboard')); ?>"><button type="button" class="btn btn-warning">Cancel</button></a>
          </div>
        </form>
      </div>
        <!-- /.box -->
        
    </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
  <?php $__env->startPush('scripts'); ?> 
  <script type="text/javascript">
    /* Function for adding more Table row */
    $(document).ready(function(){
      var lengthOfTableRow = $("#tbodyData").children('tr').length;
      var lengthOfTableCol = $("#tbodyData").children('colspan').length;
      
      $('#myTable').on('click', '.rmv', function () {
        $(this).closest('tr').remove();
        $("#myTable tbody tr:last").find('td:last').html('');
        var add='<button type="button" class="btn btn-primary tr_clone_add" name="add" onclick="addMore();"><i class="fa fa-plus"></i></button>&nbsp;'
        var remove = '<button type="button" class="btn btn-warning button-remove rmv" name="Remove"><i class="fa fa-minus"></i></button>';
        if($("#tbodyData").children('tr').length > 1){
          $("#myTable tbody tr:last").find('td:last').append(add);
          $("#myTable tbody tr:last").find('td:last').append(remove);
        }else{
          $("#myTable tbody tr:last").find('td:last').append(add);
        }
        //displayTable();
      });
    });

    function addMore(){
      console.log('here==');
      var lengthOfTableRow = $("#tbodyData").children('tr').length;
      var lengthOfTableCol = $("#tbodyData").children('colspan').length;
      var cloneHtml = $("#myTable tbody tr:first").clone();
      $("#myTable tbody tr:last").find('td:last').html('');
      $("#myTable tbody").append($("#myTable tbody tr:first").clone());
      $("#myTable tbody tr td:last").html("");
      var addMore='<button type="button" class="btn btn-primary tr_clone_add" name="add" onclick="addMore();"><i class="fa fa-plus"></i></button>&nbsp;'
      var removeMore = '<button type="button" class="btn btn-warning button-remove rmv" name="Remove"><i class="fa fa-minus"></i></button>';

      $("#myTable tbody tr:last").find('td:last').append(addMore);
      $("#myTable tbody tr:last").find('td:last').append(removeMore);
      $("#myTable tbody tr:last").find('.userRoleNameCls').val("");
      $("#myTable tbody tr:last").find('.userNameCls').attr('checked',false);
      $("#myTable tbody tr:last").find('.tatClass').val("");

      var editTr = 0;

      if(lengthOfTableRow>editTr){
        $("#myTable tbody tr").eq(lengthOfTableRow-1).find('td:last').append(removeMore);
      }

     /* BLANK FIELD START */
      $("#myTable tbody tr:last").find(".userRoleNameCls").val("");
      $("#myTable tbody tr:last").find(".checkClass").hide();
      $("#myTable tbody tr:last").find(".checkClass1").hide();
      
      if($("#myTable tbody tr:last").find(".userRoleNameCls").val("")){
        $("#myTable tbody tr:last").find(".checkClass").empty();
      } 

      $("#myTable > tbody > tr").each(function(i){
        var selectInput = $(this).find('select');
        var textInput = $(this).find('input') ;
        var divInput = $(this).find('div') ;
        var checkBox = $(this).find('input:checkbox:first').attr('checked', 'checked');
        var buttonInput = $(this).find('button') ;
        
        selectInput.eq(0).attr('id',"userRole_"+i);
        textInput.eq(0).attr('id',"selectUser_"+i);   
        textInput.eq(textInput.length-1).attr('id',"TAT_"+i);
        divInput.eq(0).attr('id',"mselct_"+i);
        divInput.eq(4).attr('id',"mselct1_"+i);
        divInput.eq(3).attr('id',"checkboxes_"+i);
        divInput.eq(7).attr('id',"checkboxes1_"+i);
        buttonInput.eq(0).attr('id',"selectDiv_"+i);
        buttonInput.eq(1).attr('id',"selectDiv1_"+i);

      })
    }

  	function validateForm(){
  	 	//alert("alert");return false;
  	  if (!blankValidation("actionName","TextField", "Action Name can not be left blank"))
  		  return false;
  	}  

  </script>  
  <?php $__env->stopPush(); ?>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-demo\resources\views/master/add-page-label-master.blade.php ENDPATH**/ ?>