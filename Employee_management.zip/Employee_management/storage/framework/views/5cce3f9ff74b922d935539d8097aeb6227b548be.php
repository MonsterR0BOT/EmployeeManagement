<?php $__env->startSection('title', 'AQUATIC'); ?>
<?php $__env->startSection('content'); ?>
     <!--Page Title-->
    <section class="page-title" style="background-image:url('../public/images/innerbanner.jpg');">
        <div class="auto-container">
            <div class="inner-container clearfix">
                <div class="title-box">
                    <h1>New Arrivals</h1>
                </div>
                <ul class="bread-crumb clearfix">
                    <li><a href="index.html"><span class="fas fa-home"></span> Home</a></li>
                    <li><span class="far fa-arrow-alt-circle-right"></span> New Arrivals</li>
                </ul>
            </div>
        </div>
    </section>
    <!--End Page Title-->
    <section class="project-section">
        <div class="auto-container">
            <div class="row">
                <!-- Image Column -->
            <?php $__currentLoopData = $productDetiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
            <?php 
            $filename = asset('series_image/orig/'.$val->TPM_product_image); 
            ?>
               <div class="team-block col-lg-3 col-md-6 col-sm-12">
                    <div class="inner-box">
                        <div class="image-box">
                            <div class="image"><a href="#"><img src="<?php echo e($filename); ?>" alt="" class="img-thumbnail"></a></div>
                            
                        </div>
                        <div class="info-box">
                            <h3 class="name"><a href="team.html"><?php echo e($val->TPM_product_name); ?></a></h3>
                            <span class="designation"><?php echo e($val->TPM_product_series); ?></span>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>   
 <?php $__env->startPush('scripts'); ?>
 <!-- Write down javascript here -->
 <?php $__env->stopPush(); ?>   
<?php $__env->stopSection(); ?>   
<?php echo $__env->make('frontend-layout.frontend-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\aquatic\resources\views/newarrival.blade.php ENDPATH**/ ?>