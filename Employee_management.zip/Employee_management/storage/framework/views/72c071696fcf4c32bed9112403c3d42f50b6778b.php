<header>
<div class="header-area">
<div class="header-top_area">
  <div class="container">
    <div class="row">
      <div class="col-xl-6 col-md-6 ">
        <div class="row">
        <!--  <div class="col-md-4">
               <div class="language-btn">
           <a href=""><span class="label label-info">English</span></a> 
           <a href=""> <span class="label label-purple">ଓଡ଼ିଆ</span></a>
              </div>
        </div> -->
          <div class="col-md-8">
            <span class="one">
              <button type="button" onClick="switch_style('default');return false;" name="theme" value="default Theme" id="purple" class="colorbtn"></button>
            </span>
            <span class="two">
              <button type="button" onClick="switch_style('green');return false;" name="theme" value="green Theme" id="green" class="colorbtn"></button>
            </span>
            <span class="three">
              <button type="button" onClick="switch_style('blue');return false;" name="theme" value="blue Theme" id="blue"
            class="colorbtn"></button>
            </span>
            <span class="four">
              <button type="button" onClick="switch_style('yellow');return false;" name="theme" value="yellow Theme" id="yellow" class="colorbtn"></button>
            </span>
            <span class="five">
              <button type="button" onClick="switch_style('red');return false;" name="theme" value="red Theme" id="red" class="colorbtn"></button>
            </span>
          <!-- <span class="badge badge-primary" data-skin="skin-blue">T</span> 
          <span class="badge badge-warning" data-skin="skin-black">T</span> 
          <span class="badge badge-danger" data-skin="skin-purple">T</span>
          <span class="badge badge-success " data-skin="skin-green">T</span> -->
          </div>
        <div class="col-md-4">
        <span>
        <button id="button1" value="larger" type="button" onclick="changeFontSize(this)" class="fontbtn">A+</button>
        </span>
        <span>
        <button id="button3" value="deafult" type="button" onclick="changeFontSize(this)" class="fontbtn">A &nbsp; </button>
        </span>
        <span>
        <button id="button2" value="smaller" type="button" onclick="changeFontSize(this)" class="fontbtn">A-</button>
        </span>
        </div>
        </div>
      </div>
      <div class="col-xl-6 col-md-6">
        <div class="short_contact_list">
            <ul>
                <li><a href="#"> <i class="fa fa-envelope"></i> info@opsc.com</a></li>
                <li><a href="#"> <i class="fa fa-phone"></i> 9898986756</a></li>
            </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<div id="sticky-header" class="main-header-area">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-xl-4 col-lg-3">
                <div class="logo">
                    <a href="<?php echo e(url('/')); ?>">
                        <img src="<?php echo e(asset('dist/img/logo_opsc.png')); ?>" class="logo img-responsive"/>
                        <h3>OPSC</h3>
                        <h6>Odisha Public Service Commission</h6> 
                    </a>
                </div>
            </div>
           <!--  <div class="col-xl-5 col-lg-7">
                <div class="main-menu  d-none d-lg-block">
                    <nav>
                        <ul id="navigation">
                            <li><a class="active" href="<?php echo e(url('/')); ?>">Home</a></li>
                            <li><a href="<?php echo e(url('home/viewDepartment')); ?>">Departments</a></li>
                            <li><a href="<?php echo e(url('home/viewNotification')); ?>">Notifications</a></li>
                            <li><a href="<?php echo e(url('home/viewFaq')); ?>">FAQ</a></li>
                            <li><a href="<?php echo e(url('home/viewContact')); ?>">Contact</a></li>
                        </ul>
                    </nav>
                </div>
            </div> -->
           <!--  <div class="col-xl-3 col-lg-2 d-none d-lg-block">
                <div class="Appointment">
                    <?php if(Session::has('userId')): ?>
                    <div  align="center">
                       <div class="txt-white"><?php echo e(Helper::getUserName()); ?></div>
                        <div class="txt-white"> <i class="fa fa-dashboard"></i> <a href="<?php echo e(url('dashboard')); ?>"> Dashboard </a> &nbsp; &#124;&#124; &nbsp; <i class="fa fa-lock"></i> <a href="<?php echo e(url('logout')); ?>"> Log out</a></div>  
                    </div>
                    <?php else: ?>
                   <div class="book_btn d-none d-lg-block">
                        <a class="popup-with-form" href="<?php echo e(url('login')); ?>">Sign in</a>
                    </div> 
                    <?php endif; ?>
                </div>
            </div> -->
            <div class="col-12">
                <div class="mobile_menu d-block d-lg-none"></div>
            </div>
        </div>
    </div>
</div>
</div>
</header><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/frontend-layout/frontend-navigation.blade.php ENDPATH**/ ?>