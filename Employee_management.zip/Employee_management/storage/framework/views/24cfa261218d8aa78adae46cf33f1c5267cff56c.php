<?php $__env->startSection('title', 'DASHBOARD'); ?>
<?php $__env->startSection('content'); ?>  
  <section class="page_breadcrumbs ds background_cover section_padding_top_65 section_padding_bottom_65">
               <div class="container">
                  <div class="row">
                     <div class="col-sm-12 text-center">
                       <h2>Dashboard</h2>
                     </div>
                  </div>
               </div>
            </section>
            <section class="ls columns_padding_25 section_padding_top_100 section_padding_bottom_110">
               <div class="container">

                  <div class="row">
                        <div class="col-sm-7">
                            <h4>Dashboard</h4>
                        </div>
                        <div class="col-sm-5">
                        <div class="input-group">
                          <input type="text" class="form-control" placeholder="Serach"name="" id="param1">
                          <div class="input-group-append">
                            <button class="btn btn-warning">Serach</button>
                          </div>
                        </div>
                        </div>
                    </div>
                     <div class="row">
                  <div class="header_right_buttons display_table_cell text-right hidden-xs"><a href="profile.php" class="theme_button color3 margin_0">View/Edit your profile</a></div>
                   <div class="header_right_buttons display_table_cell text-right hidden-xs"><a href="<?php echo e(url('home/showMatrimony')); ?>" class="theme_button color3 margin_0">Post Matrimony</a></div>
                   <div class="header_right_buttons display_table_cell text-right hidden-xs"><a href="<?php echo e(url('home/showBlogPost')); ?>" class="theme_button color3 margin_0">Blog Post</a></div>
                </div>
                  <div class="row">
                     <div class="col-sm-12">
                        <div class="table-responsive">
                           <table role="table" class="dataTable">
                              <thead role="rowgroup">
                               <tr role="row">
                                    <th role="columnheader">Name Of The Member</th>
                                    <th role="columnheader">Age</th>
                                    <th role="columnheader">Date Of Birth</th>
                                    <th role="columnheader">Phone Number</th>
                                    <th role="columnheader">Email Id</th>
                                    <th role="columnheader">Occupation</th>
                              </tr>
                            </thead>
                            <tbody role="rowgroup">
                               <tr role="row">
                                    <td role="cell"><img class="img-circle" src="<?php echo e(asset('images/1.jpg')); ?>" alt=""> Hara Prasad</td>
                                    <td role="cell">31</td>
                                    <td role="cell">12/02/1986</td>
                                    <td role="cell">7978586866</td>
                                    <td role="cell">monalisa@nirmalyalabs.com</td>
                                    <td role="cell">UI/UX Designer</td>
                                 </tr>
                               <!-- <tr role="row">
                                    <td role="cell"><img class="img-circle" src="<?php echo e(asset('images/2.jpg')); ?>" alt=""> Monalisa</td>
                                    <td role="cell">26</td>
                                    <td role="cell"> 03/05/1993</td>
                                    <td role="cell">7978586866</td>
                                    <td role="cell">monalisa@nirmalyalabs.com</td>
                                    <td role="cell"> UI/UX Designer</td>
                                 </tr>
                                <tr role="row">
                                    <td role="cell"><img class="img-circle" src="<?php echo e(asset('images/2.jpg')); ?>" alt=""> Pratyusha</td>
                                    <td role="cell">24</td>
                                    <td role="cell"> 14/08/1995</td>
                                    <td role="cell">7978586866</td>
                                    <td role="cell">monalisa@nirmalyalabs.com</td>
                                    <td role="cell">UI/UX Designer</td>
                                 </tr>
                                <tr role="row">
                                    <td role="cell"><img class="img-circle" src="<?php echo e(asset('images/2.jpg')); ?>" alt=""> Saroja</td>
                                    <td role="cell">30</td>
                                    <td role="cell"> 14/08/1990</td>
                                    <td role="cell">7978586866</td>
                                    <td role="cell">monalisa@nirmalyalabs.com</td>
                                    <td role="cell">Lecture</td>
                                  </tr>
                                <tr role="row">
                                    <td role="cell"><img class="img-circle" src="<?php echo e(asset('images/2.jpg')); ?>" alt=""> Sarada</td>
                                    <td role="cell">24</td>
                                    <td role="cell"> 14/08/1996</td>
                                    <td role="cell">7978586866</td>
                                    <td role="cell">monalisa@nirmalyalabs.com</td>
                                    <td role="cell">Singer</td>
                                 </tr>
                                <tr role="row">
                                    <td role="cell"><img class="img-circle" src="<?php echo e(asset('images/2.jpg')); ?>" alt=""> Sangita</td>
                                    <td role="cell">25</td>
                                    <td role="cell"> 14/08/1996</td>
                                    <td role="cell">7978586866</td>
                                    <td role="cell">monalisa@nirmalyalabs.com</td>
                                    <td role="cell">Entrepreneur</td>
                                 </tr>
                                <tr role="row">
                                    <td role="cell"><img class="img-circle" src="<?php echo e(asset('images/2.jpg')); ?>" alt=""> Srabana</td>
                                    <td role="cell">31</td>
                                    <td role="cell"> 14/08/1989</td>
                                    <td role="cell">7978586866</td>
                                    <td role="cell">monalisa@nirmalyalabs.com</td>
                                    <td role="cell">Business Man</td>
                                 </tr> -->

                              </tbody>
                           </table>
                        </div>
                     </div>
                     <!--eof .col-sm-8 (main content)-->
                  </div>
               </div>
            </section>
         <?php $__env->stopSection(); ?> 
<?php echo $__env->make('frontend-layout.frontend-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\wethefamily\resources\views/Dashboard1.blade.php ENDPATH**/ ?>