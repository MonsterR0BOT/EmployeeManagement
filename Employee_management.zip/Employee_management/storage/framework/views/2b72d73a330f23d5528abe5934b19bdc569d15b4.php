 
 <?php $__env->startSection('title', 'NOTIFICATIONS'); ?>
 <?php $__env->startSection('content'); ?>
 
 <!-- Notification_area_start -->
   <div class="our_department_area">
    <div class="container">
          <div class="row">
            <div class="col-xl-12">
               <div class="section_title text-center mb-55">
                  <h3>Notification</h3>
               </div>
            </div>
         </div>
         <div class="row">
           <div class="col-md-12">
              <div class="order-notification">
                <?php $__currentLoopData = $notification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="row notification-section">
                    <div class="col-md-1">
                       <div class="notify-img">
                        <!--  <img src="<?php echo e(asset('dist/img/pdf.png')); ?>" class="img-responsive" />-->
                        <?php 
                          $filename = asset('upload_files/'.$val->TOM_Order_Path); 
                        ?>
                        <a href="<?php echo e($filename); ?>" target="_blank"><i class="fa fa-file-pdf-o" aria-hidden="true"></i></a>           
                       </div>
                    </div>
                    <div class="col-md-11">
                    <p>
                       <?php echo e($val->TOM_Order_Title); ?>

                    </p>
                    </div>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </div>
           </div>
        </div>
    </div>
   </div>
<!-- notification_area_end -->
<?php $__env->startPush('styles'); ?>
<style type="text/css">
  .fa-file-pdf-o {
      color: #f10;
      font-size: 26px;
  }
</style>
<?php $__env->stopPush(); ?>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend-layout.frontend-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/order-notification.blade.php ENDPATH**/ ?>