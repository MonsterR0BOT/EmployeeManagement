<!DOCTYPE html>
<html>
<head>
<style type="text/css">
body
{
  margin:0;
  font-family:tahoma;
  font-size: 12px;
  color:#333;
}
 .mainsec
 {
  width: 794px; background: #FFF; margin:0 auto; padding:0px; 
 }
 .detailcontent
 {
  margin-bottom: 55px;
  margin-top: 105px;
 }
td
 {
   padding:6px;
   border-top: 1px solid #333;
   border-left: 1px solid #333;
 }
td:last-child {
  border-right: 1px solid #333;
}
tbody tr:last-child td{
  border-bottom: 1px solid #333;
}
th
{
  border: 1px solid #333;
}

 .logoname
 {
  font-size: 24px;
  color:#3464b3;
  font-weight:600;
  padding-bottom:8px; 
  padding-top:10px; 
 }
 .heading
 {
  font-size: 24px;
  color:#333;
  font-weight:600;
  padding-bottom:8px; 
  padding-top:10px; 
 }
 .commentsec
 {
  border: 1px solid #ccc;
  background: #f5f5f5;
  padding: 10px;
  line-height: 22px;
 }
 .commentheading
 {
  background: #e4e5e6;
  font-size: 14px;
  border-bottom: 1px solid #ccc;
 }


  .content-block, p {
    page-break-inside: avoid;
  }

  html, body {
    width: 210mm;
    height: 297mm;
    margin:0  auto;
  }

thead {
 /* position:fixed;*/
  top: 0px;
  left: 50%;
  margin-left:-397px;
  border: 2px solid #000;
  z-index: 99;
  background: #e7e9ee;
}
.footer {
  position:relative;
  height:50px;
  background: #e7e9ee;
  bottom: 0;
  width: 779px;
  border:1px solid #000;
  line-height: 30px;
}
 @page  {
      margin-top:2cm;
      margin-bottom: 2cm;    
  }
  
 .logo
 {
  float: left;
  width: 80px;
  height: 80px;
 }
 .address
 {
  padding: 10px;
  text-align: right;
  width: 200px;
  float: right;
 }
 .logotext
 {
  float: left;
  width: 300px;
  margin-left: 10px;
 }
 @media  print {
.footer {
  position: fixed;
  height:18px;
  background: #e7e9ee;
  bottom: 0px;
  width: 780px;
  border:1px solid #000;
  line-height: 18px;
  font-size: 11px;
  }
 }
</style>
</head>
<body>
 <table cellpading="0" cellspacing="0" border="0" width="780">
  <thead>
     <tr>
      
       <th width="500" valign="top" align="left" colspan="6">
        <div class="logo"><img src="<?php echo e(asset('dist/img/logo_opsc.png')); ?>" height="80" width="80"></div>
        <div class="logotext">
        <div class="logoname">OPSC</div>
        <div>Odisha Public Service Commission</div>
      </div>
        <div class="address">Date : 21/7/2019<br> <br>
       Bhubaneswar</div>
       </th>
      
     </tr>
</thead>

<!-- CONTENT -->
<tbody>
   <tr>
         <td valign="top" bgcolor="#F5F5F5" width="15">1.</td>
         <td valign="top" bgcolor="#F5F5F5">Name of the Department</td>
         <td valign="top" bgcolor="#F5F5F5" colspan="4">Agriculture Dept. </td>
     </tr>
     <tr>
         <td valign="top" bgcolor="#F5F5F5">2.</td>
         <td valign="top" bgcolor="#F5F5F5">Name Designation of the promotional Post service</td>
         <td valign="top" bgcolor="#F5F5F5" colspan="2">Assistant Engg.</td>
         <td valign="top" bgcolor="#F5F5F5" colspan="2">Assistant Engg.</td>
     </tr>
     <tr>
         <td valign="top" bgcolor="#FFFFFF">3.</td>
         <td bgcolor="#FFFFFF">Name Designation of the feeder post service for which relaxation of qualifying service</td>
         <td valign="top" bgcolor="#F5F5F5" colspan="2">Assistant Engg.</td>
         <td valign="top" bgcolor="#F5F5F5" colspan="2">Assistant Engg.</td>
     </tr>
     <tr>
         <td valign="top" bgcolor="#F5F5F5">4.</td>
         <td bgcolor="#F5F5F5"> Name of the recruitment Rules with number & clause of the Rules for which relaxation is required.If no such Rules exist,mention the number and date of Resolution/Notification/Office Memorandum prescribing eligibility criteria.Copy of Rules G.O./Resolution/O.M/Notification to be appended.</td>
         <td bgcolor="#F5F5F5">Name of the recruitment Rules</td>
         <td bgcolor="#F5F5F5" colspan="3"> Lorem Iplusm</td>
     </tr>
      <tr>
         <td valign="top" bgcolor="#F5F5F5">&nbsp;</td>
         <td bgcolor="#F5F5F5">With number & clause of the Rules</td>
         <td bgcolor="#F5F5F5">Lorem iplusum</td>
         <td bgcolor="#F5F5F5">Date of Resolution</td>
         <td bgcolor="#F5F5F5" colspan="2">22/02/2012</td>
     </tr>
      <tr>
         <td valign="top" bgcolor="#FFFFFF">5.</td>
         <td bgcolor="#FFFFFF">Period of service prescribed in the recruitment Rules for promotion to the higher grade post.</td>
         <td valign="top" bgcolor="#FFFFFF" colspan="4">opsc</td>
      </tr>
      <tr>
         <td valign="top" bgcolor="#F5F5F5">6.</td>
         <td bgcolor="#F5F5F5">Period of service already gained by the incumbents in the feeder post.</td>
         <td bgcolor="#F5F5F5" colspan="4">6 months</td>
     </tr>
      <tr>
         <td valign="top" bgcolor="#FFFFFF">7.</td>
         <td bgcolor="#FFFFFF" >
(a)Period of service now proposed by Government for one time relaxation of qualifying service.(Such relaxation should not be more than 50% of the period of service prescribed in the Recruquitment Rules e.g., <strong>If the prescribed period of qualifying service is 10 years,the proposed relaxation should not exceed 05 years</strong>) </td>
         
        <td valign="top" bgcolor="#FFFFFF" colspan="4">lorem iplusm</td>
      </tr>
      <tr>
         <td valign="top" bgcolor="#FFFFFF">&nbsp;</td>
         <td bgcolor="#FFFFFF" >(b)Whether the officers under consideration have gathered adequate experience & knowledge required to hold the promotional post after relaxation.</td>
        <td valign="top" bgcolor="#FFFFFF" colspan="4">Yes</td>
      </tr>
       <tr>
         <td valign="top" bgcolor="#FFFFFF">8.</td>
         <td bgcolor="#FFFFFF">Whether the officers under consideration have already availed relaxation of qualifying service for promotion to the feeder grade.</td>
         
        <td valign="top" bgcolor="#FFFFFF" colspan="4">Yes</td>
      </tr>
      <tr>
         <td valign="top" bgcolor="#FFFFFF">8.</td>
         <td bgcolor="#FFFFFF">Number of occasions already availed by Govt. for relaxation of qualifying service for promotion to the proposed higher grade during the last three years.(Copy of letters containing concurrence of the OPSC need to be furnished.)</td>
         <td bgcolor="#FFFFFF" colspan="4"> Executive Engineer</td>
      </tr>
       <tr>
         <td valign="top" bgcolor="#FFFFFF">9.</td>
         <td bgcolor="#FFFFFF" >Name of the recruitment Rules regulatig the promotion proposed. If no such Rules exist. mention the number and date of Resolution/ Notification/ Office Memorandum proceeding eligibility criteria. (Copy of Rules with upto date ammendments/G.O./ Resolution/ OM/ Notification to be appended)</td>
         <td bgcolor="#FFFFFF">No of occasions</td>
         <td bgcolor="#FFFFFF">8</td>
         <td bgcolor="#FFFFFF">Year</td>
         <td valign="top" bgcolor="#FFFFFF">2018</td>
      </tr>
       <tr>
         <td valign="top" bgcolor="#F5F5F5">&nbsp;</td>
         <td bgcolor="#F5F5F5">Letter No</td>
         <td bgcolor="#F5F5F5">LIC346</td>
         <td bgcolor="#F5F5F5">Date Of concurrence of the O.P.S.C</td>
         <td bgcolor="#F5F5F5" colspan="2">2019</td>
      </tr>
      <tr>
         <td valign="top" bgcolor="#F5F5F5">10.</td>
         <td bgcolor="#F5F5F5">Whether orders of the Govt. have been taken for the proposed relaxation (Copy of Notification / order list sheet need to furnished)</td>
        <td valign="top" bgcolor="#F5F5F5" colspan="4">Yes</td>
      </tr>
      <tr>
         <td valign="top" bgcolor="#F5F5F5">11.</td>
         <td bgcolor="#F5F5F5">
Whether relaxation sought for the officer from the feeder grade belongs to the same category (Direct Recruitment Departmental Promotional in which vacancy is proposed to be filled up.)</td>
        <td valign="top" bgcolor="#F5F5F5" colspan="4">Yes</td>
      </tr>
       <tr>
            <td colspan="6" style="border-bottom:1px solid #333;">
              <div class="heading">Officer Comments</div>
              
                      <div class="commentsec">
                        <div class="commentheading"><strong>Prasanna Behera</strong>, Office Asst, Agriculture & F.E Department, 12 Aug 2019 23:30:45 </div>
                        <div>A new promotional reqest is posted.</div>
                      </div>
                    
                   <div>- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - </div>
                    
                      <div class="commentsec">
                        <div class="commentheading"><strong>Prakash Nayak</strong>, HOD Dept, Agriculture & F.E Department, 12 Aug 2019 23:30:45</div>
                        <div>The promotional request is verified and found ok and send to OPSC for further verification.</div>
                      </div>
                   
            </td>
          </tr>
</tbody>
</table>


<div class="footer" align="center">OPSC, Cuttack</div>

 </body>
</html>
<script>
window.print();
</script>
    

    <?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/relaxation/view-relaxation-print.blade.php ENDPATH**/ ?>