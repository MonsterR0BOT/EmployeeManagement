 <section class="services-section" style="background-image: url(images/bg1.jpg);">
        <div class="auto-container">    
            <div class="sec-title text-center">
                <h2>Our Series</h2>
            </div>
            <div class="services-box row clearfix">
                <div class="services-carousel owl-carousel owl-theme">
                    <!-- Service Block -->
                    <!-- Service Block -->
                    <div class="service-block">
                        <div class="inner-box">
                            <div class="icon-box" align="center">
                                <img src="<?php echo e(asset('images/icon/ruby.png')); ?>">
                            </div>
                            <div class="lower-content">
                                <h3><a href="#">Ruby</a></h3>
                                <div class="text">Planning and zoning are important tools for communities in that they provide the opportunity to establish sound and efficient land use patterns.</div>
                                <div class="link-box">
                                    <a href="#">Read More <i class="fa fa-chevron-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Service Block -->
                    <div class="service-block">
                        <div class="inner-box">
                            <div class="icon-box" align="center">
                               <img src="<?php echo e(asset('images/icon/art.png')); ?>">
                            </div>
                            <div class="lower-content">
                                <h3><a href="#">Art</a></h3>
                                <div class="text">Planning and zoning are important tools for communities in that they provide the opportunity to establish sound and efficient land use patterns.</div>
                                <div class="link-box">
                                    <a href="#">Read More <i class="fa fa-chevron-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Service Block -->
                    <div class="service-block">
                        <div class="inner-box">
                            <div class="icon-box" align="center">
                                <img src="<?php echo e(asset('images/icon/lotus-tap.png')); ?>">
                            </div>
                            <div class="lower-content">
                                <h3><a href="#">Lotus</a></h3>
                                <div class="text">Planning and zoning are important tools for communities in that they provide the opportunity to establish sound and efficient land use patterns.</div>
                                <div class="link-box">
                                    <a href="#">Read More <i class="fa fa-chevron-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Service Block -->
                    <div class="service-block">
                        <div class="inner-box">
                            <div class="icon-box" align="center">
                                <img src="<?php echo e(asset('images/icon/star.png')); ?>">
                            </div>
                            <div class="lower-content">
                                <h3><a href="#">Star</a></h3>
                                <div class="text">Planning and zoning are important tools for communities in that they provide the opportunity to establish sound and efficient land use patterns.</div>
                                <div class="link-box">
                                    <a href="#">Read More <i class="fa fa-chevron-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Service Block -->
                    <div class="service-block">
                        <div class="inner-box">
                            <div class="icon-box" align="center">
                               <img src="<?php echo e(asset('images/icon/titan.png')); ?>">
                            </div>
                            <div class="lower-content">
                                <h3><a href="#">Titan</a></h3>
                                <div class="text">Planning and zoning are important tools for communities in that they provide the opportunity to establish sound and efficient land use patterns.</div>
                                <div class="link-box">
                                    <a href="#">Read More <i class="fa fa-chevron-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div> 
                    <!-- Service Block -->
                    <div class="service-block">
                        <div class="inner-box">
                            <div class="icon-box" align="center">
                               <img src="<?php echo e(asset('images/icon/classic.png')); ?>">
                            </div>
                            <div class="lower-content">
                                <h3><a href="#">Classic</a></h3>
                                <div class="text">Planning and zoning are important tools for communities in that they provide the opportunity to establish sound and efficient land use patterns.</div>
                                <div class="link-box">
                                    <a href="#">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                     <!-- Service Block -->
                    <div class="service-block">
                        <div class="inner-box">
                            <div class="icon-box" align="center">
                               <img src="<?php echo e(asset('images/icon/shower.png')); ?>">
                            </div>
                            <div class="lower-content">
                                <h3><a href="#">Shower</a></h3>
                                <div class="text">Planning and zoning are important tools for communities in that they provide the opportunity to establish sound and efficient land use patterns.</div>
                                <div class="link-box">
                                    <a href="#">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section><?php /**PATH D:\xampp\htdocs\aquatic\resources\views/frontend-layout/series.blade.php ENDPATH**/ ?>