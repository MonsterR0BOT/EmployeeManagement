<?php $__env->startSection('title', 'MODULE'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Activity Master
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Activity Master</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="box">
       <!-- <div class="box-header">
          <h3 class="box-title">Data Table With Full Features</h3>
        </div>-->
        <!-- /.box-header -->
        <div class="box-body">
        	<div id="demo">
                <div class="search-field">
                    <div class="row">
                        <div class="col-md-2">
                            <div class="org-name">Activity Name</div>
                        </div>
                        <div class="col-md-3">
                            <input class="form-control" type="text" placeholder="" name="" id="param1">
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <button class="btn btn-primary" onClick="searchData()">Search</button>
                            </div>
                        </div>
                         <div class="col-md-5">
                            <div class="form-group pull-right">
                                <a href="<?php echo e(url('add-activity-master')); ?>"><button class="btn btn-primary">Add Activity</button></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--<a data-toggle="collapse" data-target="#demo"
                class="showhideangelbg"><i class="fa fa-angle-double-down"></i>
            </a>-->
          <table id="listAllActivity" class="table table-bordered table-striped">
            <thead>
            <tr>
              <th>Module Name</th>
              <th>Function Name</th>
              <th>Activity Name</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
            </thead>
            <tbody>
           
            </tbody>
          </table>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('styles'); ?>
<!--Extra styles can written here -->
<?php $__env->stopPush(); ?>  
<?php $__env->startPush('scripts'); ?>

<script>
  $(function () {
	$('#listAllActivity').DataTable({
		'processing' : true,
		'serverSide' : true,
		'searching' : false,
		'ordering' : false,
		"ajax" : {
			'url' : 'view-activity-throughAjax',
			'data' : function(d) {
				d.param1 = $('#param1').val();
				//d.param2 = $('#param2').val();

			}
		},
		'dataSrc' : "",
		'columns' : [ {
			'data' : 'TMM_Modl_Name'
		}, {
			'data' : 'TFM_Functn_Name'
		},{
			'data' : 'TAM_Actvty_Name'
		}, {
			'data' : 'TAM_Actvty_Status'
		}, {
			'data' : 'action'
		}

		]
	});
	
  });
  //Method For Searching Records In The List
	function searchData() {
		$('#listAllActivity').DataTable().draw();
	}
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-demo\resources\views/master/activity-master.blade.php ENDPATH**/ ?>