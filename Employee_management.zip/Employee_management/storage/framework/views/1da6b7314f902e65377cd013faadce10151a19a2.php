  
  <?php $__env->startSection('title', 'Set Page Label'); ?>
  <?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h1>Add Page Labels</h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
          <li><a href="#">Master</a></li>
          <li class="active">Add Page Label</li>
        </ol>
      </section>
      <!-- Main content -->
      <section class="content">
        <!-- Default box -->
        <div class="box">
          <!-- form start -->
            <form role="form" onsubmit="return validateForm()" autocomplete="off">
            <?php echo csrf_field(); ?>
              <div class="box-body">
                <?php if(Session::has('errors')): ?>
                  <div class="col-md-12 alert alert-warning">
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php echo e($error); ?><br/>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                <?php endif; ?>
              <div class="row">
                <div class="col-md-6">
                    <!-- <div class="form-group">
                      <label for="exampleInputEmail1">Page Name</label>
                     <input type="text" name="txtpagename" class="form-control" id="pageName" value="">
                    </div>  -->
                    <div class="form-group">
                      <label for="exampleInputEmail1">Page Name</label>
                      <select class="form-control userRoleNameCls" id="pageName" name="pagelname">
                       <option value="">--Select--</option>
                          <?php $__currentLoopData = $page_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($page->TPM_PageId); ?>"><?php echo e($page->TPM_PageName); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div> 
                </div>
              </div>
            </div>
            <?php echo csrf_field(); ?>
            <table class="table" id="myTable" width="100%" border="0" cellspacing="2" cellpadding="5">
              <thead>
                <tr>
                  <th>Label Seq. No.</th>
                  <th>Language</th>
                  <th>Label Value</th>
                  <th>Action</th>
                </tr>
              </thead>
              <!-- for edit -->
              <tbody id="tbodyData">
                <tr class="tr_clone">
                  <td valign="top">
                   <input type="text" id="levelSeq_0" name="levelSeq" class="form-control userseqCls" size="2" value="">
                  </td>
                  <td valign="top">
                    <select class="form-control userRoleNameCls" id="language_0" name="language">
                      <option value="">--Select--</option>
                      <option value="1">English</option>
                      <option value="2">Odia</option>
                    </select>
                  </td>
                  <td valign="top">
                    <textarea id="pageLevel_0" name="pageLevel" class="form-control userLevelCls"></textarea>
                  </td>
                  <td valign="top">
                    <button type="button" class="btn btn-primary button-add tr_clone_add" name="add" onclick="addMore();"><i class="fa fa-plus"></i>
                    </button>
                    <button style="display: none" type="button" class="btn btn-warning button-remove rmv" name="Remove"><i class="fa fa-minus"></i>
                    </button>
                  </td>
                </tr>
                <!-- for add  -->
              </tbody>
            </table>
            <div class="box-footer">

              <button type="button" id="submtBtn" class="btn btn-primary">Submit</button>
              <a href="<?php echo e(url('dashboard')); ?>"><button type="button" class="btn btn-warning">Cancel</button></a>
            </div>
        </form>
      </div>
        <!-- /.box -->
    </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
  <?php $__env->startPush('scripts'); ?> 
  <script type="text/javascript">
    /* Function for adding more Table row */
    $(document).ready(function(){
      var lengthOfTableRow = $("#tbodyData").children('tr').length;
      var lengthOfTableCol = $("#tbodyData").children('colspan').length;
      
      $('#myTable').on('click', '.rmv', function () {
        $(this).closest('tr').remove();
        $("#myTable tbody tr:last").find('td:last').html('');
        var add='<button type="button" class="btn btn-primary tr_clone_add" name="add" onclick="addMore();"><i class="fa fa-plus"></i></button>&nbsp;'
        var remove = '<button type="button" class="btn btn-warning button-remove rmv" name="Remove"><i class="fa fa-minus"></i></button>';
        if($("#tbodyData").children('tr').length > 1){
          $("#myTable tbody tr:last").find('td:last').append(add);
          $("#myTable tbody tr:last").find('td:last').append(remove);
        }else{
          $("#myTable tbody tr:last").find('td:last').append(add);
        }
        //displayTable();
      });
    });
    function addMore(){
      console.log('here==');
      var lengthOfTableRow = $("#tbodyData").children('tr').length;
      var lengthOfTableCol = $("#tbodyData").children('colspan').length;
      var cloneHtml = $("#myTable tbody tr:first").clone();
      $("#myTable tbody tr:last").find('td:last').html('');
      $("#myTable tbody").append($("#myTable tbody tr:first").clone());
      $("#myTable tbody tr td:last").html("");
      var addMore='<button type="button" class="btn btn-primary tr_clone_add" name="add" onclick="addMore(this);"><i class="fa fa-plus"></i></button>&nbsp;'
      var removeMore = '<button type="button" class="btn btn-warning button-remove rmv" name="Remove"><i class="fa fa-minus"></i></button>';

      $("#myTable tbody tr:last").find('td:last').append(addMore);
      $("#myTable tbody tr:last").find('td:last').append(removeMore);
      $("#myTable tbody tr:last").find('.userRoleNameCls').val("");
      $("#myTable tbody tr:last").find('.userseqCls').val("");
      $("#myTable tbody tr:last").find('.userLevelCls').val("");
      $("#myTable tbody tr:last").find('.userNameCls').attr('checked',false);
      $("#myTable tbody tr:last").find('.tatClass').val("");

      var editTr = 0;

      if(lengthOfTableRow>editTr){
        $("#myTable tbody tr").eq(lengthOfTableRow-1).find('td:last').append(removeMore);
      }

     /* BLANK FIELD START */
      $("#myTable tbody tr:last").find(".userRoleNameCls").val("");
      $("#myTable tbody tr:last").find(".checkClass").hide();
      $("#myTable tbody tr:last").find(".checkClass1").hide();
      
      if($("#myTable tbody tr:last").find(".userRoleNameCls").val("")){
        $("#myTable tbody tr:last").find(".checkClass").empty();
      } 

      $("#myTable > tbody > tr").each(function(i){
        var selectInput = $(this).find('select');
        var textInput = $(this).find('input');
        var textArea = $(this).find('textarea');  

        textInput.eq(textInput.length-1).attr('id',"levelSeq_"+i);
        selectInput.eq(0).attr('id',"language_"+i); 
        textArea.eq(0).attr('id',"pageLevel_"+i); 

      })
    }

  function validateForm(){
    var lengthOfTableRow = $("#tbodyData").children('tr').length;
    if (!blankValidation("pageName","SelectBox", "Page Name can not be left blank"))
      return false;

    for(var i=0; i<(lengthOfTableRow); i++){

       if (!blankValidation("levelSeq_"+i,"SelectBox", "Label Seq. No. can not be left blank"))
           return false;
       if (!blankValidation("language_"+i,"SelectBox", "Language can not be left blank"))
           return false;
       if (!blankValidation("pageLevel_"+i,"SelectBox", "Label Value can not be left blank"))
          return false;
      }
     return true;
   }

  $( document ).ready(function() {
    $("#submtBtn").click(function(){
      if(validateForm()){
          var dataset = [];
          $("#tbodyData > tr").each(function(i){
            data = {};
            data['pageName'] =  $("#pageName").val(); 
            data['levelSeq'] =  $("#levelSeq_"+i).val();
            data['language'] =  $("#language_"+i).val();
            data['pageLevel'] =  $("#pageLevel_"+i).val(); 
            
            dataset.push(data);
        }); 
        submitPageLevel(dataset);
      }else{
        return false;
      }
    });
  });

  function submitPageLevel (data){
      $.ajaxSetup({
        headers: {
        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
        }
      });
      swal.fire({
        title: "Do you want to submit?",
        text: "",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#e7b63a',
        confirmButtonText: 'Submit',
        reverseButtons : true 
      }).then((result) => {
      if(result.value){
        $.ajax({
          type : "POST",
          url : '<?php echo e(url("master/AddPageLabel")); ?>',
          dataType : "json",
          contentType : "application/json",
          data : JSON.stringify(data),
          success : function(response){
              console.log("response ",response);
              if(response.message=="success"){
                swal({
                  title:"Data saved successfully.",
                  type: "success",
                }).then(function(){
                })
              }else{
                swal({
                  title:"Sorry ! Some required fileds are missing",
                  type:"warning"
                })
              }
          },error:function(xhr, status, error){
            var err = eval("(" + xhr.responseText + ")");
            //console.log(err)
            swal(err.message.slice(err.message.indexOf('>:'),err.message.indexOf('(SQL:')).replace('>:',''));  
          }
        }) //ajax ends
      }
    });
  }

  $(document).ready(function(){ 
    $('#submtBtn').click(function(){ 
      
    });
  });

  $( "select[name='pagelname']" ).change(function () {
      $.ajaxSetup({
        headers: {
        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
        }
      });
      var pageID = $(this).val();
      var datastring="id="+pageID;
      $.ajax({
        type: "POST",
        url:'<?php echo e(url("master/getPageLabel")); ?>',
        data: {"id":pageID},
        success: function (response){
         //console.log(response);
          $("#myTable tbody  tr:not(:last)").empty();
            if (response.message == "success") {
              $("#myTable tbody").html(response.html);
            } else {
               
            }
        },
        error:function(xhr, status, error){
          var err = eval("(" + xhr.responseText + ")");
          console.log(err)
          swal(err.message.slice(err.message.indexOf('>:'),err.message.indexOf('(SQL:')).replace('>:',''));  
        }
      })
  });

</script>  
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\wethefamily\resources\views/master/add-page-label-master.blade.php ENDPATH**/ ?>