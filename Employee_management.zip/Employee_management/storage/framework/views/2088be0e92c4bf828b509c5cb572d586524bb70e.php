<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <title>Odisha Public Service Commission</title>
      <!-- Tell the browser to be responsive to screen width -->
      <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
      <link rel="stylesheet" href="<?php echo e(asset('dist/css/skins/_all-skins.min.css')); ?>">
      <!-- Bootstrap 3.3.7 -->
      <link rel="stylesheet" href="<?php echo e(asset('bower_components/bootstrap/dist/css/bootstrap.css')); ?>">
      <!-- Font Awesome -->
      <link rel="stylesheet" href="<?php echo e(asset('bower_components/font-awesome/css/font-awesome.min.css')); ?>">
      <!-- Ionicons -->
      <link rel="stylesheet" href="<?php echo e(asset('bower_components/Ionicons/css/ionicons.min.css')); ?>">
      <!-- Theme style -->
      <link rel="stylesheet" href="<?php echo e(asset('dist/css/AdminLTE.min.css')); ?>">
      <!--front Stle-->
      <link rel="stylesheet" href="<?php echo e(asset('bower_components/front/style_purple.css')); ?>">
      <!-- <link rel="stylesheet" href="<?php echo e(asset('bower_components/front/animate.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('bower_components/front/owl.carousel.min.css')); ?>"> -->
      <!-- Google Font -->
   </head>
   <body  style="overflow-x: hidden;">
      <div class="wrapper">
         <!-- Start Navigation -->
         <?php echo $__env->make('frontend-layout.frontend-navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- End Navigation -->
         <div class="clearfix"></div>
         <!-- slider_area_start -->
            <div id="demo" class="carousel slide" data-ride="carousel">
              <ul class="carousel-indicators">
                <li data-target="#demo" data-slide-to="0" class="active"></li>
                <li data-target="#demo" data-slide-to="1"></li>
                <li data-target="#demo" data-slide-to="2"></li>
              </ul>
              <div class="carousel-inner">
                <div class="carousel-item active">
                  <img src="<?php echo e(asset('dist/img/banner-new1.jpg')); ?>" class="img-fluid"/>
                  <div class="carousel-caption">
                    <h3>Promotion</h3>
                   <!--  <p>Banner Small Description ...</p> -->
                  </div>   
                </div>
                <div class="carousel-item">
                  <img src="<?php echo e(asset('dist/img/banner-new2.jpg')); ?>" class="img-fluid"/>
                  <div class="carousel-caption">
                    <h3>Proceddings for  case action</h3>
                   <!--  <p>Banner Small Description ...</p> -->
                  </div>   
                </div>
                <div class="carousel-item">
                  <img src="<?php echo e(asset('dist/img/banner-new3.jpg')); ?>" class="img-fluid"/>
                  <div class="carousel-caption">
                    <h3>Rules Regulation Relaxation</h3>
                    <!-- <p>Banner Small Description ...</p> -->
                  </div>   
                </div>
              </div>
              <a class="carousel-control-prev" href="#demo" data-slide="prev">
                <span class="carousel-control-prev-icon"></span>
              </a>
              <a class="carousel-control-next" href="#demo" data-slide="next">
                <span class="carousel-control-next-icon"></span>
              </a>
            </div>
         <!-- slider_area_end -->
         <!-- service_area_start -->
         <!-- service_area_end -->
         <!-- welcome_docmed_area_start -->
         <!-- welcome_docmed_area_end -->
         <!-- offers_area_start -->
         <div class="our_department_area">
            <div class="container">
               <div class="row">
                  <div class="col-xl-12">
                     <div class="section_title text-center mb-55">
                        <h3>Govertment Departments</h3>
                        <!--  <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers. <br>
                           It esteems luckily or picture placing drawing. </p> -->
                     </div>
                  </div>
               </div>
               <div class="row">
                  <div class="col-xl-4 col-md-6 col-lg-4">
                     <div class="single_department">
                       
                        <div class="department_content">
                           <h3><a href="#">Agriculture & F.E Department</a></h3>
                           <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-md-6 col-lg-4">
                     <div class="single_department">
                       
                        <div class="department_content">
                           <h3><a href="#">Commerce & Transport (Commerce)</a></h3>
                           <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-md-6 col-lg-4">
                     <div class="single_department">
                        
                        <div class="department_content">
                           <h3><a href="#">Co-Operation Department</a></h3>
                           <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-md-6 col-lg-4">
                     <div class="single_department">
                       
                        <div class="department_content">
                           <h3><a href="#">Excise Department</a></h3>
                           <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-md-6 col-lg-4">
                     <div class="single_department">
                       
                        <div class="department_content">
                           <h3><a href="#">Energy Department</a></h3>
                           <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-md-6 col-lg-4">
                     <div class="single_department">
                        
                        <div class="department_content">
                           <h3><a href="#">Electronic & I.T. Department</a></h3>
                           <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-md-6 col-lg-4">
                     <div class="single_department">
                        
                        <div class="department_content">
                           <h3><a href="#">Finance Department</a></h3>
                           <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-md-6 col-lg-4">
                     <div class="single_department">
                        
                        <div class="department_content">
                           <h3><a href="#">Fisheries & ARD Department</a></h3>
                           <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-md-6 col-lg-4">
                     <div class="single_department">
                       
                        <div class="department_content">
                           <h3><a href="#">Food Supplies & Consumer Welfare Department</a></h3>
                           <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-md-6 col-lg-4">
                     <div class="single_department">
                       
                        <div class="department_content">
                           <h3><a href="#">Forest & Env. Department</a></h3>
                           <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-md-6 col-lg-4">
                     <div class="single_department">
                       
                        <div class="department_content">
                           <h3><a href="#">G.A Department</a></h3>
                           <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-md-6 col-lg-4">
                     <div class="single_department">
                       
                        <div class="department_content">
                           <h3><a href="#">Handloom, Textiles & Handicrafts Department</a></h3>
                           <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-md-6 col-lg-4">
                     <div class="single_department">
                       
                        <div class="department_content">
                           <h3><a href="#">Health & F.W. Department</a></h3>
                           <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-md-6 col-lg-4">
                     <div class="single_department">
                       
                        <div class="department_content">
                           <h3><a href="#">Department Of Higher Education</a></h3>
                           <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-md-6 col-lg-4">
                     <div class="single_department">
                       
                        <div class="department_content">
                           <h3><a href="#">Home  Department</a></h3>
                           <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-md-6 col-lg-4">
                     <div class="single_department">
                       
                        <div class="department_content">
                           <h3><a href="#">Housing & U.D. Department</a></h3>
                           <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-md-6 col-lg-4">
                     <div class="single_department">
                       
                        <div class="department_content">
                           <h3><a href="#">Industries Department</a></h3>
                           <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-md-6 col-lg-4">
                     <div class="single_department">
                       
                        <div class="department_content">
                           <h3><a href="#">Information & Public Relations Department</a></h3>
                           <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-md-6 col-lg-4">
                     <div class="single_department">
                       
                        <div class="department_content">
                           <h3><a href="#">Labour & E.S.I Department</a></h3>
                           <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-md-6 col-lg-4">
                     <div class="single_department">
                       
                        <div class="department_content">
                           <h3><a href="#">Law Department</a></h3>
                           <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-md-6 col-lg-4">
                     <div class="single_department">
                       
                        <div class="department_content">
                           <h3><a href="#">Micro Small & Medium Enterprises Department</a></h3>
                           <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-md-6 col-lg-4">
                     <div class="single_department">
                       
                        <div class="department_content">
                           <h3><a href="#">Planning & Conservation Department</a></h3>
                           <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-md-6 col-lg-4">
                     <div class="single_department">
                       
                        <div class="department_content">
                           <h3><a href="#">Panchayati Raj Department</a></h3>
                           <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-md-6 col-lg-4">
                     <div class="single_department">
                       
                        <div class="department_content">
                           <h3><a href="#">P.A Department</a></h3>
                           <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-md-6 col-lg-4">
                     <div class="single_department">
                       
                        <div class="department_content">
                           <h3><a href="#">Revenue & D.M. Department</a></h3>
                           <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-md-6 col-lg-4">
                     <div class="single_department">
                       
                        <div class="department_content">
                           <h3><a href="#">Department Of Rural Department</a></h3>
                           <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-md-6 col-lg-4">
                     <div class="single_department">
                       
                        <div class="department_content">
                           <h3><a href="#">Department Of School & Mass. Education</a></h3>
                           <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-md-6 col-lg-4">
                     <div class="single_department">
                       
                        <div class="department_content">
                           <h3><a href="#">Micro Small & Medium Enterprises Department</a></h3>
                           <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-md-6 col-lg-4">
                     <div class="single_department">
                       
                        <div class="department_content">
                           <h3><a href="#">Science & Technology Department</a></h3>
                           <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-md-6 col-lg-4">
                     <div class="single_department">
                       
                        <div class="department_content">
                           <h3><a href="#">Skill & Development & Technical Education Department</a></h3>
                           <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
                        </div>
                     </div>
                  </div>
               <div class="col-xl-4 col-md-6 col-lg-4">
                  <div class="single_department">
                   
                     <div class="department_content">
                        <h3><a href="#">Sports & Culture</a></h3>
                        <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
                     </div>
                  </div>
               </div>

            <div class="col-xl-4 col-md-6 col-lg-4">
               <div class="single_department">
                  
                  <div class="department_content">
                     <h3><a href="#">Steel & Mines Department</a></h3>
                     <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
                  </div>
               </div>
            </div>
         
         <div class="col-xl-4 col-md-6 col-lg-4">
            <div class="single_department">
               
               <div class="department_content">
                  <h3><a href="#">S.T. & S.C. Development Department</a></h3>
                  <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
               </div>
            </div>
         </div>
      
      <div class="col-xl-4 col-md-6 col-lg-4">
         <div class="single_department">
            
            <div class="department_content">
               <h3><a href="#">Skill & Development & Technical Education Department</a></h3>
               <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
            </div>
         </div>
      </div>
     
      <div class="col-xl-4 col-md-6 col-lg-4">
         <div class="single_department">
          
            <div class="department_content">
               <h3><a href="#">Tourism & Culture Department</a></h3>
               <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
            </div>
         </div>
      </div>

      <div class="col-xl-4 col-md-6 col-lg-4">
         <div class="single_department">
          
            <div class="department_content">
               <h3><a href="#">Commerce & Transport (Transport)</a></h3>
               <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
            </div>
         </div>
      </div>

      <div class="col-xl-4 col-md-6 col-lg-4">
         <div class="single_department">
           
            <div class="department_content">
               <h3><a href="#">Department Of Water Resources</a></h3>
               <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
            </div>
         </div>
      </div>

      <div class="col-xl-4 col-md-6 col-lg-4">
         <div class="single_department">
           
            <div class="department_content">
               <h3><a href="#">Women & Child Development Department</a></h3>
               <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
            </div>
         </div>
      </div>
      <div class="col-xl-4 col-md-6 col-lg-4">
         <div class="single_department">
           
            <div class="department_content">
               <h3><a href="#">Works Department</a></h3>
               <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers.</p>
            </div>
         </div>
      </div>
      </div>
      </div>
      </div>
      <!-- offers_area_end -->
      <!-- footer start -->
 <?php echo $__env->make('frontend-layout.frontend-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- footer end  -->
      <!-- link that opens popup -->
      <!-- jQuery 3 -->
      <script src="<?php echo e(asset('bower_components/jquery/jquery.min.js')); ?>"></script>
      <!-- Bootstrap 3.3.7 -->
      <script src="<?php echo e(asset('bower_components/bootstrap/dist/js/bootstrap.js')); ?>"></script>
      <!-- AdminLTE App -->
      <!-- <script src="<?php echo e(asset('dist/js/adminlte.min.js')); ?>"></script> -->
      <!-- SlimScroll -->
      <script src="<?php echo e(asset('bower_components/jquery-slimscroll/jquery.slimscroll.min.js')); ?>"></script>
      <!-- sweet alert js -->
      <script src="<?php echo e(asset('js/sweetalert2.all.min.js')); ?>"></script>
      <!-- AdminLTE for demo purposes -->
      <!-- <script src="<?php echo e(asset('dist/js/demo.js')); ?>"></script> -->
      <!-- validator js -->
      <script src="<?php echo e(asset('js/validate.js')); ?>"></script>
   </body>
</html><?php /**PATH D:\xampp\htdocs\opsc-demo\resources\views/department.blade.php ENDPATH**/ ?>