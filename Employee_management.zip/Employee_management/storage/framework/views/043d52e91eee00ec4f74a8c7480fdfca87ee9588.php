<?php if(count($offDocListCRR)>0): ?>
<h6>CCR Files</h6>
<div class="col-md-12">
    <div class="row">
         <?php $__currentLoopData = $offDocListCRR; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-3 bg-color1"><?php echo e($val->TPCD_FinancialYear); ?>  <?php echo e($val->docName); ?></div>
          <div class="col-md-3"><a href="<?php echo e(url('public/storage/promotional_files')); ?>/<?php echo e($val->TPCD_DocumentName); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a> </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php endif; ?>
<?php if(count($offDocListNotCRR)>0): ?>
<h6>Vigilance Cases/Criminal Cases/Disciplinary Proceedings</h6>
<div class="col-md-12">
    <div class="row">
         <?php $__currentLoopData = $offDocListNotCRR; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
          <div class="col-md-3 bg-color1"><?php echo e($val->TPCD_FinancialYear); ?>  <?php echo e($val->docName); ?></div>
          <div class="col-md-3"><a href="<?php echo e(url('public/storage/promotional_files')); ?>/<?php echo e($val->TPCD_DocumentName); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a> </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    </div>
</div>
<?php endif; ?><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/promotional/ajax-officer-ccr-view.blade.php ENDPATH**/ ?>