<?php $__env->startSection('title', 'DASHBOARD'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Dashboard
        <!-- <small>Version 1.0</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->
      <div class="row">
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="ion ion-ios-people-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">USERS</span>
              <span class="info-box-number">90</span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-red"><i class="ion ion-ios-people-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">PROMOTIONS</span>
              <span class="info-box-number">410</span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->

        <!-- fix for small devices only -->
        <div class="clearfix visible-sm-block"></div>

        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-green"><i class="ion ion-ios-people-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">DISCIPLINARY</span>
              <span class="info-box-number">60</span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="ion ion-ios-people-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">RELAXATION</span>
              <span class="info-box-number">20</span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <div class="row">
         <div class="col-md-12">

          <!-- BAR CHART -->
          <div class="box box-success">
            <div class="box-header with-border">
              <h3 class="box-title">Monthly Chart</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <div class="box-body">
              <div class="chart">
                <canvas id="canvas" style="height:350px"></canvas>
              </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

     
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
      

        <div class="col-md-4">

          <!-- Pie Chart For Promotion -->
          <div class="box box-success" id="chartAreaP1">
            <div class="box-header with-border">
              <h3 class="box-title">Promotional Drill Down Chart</h3>

              <div class="box-tools pull-right">
              <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
               <!--  <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button> -->
              </div>
            </div>
            <div class="box-body">
              <div class="chart">
                <canvas id="chartareaP" style="height:350px"></canvas>
              </div>
            </div>
            <!-- /.box-body -->
          </div>  
          <!-- /.box -->
        </div>


        <div class="col-md-4"> 
          <!-- Pie Chart For Disciplinary -->
          <div class="box box-success" id="chartAreaD1">
            <div class="box-header with-border">
              <h3 class="box-title">Disciplinary Drill Down Chart</h3>

              <div class="box-tools pull-right">
              <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
               <!--  <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button> -->
              </div>
            </div>
            <div class="box-body">
              <div class="chart">
                <canvas id="chartareaD" style="height:350px"></canvas>
              </div>
            </div>
            <!-- /.box-body -->
          </div> 
          <!-- /.box -->
        </div>
        <!-- /.col -->


         <div class="col-md-4"> 
          <!-- Pie Chart For Promotion -->
          <div class="box box-success" id="chartAreaR1">
            <div class="box-header with-border">
              <h3 class="box-title">Relaxation Drill Down Chart</h3>

              <div class="box-tools pull-right">
              <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
               <!--  <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button> -->
              </div>
            </div>
            <div class="box-body">
              <div class="chart">
                <canvas id="chartareaR" style="height:350px"></canvas>
              </div>
            </div>
            <!-- /.box-body -->
          </div>  
          <!-- /.box -->
        </div>
        <!-- ########### Promotion Charts By Clicked InSide############ -->
        <div class="col-md-12">
        <div class="box box-success" id="expanded1" style="display: none;">
          <div class="box-header with-border">
          <h3 class="box-title">Department Wise Promotion</h3>

          <div class="box-tools pull-right">
            <button type="button" id="back1" style="text-align: right;" class="btn btn-primary"  ">Return Back</button>
             <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
            </button>
            <!-- <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button> -->
          </div>
        </div>
        <div class="box-body">
          <div class="chart">
            <canvas id="chartareaExp" style="height:350px"></canvas>
          </div>
        </div>
      <!-- /.box-body -->
      </div>


        <div class="box box-success" id="expanded2" style="display: none;">
            <div class="box-header with-border">
              <h3 class="box-title">Post Wise Promotion</h3>


              <div class="box-tools pull-right">
                 <button type="button" id="back2" style="text-align: right;" class="btn btn-primary"  ">Return Back</button>
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <!-- <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button> -->
              </div>
            </div>
            <div class="box-body">
              <div class="chart">
                <canvas id="chartareaExp2" style="height:350px"></canvas>
              </div>
            </div>
            <!-- /.box-body -->
          </div>


          <div class="box box-success" id="expanded3" style="display: none;">
            <div class="box-header with-border">
              <h3 class="box-title">Category Wise Promotion</h3>


              <div class="box-tools pull-right">
                 <button type="button" id="back3" style="text-align: right;" class="btn btn-primary"  ">Return Back</button>
                 <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
              <!--   <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button> -->
              </div>
            </div>
            <div class="box-body">
              <div class="chart">
                <canvas id="chartareaExp3" style="height:350px"></canvas>
              </div>
            </div>
            <!-- /.box-body -->
          </div>
        </div>

         <!-- ########### Disciplinary Charts By Clicked InSide############ -->
        <div class="col-md-12">
          <div class="box box-success" id="expandedDis1" style="display: none;">
          <div class="box-header with-border">
          <h3 class="box-title">Department Wise Disciplinary</h3>

          <div class="box-tools pull-right">
            <button type="button" id="backDis1" style="text-align: right;" class="btn btn-primary">Return Back</button>
             <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
            </button>
            <!-- <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button> -->
          </div>
        </div>
        <div class="box-body">
          <div class="chart">
            <canvas id="chartareaExpDis" style="height:350px"></canvas>
          </div>
        </div>
      <!-- /.box-body -->
      </div>


            <div class="box box-success" id="expandedDis2" style="display: none;">
            <div class="box-header with-border">
              <h3 class="box-title">Post Wise Disciplinary</h3>


              <div class="box-tools pull-right">
                 <button type="button" id="backDis2" style="text-align: right;" class="btn btn-primary">Return Back</button>
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <!-- <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button> -->
              </div>
            </div>
            <div class="box-body">
              <div class="chart">
                <canvas id="chartareaExpDis2" style="height:350px"></canvas>
              </div>
            </div>
            <!-- /.box-body -->
          </div>


             <div class="box box-success" id="expandedDis3" style="display: none;">
            <div class="box-header with-border">
              <h3 class="box-title">Category Wise Disciplinary</h3>


              <div class="box-tools pull-right">
                 <button type="button" id="backDis3" style="text-align: right;" class="btn btn-primary">Return Back</button>
                 <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
              <!--   <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button> -->
              </div>
            </div>
            <div class="box-body">
              <div class="chart">
                <canvas id="chartareaExpDis3" style="height:350px"></canvas>
              </div>
            </div>
            <!-- /.box-body -->
          </div>
        </div>

         <!-- ########### Relaxation Charts By Clicked InSide############ -->
        <div class="col-md-12">
          <div class="box box-success" id="expandedRex1" style="display: none;">
          <div class="box-header with-border">
          <h3 class="box-title">Department Wise Relaxation</h3>

          <div class="box-tools pull-right">
            <button type="button" id="backRex1" style="text-align: right;" class="btn btn-primary">Return Back</button>
             <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
            </button>
            <!-- <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button> -->
          </div>
        </div>
        <div class="box-body">
          <div class="chart">
            <canvas id="chartareaExpRex" style="height:350px"></canvas>
          </div>
        </div>
      <!-- /.box-body -->
      </div>


            <div class="box box-success" id="expandedRex2" style="display: none;">
            <div class="box-header with-border">
              <h3 class="box-title">Post Wise Relaxation</h3>


              <div class="box-tools pull-right">
                 <button type="button" id="backRex2" style="text-align: right;" class="btn btn-primary">Return Back</button>
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <!-- <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button> -->
              </div>
            </div>
            <div class="box-body">
              <div class="chart">
                <canvas id="chartareaExpRex2" style="height:350px"></canvas>
              </div>
            </div>
            <!-- /.box-body -->
          </div>


             <div class="box box-success" id="expandedRex3" style="display: none;">
            <div class="box-header with-border">
              <h3 class="box-title">Category Wise Relaxation</h3>


              <div class="box-tools pull-right">
                 <button type="button" id="backRex3" style="text-align: right;" class="btn btn-primary">Return Back</button>
                 <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
              <!--   <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button> -->
              </div>
            </div>
            <div class="box-body">
              <div class="chart">
                <canvas id="chartareaExpRex3" style="height:350px"></canvas>
              </div>
            </div>
            <!-- /.box-body -->
          </div>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        <!-- Left col -->
        <div class="col-md-4">
          <!-- TABLE: LATEST ORDERS -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Latest Promotions</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
               <!--  <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button> -->
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="table-responsive">
                <table class="table no-margin">
                  <thead>
                  <tr>
                    <th>Request Ref#</th>
                    <th>Department</th>
                    <th>Status</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td><a href="<?php echo e(url('view-cm-disciplinary-request-opsc')); ?>">PRO/2018-2019/1001</a></td>
                    <td>Works</td>
                    <td><span class="label label-info">Open</span></td>
                  </tr>
                  <tr>
                    <td><a href="<?php echo e(url('view-cm-disciplinary-request-opsc')); ?>">PRO/2018-2019/1002</a></td>
                    <td>Excise</td>
                    <td><span class="label label-info">Open</span></td>
                  </tr>
                  <tr>
                    <td><a href="<?php echo e(url('view-cm-disciplinary-request-opsc')); ?>">PRO/2018-2019/1003</a></td>
                    <td>Forest</td>
                    <td><span class="label label-info">Open</span></td>
                  </tr>
                  <tr>
                    <td><a href="<?php echo e(url('view-cm-disciplinary-request-opsc')); ?>">PRO/2018-2019/1004</a></td>
                    <td>Home</td>
                    <td><span class="label label-info">Open</span></td>
                  </tr>
                  <tr>
                    <td><a href="<?php echo e(url('view-cm-disciplinary-request-opsc')); ?>">PRO/2018-2019/1005</a></td>
                    <td>Revenue & Tax</td>
                    <td><span class="label label-info">Open</span></td>
                  </tr>
                  </tbody>
                </table>
              </div>
              <!-- /.table-responsive -->
            </div>
            <!-- /.box-body -->
            <div class="box-footer clearfix">
              <!-- <a href="javascript:void(0)" class="btn btn-sm btn-info btn-flat pull-left">Place New Order</a> -->
              <a href="<?php echo e(url('promotional/viewcommissionerPromotinal')); ?>" class="btn btn-sm btn-default btn-flat pull-right">View All Promotions</a>
            </div>
            <!-- /.box-footer -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->

        <div class="col-md-4">
           <!-- TABLE: LATEST ORDERS -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Latest Disciplinary Cases</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
               <!--  <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button> -->
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="table-responsive">
                <table class="table no-margin">
                  <thead>
                  <tr>
                    <th>Request Ref#</th>
                    <th>Department</th>
                    <th>Status</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td><a href="<?php echo e(url('view-cm-disciplinary-request-opsc')); ?>">DSCP/2018-2019/1001</a></td>
                    <td>Works</td>
                    <td><span class="label label-info">Open</span></td>
                  </tr>
                  <tr>
                     <td><a href="<?php echo e(url('view-cm-disciplinary-request-opsc')); ?>">DSCP/2018-2019/1002</a></td>
                    <td>Home</td>
                    <td><span class="label label-info">Open</span></td>
                  </tr>
                  <tr>
                     <td><a href="<?php echo e(url('view-cm-disciplinary-request-opsc')); ?>">DSCP/2018-2019/1003</a></td>
                    <td>Revenue & Tax</td>
                    <td><span class="label label-info">Open</span></td>
                  </tr>
                  <tr>
                    <td><a href="<?php echo e(url('view-cm-disciplinary-request-opsc')); ?>">DSCP/2018-2019/1004</a></td>
                    <td>Home</td>
                    <td><span class="label label-info">Open</span></td>
                  </tr>
                  <tr>
                     <td><a href="<?php echo e(url('view-cm-disciplinary-request-opsc')); ?>">DSCP/2018-2019/1005</a></td>
                    <td>Excise</td>
                    <td><span class="label label-info">Open</span></td>
                  </tr>
                  </tbody>
                </table>
              </div>
              <!-- /.table-responsive -->
            </div>
            <!-- /.box-body -->
            <div class="box-footer clearfix">
              <!-- <a href="javascript:void(0)" class="btn btn-sm btn-info btn-flat pull-left">Add New Request</a> -->
              <a href="<?php echo e(url('diciplinary/viewCommissionerDiciplinary')); ?>" class="btn btn-sm btn-default btn-flat pull-right">View All Disciplinary</a>
            </div>
            <!-- /.box-footer -->
          </div>
          <!-- /.box -->
          
        </div>
        <!-- /.col -->
        <!-- Left col -->
        <div class="col-md-4">
          <!-- TABLE: LATEST ORDERS -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Latest Relaxations</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
               <!--  <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button> -->
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="table-responsive">
                <table class="table no-margin">
                  <thead>
                  <tr>
                    <th>Request Ref#</th>
                    <th>Department</th>
                    <th>Status</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td><a href="<?php echo e(url('relaxation/viewCommissionerRelaxation')); ?>">RXA/2018-2019/1001</a></td>
                    <td>Works</td>
                    <td><span class="label label-info">Open</span></td>
                  </tr>
                  <tr>
                    <td><a href="<?php echo e(url('relaxation/viewCommissionerRelaxation')); ?>">RXA/2018-2019/1002</a></td>
                    <td>Excise</td>
                    <td><span class="label label-info">Open</span></td>
                  </tr>
                  <tr>
                   <td><a href="<?php echo e(url('relaxation/viewCommissionerRelaxation')); ?>">RXA/2018-2019/1003</a></td>
                    <td>Water Resources</td>
                    <td><span class="label label-info">Open</span></td>
                  </tr>
                  <tr>
                    <td><a href="<?php echo e(url('relaxation/viewCommissionerRelaxation')); ?>">RXA/2018-2019/1004</a></td>
                    <td>Home</td>
                    <td><span class="label label-info">Open</span></td>
                  </tr>
                  <tr>
                    <td><a href="<?php echo e(url('relaxation/viewCommissionerRelaxation')); ?>">RXA/2018-2019/1005</a></td>
                    <td>Forest</td>
                    <td><span class="label label-info">Open</span></td>
                  </tr>
                  </tbody>
                </table>
              </div>
              <!-- /.table-responsive -->
            </div>
            <!-- /.box-body -->
            <div class="box-footer clearfix">
              <!-- <a href="javascript:void(0)" class="btn btn-sm btn-info btn-flat pull-left">Place New Order</a> -->
              <a href="<?php echo e(url('relaxation/viewCommissionerRelaxation')); ?>" class="btn btn-sm btn-default btn-flat pull-right">View All Relaxations</a>
            </div>
            <!-- /.box-footer -->
          </div>
          <!-- /.box -->
        </div>

      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('scripts'); ?>
<script>
    var config33 = {
      type: 'line',
      data: {
        labels: ['January', 'February', 'March', 'April', 'May', 'June','July','August','September','October','November','December'],
        datasets: [{
          label: 'Promotional',
          backgroundColor:'rgba(100,168,10,0.9)',
          borderColor: 'rgba(100,168,10,0.9)',
          data: [95, 125, 143, 68, 114, 73,85,148,159,85,96,120],
          fill: false,
        }, {
          label: 'Disciplinary',
          backgroundColor:'rgba(243,156,18,0.9)',
          borderColor: 'rgba(243,156,18,0.9)',
          data: [65, 95, 83, 58, 134, 173,65,48,19,35,29,68],
          fill: false,
        },{
          label: 'Relaxation',
          fill: false,
          backgroundColor: 'rgba(150,158,210,0.9)',
          borderColor: 'rgba(150,158,210,0.9)',
          data: [75, 15, 103, 68, 24, 93,23,85,98,69,165,76,85],
        } ]
      },
      options: {
        responsive: true,
        title: {
          display: false,
          text: 'MIS Monthly Promotional VS Disciplinary VS Relaxation Chart'
        },
        tooltips: {
          mode: 'index',
          intersect: false,
        },
        /*hover: {
          mode: 'nearest',
          intersect: true
        },*/
        hover: {
                  mode: 'nearest',
                  "animationDuration": 0,
                  intersect: true
                },

                "animation": {
                "duration": 1,
                "onComplete": function () {
                  var chartInstance = this.chart,
                  ctx = chartInstance.ctx;

                  ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
                  ctx.textAlign = 'left';
                  ctx.textBaseline = 'bottom';

                  this.data.datasets.forEach(function (dataset, i) {
                    var meta = chartInstance.controller.getDatasetMeta(i);
                    meta.data.forEach(function (bar, index) {
                      var data = dataset.data[index];                            
                      ctx.fillText(data, bar._model.x, bar._model.y - 5);
                    });
                  });
                }
              },
              scales: {
                xAxes: [{
                  display: true,
                  scaleLabel: {
                    display: true,
                    labelString: 'Monthly'
                  }
                }], 
                 yAxes: [{
                          ticks: {
                              beginAtZero: true
                          }
                      }]
              }
          }
    };

    $(function () {
      var ctx33 = document.getElementById('canvas').getContext('2d');
      window.myLine = new Chart(ctx33, config33);

      
    }); 


    
 /*################ PIE CHART FOR PROMOTION #########################*/
    var configPie = {
      type: 'pie',
      data: {
        datasets: [{
          data: [20,35,40,10,15,30],
          backgroundColor: [
          'rgba(60,141,188,1)',
          'rgba(0,192,239,1)',
          'rgba(243,156,18,1)',
          'rgba(221,75,57,1)',
          'rgba(0,166,90,1)',
          'rgba(100,168,10,1)'
          ],
          label: 'Pie Chart'
        }],
        labels: [
          'New',
          'Open',
          'Returned',
          'Rejected',
          'Approved',
          'Accepted'
        ]
      },
      options: {
        responsive: true
      }
    };



    $(function () {
      //////////////
      var ctx1 = document.getElementById('barChart').getContext('2d');
      window.myBar = new Chart(ctx1, {
        type: 'bar',
        data: barChartData,
        options: {
          responsive: true,
          legend: {
            position: 'top',
          },
          hover: {
            mode: 'nearest',
            "animationDuration": 0,
            intersect: true
          },

          "animation": {
              "duration": 1,
              "onComplete": function () {
                var chartInstance = this.chart,
                ctx = chartInstance.ctx;
                
                ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
                ctx.textAlign = 'center';
                ctx.textBaseline = 'botton';

                this.data.datasets.forEach(function (dataset, i) {
                  var meta = chartInstance.controller.getDatasetMeta(i);
                  meta.data.forEach(function (bar, index) {
                    var data = dataset.data[index];                            
                    ctx.fillText(data, bar._model.x, bar._model.y - 5);
                  });
                });
              }
          },
          title: {
            display: false,
            text: 'Audit Weekly Promotional Chart'
          }
        }
      });
      ////////////////
      var ctx = document.getElementById('pieChart').getContext('2d');
      window.myPie = new Chart(ctx, configPie);
    }); 
    
    var config = {
      type: 'pie',
      data: {
        datasets: [{
          data: [200,350,400,100,150,300],
          backgroundColor: [
          'rgba(60,141,188,1)',
          'rgba(0,192,239,1)',
          'rgba(243,156,18,1)',
          'rgba(221,75,57,1)',
          'rgba(0,166,90,1)',
          'rgba(100,168,10,1)'
          ],
          label: 'Pie Chart'
        }],
        labels: ['New','Open','Returned','Rejected','Approved', 'Accepted']
      },
      options: {
        responsive: true
      }
    };

    $(function () { 
      var ctx = document.getElementById('chartareaP').getContext('2d');
      window.myPie = new Chart(ctx, config); 

      chartareaP.onclick = function(evt) { 
             var activePoints = myPie.getElementsAtEvent(evt);
             if (activePoints[0]) {
               var chartData = activePoints[0]['_chart'].config.data;
               var idx = activePoints[0]['_index'];

               var label = chartData.labels[idx];
               var value = chartData.datasets[0].data[idx];
               var color = chartData.datasets[0].backgroundColor[idx];  
               showAnother(value,label);
             } 
          }; 

          back1.onclick = function(evt) {
            $("#expanded1").hide(); 
            $("#chartAreaP1").show(); 
            $("#chartAreaD1").show(); 
            $("#chartAreaR1").show();
          }; 

          back2.onclick = function(evt) { 
            $("#expanded1").show();
            $("#expanded2").hide();
          }; 

          back3.onclick = function(evt) { 
            $("#expanded2").show();
            $("#expanded3").hide();
          };  

          backDis1.onclick = function(evt) { 
            $("#expandedDis1").hide(); 
            $("#chartAreaP1").show(); 
            $("#chartAreaD1").show(); 
            $("#chartAreaR1").show();
          };

          backDis2.onclick = function(evt) { 
            $("#expandedDis1").show();
            $("#expandedDis2").hide();
          };

          backDis3.onclick = function(evt) { 
            $("#expandedDis2").show();
            $("#expandedDis3").hide();
          };

          backRex1.onclick = function(evt) { 
            $("#expandedRex1").hide(); 
            $("#chartAreaP1").show(); 
            $("#chartAreaD1").show(); 
            $("#chartAreaR1").show();
          };

          backRex2.onclick = function(evt) { 
            $("#expandedRex1").show();
            $("#expandedRex2").hide();
          };

          backRex3.onclick = function(evt) { 
            $("#expandedRex2").show();
            $("#expandedRex3").hide();
          };
    }); 

    var config1 = { 
      type: 'bar',
      data: {
        labels: ['2019-2020'],
        datasets: [{
          label: 'Home',
          backgroundColor:'rgba(97,50,105,0.9)',
          borderColor: 'rgba(97,50,105,0.9)',
          data: [34],
          fill: false,
        }, {
          label: 'Excise & Duty',
          fill: false,
          backgroundColor: 'rgba(247,122,26,0.9)',
          borderColor:  'rgba(247,122,26,0.9)',
          data: [82],
        }, {
          label: 'Mines',
          fill: false,
          backgroundColor: 'rgba(174,189,26,0.9)',
          borderColor:  'rgba(174,189,26,0.9)',
          data: [71],
        }, {
          label: 'Water Reserve',
          fill: false,
          backgroundColor: 'rgba(209,21,71,0.9)',
          borderColor: 'rgba(209,21,71,0.9)',
          data: [54],
        }, {
          label: 'Custom',
          fill: false,
          backgroundColor: 'rgba(27,12,86,0.9)',
          borderColor:  'rgba(27,12,86,0.9)',
          data: [29],
        }, {
          label: 'Agriculture',
          fill: false,
          backgroundColor: 'rgba(74,89,126,0.9)',
          borderColor:  'rgba(74,89,126,0.9)',
          data: [21],
        }, {
          label: 'Education',
          fill: false,
          backgroundColor: 'rgba(59,21,111,0.9)',
          borderColor: 'rgba(59,21,111,0.9)',
          data: [59],
        }]
      },
      options: {
        responsive: true,
        title: {
          display: false,
          text: 'MIS Yearly Promotional Cases'
        },
        tooltips: {
          mode: 'index',
          intersect: false,
        },
        hover: {
          mode: 'nearest',
          "animationDuration": 0,
          intersect: true
        },

        "animation": {
                "duration": 1,
          "onComplete": function () {
            var chartInstance = this.chart,
              ctx = chartInstance.ctx;
            
            ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
            ctx.textAlign = 'center';
            ctx.textBaseline = 'bottom';

            this.data.datasets.forEach(function (dataset, i) {
              var meta = chartInstance.controller.getDatasetMeta(i);
              meta.data.forEach(function (bar, index) {
                var data = dataset.data[index];                            
                ctx.fillText(data, bar._model.x, bar._model.y - 5);
              });
            });
          }
                },
        scales: {
          xAxes: [{
            display: true,
            scaleLabel: {
              display: true,
              labelString: 'Yearly'
            }
          }], 
           yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
        }
      }
    };

    function showAnother(value,label){ 
       $("#chartAreaP1").hide();
       $("#chartAreaD1").hide();
       $("#chartAreaR1").hide();
       $("#expanded1").show();

      var ctx1 = document.getElementById('chartareaExp').getContext('2d');
      window.myLine = new Chart(ctx1, config1); 
      chartareaExp.onclick = function(evt) { 
             var activePoints = myLine.getElementsAtEvent(evt); 
             if (activePoints[0]) {
               var chartData = activePoints[0]['_chart'].config.data;
               var idx = activePoints[0]['_index'];

               var label = chartData.labels[idx];
               var value = chartData.datasets[0].data[idx];
               var color = chartData.datasets[0].backgroundColor[idx];  
               showAnother2(value,label);
             } 
          };
    }

      var config2 = {
      type: 'bar',
      data: {
        labels: ['2019-2020'],
        datasets: [{
          label: 'SP',
          backgroundColor:'rgba(97,50,105,0.9)',
          borderColor: 'rgba(97,50,105,0.9)',
          data: [4],
          fill: false,
        }, {
          label: 'DSP',
          fill: false,
          backgroundColor: 'rgba(247,122,26,0.9)',
          borderColor:  'rgba(247,122,26,0.9)',
          data: [8],
        }, {
          label: 'Inspector',
          fill: false,
          backgroundColor: 'rgba(174,189,26,0.9)',
          borderColor:  'rgba(174,189,26,0.9)',
          data: [24],
        }, {
          label: 'Sub Inspector',
          fill: false,
          backgroundColor: 'rgba(209,21,71,0.9)',
          borderColor: 'rgba(209,21,71,0.9)',
          data: [26],
        }, {
          label: ' Assistant Sub Inspector',
          fill: false,
          backgroundColor: 'rgba(27,12,86,0.9)',
          borderColor:  'rgba(27,12,86,0.9)',
          data: [20],
        } ]
      },
      options: {
        responsive: true,
        title: {
          display: false,
          text: 'MIS Yearly Promotional Cases'
        },
        tooltips: {
          mode: 'index',
          intersect: false,
        },
        hover: {
          mode: 'nearest',
          "animationDuration": 0,
          intersect: true
        },

        "animation": {
                "duration": 1,
          "onComplete": function () {
            var chartInstance = this.chart,
              ctx = chartInstance.ctx;
            
            ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
            ctx.textAlign = 'center';
            ctx.textBaseline = 'bottom';

            this.data.datasets.forEach(function (dataset, i) {
              var meta = chartInstance.controller.getDatasetMeta(i);
              meta.data.forEach(function (bar, index) {
                var data = dataset.data[index];                            
                ctx.fillText(data, bar._model.x, bar._model.y - 5);
              });
            });
          }
                },
        scales: {
          xAxes: [{
            display: true,
            scaleLabel: {
              display: true,
              labelString: 'Yearly'
            }
          }], 
           yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
        }
      }
    };

    function showAnother2(value,label){ 
       $("#expanded1").hide();
       $("#expanded2").show();

      var ctx2 = document.getElementById('chartareaExp2').getContext('2d');
      window.myLine = new Chart(ctx2, config2);

      chartareaExp2.onclick = function(evt) { 
             var activePoints = myLine.getElementsAtEvent(evt); 
             if (activePoints[0]) {
               var chartData = activePoints[0]['_chart'].config.data;
               var idx = activePoints[0]['_index'];

               var label = chartData.labels[idx];
               var value = chartData.datasets[0].data[idx];
               var color = chartData.datasets[0].backgroundColor[idx];  
               showAnother3(value,label);
             } 
          }; 
    }


    var config3 = {
      type: 'bar',
      data: {
        labels: ['2019-2020'],
        datasets: [{
          label: 'SC',
          backgroundColor:'rgba(97,50,105,0.9)',
          borderColor: 'rgba(97,50,105,0.9)',
          data: [10],
          fill: false,
        }, {
          label: 'ST',
          fill: false,
          backgroundColor: 'rgba(247,122,26,0.9)',
          borderColor:  'rgba(247,122,26,0.9)',
          data: [2],
        }, {
          label: 'Unreserved',
          fill: false,
          backgroundColor: 'rgba(174,189,26,0.9)',
          borderColor:  'rgba(174,189,26,0.9)',
          data: [14],
        }  ]
      },
      options: {
        responsive: true,
        title: {
          display: false,
          text: 'MIS Yearly Promotional Cases'
        },
        tooltips: {
          mode: 'index',
          intersect: false,
        },
        hover: {
          mode: 'nearest',
          "animationDuration": 0,
          intersect: true
        },

        "animation": {
                "duration": 1,
          "onComplete": function () {
            var chartInstance = this.chart,
              ctx = chartInstance.ctx;
            
            ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
            ctx.textAlign = 'center';
            ctx.textBaseline = 'bottom';

            this.data.datasets.forEach(function (dataset, i) {
              var meta = chartInstance.controller.getDatasetMeta(i);
              meta.data.forEach(function (bar, index) {
                var data = dataset.data[index];                            
                ctx.fillText(data, bar._model.x, bar._model.y - 5);
              });
            });
          }
                },
        scales: {
          xAxes: [{
            display: true,
            scaleLabel: {
              display: true,
              labelString: 'Yearly'
            }
          }], 
           yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
        }
      }
    };



    function showAnother3(value,label){ 
       $("#expanded2").hide();
       $("#expanded3").show();

      var ctx3 = document.getElementById('chartareaExp3').getContext('2d');
      window.myLine = new Chart(ctx3, config3); 
    }

   
     /*################ PIE CHART FOR DISCIPLINARY #########################*/
    var configDis = {
      type: 'pie',
      data: {
        datasets: [{
          data: [36,274,237,72,189,201],
          backgroundColor: [
          'rgba(60,141,188,1)',
          'rgba(0,192,239,1)',
          'rgba(243,156,18,1)',
          'rgba(221,75,57,1)',
          'rgba(0,166,90,1)',
          'rgba(100,168,10,1)'
          ],
          label: 'Pie Chart'
        }],
        labels: ['New','Open','Returned','Rejected','Approved', 'Accepted']
      },
      options: {
        responsive: true
      }
    };

    $(function () { 
      var ctxDis = document.getElementById('chartareaD').getContext('2d');
      window.myPie = new Chart(ctxDis, configDis); 

      chartareaD.onclick = function(evt) {  
             var activePoints = myPie.getElementsAtEvent(evt);
             if (activePoints[0]) {
               var chartData = activePoints[0]['_chart'].config.data;
               var idx = activePoints[0]['_index'];

               var label = chartData.labels[idx];
               var value = chartData.datasets[0].data[idx];
               var color = chartData.datasets[0].backgroundColor[idx];  
               showAnotherDis(value,label);
             } 
          }; 
    }); 

    var configDis1 = { 
      type: 'bar',
      data: {
        labels: ['2019-2020'],
        datasets: [{
          label: 'Home',
          backgroundColor:'rgba(97,50,105,0.9)',
          borderColor: 'rgba(97,50,105,0.9)',
          data: [34],
          fill: false,
        }, {
          label: 'Excise & Duty',
          fill: false,
          backgroundColor: 'rgba(247,122,26,0.9)',
          borderColor:  'rgba(247,122,26,0.9)',
          data: [82],
        }, {
          label: 'Mines',
          fill: false,
          backgroundColor: 'rgba(174,189,26,0.9)',
          borderColor:  'rgba(174,189,26,0.9)',
          data: [71],
        }, {
          label: 'Water Reserve',
          fill: false,
          backgroundColor: 'rgba(209,21,71,0.9)',
          borderColor: 'rgba(209,21,71,0.9)',
          data: [54],
        }, {
          label: 'Custom',
          fill: false,
          backgroundColor: 'rgba(27,12,86,0.9)',
          borderColor:  'rgba(27,12,86,0.9)',
          data: [29],
        }, {
          label: 'Agriculture',
          fill: false,
          backgroundColor: 'rgba(74,89,126,0.9)',
          borderColor:  'rgba(74,89,126,0.9)',
          data: [21],
        }, {
          label: 'Education',
          fill: false,
          backgroundColor: 'rgba(59,21,111,0.9)',
          borderColor: 'rgba(59,21,111,0.9)',
          data: [59],
        }]
      },
      options: {
        responsive: true,
        title: {
          display: false,
          text: 'MIS Yearly Disciplinary Cases'
        },
        tooltips: {
          mode: 'index',
          intersect: false,
        },
        hover: {
          mode: 'nearest',
          "animationDuration": 0,
          intersect: true
        },

        "animation": {
                "duration": 1,
          "onComplete": function () {
            var chartInstance = this.chart,
              ctx = chartInstance.ctx;
            
            ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
            ctx.textAlign = 'center';
            ctx.textBaseline = 'bottom';

            this.data.datasets.forEach(function (dataset, i) {
              var meta = chartInstance.controller.getDatasetMeta(i);
              meta.data.forEach(function (bar, index) {
                var data = dataset.data[index];                            
                ctx.fillText(data, bar._model.x, bar._model.y - 5);
              });
            });
          }
                },
        scales: {
          xAxes: [{
            display: true,
            scaleLabel: {
              display: true,
              labelString: 'Yearly'
            }
          }], 
           yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
        }
      }
    };

    function showAnotherDis(value,label){ 
       $("#chartAreaP1").hide();
       $("#chartAreaD1").hide();
       $("#chartAreaR1").hide();
       $("#expandedDis1").show();

      var ctxDis1 = document.getElementById('chartareaExpDis').getContext('2d');
      window.myLine = new Chart(ctxDis1, configDis1); 
      chartareaExpDis.onclick = function(evt) { 
             var activePoints = myLine.getElementsAtEvent(evt); 
             if (activePoints[0]) {
               var chartData = activePoints[0]['_chart'].config.data;
               var idx = activePoints[0]['_index'];

               var label = chartData.labels[idx];
               var value = chartData.datasets[0].data[idx];
               var color = chartData.datasets[0].backgroundColor[idx];  
               showAnotherDis2(value,label);
             } 
          };
    }
 
 var configDis2 = {
      type: 'bar',
      data: {
        labels: ['2019-2020'],
        datasets: [{
          label: 'SP',
          backgroundColor:'rgba(97,50,105,0.9)',
          borderColor: 'rgba(97,50,105,0.9)',
          data: [4],
          fill: false,
        }, {
          label: 'DSP',
          fill: false,
          backgroundColor: 'rgba(247,122,26,0.9)',
          borderColor:  'rgba(247,122,26,0.9)',
          data: [8],
        }, {
          label: 'Inspector',
          fill: false,
          backgroundColor: 'rgba(174,189,26,0.9)',
          borderColor:  'rgba(174,189,26,0.9)',
          data: [24],
        }, {
          label: 'Sub Inspector',
          fill: false,
          backgroundColor: 'rgba(209,21,71,0.9)',
          borderColor: 'rgba(209,21,71,0.9)',
          data: [26],
        }, {
          label: ' Assistant Sub Inspector',
          fill: false,
          backgroundColor: 'rgba(27,12,86,0.9)',
          borderColor:  'rgba(27,12,86,0.9)',
          data: [20],
        } ]
      },
      options: {
        responsive: true,
        title: {
          display: false,
          text: 'MIS Yearly Disciplinary Cases'
        },
        tooltips: {
          mode: 'index',
          intersect: false,
        },
        hover: {
          mode: 'nearest',
          "animationDuration": 0,
          intersect: true
        },

        "animation": {
                "duration": 1,
          "onComplete": function () {
            var chartInstance = this.chart,
              ctx = chartInstance.ctx;
            
            ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
            ctx.textAlign = 'center';
            ctx.textBaseline = 'bottom';

            this.data.datasets.forEach(function (dataset, i) {
              var meta = chartInstance.controller.getDatasetMeta(i);
              meta.data.forEach(function (bar, index) {
                var data = dataset.data[index];                            
                ctx.fillText(data, bar._model.x, bar._model.y - 5);
              });
            });
          }
                },
        scales: {
          xAxes: [{
            display: true,
            scaleLabel: {
              display: true,
              labelString: 'Yearly'
            }
          }], 
           yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
        }
      }
    };

    function showAnotherDis2(value,label){ 
       $("#expandedDis1").hide();
       $("#expandedDis2").show();

      var ctxDis2 = document.getElementById('chartareaExpDis2').getContext('2d');
      window.myLine = new Chart(ctxDis2, configDis2);

      chartareaExpDis2.onclick = function(evt) { 
             var activePoints = myLine.getElementsAtEvent(evt); 
             if (activePoints[0]) {
               var chartData = activePoints[0]['_chart'].config.data;
               var idx = activePoints[0]['_index'];

               var label = chartData.labels[idx];
               var value = chartData.datasets[0].data[idx];
               var color = chartData.datasets[0].backgroundColor[idx];  
               showAnotherDis3(value,label);
             } 
          }; 
    }


    var configDis3 = {
      type: 'bar',
      data: {
        labels: ['2019-2020'],
        datasets: [{
          label: 'SC',
          backgroundColor:'rgba(97,50,105,0.9)',
          borderColor: 'rgba(97,50,105,0.9)',
          data: [10],
          fill: false,
        }, {
          label: 'ST',
          fill: false,
          backgroundColor: 'rgba(247,122,26,0.9)',
          borderColor:  'rgba(247,122,26,0.9)',
          data: [2],
        }, {
          label: 'Unreserved',
          fill: false,
          backgroundColor: 'rgba(174,189,26,0.9)',
          borderColor:  'rgba(174,189,26,0.9)',
          data: [14],
        }  ]
      },
      options: {
        responsive: true,
        title: {
          display: false,
          text: 'MIS Yearly Disciplinary Cases'
        },
        tooltips: {
          mode: 'index',
          intersect: false,
        },
        hover: {
          mode: 'nearest',
          "animationDuration": 0,
          intersect: true
        },

        "animation": {
                "duration": 1,
          "onComplete": function () {
            var chartInstance = this.chart,
              ctx = chartInstance.ctx;
            
            ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
            ctx.textAlign = 'center';
            ctx.textBaseline = 'bottom';

            this.data.datasets.forEach(function (dataset, i) {
              var meta = chartInstance.controller.getDatasetMeta(i);
              meta.data.forEach(function (bar, index) {
                var data = dataset.data[index];                            
                ctx.fillText(data, bar._model.x, bar._model.y - 5);
              });
            });
          }
                },
        scales: {
          xAxes: [{
            display: true,
            scaleLabel: {
              display: true,
              labelString: 'Yearly'
            }
          }], 
           yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
        }
      }
    };

    function showAnotherDis3(value,label){ 
       $("#expandedDis2").hide();
       $("#expandedDis3").show();

      var ctxDis3 = document.getElementById('chartareaExpDis3').getContext('2d');
      window.myLine = new Chart(ctxDis3, configDis3); 
    }

/*################ PIE CHART FOR RELAXATION #########################*/
    var configRex = {
      type: 'pie',
      data: {
        datasets: [{
          data: [184,195,27,90,50,60],
          backgroundColor: [
          'rgba(60,141,188,1)',
          'rgba(0,192,239,1)',
          'rgba(243,156,18,1)',
          'rgba(221,75,57,1)',
          'rgba(0,166,90,1)',
          'rgba(100,168,10,1)'
          ],
          label: 'Pie Chart'
        }],
        labels: ['New','Open','Returned','Rejected','Approved', 'Accepted']
      },
      options: {
        responsive: true
      }
    };

    $(function () { 
      var ctxRex = document.getElementById('chartareaR').getContext('2d');
      window.myPie = new Chart(ctxRex, configRex); 

      chartareaR.onclick = function(evt) {  
             var activePoints = myPie.getElementsAtEvent(evt);
             if (activePoints[0]) {
               var chartData = activePoints[0]['_chart'].config.data;
               var idx = activePoints[0]['_index'];

               var label = chartData.labels[idx];
               var value = chartData.datasets[0].data[idx];
               var color = chartData.datasets[0].backgroundColor[idx];  
               showAnotherRex(value,label);
             } 
          }; 
    }); 

    var configRex1 = { 
      type: 'bar',
      data: {
        labels: ['2019-2020'],
        datasets: [{
          label: 'Home',
          backgroundColor:'rgba(97,50,105,0.9)',
          borderColor: 'rgba(97,50,105,0.9)',
          data: [34],
          fill: false,
        }, {
          label: 'Excise & Duty',
          fill: false,
          backgroundColor: 'rgba(247,122,26,0.9)',
          borderColor:  'rgba(247,122,26,0.9)',
          data: [82],
        }, {
          label: 'Mines',
          fill: false,
          backgroundColor: 'rgba(174,189,26,0.9)',
          borderColor:  'rgba(174,189,26,0.9)',
          data: [71],
        }, {
          label: 'Water Reserve',
          fill: false,
          backgroundColor: 'rgba(209,21,71,0.9)',
          borderColor: 'rgba(209,21,71,0.9)',
          data: [54],
        }, {
          label: 'Custom',
          fill: false,
          backgroundColor: 'rgba(27,12,86,0.9)',
          borderColor:  'rgba(27,12,86,0.9)',
          data: [29],
        }, {
          label: 'Agriculture',
          fill: false,
          backgroundColor: 'rgba(74,89,126,0.9)',
          borderColor:  'rgba(74,89,126,0.9)',
          data: [21],
        }, {
          label: 'Education',
          fill: false,
          backgroundColor: 'rgba(59,21,111,0.9)',
          borderColor: 'rgba(59,21,111,0.9)',
          data: [59],
        }]
      },
      options: {
        responsive: true,
        title: {
          display: false,
          text: 'MIS Yearly Relaxation Cases'
        },
        tooltips: {
          mode: 'index',
          intersect: false,
        },
        hover: {
          mode: 'nearest',
          "animationDuration": 0,
          intersect: true
        },

        "animation": {
                "duration": 1,
          "onComplete": function () {
            var chartInstance = this.chart,
              ctx = chartInstance.ctx;
            
            ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
            ctx.textAlign = 'center';
            ctx.textBaseline = 'bottom';

            this.data.datasets.forEach(function (dataset, i) {
              var meta = chartInstance.controller.getDatasetMeta(i);
              meta.data.forEach(function (bar, index) {
                var data = dataset.data[index];                            
                ctx.fillText(data, bar._model.x, bar._model.y - 5);
              });
            });
          }
                },
        scales: {
          xAxes: [{
            display: true,
            scaleLabel: {
              display: true,
              labelString: 'Yearly'
            }
          }], 
           yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
        }
      }
    };

    function showAnotherRex(value,label){ 
       $("#chartAreaP1").hide();
       $("#chartAreaD1").hide();
       $("#chartAreaR1").hide();
       $("#expandedRex1").show();

      var ctxRex1 = document.getElementById('chartareaExpRex').getContext('2d');
      window.myLine = new Chart(ctxRex1, configRex1); 
      chartareaExpRex.onclick = function(evt) {
         
            var activePoints = myLine.getElementsAtEvent(evt); 
            if (activePoints[0]) {
               var chartData = activePoints[0]['_chart'].config.data;
               var idx = activePoints[0]['_index'];

               var label = chartData.labels[idx];
               var value = chartData.datasets[0].data[idx];
               var color = chartData.datasets[0].backgroundColor[idx];  
               showAnotherRex2(value,label);
             } 
          };
    }
 
 var configRex2 = {
      type: 'bar',
      data: {
        labels: ['2019-2020'],
        datasets: [{
          label: 'SP',
          backgroundColor:'rgba(97,50,105,0.9)',
          borderColor: 'rgba(97,50,105,0.9)',
          data: [4],
          fill: false,
        }, {
          label: 'DSP',
          fill: false,
          backgroundColor: 'rgba(247,122,26,0.9)',
          borderColor:  'rgba(247,122,26,0.9)',
          data: [8],
        }, {
          label: 'Inspector',
          fill: false,
          backgroundColor: 'rgba(174,189,26,0.9)',
          borderColor:  'rgba(174,189,26,0.9)',
          data: [24],
        }, {
          label: 'Sub Inspector',
          fill: false,
          backgroundColor: 'rgba(209,21,71,0.9)',
          borderColor: 'rgba(209,21,71,0.9)',
          data: [26],
        }, {
          label: ' Assistant Sub Inspector',
          fill: false,
          backgroundColor: 'rgba(27,12,86,0.9)',
          borderColor:  'rgba(27,12,86,0.9)',
          data: [20],
        } ]
      },
      options: {
        responsive: true,
        title: {
          display: false,
          text: 'MIS Yearly Relaxation Cases'
        },
        tooltips: {
          mode: 'index',
          intersect: false,
        },
        hover: {
          mode: 'nearest',
          "animationDuration": 0,
          intersect: true
        },

        "animation": {
                "duration": 1,
          "onComplete": function () {
            var chartInstance = this.chart,
              ctx = chartInstance.ctx;
            
            ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
            ctx.textAlign = 'center';
            ctx.textBaseline = 'bottom';

            this.data.datasets.forEach(function (dataset, i) {
              var meta = chartInstance.controller.getDatasetMeta(i);
              meta.data.forEach(function (bar, index) {
                var data = dataset.data[index];                            
                ctx.fillText(data, bar._model.x, bar._model.y - 5);
              });
            });
          }
                },
        scales: {
          xAxes: [{
            display: true,
            scaleLabel: {
              display: true,
              labelString: 'Yearly'
            }
          }], 
           yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
        }
      }
    };

    function showAnotherRex2(value,label){ 
       $("#expandedRex1").hide();
       $("#expandedRex2").show();

      var ctxRex2 = document.getElementById('chartareaExpRex2').getContext('2d');
      window.myLine = new Chart(ctxRex2, configRex2);

      chartareaExpRex2.onclick = function(evt) { 
             var activePoints = myLine.getElementsAtEvent(evt); 
            if (activePoints[0]) {
               var chartData = activePoints[0]['_chart'].config.data;
               var idx = activePoints[0]['_index'];

               var label = chartData.labels[idx];
               var value = chartData.datasets[0].data[idx];
               var color = chartData.datasets[0].backgroundColor[idx];  
               showAnotherRex3(value,label);
             } 
          }; 
    } 

    var configRex3 = {
      type: 'bar',
      data: {
        labels: ['2019-2020'],
        datasets: [{
          label: 'SC',
          backgroundColor:'rgba(97,50,105,0.9)',
          borderColor: 'rgba(97,50,105,0.9)',
          data: [10],
          fill: false,
        }, {
          label: 'ST',
          fill: false,
          backgroundColor: 'rgba(247,122,26,0.9)',
          borderColor:  'rgba(247,122,26,0.9)',
          data: [2],
        }, {
          label: 'Unreserved',
          fill: false,
          backgroundColor: 'rgba(174,189,26,0.9)',
          borderColor:  'rgba(174,189,26,0.9)',
          data: [14],
        }  ]
      },
      options: {
        responsive: true,
        title: {
          display: false,
          text: 'MIS Yearly Relaxation Cases'
        },
        tooltips: {
          mode: 'index',
          intersect: false,
        },
        hover: {
          mode: 'nearest',
          "animationDuration": 0,
          intersect: true
        },

        "animation": {
                "duration": 1,
          "onComplete": function () {
            var chartInstance = this.chart,
              ctx = chartInstance.ctx;
            
            ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
            ctx.textAlign = 'center';
            ctx.textBaseline = 'bottom';

            this.data.datasets.forEach(function (dataset, i) {
              var meta = chartInstance.controller.getDatasetMeta(i);
              meta.data.forEach(function (bar, index) {
                var data = dataset.data[index];                            
                ctx.fillText(data, bar._model.x, bar._model.y - 5);
              });
            });
          }
                },
        scales: {
          xAxes: [{
            display: true,
            scaleLabel: {
              display: true,
              labelString: 'Yearly'
            }
          }], 
           yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
        }
      }
    }; 

    function showAnotherRex3(value,label){ 
       $("#expandedRex2").hide();
       $("#expandedRex3").show();

      var ctxRex3 = document.getElementById('chartareaExpRex3').getContext('2d');
      window.myLine = new Chart(ctxRex3, configRex3); 
    }
  </script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\wethefamily\resources\views/dashboard/dashboard-commissioner.blade.php ENDPATH**/ ?>