<?php $__env->startSection('title', 'AQUATIC'); ?>
<?php $__env->startSection('content'); ?>
     <!--Page Title-->
     <section class="page-title" style="background-image:url('../public/images/innerbanner.jpg');">
        <div class="auto-container">
            <div class="inner-container clearfix">
                <div class="title-box">
                    <h1>Login</h1>
                </div>
                <ul class="bread-crumb clearfix">
                    <li><a href="index.html"><span class="fas fa-home"></span> Home</a></li>
                    <li><span class="far fa-arrow-alt-circle-right"></span>Login</li>
                </ul>
            </div>
        </div>
    </section>
    <!--End Page Title-->    
<section id="" class="ls section_padding_top_40 columns_padding_30 bg-img">
  <div class="container">
      <div class="row">
          <div class="col-md-4 offset-md-4 login-bg" data-animation="fadeInUp" data-delay="600">
             <?php if(Session::has('errors')): ?>
              <div class="col-md-12 alert alert-warning">
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php echo e($error); ?><br/>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            <?php endif; ?>
            <?php if(Session::has('message')): ?>
            <div class="alert alert-warning">                        
                <i class="fa fa-check"></i> <?php echo e(Session::get('message')); ?> 
            </div>
            <?php endif; ?>
            <h2> Admin Login</h2>
              
            <form action="<?php echo e(url('post-login')); ?>" method="post" onSubmit="return validateForm()" autocomplete="off"> 
              <?php echo csrf_field(); ?>
              <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
              </div>
              <div class="form-group">
                <label for="pwd">Password:</label>
                <input type="password" class="form-control" id="password" placeholder="Enter password" name="password">
              </div>
              <div class="form-group has-feedback">
                 <div class="row">
                    <div class="col-md-6">
                       <input type="text" class="form-control" placeholder="Enter Captcha code" name="captchCode" id="captchCode">
                    </div>
                    <div class="col-md-6 captcha">
                       <span><?php echo captcha_img(); ?></span>
                       <div class="pull-right"><a href="javascript:void(0)" class="btn btn-default" id="refresh"><i class="fa fa-refresh"></i></a></div>
                    </div>
                 </div>
              </div>
             <!--  <div class="checkbox">
                <label><input type="checkbox" name="remember"> Remember me</label>
              </div> -->
              <!-- <div class="col-md-10 col-md-offset-1">
              Don't have an account! <a href="<?php echo e(url('home/showJoinus')); ?>">Sign Up Here</a>
              </div> -->
              <div class="row">
              <div class="col-md-4 col-md-offset-4">
              <button type="submit" class="btn btn-default" >Submit</button>
             </div>
            </div>

           </from>

          </div>
        </div>
  </section> 

 <?php $__env->startPush('scripts'); ?>  
  <script>
     function validateForm(){ //alert("here"); return false;
         if (!blankValidation("email", "TextField","Email is required"))
           return false;
         if (!RemoveSQLCharacter("email"))
           return false;
         if (!checkEmailId("email","Invalid email id !!!"))
           return false;
         if (!blankValidation("password", "TextField","Password is required"))
           return false; 
        if (!blankValidation("captchCode", "TextField","Captcha code is required"))
           return false; 
     }
    
  </script>
  <?php $__env->stopPush(); ?>

 <?php $__env->startPush('scripts'); ?>
 <!-- Write down javascript here -->
 <?php $__env->stopPush(); ?>   
<?php $__env->stopSection(); ?>   
<?php echo $__env->make('frontend-layout.frontend-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\aquatic\resources\views/login.blade.php ENDPATH**/ ?>