<?php $__env->startSection('title', 'DASHBOARD'); ?>
<?php $__env->startSection('content'); ?>  
  <section class="page_breadcrumbs ds background_cover section_padding_top_65 section_padding_bottom_65">
               <div class="container">
                  <div class="row">
                     <div class="col-sm-12 text-center">
                       <h2>Dashboard</h2>
                     </div>
                  </div>
               </div>
            </section>
            <section class="ls columns_padding_25 section_padding_top_100 section_padding_bottom_110">
               <div class="container">
            <?php if(Session::has('errors')): ?>
            <div class="col-md-12 alert alert-warning">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($error); ?><br/>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <?php if(Session::has('message')): ?>
        <div class="alert alert-danger">                        
            <i class="fa fa-times"></i> <?php echo e(Session::get('message')); ?> 
        </div>
        <?php endif; ?>
                  <div class="row">
                        <div class="col-sm-7">
                            <h4>Dashboard</h4>
                        </div>
                        <div class="col-sm-5">
                        <div class="input-group">
                          <input type="text" class="form-control" placeholder="Serach"name="" id="param1">
                          <div class="input-group-append">
                            <button class="btn btn-warning">Serach</button>
                          </div>
                        </div>
                        </div>
                    </div>
                <div class="row">
                <div class="header_right_buttons display_table_cell text-right hidden-xs"><a href="<?php echo e(url('home/editMember')); ?>" class="theme_button color3 margin_0">View/Edit your profile</a></div>
                   <div class="header_right_buttons display_table_cell text-right hidden-xs"><a href="<?php echo e(url('home/showMatrimony')); ?>" class="theme_button color3 margin_0">Post Matrimony</a></div>
                   <div class="header_right_buttons display_table_cell text-right hidden-xs"><a href="<?php echo e(url('home/showBlogPost')); ?>" class="theme_button color3 margin_0">Blog Post</a></div>
                    <div class="header_right_buttons display_table_cell text-right hidden-xs"><a href="<?php echo e(url('change-member-password')); ?>" class="theme_button color3 margin_0">Change Password</a></div>
                    <div class="header_right_buttons display_table_cell text-right hidden-xs"><a href="<?php echo e(url('member-logout')); ?>" class="theme_button color3 margin_0">Log Out</a></div>
                </div>
                  <div class="row">
                     <div class="col-sm-12">
                        <div class="table-responsive">
                           <table role="table" class="dataTable">
                              <thead role="rowgroup">
                               <tr role="row">
                                    <th role="columnheader">Name Of The Member</th>
                                    <th role="columnheader">Age</th>
                                    <th role="columnheader">Date Of Birth</th>
                                    <th role="columnheader">Phone Number</th>
                                    <th role="columnheader">Email Id</th>
                                    <th role="columnheader">Occupation</th>
                              </tr>
                            </thead>
                            <tbody role="rowgroup">
                              <?php $__currentLoopData = $member_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php
                        $TMM_Member_Image = $data->TMM_Member_Image;
                                    ?> 
                               <tr role="row">
                                    <td role="cell"><img class="img-circle" src="<?php echo e(asset('member_image/thumb/'.$TMM_Member_Image)); ?>" alt=""><?php echo e($data->TMM_Member_Name); ?></td>
                                    <td role="cell"><?php echo e($data->memberAge); ?></td>
                                    <td role="cell"><?php echo e($data->TMM_Member_Dob); ?></td>
                                    <td role="cell"><?php echo e($data->TMM_Member_Mobile); ?></td>
                                    <td role="cell"><?php echo e($data->TMM_Member_Email); ?></td>
                                    <td role="cell"><?php echo e($data->TOM_Occupation_Name); ?></td>
                                 </tr>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               <!-- <tr role="row">
                                    <td role="cell"><img class="img-circle" src="<?php echo e(asset('images/2.jpg')); ?>" alt=""> Monalisa</td>
                                    <td role="cell">26</td>
                                    <td role="cell"> 03/05/1993</td>
                                    <td role="cell">7978586866</td>
                                    <td role="cell">monalisa@nirmalyalabs.com</td>
                                    <td role="cell"> UI/UX Designer</td>
                                 </tr>
                                <tr role="row">
                                    <td role="cell"><img class="img-circle" src="<?php echo e(asset('images/2.jpg')); ?>" alt=""> Pratyusha</td>
                                    <td role="cell">24</td>
                                    <td role="cell"> 14/08/1995</td>
                                    <td role="cell">7978586866</td>
                                    <td role="cell">monalisa@nirmalyalabs.com</td>
                                    <td role="cell">UI/UX Designer</td>
                                 </tr>
                                <tr role="row">
                                    <td role="cell"><img class="img-circle" src="<?php echo e(asset('images/2.jpg')); ?>" alt=""> Saroja</td>
                                    <td role="cell">30</td>
                                    <td role="cell"> 14/08/1990</td>
                                    <td role="cell">7978586866</td>
                                    <td role="cell">monalisa@nirmalyalabs.com</td>
                                    <td role="cell">Lecture</td>
                                  </tr>
                                <tr role="row">
                                    <td role="cell"><img class="img-circle" src="<?php echo e(asset('images/2.jpg')); ?>" alt=""> Sarada</td>
                                    <td role="cell">24</td>
                                    <td role="cell"> 14/08/1996</td>
                                    <td role="cell">7978586866</td>
                                    <td role="cell">monalisa@nirmalyalabs.com</td>
                                    <td role="cell">Singer</td>
                                 </tr>
                                <tr role="row">
                                    <td role="cell"><img class="img-circle" src="<?php echo e(asset('images/2.jpg')); ?>" alt=""> Sangita</td>
                                    <td role="cell">25</td>
                                    <td role="cell"> 14/08/1996</td>
                                    <td role="cell">7978586866</td>
                                    <td role="cell">monalisa@nirmalyalabs.com</td>
                                    <td role="cell">Entrepreneur</td>
                                 </tr>
                                <tr role="row">
                                    <td role="cell"><img class="img-circle" src="<?php echo e(asset('images/2.jpg')); ?>" alt=""> Srabana</td>
                                    <td role="cell">31</td>
                                    <td role="cell"> 14/08/1989</td>
                                    <td role="cell">7978586866</td>
                                    <td role="cell">monalisa@nirmalyalabs.com</td>
                                    <td role="cell">Business Man</td>
                                 </tr> -->

                              </tbody>
                           </table>
                        </div>
                     </div>
                     <!--eof .col-sm-8 (main content)-->
                  </div>
               </div>
            </section>
         <?php $__env->stopSection(); ?> 
<?php echo $__env->make('frontend-layout.frontend-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\wethefamily\resources\views/dashboard1.blade.php ENDPATH**/ ?>