<?php $__env->startSection('title', 'AUDIT'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      Query Based Promotional Report
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">MIS Report</a></li>
        <li class="active">Query Based Promotional Report</li>
      </ol>
    </section>
 
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <!-- <h3 class="box-title">Data Table With Full Features</h3> -->
                 <div class="search-field">
                    <div class="row">
                      <div class="col-md-1">
                            <div class="org-name">From Date</div>
                        </div>
                        <div class="col-md-3">
                          <div class="input-group">
                              <div class="input-group-prepend">
                                  <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                              </div>
                              <input type="text" class="form-control pull-right datepicker" id="param1">
                          </div>
                        </div>
    
                        <div class="col-md-1">
                            <div class="org-name">To Date</div>
                        </div>
                       <div class="col-md-3">
                          <div class="input-group">
                              <div class="input-group-prepend">
                                  <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                              </div>
                              <input type="text" class="form-control pull-right datepicker" id="param2">
                          </div>
                        </div>
                        
                        <div class="col-md-1">
                            <div class="org-name">Request Ref#</div>
                        </div>
                        <div class="col-md-3">
                            <input class="form-control" type="text" id="param3">
                        </div>
                        
                       
                    </div>
                     <div class="row">
    
                        <div class="col-md-1">
                            <div class="org-name">Group</div>
                        </div>
                        <div class="col-md-3">
                          <select class="form-control" multiple="multiple" id="grouplist"> 
                                <?php $__currentLoopData = $grouplist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($val->TGM_Group); ?>" ><?php echo e($val->TGM_GroupName); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                         <div class="col-md-1">
                            <div class="org-name">Department</div>
                        </div>
                        <div class="col-md-3">
                            <select class="form-control" id="deptId" onchange="postChange()">
                            <option value="">--Select--</option>
                            <?php $__currentLoopData = $dept_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($val->TDM_Dept); ?>" ><?php echo e($val->TDM_Dept_Name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                        <div class="col-md-1">
                            <div class="org-name">Post</div>
                        </div>
                        <div class="col-md-3">
                          <select class="form-control" multiple="multiple" id="postlist">
                            
                          </select>
                        </div>

                       
                        
                        <div class="col-md-1">
                            <div class="org-name">Status</div>
                        </div>
                        <div class="col-md-3">
                           <select class="form-control" multiple="multiple" id="statuslist">
                            <?php $__currentLoopData = $statuslist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($val->statusId); ?>"><?php echo e($val->statusName); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </select> 
                        </div>

                        <div class="col-md-1">
                            <div class="org-name">category</div>
                        </div>                        
                        <div class="col-md-3">
                           <select class="form-control" multiple="multiple" id="catlist"> 
                            <?php $__currentLoopData = $catlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($val->TCM_Category); ?>"><?php echo e($val->TCM_CategoryName); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </select> 
                            
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <button class="btn btn-primary" onClick="searchData()">Search</button>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12" align="right">
                        <a href="#" target="_blank" class="btn btn-default"><i class="fa fa-print"></i> Print</a>
                        <a href="#" target="_blank" class="btn btn-default"><i class="fa fa-file-pdf-o"></i> PDF</a>
                    </div>
                    </div>

                </div>
                <div>
                  <textarea class="form-control" placeholder="Enter ..." id="QueryText" name="QueryText" autocomplete="off"> </textarea>
                </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="listAllPrmotionalData" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Application No.</th>
                  <th>Application Date Time</th>
                  <th>Department</th> 
                  <th>Status</th> 
                  <th>By Whom</th>
                  <th>Comments</th>
                  <th>IP Address</th>
                </tr>
                </thead>
                <tbody>  
                </tbody>
              </table>
            </div>
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content --> 
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('styles'); ?>
<!--Extra styles can written here -->
<?php $__env->stopPush(); ?>  
<?php $__env->startPush('scripts'); ?>

<script> 
   $(function () {
  $('#listAllPrmotionalData').DataTable({
    'processing' : true,
    'serverSide' : true,
    'searching' : false,
    'ordering' : false,
    "ajax" : {
      url : "<?php echo e(url('PromotionalMIS/viewPromotionalMISthroughAjax')); ?>",
      'data' : function(d) {
        d.param1 = $('#param1').val();
        d.param2 = $('#param2').val();
        d.param3 = $('#param3').val();
        d.param4 = $('#grouplist').val();
        d.param5 = $('#deptId').val();
        d.param6 = $('#postlist').val();
        d.param7 = $('#statuslist').val();
        d.param8 = $('#catlist').val();
 
      }
    },
    'dataSrc' : "",
    'columns' : [ {
      'data' : 'PromotionalId'
    },{
      'data' : 'ApplicationDate'
    }, {
      'data' : 'Department'
    }, {
      'data' : 'ApplicationStatus'
    }, {
      'data' : 'ByWhom'
    }, {
      'data' : 'ApplicationComment'
    },{
      'data' : 'IPAddress'
    }

    ]
  });
  
  });


  //Method For Searching Records In The List
  function searchData() {
    $('#listAllPrmotionalData').DataTable().draw();
  }
  function postChange() { 
  $.ajaxSetup({
    headers: {
      'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
    }
  });
   if($("#deptId").val()!=''){
    //alert($("#deptId").val());
    $.ajax({
      type : "POST",
      'url' : '<?php echo e(url("PromotionalMIS/getPostListOnchange")); ?>', 
      dataType : 'json', 
      data : {"deptId":$("#deptId").val()},
      success : function(response) {
        if (response.message == "success") {
          console.log(response);
          $("#postlist").empty(); 
          for (var i = 0; i < response.postList.length; i++) {
            var option = $("<option></option>");
            $(option).val(response.postList[i].TPM_Post);
            $(option).html(response.postList[i].TPM_Post_Name);
            $("#postlist").append(option);
          } 
        }
      },
      error : function(data) {
        console.log(data);
      }
    })
  }else{
    $("#postlist").empty();
    var option = $("<option></option>");
    $(option).val(null);
    $(option).html("--Select--");
    $("#postlist").append(option); 
  }
}
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/mis/manage-query-based-promotional-report.blade.php ENDPATH**/ ?>