<?php $__env->startSection('title', 'GALLERY'); ?>
<?php $__env->startSection('content'); ?>  


       <section class="page_breadcrumbs ds background_cover section_padding_top_65 section_padding_bottom_65">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 text-center">
                            <h2>Our Gallery</h2>
                        </div>
                    </div>
                </div>
        </section>

    <div class="container page-top">
        <div class="row">
            <?php $__currentLoopData = $gallery_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                 <?php
                 $TGM_Gallery_Image = $data->TGM_Gallery_Image;
                 ?>
            <div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a href="<?php echo e(asset('gallery_image/orig/'.$TGM_Gallery_Image)); ?>" class="fancybox" rel="ligthbox">
                    <img  src="<?php echo e(asset('gallery_image/orig/'.$TGM_Gallery_Image)); ?>" class="zoom img-fluid "  alt="Gallery image">
                   
                </a>
            </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
       </div>
    </div>

 <script>
         $(document).ready(function(){
  $(".fancybox").fancybox({
        openEffect: "none",
        closeEffect: "none"
    });
    
    $(".zoom").hover(function(){
        
        $(this).addClass('transition');
    }, function(){
        
        $(this).removeClass('transition');
    });
});
</script>   
<?php $__env->startPush('scripts'); ?>


<?php $__env->stopPush(); ?>


<?php $__env->stopSection(); ?> 

<?php echo $__env->make('frontend-layout.frontend-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\wethefamily\resources\views/gallery.blade.php ENDPATH**/ ?>