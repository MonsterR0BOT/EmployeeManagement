   
    <div class="box box-success" id="expanded2">
	<div class="box-header with-border">
		<h3 class="box-title">Expanded Promotional Post Chart</h3>

		<div class="box-tools pull-right">
		  	<button type="button" id="back1" style="text-align: right;" class="btn btn-primary"  onClick="ReturnShowDepartmentWiseChart(<?php echo e($levelValue); ?>,<?php echo e($financialYear); ?>)">Return Back</button>   
		</div>
	</div>
	<div class="box-body">
		<div class="chart">
			<canvas id="chartareaExp2" style="height:350px"></canvas>
		</div>
	</div>
<!-- /.box-body     -->
</div> 
             
<script>
		var config2 = {
			type: 'bar',
			 data: { 

			      labels: [<?php echo $postNames ?>],///financialYear
			    
			      datasets: [
			        {
			          label: [<?php echo $financialYear ?>],
			         backgroundColor: ['rgba(97,50,105,0.9)', 'rgba(247,122,26,0.9)','rgba(174,189,26,0.9)','rgba(209,21,71,0.9)','rgba(97,50,105,0.9)','rgba(97,50,105,0.9)', 'rgba(247,122,26,0.9)','rgba(174,189,26,0.9)','rgba(209,21,71,0.9)',],
			          data: [<?php echo $countPosts ?>],
			          id: [<?php echo $postIds ?>]
			        }
			      ]
			    },
			options: {
				responsive: true,
				title: {
					display: false,
					text: 'MIS Yearly Promotional Cases'
				},
				tooltips: {
					mode: 'index',
					intersect: false,
				},
				hover: {
					mode: 'nearest',
					"animationDuration": 0,
					intersect: true
				},

				"animation": {
	        	    "duration": 1,
					"onComplete": function () {
						var chartInstance = this.chart,
							ctx = chartInstance.ctx;
						
						ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
						ctx.textAlign = 'center';
						ctx.textBaseline = 'bottom';

						this.data.datasets.forEach(function (dataset, i) {
							var meta = chartInstance.controller.getDatasetMeta(i);
							meta.data.forEach(function (bar, index) {
								var data = dataset.data[index];                            
								ctx.fillText(data, bar._model.x, bar._model.y - 5);
							});
						});
					}
                },
				scales: {
					xAxes: [{
						display: true,
						scaleLabel: {
							display: true,
							labelString: 'Yearly'
						}
					}], 
					 yAxes: [{
				            ticks: {
				                beginAtZero: true
				            }
				        }]
				}
			}
		};

	$(function () {
		 

			var ctx2 = document.getElementById('chartareaExp2').getContext('2d');
			window.myLine = new Chart(ctx2, config2);

			chartareaExp2.onclick = function(evt) {
			 //  	alert('hello');
			       var activePoints = myLine.getElementsAtEvent(evt);
			      // 	alert('hello');
			      if (activePoints[0]) {
			         var chartData = activePoints[0]['_chart'].config.data;
			         var idx = activePoints[0]['_index'];
			         var id = chartData.datasets[0].id[idx];
			         var label = chartData.labels[idx];
			         var value = chartData.datasets[0].data[idx];
			         var color = chartData.datasets[0].backgroundColor[idx];  
			      //   alert(id);
			         showCategoryWiseChart(id,<?php echo $financialYear ?>,<?php echo $levelValue ?>,'<?php echo $deptId ?>');
			       } 
			    }; 
	}); 


</script><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/mis/ajax-mis-post-afterdept-promotion.blade.php ENDPATH**/ ?>