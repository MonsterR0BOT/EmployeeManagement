<?php $__env->startSection('title', 'AUDIT'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       User Log Report
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Audit Trail</a></li>
        <li class="active">User Log Report</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box">
           <!-- <div class="box-header">
              <h3 class="box-title">Data Table With Full Features</h3>
            </div>-->
            <!-- /.box-header -->
            <div class="box-body">
            	<div id="demo" >
                <div class="search-field">
                    <div class="row">
    
                        <div class="col-md-2">
                            <div class="org-name">From Date</div>
                        </div>
                        <div class="col-md-2">
                            <input class="form-control datepicker" type="text" id="param1">
                        </div>
                        
                        <div class="col-md-1">
                            <div class="org-name">To Date</div>
                        </div>
                        <div class="col-md-2">
                            <input class="form-control datepicker" type="text" id="param2">
                        </div>
                        
                        <div class="col-md-1">
                            <div class="org-name">Department</div>
                        </div>
                        <div class="col-md-2">
                           <select class="form-control">
                            <option value="Home">Home</option>
                            <option value="Production">Production</option>
                            <option value="Education">Education</option>
                            <option value="Agriculture">Agriculture</option>
                            <option value="Water Resource">Water Resource</option>
                            <option value="Natural Resource">Natural Resource</option>
                            <option value="Electricity">Electricity</option>
                          </select>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <button class="btn btn-primary" onClick="searchData()">Search</button>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12" align="right">
                        <a href="#" target="_blank" class="btn btn-default"><i class="fa fa-print"></i> Print</a>
                        <a href="#" target="_blank" class="btn btn-default"><i class="fa fa-file-pdf-o"></i> PDF</a>
                    </div>
                    </div>
                </div>
            </div>
            <!-- <a data-toggle="collapse" data-target="#demo"
                class="showhideangelbg"><i class="fa fa-angle-double-down"></i>
            </a> -->
           
              <table id="listAllUser" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>User Name</th>
                  <th>Designation</th>
                  <th>Department</th>
                  <th>Role</th>
                  <th>Login Time</th>
                  <th>Logout Time</th>
                  <th>Time Spent</th>
                  <th>IP Address</th>
                </tr>
                </thead>
                <tbody>
                 <tr>
                  <td><a href="<?php echo e(url('audit/u001')); ?>" >Aman Kumar</a></td>
                  <td>Office Asst</td>
                  <td>Home</td>
                  <td>Creator</td>
                  <td>12-12-2019 12:00:45</td>
                  <td>12-12-2019 42:00:45</td>
                  <td>40 Min</td>
                  <td>192.168.0.35</td>
                </tr>
               <tr>
                  <td><a href="<?php echo e(url('audit/u001')); ?>" >Aman Kumar</a></td>
                  <td>Office Asst</td>
                  <td>Home</td>
                  <td>Creator</td>
                  <td>12-12-2019 12:00:45</td>
                  <td>12-12-2019 42:00:45</td>
                  <td>40 Min</td>
                  <td>192.168.0.35</td>
                </tr>
                <tr>
                  <td><a href="<?php echo e(url('audit/u001')); ?>" >Aman Kumar</a></td>
                  <td>Office Asst</td>
                  <td>Home</td>
                  <td>Creator</td>
                  <td>12-12-2019 12:00:45</td>
                  <td>12-12-2019 42:00:45</td>
                  <td>40 Min</td>
                  <td>192.168.0.35</td>
                </tr>
                <tr>
                  <td><a href="<?php echo e(url('audit/u001')); ?>" >Aman Kumar</a></td>
                  <td>Office Asst</td>
                  <td>Home</td>
                  <td>Creator</td>
                  <td>12-12-2019 12:00:45</td>
                  <td>12-12-2019 42:00:45</td>
                  <td>40 Min</td>
                  <td>192.168.0.35</td>
                </tr>
                <tr>
                  <td><a href="<?php echo e(url('audit/u001')); ?>" >Aman Kumar</a></td>
                  <td>Office Asst</td>
                  <td>Home</td>
                  <td>Creator</td>
                  <td>12-12-2019 12:00:45</td>
                  <td>12-12-2019 42:00:45</td>
                  <td>40 Min</td>
                  <td>192.168.0.35</td>
                </tr>
                <tr>
                  <td><a href="<?php echo e(url('audit/u001')); ?>" >Aman Kumar</a></td>
                  <td>Office Asst</td>
                  <td>Home</td>
                  <td>Creator</td>
                  <td>12-12-2019 12:00:45</td>
                  <td>12-12-2019 42:00:45</td>
                  <td>40 Min</td>
                  <td>192.168.0.35</td>
                </tr>
                <tr>
                  <td><a href="<?php echo e(url('audit/u001')); ?>" >Aman Kumar</a></td>
                  <td>Office Asst</td>
                  <td>Home</td>
                  <td>Creator</td>
                  <td>12-12-2019 12:00:45</td>
                  <td>12-12-2019 42:00:45</td>
                  <td>40 Min</td>
                  <td>192.168.0.35</td>
                </tr>
                <tr>
                  <td><a href="<?php echo e(url('audit/u001')); ?>" >Aman Kumar</a></td>
                  <td>Office Asst</td>
                  <td>Home</td>
                  <td>Creator</td>
                  <td>12-12-2019 12:00:45</td>
                  <td>12-12-2019 42:00:45</td>
                  <td>40 Min</td>
                  <td>192.168.0.35</td>
                </tr>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
    	<!-- Modal Start-->
		<div id="myModal" class="modal fade" role="dialog">
			<div class="modal-dialog">
				<!-- Modal content-->
				<div class="modal-content" style="width: 750px;">
					<div class="modal-header">
						<h4 class="modal-title">View Details of User Management</h4>
						<button type="button" class="close" data-dismiss="modal">&times;</button>
					</div>
					<div class="modal-body">
						<table id="table1"
							class="table table-striped table-bordered" width="100%"
							border="0">
							<thead>
								<tr>
									<th>User Name</th>
									<th>Mobile No</th>
									<th>Email</th>
									<!-- <th>User Role</th> -->
									<th>Country</th>
									<th>State</th>
									<th>District</th>
									<th>PIN</th>
									<th>Status</th>
								</tr>
							</thead>
							<tbody>
								
							</tbody>
						</table>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
		</div>
		<!-- Modal End-->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('styles'); ?>
<!--Extra styles can written here -->
<?php $__env->stopPush(); ?>  
<?php $__env->startPush('scripts'); ?>

<script>
$(function () {
	$('#listAllUser').DataTable({
		'processing' : true,
		'serverSide' : false,
		'searching' : false,
		'ordering' : false
	});
	
  });
  /*$(function () {
	$('#listAllUser').DataTable({
		'processing' : true,
		'serverSide' : true,
		'searching' : false,
		'ordering' : false,
		"ajax" : {
			'url' : 'view-user-throughAjax',
			'data' : function(d) {
				d.param1 = $('#param1').val();
				d.param2 = $('#param2').val();
				d.param3 = $('#param3').val();

			}
		},
		'dataSrc' : "",
		'columns' : [ {
			'data' : 'TUM_User_Name'
		}, {
			'data' : 'TUT_UserTypeName'
		}, {
			'data' : 'TUM_User_IMEI'
		}, {
			'data' : 'TUM_User_Mobile'
		}, {
			'data' : 'TUM_User_Email'
		}, {
			'data' : 'TCM_Country_Name'
		}, {
			'data' : 'TSM_State_Name'
		}, {
			'data' : 'TDM_Dist_Name'
		}, {
			'data' : 'TUM_User_Pin'
		}, {
			'data' : 'TUM_User_Status'
		}, {
			'data' : 'action'
		}

		]
	});
	
  });*/
  //Method For Searching Records In The List
	/*function searchData() {
		$('#listAllUser').DataTable().draw();
	}*/
	
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/audit/manage-user-log.blade.php ENDPATH**/ ?>