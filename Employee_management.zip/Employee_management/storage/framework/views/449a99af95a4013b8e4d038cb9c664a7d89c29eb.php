 <?//php print_r($about_list); exit;
?>
 <section class="about-section">

        <div class="auto-container">
            <?php $__currentLoopData = $about_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
            <?php 
            $filename = asset('images/'.$val->TCM_Content_Image); 
            ?>
            
            <div class="row">
                <!-- Image Column -->
                <div class="image-column col-lg-6 col-md-12 col-sm-12">
                    <div class="inner-column">
                        <div class="image-box">
                            <figure class="image wow fadeInLeft" data-wow-delay='600ms'><img src="<?php echo e($filename); ?>" alt=""></figure>
                        </div>
                    </div>
                </div>

                <!-- Content Column -->
                <div class="content-column col-lg-6 col-md-12 col-sm-12">
                    <div class="inner-column wow fadeInLeft">
                        <div class="content-box">
                            <!-- <div class="sec-title">
                                <h2 data-animation-child class="title-fill" data-animation="title-fill-anim" data-text="About Company"></h2>
                            </div> -->
                            
                            <h5><?php echo e($val->TCM_Content_Name); ?></h5>
                            <div class="text"><?php echo e($val->TCM_Content_Description); ?></div>
                            <div class="link-box"><a href="#" class="theme-btn btn-style-three">Read More<i class="fa fa-chevron-right"></i></a></div>
                            
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section><?php /**PATH E:\xampp\htdocs\Employee_management\resources\views/frontend-layout/homeabout.blade.php ENDPATH**/ ?>