<?php $__env->startSection('title', 'RESET PASSWORD'); ?>
<?php $__env->startSection('content'); ?>
     <div class="login-box">
        <div class="login-logo">
           <a href="<?php echo e(url('/')); ?>">RESET PASSWORD</a>
        </div>
        <!-- /.login-logo -->
        <div class="login-box-body">
          <?php if(Session::has('errors')): ?>
          <div class="col-md-12 alert alert-warning">
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($error); ?><br/>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
         <?php endif; ?>
         <?php if(Session::has('warning')): ?>
         <div class="alert alert-warning">                        
             <i class="fa fa-check"></i> <?php echo e(Session::get('warning')); ?> 
         </div>
         <?php endif; ?>
         <?php if(Session::has('message')): ?>
           <div class="callout callout-danger1">
              <h4><?php echo e(Session::get('message')); ?></h4>
           </div>
           <div class="callout callout-danger1">
              <h4>Your password must be have at least</h4>
              <div>
                 <p>
                    -Password should be minimum of 6 characters and maximum 16 charaters.<br>
                    -must have at least one uppercase ,one lowercase one numeric and one special character.<br>
                    -special characters  allowed ! @$ # & * ().<br>
                    -password should not contain you first name.<br>
                    -password should not start with a special character.
                 </p>
              </div>
           </div>
           <?php endif; ?>
           <p class="login-box-msg">Enter OTP to reset your password</p>
           <form action="<?php echo e(url('reset-password-post')); ?>" method="post"  autocomplete="off" onSubmit="return validateForm()">
              <?php echo csrf_field(); ?>
              <div class="form-group has-feedback">
               <input type="text" class="form-control" placeholder="Enter OTP" name="resetOtp" id="resetOtp">

            </div>
              <div class="form-group has-feedback">
                 <input type="password" class="form-control" placeholder="Enter new password" name="newPassword" id="newPassword">

              </div>
               <div class="form-group has-feedback">
                 <input type="password" class="form-control" placeholder="Enter confirm password" name="confirmPassword" id="confirmPassword">

              </div>
              <div class="form-group has-feedback">
                 <div class="row">
                    <div class="col-md-6">
                       <input type="text" class="form-control" placeholder="Enter captcha code" name="captchCode" id="captchCode">
                    </div>
                     <div class="col-md-6 captcha">
                       <span><?php echo captcha_img(); ?></span>
                       <div class="pull-right"><a href="javascript:void(0)" class="btn btn-default" id="refresh"><i class="fa fa-refresh"></i></a></div>
                    </div>
                 </div>
              </div>
              <div class="row">
                 <div class="col-md-8">
                    <!--<div class="checkbox icheck">
                       <label>
                         <input type="checkbox"> Remember Me
                       </label>
                       </div>-->
                   <button type="button" class="btn btn-primary btn-flat" onclick="resendOTP();">Resend OTP</button>     
                 </div>
                 <!-- /.col -->
                 <div class="col-md-4">
                    <button type="submit" class="btn btn-primary btn-block btn-flat">Submit</button>
                 </div>
                 <!-- /.col -->
              </div>
           </form>
           <div class="text-center">
            <a href="<?php echo e(url('login')); ?>">Return to login</a> 
           </div>
           
           <!--     <a href="#">I forgot my password</a><br> -->
           <!--<a href="register.html" class="text-center">Register a new membership</a>-->
        </div>
        <!-- /.login-box-body -->
     </div>
  <?php $__env->startPush('scripts'); ?>
    <script>
       /*$(function () {
         $('input').iCheck({
           checkboxClass: 'icheckbox_square-blue',
           radioClass: 'iradio_square-blue',
           increaseArea: '20%' 
         });
       });*/
       function validateForm(){ //alert("here"); return false;
          if (!blankValidation("resetOtp", "TextField","OTP is required"))
               return false;
             if (!RemoveSQLCharacter("resetOtp"))
               return false;
          if (!blankValidation("newPassword", "TextField","New password is required"))
             return false;
          if (!blankValidation("confirmPassword", "TextField","Confirm password is required"))
             return false;
          if($('#newPassword').val() != $('#confirmPassword').val()){
            swal("Sorry !! Password mismatch");
            return false;
          } 
          if (!blankValidation("captchCode", "TextField","Captcha code is required"))
             return false; 
       }
        function resendOTP(){
            $.ajaxSetup({
              headers: {
                  'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                  }
              });
            swal.fire({
                title: "Do you want to resend OTP?",
                text: "Once send, can't revert back !",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#e7b63a',
                confirmButtonText: 'Send',
                reverseButtons : true
                
              }).then((result) => {
                if(result.value){
                  $("#maskid").show();
                  $.ajax({
                      type: "POST",
                      url:"<?php echo e(url('reset-password-otp-throughAjax')); ?>",
                      //data:{'id':id},
                      success: function(response) {
                        $("#maskid").hide();
                      //return false;
                          if (response.message == "success") {
                            swal({
                              title: "OTP resend successfully.",
                              type: "success"
                            }).then(function(){
                               location.reload();
                            })
                          
                            
                          } else {
                              swal({
                                  title: 'Unsuccess',
                                  text: response.code
                              })
                          }
                      },
                      error: function(data) {
                       
                      }
                  })
                }
                
              });
        } 
    </script>
  <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend-layout.frontend-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/reset-password.blade.php ENDPATH**/ ?>