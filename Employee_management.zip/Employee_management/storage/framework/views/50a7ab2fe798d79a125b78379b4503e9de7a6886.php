<?php $__env->startSection('title', 'DASHBOARD'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Add User</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">User</a></li>
        <li class="active">Add User</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
    	
      <!-- Default box -->
      <div class="box">
       <!-- <div class="box-header">
          <h3 class="box-title">Quick Example</h3>
        </div>-->
        <!-- /.box-header -->
        <!-- form start -->
        <form role="form" method="post" action="<?php echo e(url('post-add-user')); ?>"  onsubmit="return validateForm()" autocomplete="off">
        	<?php echo csrf_field(); ?>
          <div class="box-body">
            <div class="row">
                <div class="col-md-6">
                <?php //print "<pre>"; print_r($data);exit;?>
                	<?php
                    if(!empty($data)){
                    	$userId = $data[0]->TUM_User;
                        $TUM_User_Name = $data[0]->TUM_User_Name;
                        $TUM_User_Lname = $data[0]->TUM_User_Lname;
                        $TUM_User_IMEI = $data[0]->TUM_User_IMEI;
                        
                        $TUM_User_Mobile = $data[0]->TUM_User_Mobile;
                        $TUM_User_Email = $data[0]->TUM_User_Email;
                        $TUM_User_State = $data[0]->TUM_User_State;
                        
                        $TUM_User_Country = $data[0]->TUM_User_Country;
                        $TUM_User_Dist = $data[0]->TUM_User_Dist;
                        $TUM_User_Pin = $data[0]->TUM_User_Pin;
                        
                        $TUM_User_Status = $data[0]->TUM_User_Status;
                        $TUM_User_UserType = $data[0]->TUM_User_UserType;
                        $TUM_User_Password = $data[0]->TUM_User_Password;
                        
                        $TUM_User_Address = $data[0]->TUM_User_Address;
                        $TUM_User_PINno = $data[0]->TUM_User_PINno;
                        $TURA_UserRole = $data[0]->TURA_UserRole;
                        $roleArr = explode(",",$TURA_UserRole);
                        
                    }else{
                    	$userId = '';
                        $TUM_User_Name = '';
                        $TUM_User_Lname = '';
                        $TUM_User_IMEI = '';
                        
                        $TUM_User_Mobile = '';
                        $TUM_User_Email = '';
                        $TUM_User_State = '';
                        
                        $TUM_User_Country = '';
                        $TUM_User_Dist = '';
                        $TUM_User_Pin = '';
                        
                        $TUM_User_Status = '';
                        $TUM_User_UserType = '';
                        $TUM_User_Password = '';
                        
                        $TUM_User_Address = '';
                        $TUM_User_PINno = '';
                        $TURA_UserRole = '';
                        $roleArr = array();
                    }
                    ?>
                    
                    <div class="form-group">
                      <label for="exampleInputEmail1">First Name</label>
                      <input type="text" class="form-control" name="userName" id="userName" value="<?php echo e($TUM_User_Name); ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">IMEI Number</label>
                      <input  class="form-control" name="userIMEI" id="userIMEI" value="<?php echo e($TUM_User_IMEI); ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Mobile Number</label>
                      <input  class="form-control" name="userMobile" id="userMobile" value="<?php echo e($TUM_User_Mobile); ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputFile">User Role</label>
                      <select class="form-control" name="userRoles[]" id="userRoles" multiple="multiple">
                        <?php $__currentLoopData = $user_role_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($val->TURM_UserRole); ?>" <?php if(in_array($val->TURM_UserRole, $roleArr)): ?> selected="selected" <?php endif; ?> ><?php echo e($val->TURM_URole_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Country</label>
                      <select class="form-control" name="userCountry" id="userCountry" onchange="countryChange()">
                      	<option value="">--Select--</option>
                        <?php $__currentLoopData = $country_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($val->TCM_Country); ?>" <?php if($TUM_User_Country == $val->TCM_Country): ?> selected="selected" <?php endif; ?> ><?php echo e($val->TCM_Country_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">PIN/Zipcode</label>
                      <input type="text" class="form-control" name="userPINno" id="userPINno" value="<?php echo e($TUM_User_PINno); ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Address</label>
                      <textarea class="form-control" name="userAddress" id="userAddress"><?php echo e($TUM_User_Address); ?></textarea>
                    </div>
                    
                </div>
                
                <div class="col-md-6">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Last Name</label>
                      <input type="text" class="form-control" name="userLastName" id="userLastName" value="<?php echo e($TUM_User_Lname); ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">User Type</label>
                      <select class="form-control" name="userType" id="userType">
                      	<option value="">--Select--</option>
                        <?php $__currentLoopData = $user_type_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($val->TUT_UserType); ?>" <?php if($TUM_User_UserType == $val->TUT_UserType): ?> selected="selected" <?php endif; ?> ><?php echo e($val->TUT_UserTypeName); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                    <?php if($userId==''): ?>
                    <div class="form-group">
                      <label for="exampleInputPassword1">User Password</label>
                      <input type="password" class="form-control" name="userPassword" id="userPassword">
                    </div>
                    <?php endif; ?>
                    <div class="form-group">
                      <label for="exampleInputEmail1">PIN(4 Digit)</label>
                      <input type="text" class="form-control" name="userPin" id="userPin" value="<?php echo e($TUM_User_Pin); ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Email</label>
                      <input type="text" class="form-control" name="userEmail" id="userEmail" value="<?php echo e($TUM_User_Email); ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">State</label>
                      <select class="form-control" name="userState" id="userState" onchange="stateChange()">
                      	<option value="">--Select--</option>
                        <?php $__currentLoopData = $state_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($state->TSM_State); ?>" <?php if($TUM_User_State == $state->TSM_State): ?> selected="selected" <?php endif; ?> ><?php echo e($state->TSM_State_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">District</label>
                      <select class="form-control" name="userDistrict" id="userDistrict">
                      	<option value="">--District--</option>
                        <?php $__currentLoopData = $district_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($val->TDM_District); ?>" <?php if($TUM_User_Dist == $val->TDM_District): ?> selected="selected" <?php endif; ?> ><?php echo e($val->TDM_Dist_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Status</label>
                      <select class="form-control" name="userStatus" id="userStatus">
                      	<option value="">--Select--</option>
                        <option value="1" <?php if($TUM_User_Status ==1): ?> selected="selected" <?php endif; ?>>Active</option>
                        <option value="0" <?php if($TUM_User_Status ==0): ?> selected="selected" <?php endif; ?>>Inactive</option>
                      </select>
                    </div>
                </div>
                
            </div>
          </div>
          <!-- /.box-body -->
          <div class="box-footer">
          	<input type="hidden" name="hidUser" value="<?php echo e($userId); ?>"/>
            <button type="submit" class="btn btn-primary">Submit</button>
            <button type="button" class="btn btn-warning" onclick="window.location.href='manage-user'">Cancel</button>
          </div>
        </form>
      </div>
      <!-- /.box -->
      
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php $__env->startPush('scripts'); ?> 
	<script type="text/javascript">
		function validateForm(){
			if (!blankValidation("userName", "TextField","First Name Required"))
				return false;
			if (!checkSpecialCharacter("userName","Special character is not allowed!!!"))
				return false;
			if (!blankValidation("userLastName", "TextField","Last Name Required"))
				return false;
			if (!checkSpecialCharacter("userLastName","Special character is not allowed!!!"))
				return false;
			if (!blankValidation("userType","SelectBox", "Please Select User Type"))
				return false; 
					
			if (!blankValidation("userIMEI", "TextField","IMEI Number Required"))
				return false;
			if (!blankValidation("userMobile", "TextField","Mobile Required"))
				return false;
			if (!blankValidation("userPassword", "TextField","User Password Required"))
				return false;	
			if (!blankValidation("userRoles","SelectBox", "Please Select User Role"))
				return false; 
			if (!blankValidation("userPin", "TextField","PIN Required"))
				return false;
			if (!checkSpecialCharacter("userPin","Special character is not allowed!!!"))
				return false;	
			if (!blankValidation("userEmail", "TextField","Email Required"))
				return false;		
			if (!blankValidation("userCountry","SelectBox", "Please Select Country"))
				return false;
			if (!blankValidation("userState","SelectBox", "Please Select State"))
				return false;
			if (!blankValidation("userDistrict","SelectBox", "Please Select District"))
				return false;	
			if (!blankValidation("userPINno", "TextField","User PIN Required"))
				return false;	
			if (!blankValidation("userAddress", "TextArea","Address Required"))
				return false;
			/* if (!checkSpecialCharacter("userEmail","Special character is not allowed!!!"))
				return false; */
			if (!blankValidation("userStatus","SelectBox", "Please Select Status"))
				return false;
		}
		function countryChange() {
			$.ajaxSetup({
				headers: {
					'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
				}
			});
			if($("#userCountry").val()!=''){
				$.ajax({
					type : "POST",
					url : "add-user-state-list",
					dataType : 'json',
					//contentType : 'application/json',
					data : {"countryId":$("#userCountry").val()},
					success : function(response) {
						if (response.message == "success") {
							console.log(response);
							$("#userState").empty();
							var option = $("<option></option>");
							$(option).val(null);
							$(option).html("--Select--");
							$("#userState").append(option);
							for (var i = 0; i < response.stateList.length; i++) {
								var option = $("<option></option>");
								$(option).val(response.stateList[i].TSM_State);
								$(option).html(response.stateList[i].TSM_State_Name);
								$("#userState").append(option);
							}
			
						}
					},
					error : function(data) {
						console.log(data);
					}
				})
			}else{
				$("#userState").empty();
				var option = $("<option></option>");
				$(option).val(null);
				$(option).html("--Select--");
				$("#userState").append(option);
			}
		}
		function stateChange() {
			$.ajaxSetup({
				headers: {
					'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
				}
			});
			//alert($("#userState").val());
			if($("#userState").val()!=''){
				$.ajax({
					type : "POST",
					url : "add-user-district-list",
					dataType : 'json',
					//contentType : 'application/json',
					data : {"stateId":$("#userState").val()},
					success : function(response) {
						if (response.message == "success") {
							console.log(response);
							$("#userDistrict").empty();
							var option = $("<option></option>");
							$(option).val(null);
							$(option).html("--Select--");
							$("#userDistrict").append(option);
							for (var i = 0; i < response.districtList.length; i++) {
								var option = $("<option></option>");
								$(option).val(response.districtList[i].TDM_District);
								$(option).html(response.districtList[i].TDM_Dist_Name);
								$("#userDistrict").append(option);
							}
			
						}
					},
					error : function(data) {
						console.log(data);
					}
				})
			}else{
				$("#userDistrict").empty();
				var option = $("<option></option>");
				$(option).val(null);
				$(option).html("--Select--");
				$("#userDistrict").append(option);
			}
		}
    </script>  
  <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opscautomation\resources\views/user/add-user.blade.php ENDPATH**/ ?>