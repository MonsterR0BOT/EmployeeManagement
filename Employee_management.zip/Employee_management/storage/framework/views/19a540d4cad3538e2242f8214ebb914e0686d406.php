  
 <?php $__env->startSection('title', 'DISCIPLINARY'); ?> 
 <?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
	<!-- Content Header (Page header) -->
	<section class="content-header">
		<h1>View Disciplinary Request</h1>
		<ol class="breadcrumb">
			<li>
				<a href="#">
					<i class="fa fa-dashboard"></i> Home
				</a>
			</li>
			<li>
				<a href="#">User</a>
			</li>
			<li class="active">View Disciplinary Request</li>
		</ol>
	</section>
	<!-- Main content -->
	<section class="content">
    <?php
   // print_r($data); exit;
			if(!empty($authorityData)){
		        $groupActionArr = $authorityData[0]->groupAction ? explode(',',$authorityData[0]->groupAction):array();

		        $TSA_ApprovalActionArr = $authorityData[0]->TSA_ApprovalAction?explode(',',$authorityData[0]->TSA_ApprovalAction):array();
		        $TSA_SetAuthority_StageNo = $authorityData[0]->TSA_SetAuthority_StageNo;
		    }else{
		    	 $groupActionArr = array();
		    	 $TSA_ApprovalActionArr =array();
		    	 $TSA_SetAuthority_StageNo ='';
			}
			
				$user_list=!empty($user_list)?$user_list:array();
			
	       	?>
        <input type="text" name="hdDisplineId" id="hdDisplineId" value="<?php echo e($data[0]->TDR_DisciplinaryRequest); ?>">
        <input type="hidden" name="hdApprovalFromStatus" id="hdApprovalFromStatus" value="<?php echo e($data[0]->TDR_DisReq_Approval_Status); ?>">
		<input type="hidden1" name="hdApprovalFromStage" id="hdApprovalFromStage" value="<?php echo e($data[0]->TDR_DisReq_Approval_Stage); ?>">
		<div class="row">
			<div class="col-md-12">
				<div class="bs-example">
					<div class="accordion" id="accordionExample">
						<div class="box">
							<div class="card-header" id="headingOne">
								<a data-toggle="collapse" data-target="#collapseOne" class="accordianheading">
									<div class="row">
										<div class="col-md-11">
											<h5>OPSC Information</h5>
										</div>
										<div class="col-md-1">
											<i class="fa faicon acrdplus fa-plus-circle"></i>
										</div>
									</div>
								</a>
							</div>
							<div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
								<div class="card-body">
									<div class="box-body">
										<div class="formsecalt row">
											<div class="col-md-6 bg-color1">
												<div class="paddinglessmin"></div>
												<div class="paddinglessmax">Request Reference#</div>
											</div>
											<div class="col-md-6">
												<div class="form-group">
													<label><?php echo e($data[0]->TDR_DisciplinaryRequest); ?></label>
												</div>
											</div>
										</div>
										<div class="formsec row">
											<div class="col-md-3 bg-color1">
												<div class="paddingsmlmin">1.</div>
												<div class="paddingsmlmax">Name of the delinquent officer</div>
											</div>
											<div class="col-md-3">
												<div class="form-group">
													<label><?php echo e($data[0]->TDR_Deliquency_OfficerName); ?></label>
												</div>
											</div>
											<div class="col-md-3 bg-color1">
												<div class="paddingsmlmin">2.</div>
												<div class="paddingsmlmax">Date of birth:</div>
											</div>
											<div class="col-md-3">
												<div class="form-group">
													<label><?php echo e(($data[0]->TDR_Deliquency_DOB !='')?date("d-m-Y", strtotime($data[0]->TDR_Deliquency_DOB)):''); ?></label>
												</div>
											</div>
										</div>
										<div class="formsecalt row">
											<div class="col-md-3 bg-color1">
												<div class="paddingsmlmin">3.</div>
												<div class="paddingsmlmax">Name(s) of the Department</div>
											</div>
											<div class="col-md-3">
												<label><?php echo e($data[0]->TDR_Department); ?></label>
											</div>
											<div class="col-md-3 bg-color1">
												<div class="paddingsmlmin">4.</div>
												<div class="paddingsmlmax">Employee ID(HRMS)</div>
											</div>
											<div class="col-md-3">
												<label><?php echo e($data[0]->TDR_Deliquency_HRMSID); ?></label>
											</div>
										</div>
										<div class="formsec row">
											<div class="col-md-3 bg-color1">
												<div class="paddingsmlmin">5.</div>
												<div class="paddingsmlmax">i) Present designation</div>
											</div>
											<div class="col-md-3">
												<div class="form-group">
													<label><?php echo e($data[0]->TDR_Current_Designation); ?></label>
												</div>
											</div>
											<div class="col-md-3 bg-color1">
												<div class="paddingsmlmax">ii) Designation when the delinquency was commited</div>
											</div>
											<div class="col-md-3">
												<div class="form-group">
													<label><?php echo e($data[0]->TDR_Deliquency_Designation); ?></label>
												</div>
											</div>
										</div>
										<div class="formsecalt row">
											<div class="col-md-6 bg-color1">
												<div class="paddinglessmin">6.</div>
												<div class="paddinglessmax">Period during which the delinquency was commited</div>
											</div>
											<div class="col-md-6">
												<div class="form-group">
													<label><?php echo e($data[0]->TDR_Deliquency_Period); ?></label>
												</div>
											</div>
										</div>
										<div class="formsec row">
											<div class="col-md-6 bg-color1">
												<div class="paddinglessmin">7.</div>
												<div class="paddinglessmax">Whether the officer was suspended, if so, the date(s) of Suspension and re-instatement, if any (if not applicable, write NA) :</div>
											</div>
											<div class="col-md-6">
												<div class="row">
													<div class="col-md-6"><?php echo e($data[0]->TDR_Suspension_Statement); ?></div>
													<div class="col-md-6">
														<div class="input-group"><?php echo e(($data[0]->TDR_Suspension_FromDate !='')?date("d-m-Y", strtotime($data[0]->TDR_Suspension_FromDate)):''); ?></div>
													</div>
												</div>
											</div>
											<div class="clearfix"></div>
											<div class="col-md-6 bg-color1">
												<div class="txtindenting"> Provision of the O.C.S. (CC&A) Rules, 1962 and O.C.S.(Pension) Rules 1992 under which proceeding has been initiated (Tick the appropriate box) :</div>
											</div>
											<div  class="col-md-3">
												<div class="row">
													<div class="col-md-6"> 
                                                       <?php echo e($data[0]->TDR_OCS_Rule); ?>

                                                    </div>
												</div>
											</div>
										</div>
										<div class="formsecalt row">
											<div class="col-md-6 bg-color1">
												<div class="paddinglessmin">8.</div>
												<div class="paddinglessmax">Date of communication of charge(s) along with statement of allegation/inputation (Copy of the same to be enclosed) :</div>
											</div>
											<div class="col-md-6">
												<div class="row">
													<div class="col-md-6">
														<div class="form-group">
															<label><?php echo e($data[0]->TDR_Allegation_Statement); ?></label>
															<label><?php echo e(($data[0]->TDR_Allegation_Date !='')?date("d-m-Y", strtotime($data[0]->TDR_Allegation_Date)):''); ?></label>
														</div>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary">
																<i class="fa fa-file-pdf-o"></i> View File
															</a>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="formsec row">
											<div class="col-md-6 bg-color1">
												<div class="paddinglessmin">9.</div>
												<div class="paddinglessmax">Date of submission of written statement of defence by the delinquent officer (Copy of the same to be enclosed) :</div>
											</div>
											<div class="col-md-6">
												<div class="row">
													<div class="col-md-6">
														<div class="form-group">
															<label><?php echo e(($data[0]->TDR_DfenceStmtSubmison_Date !='')?date("d-m-Y", strtotime($data[0]->TDR_DfenceStmtSubmison_Date)):''); ?></label>
														</div>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary">
																<i class="fa fa-file-pdf-o"></i> View File
															</a>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="formsecalt row">
											<div class="col-md-6 bg-color1">
												<div class="paddinglessmin">10.</div>
												<div class="paddinglessmax">Whether enquiry was conducted (Tick the appropriate box) :</div>
											</div>
											<div class="col-md-6">
												<div class="row">
													<div class="col-md-3">
                                                    <?php if($data[0]->TDR_IsEnquiry_Conducted==1): ?>
                                                  	<?php echo e("Yes"); ?>

                                                  	<?php else: ?>
                                                  	<?php echo e("No"); ?>

                                                  	<?php endif; ?>
                                                    </div>
												</div>
											</div>
										</div>
										<div class="formsec row">
											<div class="col-md-6 bg-color1">
												<div class="paddinglessmin">11.</div>
												<div class="paddinglessmax">If yes, designation of the I.O. and date of submission of his report (Copy of the report of I.O. to be enclosed) :</div>
											</div>
											<div class="col-md-6">
												<div class="row">
													<div class="col-md-6">
														<div class="row">
															<div class="col-md-6">
                                                            <?php echo e($data[0]->TDR_IO_Designation); ?><?php echo e($data[0]->TDR_IO_PostedArea); ?> Division <?php echo e(($data[0]->TDR_IOReport_SubmisionDate !='')?date("d-m-Y", strtotime($data[0]->TDR_IOReport_SubmisionDate)):''); ?>

                                                            </div>
														</div>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary">
																<i class="fa fa-file-pdf-o"></i> View File
															</a>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="formsecalt row">
											<div class="col-md-6 bg-color1">
												<div class="paddinglessmin">12.</div>
												<div class="paddinglessmax">Whether report of the I.O. was sent to the delinquent officer along with show cause notice calling him to submit his presentation within 15 days as required under Rule 15(10)(i)(a)of the O.C.S. (C.C.&A) Rules,1962 (Tick the appropriate box). (Copy of notice to be enclosed) :</div>
											</div>
											<div class="col-md-6">
												<div class="row">
													<div class="col-md-6">
														<?php if($data[0]->TDR_IsIOReport_SentToOficer==1): ?>
                                                  	<?php echo e("Yes"); ?>

                                                  	<?php else: ?>
                                                  	<?php echo e("No"); ?>

                                                  	<?php endif; ?>
                                                    </div>
													<div class="col-md-6">
														<div class="form-group">
															<a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary">
																<i class="fa fa-file-pdf-o"></i> View File
															</a>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="formsec row ">
											<div class="col-md-6 bg-color1 ">
												<div class="paddinglessmin">13.</div>
												<div class="paddinglessmax">Date of represenation of the D.O. in response to the notice required under Rule 15(10) (i) (a) of the O.C.S. (C.C. &A) Rules, 1962 (Copy of represenation to be enclosed) :</div>
											</div>
											<div class="col-md-6 ">
												<div class="row ">
													<div class="col-md-6 ">
														<div class="form-group">
															<label><?php echo e(($data[0]->TDR_DORepresent_Date !='')?date("d-m-Y", strtotime($data[0]->TDR_DORepresent_Date)):''); ?></label>
														</div>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary">
																<i class="fa fa-file-pdf-o"></i> View File
															</a>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="formsecalt row ">
											<div class="col-md-6 bg-color1 ">
												<div class="paddinglessmin">14.</div>
												<div class="paddinglessmax"> Penalty imposed by the Disciplinary Authority before the issue of 2nd show cause notice (Copy of detailed finding and order of Disciplinary Authority and Govt. to be enclosed).</div>
											</div>
											<div class="col-md-6 ">
												<div class="row ">
													<div class="col-md-6">
														<label>a) <?php echo e($data[0]->TDR_BfScndShwCausNotic_PenalityImposed); ?></label>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary">
																<i class="fa fa-file-pdf-o"></i> View File
															</a>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="formsec row ">
											<div class="col-md-6  bg-color1 ">
												<div class="paddinglessmin">15.</div>
												<div class=" paddinglessmax">In case imposition of major penalty :-</div>
												<div class="txtindentingone">
                                                    (a) Date of second show cause notice issued u/r 15(10) (i)(b) (Copy to be enclosed):
                                                   </div>
											</div>
											<div class="col-md-3">
												<div class="form-group">
													<label><?php echo e(($data[0]->TDR_SecondShowCauseNotice_Date !='')?date("d-m-Y", strtotime($data[0]->TDR_SecondShowCauseNotice_Date)):''); ?></label>
												</div>
											</div>
											<div class="col-md-3">
												<div class="form-group">
													<a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary">
														<i class="fa fa-file-pdf-o"></i> View File
													</a>
												</div>
											</div>
											<div class="clearfix"></div>
											<div class="col-md-6 bg-color1">
												<div class="txtindentingone">
                                        (b) Date of explanation received from the delinquent officer in reply to 2nd show causes notice (Copy of explanation of D.O. to be enclosed)
                                    </div>
											</div>
											<div class="col-md-3">
												<div class="form-group">
													<label><?php echo e(($data[0]->TDR_SecndCauseNotice_ExplanatnDate !='')?date("d-m-Y", strtotime($data[0]->TDR_SecndCauseNotice_ExplanatnDate)):''); ?></label>
												</div>
											</div>
											<div class="col-md-3">
												<div class="form-group">
													<a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary">
														<i class="fa fa-file-pdf-o"></i> View File
													</a>
												</div>
											</div>
										</div>
										<div class="formsecalt row">
											<div class="col-md-6 bg-color1">
												<div class="paddinglessmin">16.</div>
												<div class="paddinglessmax">Incase of disagreement with the finding of recommendation of I.O. whether reasons for the same has been recorded (Copy of order of Disciplinary Authority to be enclosed) :</div>
											</div>
											<div class="col-md-6 ">
												<div class="row ">
													<div  class="col-md-6">
                                                    <?php if($data[0]->TDR_IsDisagrementReson_Recorded==1): ?>
                                                  	<?php echo e("Yes"); ?>

                                                  	<?php else: ?>
                                                  	<?php echo e("No"); ?>

                                                  	<?php endif; ?>
                                                        </div>
													<div class="col-md-6">
														<div class="form-group">
															<a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary">
																<i class="fa fa-file-pdf-o"></i> View File
															</a>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="formsec row">
											<div class="col-md-6 bg-color1">
												<div class="paddinglessmin">17.</div>
												<div class="paddinglessmax">In the event of joint proceedings u/r 17 of the O.C.S. (CC&A) Rules, 1962, is concurrence of disciplinary authorities of all the Depts to which delinquent officers belong to have been taken?</div>
											</div>
											<div class="col-md-6">
												<div class="row">
													<div class="col-md-3">
												  <?php if($data[0]->TDR_IsConcurrance_ByDisplinaryAuthority==1): ?>
                                                  	<?php echo e("Yes"); ?>

                                                  	<?php else: ?>
                                                  	<?php echo e("No"); ?>

                                                  	<?php endif; ?>		
                                                </div>
												</div>
											</div>
										</div>
										<div class="formsecalt row">
											<div class="col-md-6 bg-color1">
												<div class="paddinglessmin">18.</div>
												<div class="paddinglessmax">In case of proposal for imposition of penalty on the D.O. whether orders of Govt.have been taken?</div>
											</div>
											<div class="col-md-6"> <?php if($data[0]->TDR_IsPenalityImpositnOrder_HasTaken==1): ?>
                                                  	<?php echo e("Yes"); ?>

                                                  	<?php else: ?>
                                                  	<?php echo e("No"); ?>

                                                  	<?php endif; ?></div>
											<div class="col-md-6 bg-color1">
												<div class="txtindenting">Copy of the Notes & Order sheet of Govt. from appropriate level to be enclosed :</div>
											</div>
											<div class="col-md-6">
												<div class="row">
													<div class="col-md-6">
														<?php if($data[0]->TDR_IsCopyOfNotesEnclosed==1): ?>
                                                  	<?php echo e("Yes"); ?>

                                                  	<?php else: ?>
                                                  	<?php echo e("No"); ?>

                                                  	<?php endif; ?>
                                                </div>
													<div class="col-md-6">
														<div class="form-group">
															<a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary">
																<i class="fa fa-file-pdf-o"></i> View File
															</a>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div align="right" class="col-md-12 mrt_10">
											<a href="<?php echo e(url('DisciplinaryRequest/viewDisciplinaryPrint')); ?>/<?php echo e(Crypt::encryptString($data[0]->TDR_DisciplinaryRequest)); ?>"  target="_blank" class="btn btn-secondary" id="printbtn"><i class="fa fa-print"></i> Print</a>
											<button class="btn btn-danger"onclick="window.history.go(-1); return false;">Cancel</button>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="box">
							<div class="card-header" id="headingThree">
								<a data-toggle="collapse" data-target="#collapseThree" class="accordianheading">
									<div class="row">
										<div class="col-md-11">
											<h5>Document Check List</h5>
										</div>
										<div class="col-md-1">
											<i class="fa faicon acrdplus fa-plus-circle"></i>
										</div>
									</div>
								</a>
							</div>
							<div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
								<div class="card-body">
									<div class="col-md-12">
										<div class="row">
											<?php $sl=1; 
											if(!empty($chk_doc_list)){
	                              				$arrColumns = array_column($chk_doc_list,'docType');
	                              			}
											?>
												<?php $__currentLoopData = $doc_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<div class="col-md-6">
													<div class="row listview">
														<div class="col-md-11"><?php echo e($sl.'. '); ?> <?php echo e($val->TDM_Doc_Name); ?></div>
														<div class="col-md-1 listicon">
															 <?php if(!empty($arrColumns)): ?><?php if(in_array($val->TDM_Doc,$arrColumns)): ?> <i class="fa fa-check text-success"></i> 
															 <?php endif; ?> <?php endif; ?>
														</div>
													</div>
												</div>
											<?php $sl+=1; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

										</div>
									</div>
									<div class="clearfix"></div>
									<div align="right" class="col-md-12 mrt_10">
										<button class="btn btn-danger"onclick="window.history.go(-1); return false;">Cancel</button>
									</div>
								</div>
								<div class="clearfix"></div>
							</div>
						</div>
						<div class="box">
							<div class="card-header" id="headingFour">
								<a data-toggle="collapse" data-target="#collapseFour" class="accordianheading">
									<div class="row">
										<div class="col-md-11">
											<h5>Officer Comments</h5>
										</div>
										<div class="col-md-1">
											<i class="fa fa-plus-circle faicon acrdplus"></i>
										</div>
									</div>
									<div class="clearfix"></div>
								</a>
							</div>
							<div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
								<div class="card-body">
									<div class="box-body">
										<div class="row">
											<div class="col-md-12">
												<!-- The timeline -->
											<ul class="timeline timeline-inverse">
												   <?php $__currentLoopData = $commentsArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date=>$comments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<?php
														$dateclass= ($date < date('Y-m-d h:i:s'))?'bg-red':'bg-green';
													?>
													<!-- timeline time label -->
													<li class="time-label">
														<span class="<?php echo e($dateclass); ?>"><?php echo e(date('d M Y', strtotime($date))); ?></span>
													</li>
													<!-- /.timeline-label -->
													<!-- timeline item -->
													<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<li>
														<i class="fa fa-comments bg-yellow"></i>
														<div class="timeline-item">
															<span class="time">
																<i class="fa fa-clock-o"></i> <?php echo e(date('d M Y h:i:s', strtotime($val->TDAH_Approval_CreatedOn))); ?>

															</span>
															<h3 class="timeline-header">
																<a href="#"><?php echo e($val->TUM_User_Name.' '); ?> <?php echo e($val->TUM_User_Lname); ?></a>, <?php echo e($val->TDM_Desig_Name); ?>, <?php echo e($val->TUM_User_Dept); ?>

															</h3>
															<div class="timeline-body"><?php echo e($val->TDAH_Approval_Comment); ?> </div>

														</div>
													</li>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													<!-- END timeline item -->
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													<li>
														<i class="fa fa-clock-o bg-gray"></i>
													</li>
												</ul>
												<div class="col-md-12 padding_10" align="right">
												<?php if($data[0]->TDR_DisReq_Approval_Stage== $TSA_SetAuthority_StageNo): ?> 
												 <button class="btn btn-success" data-toggle="modal" data-target="#comments" data-backdrop="static" data-keyboard="false" id="btnGiveComments">Give your comments</button><?php endif; ?>
												 <a href="<?php echo e(url('DisciplinaryRequest/viewDisciplinaryPrint')); ?>/<?php echo e(Crypt::encryptString($data[0]->TDR_DisciplinaryRequest)); ?>" target="_blank" class="btn btn-secondary" id="printbtn"><i class="fa fa-print"></i> Print</a>
												<button class="btn btn-danger"onclick="window.history.go(-1); return false;">Cancel</button>
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- /.box -->
			</div>
			<!-- /.col -->
		</div>
		<!-- /.box -->
	</section>
	<!-- /.content -->
</div>
<!-- /.content-wrapper -->
<div class="modal" id="myModal">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<!-- Modal Header -->
			<div class="modal-header">
				<h4 class="modal-title">Upload Files</h4>
				<!-- <button type="button" class="close" data-dismiss="modal">×</button> -->
			</div>
			<!-- Modal body -->
			<div class="modal-body">
				<div class="col-md-12">
					<div class="row">
						
						<?php $__currentLoopData = $uploadedDocumentData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-md-4 bg-color1"><?php echo e(isset($val->docText)? $val->docText:''); ?></div>
						<div class="col-md-2">
							<a href="<?php echo e(url('public/storage/disciplinary_files')); ?>/<?php echo e(isset($val->docName)? $val->docName:''); ?>"  target="_blank">
								<i class="fa fa-file-pdf-o fa-2x text-danger"></i>
							</a>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
					</div>
				</div>
			</div>
			<!-- Modal footer -->
			<div class="modal-footer" align="center">
				<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>
<!--Modal Start-->
<div class="modal" id="comments">
  <div class="modal-dialog">
    <div class="modal-content">
      <!-- Modal Header -->
        <div class="modal-header">
        <h4 class="modal-title">Give your comments</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <!-- Modal body -->
      <div class="modal-body">
     <div class="col-md-12">
        <div class="modalstyleheader">
         <div class="row">
          <div class="col-md-7">
            <div class="row mrt_10">
            	<?php $__currentLoopData = $groupActionArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6">
                    <input type="radio" name="rdApprove" class="minimal" value="<?php echo e($TSA_ApprovalActionArr[$k]); ?>"> <?php echo e($val); ?>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- <div class="col-md-6">
                    <input type="radio" name="rdApprove" class="minimal" value="0"> Reassign
                </div> -->
            </div>
           </div>
           <div class="col-md-5" id='div_userList' style="display:none" >
             <select class="form-control" id="reassign">
                <option>--Select--</option>
                <?php $__currentLoopData = $user_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($val->TUM_User); ?>">
                <?php echo e($val->TUM_User_Name); ?> <?php echo e($val->TUM_User_Lname); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </select>
           </div>
       </div>
       </div>   
     
     <div class="row">
      <div class="col-md-12"><textarea name="txaComments" id="txaComments" class="form-control" rows="5" placeholder="Give your comments... "></textarea>
      </div>
    </div>
    </div>
      </div>
      <!-- Modal footer -->
      <div class="modal-footer" align="center">
         <button class="btn btn-primary" id="saveComment">Submit</button>
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!-- Modal End -->


<?php $__env->startPush('scripts'); ?>


<script>
	$(document).ready(function(){
    $('input[name="rdApprove"]').click(function(){
        var inputValue = $(this).attr("value");
        if(inputValue=='app002'){
        	$("#div_userList").show();
        }else{
        	$("#div_userList").hide();
        }
        
    });
});


function validateForm(){
    //alert("alert");return false;
  if (!blankValidation("rdApprove","RadioButton", "Please select one option"))
      return false; 
  if (!blankValidation("txaComments","TextArea", "Comments can not be left blank"))
      return false;

  return true;
 } 

$("#saveComment").click(function(){
	if(validateForm()){
    var  data = {};
    data['disciplinaryId']=$("#hdDisplineId").val();
 	data['approvalFromStage']=$("#hdApprovalFromStage").val();
	data['approvalFromStatus']=$("#hdApprovalFromStatus").val();
    data['txaComments']=$("#txaComments").val();
    data['rdApprove']=$("input[name='rdApprove']:checked").val();
    data['reassign']=$("#reassign").val();
    submitComment(data);
    }else
		return false;
    });

function submitComment(data){
    console.log('submit as submitComment --',data);
     //return false;
    $.ajaxSetup({
    headers: {
    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
    }
    });
    swal.fire({
    title: "Do you want to submit?",
    text: "",
    type: "warning",
    showCancelButton: true,
    confirmButtonColor: '#d33',
    cancelButtonColor: '#e7b63a',
    confirmButtonText: 'Submit',
    reverseButtons : true

    }).then((result) => {
    if(result.value){
    $.ajax({
    type: "POST",
    url:"<?php echo e(url('disciplinaryRequest/saveComment')); ?>",
    dataType  : "json",
    contentType : "application/json",
    data    : JSON.stringify(data),
    success   : function(response){
      console.log("response ",response);
      if(response.message=="success"){
        swal({
            title:"Data Saved Successfully.",
            type: "success",
        }).then(function(){
          //window.location.href='manage-relaxation-request'; 
           window.location.href='<?php echo e(url("disciplinaryRequest/viewHodDisciplinary")); ?>';
        })
      }else{
        swal({
          title:response.code,
          text: response.message,
          type:"warning"
        })
      }
    },
    error : function(data) {
    console.log(data); 
    }
    })
    }

    });
    }


</script>
<?php $__env->stopPush(); ?> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/disciplinary/view-disciplinary.blade.php ENDPATH**/ ?>