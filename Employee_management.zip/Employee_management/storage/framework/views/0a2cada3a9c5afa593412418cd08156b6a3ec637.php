<?php $__env->startSection('title', 'DISCIPLINARY'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Manage Disciplinary
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Department Requisition</a></li>
        <li class="active">Manage Disciplinary</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box">
           <!-- <div class="box-header">
              <h3 class="box-title">Data Table With Full Features</h3>
            </div>-->
            <!-- /.box-header -->
            <div class="box-body">
              <div id="demo" >
                <div class="search-field">
                   
                    <div class="row">
    
                        <div class="col-md-1">
                            <div class="org-name">From Date</div>
                        </div>
                        <div class="col-md-2">
                            <input class="form-control" type="text" id="param1">
                        </div>
                        
                        <div class="col-md-1">
                            <div class="org-name">To Date</div>
                        </div>
                        <div class="col-md-2">
                            <input class="form-control" type="text" id="param2">
                        </div>
                        
                        <div class="col-md-1">
                            <div class="org-name">Request Ref#</div>
                        </div>
                        <div class="col-md-2">
                            <input class="form-control" type="text" id="param3">
                        </div>
                        <div class="col-md-1">
                            <div class="form-group">
                                <button class="btn btn-primary" onClick="searchData()">Search</button>
                            </div>
                        </div>
                         <div class="col-md-2">
                              <div class="form-group pull-right">
                               <a href="<?php echo e(url('add-disciplinary-request')); ?>">
                                <button class="btn btn-primary">Add  Request</button>
                              </a>
                              </div>
                          </div>
                    </div>
                   <!--  <div class="row">
                      <div class="col-md-12" align="right">
                        <a href="#" target="_blank" class="btn btn-default"><i class="fa fa-print"></i> Print</a>
                        <a href="#" target="_blank" class="btn btn-default"><i class="fa fa-file-pdf-o"></i> PDF</a>
                    </div>
                    </div> -->
                </div>
            </div>
            <!-- <a data-toggle="collapse" data-target="#demo"
                class="showhideangelbg"><i class="fa fa-angle-double-down"></i>
            </a> -->
           
              <table id="listAllUser" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Request Ref#</th>
                  <th>Department</th>
                  <th>Delinquent Officer</th>
                  <th>Designation</th>
                  <th>Status</th>
                  <th>Dept Status</th>
                  <th>Date Time</th>                 
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                 <tr>
                  <td><a href="<?php echo e(url('view-disciplinary-request')); ?>">DISCP/2018-2019/1001</a></td>
                  <td>Works</td>
                  <td>Shyma Prasad</td>
                  <td>Forest Ranger</td>
                  <td><span class="label label-primary">New</span></td>
                  <td>Un approved</td>
                  <td>12-12-2019 12:00:45</td>
                  <td>
                    <a href="<?php echo e(url('view-disciplinary-request')); ?>"><i class="fa fa-eye"></i></a> &nbsp;&nbsp;  <a href="<?php echo e(url('edit-disciplinary-request')); ?>"><i class="fa fa-edit"></i></a> &nbsp;&nbsp; 
                    <a href='javascript:void(0)' onclick='deleteRecord()'><i class="fa fa-trash"></i></a>
                  </td>
                </tr>
                <tr>
                  <td><a href="<?php echo e(url('view-disciplinary-request')); ?>">DISCP/2018-2019/1002</a></td>
                  <td>Works</td>
                  <td>Tapan Patanayak</td>
                  <td>Executive Engg.</td>
                  <td><span class="label label-primary">New</span></td>
                  <td>Un approved</td>
                  <td>12-12-2019 12:00:45</td>
                  <td>
                    <a href="<?php echo e(url('view-disciplinary-request')); ?>"><i class="fa fa-eye"></i></a> &nbsp;&nbsp;  <a href="<?php echo e(url('edit-disciplinary-request')); ?>"><i class="fa fa-edit"></i></a> &nbsp;&nbsp; 
                    <a href='javascript:void(0)' onclick='deleteRecord()'><i class="fa fa-trash"></i></a>
                  </td>
                </tr>
                <tr>
                  <td><a href="<?php echo e(url('view-disciplinary-request')); ?>">DISCP/2018-2019/1003</a></td>
                  <td>Works</td>
                  <td>Monalisha Kar</td>
                  <td>Dy. Engg.</td>
                  <td><span class="label label-primary">New</span></td>
                  <td>Un approved</td>
                  <td>12-12-2019 12:00:45</td>
                  <td>
                    <a href="<?php echo e(url('view-disciplinary-request')); ?>"><i class="fa fa-eye"></i></a> &nbsp;&nbsp;  <a href="<?php echo e(url('edit-disciplinary-request')); ?>"><i class="fa fa-edit"></i></a> &nbsp;&nbsp; 
                    <a href='javascript:void(0)' onclick='deleteRecord()'><i class="fa fa-trash"></i></a>
                  </td>
                </tr>
                 <tr>
                  <td><a href="<?php echo e(url('view-disciplinary-request')); ?>">DISCP/2018-2019/1004</a></td>
                  <td>Works</td>
                  <td>Jagabandhu Sahoo</td>
                  <td>DFO</td>
                  <td><span class="label label-info">Open</span></td>
                  <td>Approved</td>
                  <td>12-12-2019 12:00:45</td>
                  <td>
                    <a href="<?php echo e(url('view-disciplinary-request')); ?>"><i class="fa fa-eye"></i></a> &nbsp;&nbsp;<a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false"><i class="fa fa-clock-o"></i></a>
                  </td>
                </tr>
                <tr>
                  <td><a href="<?php echo e(url('view-disciplinary-request')); ?>">DISCP/2018-2019/1005</a></td>
                  <td>Works</td>
                  <td>Sunanda Swain</td>
                  <td>Executive Eng.</td>
                  <td><span class="label label-info">Open</span></td>
                  <td>Approved</td>
                  <td>12-12-2019 12:00:45</td>
                  <td>
                    <a href="<?php echo e(url('view-disciplinary-request')); ?>"><i class="fa fa-eye"></i></a> &nbsp;&nbsp;<a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false"><i class="fa fa-clock-o"></i></a>
                  </td>
                </tr>
                <tr>
                  <td><a href="<?php echo e(url('view-disciplinary-request')); ?>">DISCP/2018-2019/1006</a></td>
                  <td>Works</td>
                  <td>Malaya Mishra</td>
                  <td>Dy. Secretary</td>
                  <td><span class="label label-danger">Rejected</span></td>
                  <td>Approved</td>
                  <td>12-12-2019 12:00:45</td>
                 <td>
                    <a href="<?php echo e(url('view-disciplinary-request')); ?>"><i class="fa fa-eye"></i></a> &nbsp;&nbsp;<a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false"><i class="fa fa-clock-o"></i></a>
                  </td>
                </tr>
                <tr>
                  <td><a href="<?php echo e(url('view-disciplinary-request')); ?>">DISCP/2018-2019/1007</a></td>
                  <td>Works</td>
                  <td>Dinesh Kumar</td>
                  <td>AGM</td>
                  <td><span class="label label-success">Approved</span></td>
                  <td>Approved</td>
                  <td>12-12-2019 12:00:45</td>
                  <td>
                    <a href="<?php echo e(url('view-disciplinary-request')); ?>"><i class="fa fa-eye"></i></a> &nbsp;&nbsp;<a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false"><i class="fa fa-clock-o"></i></a>
                  </td>
                </tr>
                <tr>
                  <td><a href="<?php echo e(url('view-disciplinary-request')); ?>">DISCP/2018-2019/1008</a></td>
                  <td>Works</td>
                  <td>Sdhansu Mishra</td>
                  <td>Addl. Secretary</td>
                  <td><span class="label label-primary">New</span></td>
                  <td>Approved</td>
                  <td>12-12-2019 12:00:45</td>
                  <td>
                    <a href="<?php echo e(url('view-disciplinary-request')); ?>"><i class="fa fa-eye"></i></a> &nbsp;&nbsp;  <a href="<?php echo e(url('edit-disciplinary-request')); ?>"><i class="fa fa-edit"></i></a> &nbsp;&nbsp; 
                    <a href='javascript:void(0)' onclick='deleteRecord()'><i class="fa fa-trash"></i></a>
                  </td>
                </tr>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
    <!-- Modal Start-->
    <div id="myModal" class="modal fade" role="dialog">
      <div class="modal-dialog modal-lg">
        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Proceeding Status</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          </div>
          <div class="modal-body">
            <div class="col-md-12">
                    <!-- The timeline -->
                    <ul class="timeline timeline-inverse">
                        <!-- timeline time label -->
                        <li class="time-label"> <span class="bg-red">10 Dec. 2019</span>
                        </li>
                        <!-- /.timeline-label -->
                        <!-- timeline item -->
                        <li>
                            <i class="fa fa-user bg-blue"></i>
                            <div class="timeline-item"><span class="time"><i class="fa fa-clock-o"></i> 10 Dec. 2019 12:05:20</span>
                                <h3 class="timeline-header"><a href="#">Prasanna Behera</a>, Office Asst, Agriculture & F.E Department</h3>
                                <div class="timeline-body">I certify that all information given above have been checked by me and found to be correct & all copies of relevant documents as mentioned above have been enclosed. </div>
                                <!-- <div class="timeline-footer">     <a class="btn btn-primary btn-xs">Read more</a>     <a class="btn btn-danger btn-xs">Delete</a>   </div> -->
                            </div>
                        </li>
                        <!-- END timeline item -->
                        <!-- timeline item -->
                        <li>
                            <i class="fa fa-comments bg-yellow"></i>
                            <div class="timeline-item"><span class="time"><i class="fa fa-clock-o"></i> 10 Dec. 2019 15:20:35</span>
                                <h3 class="timeline-header"><a href="#">Prakash Nayak</a>, HOD Dept, Agriculture & F.E Department</h3>
                                <div class="timeline-body"> The proceeding is verified and found ok and send to OPSC for further verification. </div>
                            </div>
                        </li>
                        <!-- END timeline item -->
                        <!-- timeline item -->
                        <li>
                            <i class="fa fa-comments bg-yellow"></i>
                            <div class="timeline-item"><span class="time"><i class="fa fa-clock-o"></i> 10 Dec. 2019 10:27:00</span>
                                <h3 class="timeline-header"><a href="#">Golak Roy</a>, SO, OPSC</h3>
                                <div class="timeline-body"> Checked the proceeding and assigned to ASO for further verification </div>
                                <!-- <div class="timeline-footer">     <a class="btn btn-warning btn-flat btn-xs">View comment</a>   </div> -->
                            </div>
                        </li>
                        <!-- END timeline item -->
                        <!-- timeline time label -->
                        <li class="time-label"> <span class="bg-green">12 Dec. 2019</span>
                        </li>
                        <!-- /.timeline-label -->
                        <!-- timeline item -->
                        <li>
                            <i class="fa fa-comments bg-yellow"></i>
                            <div class="timeline-item"><span class="time"><i class="fa fa-clock-o"></i> 12 Dec. 2019 9:27:35</span>
                                <h3 class="timeline-header"><a href="#">Yudhistir Nayak</a>, Dy. Secretary, OPSC</h3>
                                <div class="timeline-body"> Checked the proceeding and assigned to ASO for further verification </div>
                                <!-- <div class="timeline-footer">     <a class="btn btn-warning btn-flat btn-xs">View comment</a>   </div> -->
                            </div>
                        </li>
                        <!-- END timeline item -->
                        <!-- timeline item -->
                        <li>
                            <i class="fa fa-comments bg-yellow"></i>
                            <div class="timeline-item"><span class="time"><i class="fa fa-clock-o"></i> 12 Dec. 2019 11:30:45</span>
                                <h3 class="timeline-header"><a href="#">Subodha Nayak</a>, Secretary, OPSC</h3>
                                <div class="timeline-body"> Checked the proceeding and assigned to ASO for further verification </div>
                                <!-- <div class="timeline-footer">     <a class="btn btn-warning btn-flat btn-xs">View comment</a>   </div> -->
                            </div>
                        </li>
                        <!-- END timeline item -->
                        <li> <i class="fa fa-clock-o bg-gray"></i></li>
                    </ul>
            </div>
          </div>
          <div class="modal-footer" align="center">
            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>
    <!-- Modal End-->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('styles'); ?>
<!--Extra styles can written here -->
<?php $__env->stopPush(); ?>  
<?php $__env->startPush('scripts'); ?>

<script>
$(function () {
  $('#listAllUser').DataTable({
    'processing' : true,
    'serverSide' : false,
    'searching' : false,
    'ordering' : false
  });
  
  });
  /*$(function () {
  $('#listAllUser').DataTable({
    'processing' : true,
    'serverSide' : true,
    'searching' : false,
    'ordering' : false,
    "ajax" : {
      'url' : 'view-user-throughAjax',
      'data' : function(d) {
        d.param1 = $('#param1').val();
        d.param2 = $('#param2').val();
        d.param3 = $('#param3').val();

      }
    },
    'dataSrc' : "",
    'columns' : [ {
      'data' : 'TUM_User_Name'
    }, {
      'data' : 'TUT_UserTypeName'
    }, {
      'data' : 'TUM_User_IMEI'
    }, {
      'data' : 'TUM_User_Mobile'
    }, {
      'data' : 'TUM_User_Email'
    }, {
      'data' : 'TCM_Country_Name'
    }, {
      'data' : 'TSM_State_Name'
    }, {
      'data' : 'TDM_Dist_Name'
    }, {
      'data' : 'TUM_User_Pin'
    }, {
      'data' : 'TUM_User_Status'
    }, {
      'data' : 'action'
    }

    ]
  });
  
  });*/
  //Method For Searching Records In The List
  /*function searchData() {
    $('#listAllUser').DataTable().draw();
  }*/
  //Deleting the Record
  function deleteRecord(id){
    swal.fire({
        title: "Are you sure want to Delete?",
        text: "Once Deleted,Can't revert back !",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#e7b63a',
        confirmButtonText: 'Delete',
        reverseButtons : true
        
      }).then((result) => {
        if(result.value){
        /* $.ajax({
              type: "GET",
              url:"delete-department?id="+ id,
              success: function(response) {
            console.log(response);
            //return false;
                  if (response.message == "success") {
                    swal({
                      title: "Record Deleted Successfully.",
                      type: "success"
                    }).then(function(){
                       location.reload();
                    })
                  
                    
                  } else {
                      swal({
                          title: 'Unsuccess',
                          text: response.code
                      })
                  }
              },
              error: function(data) {
               
              }
          })*/
        }
        
      });
  } 
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/disciplinary/manage-disciplinary.blade.php ENDPATH**/ ?>