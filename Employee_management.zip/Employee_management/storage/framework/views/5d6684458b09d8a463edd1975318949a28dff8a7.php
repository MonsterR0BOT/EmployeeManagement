<?php $__env->startSection('title', 'CONTACT'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1> Edit Term&Condition</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Edit Term&Condition</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <?php //print_r($emailDetails);exit;?>
      <!-- Default box -->
      <div class="box">
        <form role="form" id="emailForm" method="post" autocomplete="off" action="<?php echo e(url('content/saveContactAddress')); ?>">
          <?php echo e(csrf_field()); ?>

          <div class="box-body">
             <?php if(Session::has('errors')): ?>
                  <div class="col-md-12 alert alert-warning">
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php echo e($error); ?><br/>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
              <?php endif; ?>
            <div class="row">
                <div class="col-md-6">
                  <?php
                        if(!empty($data)){
                            $contactId = $data[0]->TCM_Contact;
                            $TCM_Contact_Name  = $data[0]->TCM_Contact_Name ;
                            $TCM_Contact_Phone = $data[0]->TCM_Contact_Phone;
                            $TCM_Contact_Email = $data[0]->TCM_Contact_Email;
                            $TCM_Contact_Active = $data[0]->TCM_Contact_Active;
                        }else{
                            $contactId = '';
                            $TCM_Contact_Name  = '' ;
                            $TCM_Contact_Phone = '';
                            $TCM_Contact_Email = '';
                            $TCM_Contact_Active = 1;
                        }
                    ?>
                    <input type="hidden" name="hdContactId" id="hdContactId" value="<?php echo e($contactId); ?>"> 
                    <div class="form-group">
                      <label for="name">Postal Address</label>
                      <input type="text" class="form-control" name="postaladdreass" id="postaladdreass" value="<?php echo e($TCM_Contact_Name); ?>"> 
                    </div>

                  
                </div>
            <!--      <div class="col-md-6">
                  <div class="col-md-6">
                       <div class="form-group form-bg">
                          <label>Do you want to Write in Odia ? </label>
                       </div>
                    </div>
                    <div class="col-md-6">
                       <div class="form-group">
                          <div class="checkbox">
                             <input type="checkbox" id="checkboxId" onClick="javascript:checkboxClickHandler()">
                            <select id="languageDropDown" name="languageDropDown" onChange="javascript:languageChangeHandler()"></select>                                                   
                          </div> 
                       </div>
                    </div>
                </div> -->
                <div>
                </div>
                <div class="col-md-6">    
                    <div class="form-group">
                      <label for="name">Phone</label>
                      <input type="text" class="form-control" name="Phone" id="Phone" value="<?php echo e($TCM_Contact_Phone); ?>"> 
                    </div>
                     
                </div>
                <div class="col-md-6">    
                    <div class="form-group">
                      <label for="name">Email</label>
                      <input type="text" class="form-control" name="email" id="email" value="<?php echo e($TCM_Contact_Email); ?>"> 
                    </div>
                     
                </div>
         
            </div>
          </div>
          <!-- /.box-body -->
          <div class="box-footer">
            <button type="button" class="btn btn-primary" onclick="validateForm();">Save</button>
             <a href="<?php echo e(url('content/viewContactAddress')); ?>"><button type="button" class="btn btn-warning" >Cancel</button></a>
          </div>
        </form>
      </div>
      <!-- /.box -->
      
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('scripts'); ?> 
<script type="text/javascript">
   function validateForm(){
      if (!blankValidation("postaladdreass","TextField", "Address Name can not be left blank"))
          return false; 
         if (!blankValidation("phone","TextField", "Phone No can not be left blank"))
          return false; 
         if (!blankValidation("email","TextField", "Email can not be left blank"))
          return false; 
      $('#emailForm').submit();
   }  
   $(function () {
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    CKEDITOR.replace('termconditionDescription')
    //CKEDITOR.replace('contentDescriptionOdia')
    $("#checkboxId").click();
  })
</script>
<!--FOR CHANGE LANGUAGE-->
<script type="text/javascript" src="https://www.google.com/jsapi"></script>
  <script type="text/javascript">
    google.load("elements", "1", {
      packages: "transliteration"
    });

    var transliterationControl;
    function onLoad() {
      var options = {
        sourceLanguage: 'en',
        destinationLanguage: ['or'],
        transliterationEnabled: false,
        shortcutKey: 'ctrl+g'
      };
      // Create an instance on TransliterationControl with the required
      // options.
      transliterationControl =
      new google.elements.transliteration.TransliterationControl(options);

      // Enable transliteration in the textfields with the given ids.
      var ids = [  "contentNameOdia", "contentDescriptionOdia"];
      transliterationControl.makeTransliteratable(ids);

      // Add the STATE_CHANGED event handler to correcly maintain the state
      // of the checkbox.
      transliterationControl.addEventListener(
      google.elements.transliteration.TransliterationControl.EventType.STATE_CHANGED,
      transliterateStateChangeHandler);

      // Add the SERVER_UNREACHABLE event handler to display an error message
      // if unable to reach the server.
      transliterationControl.addEventListener(
      google.elements.transliteration.TransliterationControl.EventType.SERVER_UNREACHABLE,
      serverUnreachableHandler);

      // Add the SERVER_REACHABLE event handler to remove the error message
      // once the server becomes reachable.
      transliterationControl.addEventListener(
      google.elements.transliteration.TransliterationControl.EventType.SERVER_REACHABLE,
      serverReachableHandler);

      // Set the checkbox to the correct state.
      document.getElementById('checkboxId').checked =
      transliterationControl.isTransliterationEnabled();

      // Populate the language dropdown
      var destinationLanguage =
      transliterationControl.getLanguagePair().destinationLanguage;
      var languageSelect = document.getElementById('languageDropDown');
      var supportedDestinationLanguages =
      google.elements.transliteration.getDestinationLanguages(
      google.elements.transliteration.LanguageCode.ENGLISH);
      for (var lang in supportedDestinationLanguages) {
        var opt = document.createElement('option');
        opt.text = lang;
        if (lang=="ORIYA" ){
          opt.value = supportedDestinationLanguages[lang];
          if (destinationLanguage == opt.value) {
            opt.selected = true;
          }
          try {
            languageSelect.add(opt, null);
          } catch (ex) {
            languageSelect.add(opt);
          }
        }//End of if
      }
       //english bydefault
        //var opt_enlang=document.createElement('option');
        //opt_enlang.text='ENGLISH';
        //opt_enlang.value='en';
        //languageSelect.add(opt_enlang);
       
    }
    function transliterateStateChangeHandler(e) {
      document.getElementById('checkboxId').checked = e.transliterationEnabled;
    }
    function checkboxClickHandler() {
      transliterationControl.toggleTransliteration();
    }
    function languageChangeHandler() {
      var dropdown = document.getElementById('languageDropDown');
      transliterationControl.setLanguagePair(
      google.elements.transliteration.LanguageCode.ENGLISH,
      dropdown.options[dropdown.selectedIndex].value);
    }

    function serverUnreachableHandler(e) {
      document.getElementById("errorDiv").innerHTML =
      "Transliteration Server unreachable";
    }
    function serverReachableHandler(e) {
      document.getElementById("errorDiv").innerHTML = "";
    }
    google.setOnLoadCallback(onLoad);
  </script>
  <!--FOR CHANGE LANGUAGE-->  
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\wethefamily\resources\views/content/edit-contact.blade.php ENDPATH**/ ?>