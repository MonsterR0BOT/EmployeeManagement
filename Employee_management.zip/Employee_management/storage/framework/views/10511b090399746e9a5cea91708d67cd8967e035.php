<?php $__env->startSection('title', 'ORDER & NOTIFICATIONS'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Add/Edit Order & Notifications</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Add/Edit Order & Notifications</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
    	
      <!-- Default box -->
      <div class="box">
      <?php if(Session::has('message')): ?>
        <div class="alert alert-success">                        
            <i class="fa fa-check"></i> <?php echo e(Session::get('message')); ?> 
        </div>
        <?php endif; ?>
        <!-- form start -->
        <form role="form" method="post" action="<?php echo e(url('content/saveOrders')); ?>"  onsubmit="return validateForm()" autocomplete="off" enctype="multipart/form-data">
        	<?php echo csrf_field(); ?>
          <div class="box-body">
              <?php if(Session::has('errors')): ?>
                  <div class="col-md-12 alert alert-warning">
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php echo e($error); ?><br/>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
              <?php endif; ?>
            <div class="row">
                <div class="col-md-6">
                	<?php
                        if(!empty($data)){
                            $dataId = $data[0]->TOM_Order;
                            $TOM_Order_Title  = $data[0]->TOM_Order_Title ;
                            $TOM_Order_Title_Odia = $data[0]->TOM_Order_Title_Odia;
                            $TOM_Order_Dept = $data[0]->TOM_Order_Dept;
                            
                            $TOM_Order_Active = $data[0]->TOM_Order_Active;
                        }else{
                            $dataId = '';
                            $TOM_Order_Title  = '' ;
                            $TOM_Order_Title_Odia = '';
                            $TOM_Order_Dept = '';
                            $TOM_Order_Active = 1;
                            
                        }
                    ?>
                   
                    <div class="form-group">
                      <label for="exampleInputPassword1">Department</label>
                      <select class="form-control" name="Department" id="Department">
                        <option value="">--Select--</option>
                        <?php $__currentLoopData = $department_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($val->TDM_Dept); ?>" <?php if($TOM_Order_Dept == $val->TDM_Dept): ?> selected="selected" <?php endif; ?>><?php echo e($val->TDM_Dept_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Title</label>
                       <span class="text-danger">*</span>
                      <input type="text" class="form-control" name="planSubject" id="planSubject" value="<?php echo e($TOM_Order_Title); ?>">
                      <!--  <span class="text-danger"><?php echo e($errors->first('planSubject')); ?></span> -->
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Title Odia</label>
                      <span class="text-danger">*</span>
                      <input type="text" class="form-control" name="planSubjectOdia" id="planSubjectOdia" value="<?php echo e($TOM_Order_Title_Odia); ?>">
                     <!--  <span class="text-danger"><?php echo e($errors->first('planSubjectOdia')); ?></span> -->
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Upload File</label>
                      <span class="text-danger">*</span>
                       <input type="file" class="form-control" name="uploadPDF" id="uploadPDF" onChange="checkFileFormat(this)">
                       <!-- <span class="text-danger"><?php echo e($errors->first('uploadPDF')); ?></span> -->
                    </div>
                </div>
                <div class="col-md-6">
                  <div class="col-md-6">
                       <div class="form-group form-bg">
                          <label>Do you want to Write in Odia ? </label>
                       </div>
                    </div>
                    <div class="col-md-6">
                       <div class="form-group">
                          <div class="checkbox">
                             <input type="checkbox" id="checkboxId" onClick="javascript:checkboxClickHandler()">
                            <select id="languageDropDown" name="languageDropDown" onChange="javascript:languageChangeHandler()"></select>                                                   
                          </div> 
                       </div>
                    </div>
                </div>
                
            </div>
          </div>
          <!-- /.box-body -->
          <div class="box-footer">
          	<input type="hidden" name="hidDataId" id="hidDataId" value="<?php echo e($dataId); ?>"/>
            <button type="submit" class="btn btn-primary">Submit</button>
            <a href="<?php echo e(url('content/viewOrders')); ?>"><button type="button" class="btn btn-warning">Cancel</button></a>
          </div>
        </form>
      </div>
      <!-- /.box -->
      
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('scripts'); ?> 
<script type="text/javascript">
       function validateForm(){ 
         if (!blankValidation("planSubject","TextField", "Title can not be left blank"))
            return false;  
        if (!blankValidation("planSubjectOdia","TextField", "Title odia can not be left blank"))
            return false;
        if($("#hidDataId").val()==''){
          if (!blankValidation("uploadPDF","TextField", "Upload file can not be left blank"))
              return false;  
        } 
       }  
   $(function () {
    $("#checkboxId").click();
  })
</script>
<!--FOR CHANGE LANGUAGE-->
<script type="text/javascript" src="https://www.google.com/jsapi"></script>
  <script type="text/javascript">
    google.load("elements", "1", {
      packages: "transliteration"
    });

    var transliterationControl;
    function onLoad() {
      var options = {
        sourceLanguage: 'en',
        destinationLanguage: ['or'],
        transliterationEnabled: false,
        shortcutKey: 'ctrl+g'
      };
      // Create an instance on TransliterationControl with the required
      // options.
      transliterationControl =
      new google.elements.transliteration.TransliterationControl(options);

      // Enable transliteration in the textfields with the given ids.
      var ids = ["planSubjectOdia"];
      transliterationControl.makeTransliteratable(ids);

      // Add the STATE_CHANGED event handler to correcly maintain the state
      // of the checkbox.
      transliterationControl.addEventListener(
      google.elements.transliteration.TransliterationControl.EventType.STATE_CHANGED,
      transliterateStateChangeHandler);

      // Add the SERVER_UNREACHABLE event handler to display an error message
      // if unable to reach the server.
      transliterationControl.addEventListener(
      google.elements.transliteration.TransliterationControl.EventType.SERVER_UNREACHABLE,
      serverUnreachableHandler);

      // Add the SERVER_REACHABLE event handler to remove the error message
      // once the server becomes reachable.
      transliterationControl.addEventListener(
      google.elements.transliteration.TransliterationControl.EventType.SERVER_REACHABLE,
      serverReachableHandler);

      // Set the checkbox to the correct state.
      document.getElementById('checkboxId').checked =
      transliterationControl.isTransliterationEnabled();

      // Populate the language dropdown
      var destinationLanguage =
      transliterationControl.getLanguagePair().destinationLanguage;
      var languageSelect = document.getElementById('languageDropDown');
      var supportedDestinationLanguages =
      google.elements.transliteration.getDestinationLanguages(
      google.elements.transliteration.LanguageCode.ENGLISH);
      for (var lang in supportedDestinationLanguages) {
        var opt = document.createElement('option');
        opt.text = lang;
        if (lang=="ORIYA" ){
          opt.value = supportedDestinationLanguages[lang];
          if (destinationLanguage == opt.value) {
            opt.selected = true;
          }
          try {
            languageSelect.add(opt, null);
          } catch (ex) {
            languageSelect.add(opt);
          }
        }//End of if
      }
       //english bydefault
        //var opt_enlang=document.createElement('option');
        //opt_enlang.text='ENGLISH';
        //opt_enlang.value='en';
        //languageSelect.add(opt_enlang);
       
    }
    function transliterateStateChangeHandler(e) {
      document.getElementById('checkboxId').checked = e.transliterationEnabled;
    }
    function checkboxClickHandler() {
      transliterationControl.toggleTransliteration();
    }
    function languageChangeHandler() {
      var dropdown = document.getElementById('languageDropDown');
      transliterationControl.setLanguagePair(
      google.elements.transliteration.LanguageCode.ENGLISH,
      dropdown.options[dropdown.selectedIndex].value);
    }

    function serverUnreachableHandler(e) {
      document.getElementById("errorDiv").innerHTML =
      "Transliteration Server unreachable";
    }
    function serverReachableHandler(e) {
      document.getElementById("errorDiv").innerHTML = "";
    }
    google.setOnLoadCallback(onLoad);
  </script>
<!--FOR CHANGE LANGUAGE-->    
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/content/add-orders.blade.php ENDPATH**/ ?>