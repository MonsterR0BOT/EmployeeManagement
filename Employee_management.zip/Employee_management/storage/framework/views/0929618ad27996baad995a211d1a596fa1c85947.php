<?php $__env->startSection('title', 'DISCIPLINARY'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Manage Disciplinary
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Department Requisition</a></li>
        <li class="active">Manage Disciplinary</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
           <ul class="nav nav-tabs">

              <li class="nav-item">
                <a class="nav-link active" href="<?php echo e(url('DisciplinaryRequest/viewDisciplinaryOthers')); ?>">OTHERS</a>
              </li>

               <li class="nav-item">
                <a class="nav-link" href="<?php echo e(url('DisciplinaryRequest/viewDisciplinaryDraft')); ?>">DRAFT</a>
              </li>
              
            </ul>
          <div class="box">
         
            <!-- /.box-header -->
            <div class="box-body">
              <div id="demo" >
                <div class="search-field">
                   
                    <div class="row">
    
                        <div class="col-md-1">
                            <div class="org-name">From Date</div>
                        </div>
                        <div class="col-md-2">
                          <div class="input-group">
                              <div class="input-group-prepend">
                                  <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                              </div>
                              <input type="text" class="form-control pull-right datepicker" id="param1">
                          </div>
                        </div>
                        
                        <div class="col-md-1">
                            <div class="org-name">To Date</div>
                        </div>
                       <div class="col-md-2">
                          <div class="input-group">
                              <div class="input-group-prepend">
                                  <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                              </div>
                              <input type="text" class="form-control pull-right datepicker" id="param2">
                          </div>
                        </div>
                        
                        <div class="col-md-1">
                            <div class="org-name">Request Ref#</div>
                        </div>
                        <div class="col-md-2">
                            <input class="form-control" type="text" id="param3">
                        </div>
                        <div class="col-md-1">
                            <div class="form-group">
                                <button class="btn btn-primary" onClick="searchData()">Search</button>
                            </div>
                        </div>
                         <div class="col-md-2">
                              <div class="form-group pull-right">
                               <!-- <a href="<?php echo e(url('add-disciplinary-request')); ?>"> -->
                                 <a href="<?php echo e(url('DisciplinaryRequest/addDisciplinary')); ?>">
                                <button class="btn btn-primary">Add  Request</button>
                              </a>
                              </div>
                          </div>
                    </div>
                    
                </div>
            </div> 
           
              <table id="listAllDraftList" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Request Ref#</th>
                  <th>Department</th>
                  <th>Delinquent Officer</th>
                  <th>Designation</th>
                  <th>Status</th>
                  <th>Dept Status</th>  
                  <th>Date Time</th>               
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                 
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <!-- Modal Start-->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Proceeding Status</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        <div class="col-md-12">
                <!-- The timeline -->
                <ul class="timeline timeline-inverse">
                    <!-- timeline time label -->
                    <li class="time-label"> <span class="bg-red">10 Dec. 2019</span>
                    </li>
                    <!-- /.timeline-label -->
                    <!-- timeline item -->
                    <li>
                        <i class="fa fa-user bg-blue"></i>
                        <div class="timeline-item"><span class="time"><i class="fa fa-clock-o"></i> 10 Dec. 2019 12:05:20</span>
                            <h3 class="timeline-header"><a href="#">Prasanna Behera</a>, Office Asst, Agriculture & F.E Department</h3>
                            <div class="timeline-body">I certify that all information given above have been checked by me and found to be correct & all copies of relevant documents as mentioned above have been enclosed. </div>
                            <!-- <div class="timeline-footer">     <a class="btn btn-primary btn-xs">Read more</a>     <a class="btn btn-danger btn-xs">Delete</a>   </div> -->
                        </div>
                    </li>
                    <!-- END timeline item -->
                    <!-- timeline item -->
                    <li>
                        <i class="fa fa-comments bg-yellow"></i>
                        <div class="timeline-item"><span class="time"><i class="fa fa-clock-o"></i> 10 Dec. 2019 15:20:35</span>
                            <h3 class="timeline-header"><a href="#">Prakash Nayak</a>, HOD Dept, Agriculture & F.E Department</h3>
                            <div class="timeline-body"> The proceeding is verified and found ok and send to OPSC for further verification. </div>
                        </div>
                    </li>
                    <!-- END timeline item -->
                    <!-- timeline item -->
                    <li>
                        <i class="fa fa-comments bg-yellow"></i>
                        <div class="timeline-item"><span class="time"><i class="fa fa-clock-o"></i> 10 Dec. 2019 10:27:00</span>
                            <h3 class="timeline-header"><a href="#">Golak Roy</a>, SO, OPSC</h3>
                            <div class="timeline-body"> Checked the proceeding and assigned to ASO for further verification </div>
                            <!-- <div class="timeline-footer">     <a class="btn btn-warning btn-flat btn-xs">View comment</a>   </div> -->
                        </div>
                    </li>
                    <!-- END timeline item -->
                    <!-- timeline time label -->
                    <li class="time-label"> <span class="bg-green">12 Dec. 2019</span>
                    </li>
                    <!-- /.timeline-label -->
                    <!-- timeline item -->
                    <li>
                        <i class="fa fa-comments bg-yellow"></i>
                        <div class="timeline-item"><span class="time"><i class="fa fa-clock-o"></i> 12 Dec. 2019 9:27:35</span>
                            <h3 class="timeline-header"><a href="#">Yudhistir Nayak</a>, Dy. Secretary, OPSC</h3>
                            <div class="timeline-body"> Checked the proceeding and assigned to ASO for further verification </div>
                            <!-- <div class="timeline-footer">     <a class="btn btn-warning btn-flat btn-xs">View comment</a>   </div> -->
                        </div>
                    </li>
                    <!-- END timeline item -->
                    <!-- timeline item -->
                    <li>
                        <i class="fa fa-comments bg-yellow"></i>
                        <div class="timeline-item"><span class="time"><i class="fa fa-clock-o"></i> 12 Dec. 2019 11:30:45</span>
                            <h3 class="timeline-header"><a href="#">Subodha Nayak</a>, Secretary, OPSC</h3>
                            <div class="timeline-body"> Checked the proceeding and assigned to ASO for further verification </div>
                            <!-- <div class="timeline-footer">     <a class="btn btn-warning btn-flat btn-xs">View comment</a>   </div> -->
                        </div>
                    </li>
                    <!-- END timeline item -->
                    <li> <i class="fa fa-clock-o bg-gray"></i></li>
                </ul>
        </div>
      </div>
      <div class="modal-footer" align="center">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!-- Modal End--> 
<?php $__env->startPush('styles'); ?>
<!--Extra styles can written here -->
<?php $__env->stopPush(); ?>  
<?php $__env->startPush('scripts'); ?>

<script> 
  $(function () {
  $('#listAllDraftList').DataTable({
    'processing' : true,
    'serverSide' : true,
    'searching' : false,
    'ordering' : false,
    "ajax" : {
      'url' : '<?php echo e(url("DisciplinaryRequest/viewDisciplinaryAsOthers")); ?>',
      'data' : function(d) {
        d.param1 = $('#param1').val();
        d.param2 = $('#param2').val();
        d.param3 = $('#param3').val();
      }
    },
    'dataSrc' : "",
    'columns' : [ {
      'data' : 'TDR_DisciplinaryRequest'
    },{
      'data' : 'TDR_Department'
    }, {
      'data' : 'TDR_Deliquency_OfficerName'
    },{
      'data' : 'TDR_Deliquency_Designation'
    }, {
      'data' : 'TDR_DisReq_Approval_Status'
    }, {
      'data' : 'TDR_Dept_Approve'
    },{
      'data' : 'TDR_DisReq_CreatedOn'
    },{
      'data' : 'action'
    }

    ]
  });
  
  });
  //Method For Searching Records In The List
  function searchData() {
    $('#listAllDraftList').DataTable().draw();
  }
   


function deleteDiscipline(id){ 
   $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
      }
    });
    swal.fire({
        title: "Are you sure want to Delete?",
        text: "Once Deleted,Can't revert back !",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#e7b63a',
        confirmButtonText: 'Delete',
        reverseButtons : true
        
      }).then((result) => {
        if(result.value){
         $.ajax({
              type: "GET",
              'url' : '<?php echo e(url("DisciplinaryRequest/deleteDisciplineReqFromDB")); ?>' ,
              data  : {"disciplinaryId":id},
              success: function(response) {
              console.log(response);
              //return false;
                  if (response.message == "success") {
                    swal({
                      title: "Record deleted successfully.",
                      type: "success"
                    }).then(function(){
                       location.reload();
                    })
                  
                    
                  } else {
                      swal({
                          title: 'Unsuccess',
                          text: response.code
                      })
                  }
              },
              error: function(data) {
               
              }
          })
        }
        
      });
  }
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/disciplinary/manage-disciplinary-others.blade.php ENDPATH**/ ?>