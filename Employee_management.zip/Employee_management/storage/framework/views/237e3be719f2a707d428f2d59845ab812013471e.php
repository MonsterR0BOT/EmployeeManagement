 <section class="banner-section">
        <div class="carousel-column">
            <div class="carousel-outer">
                <ul class="banner-carousel owl-carousel owl-theme">

                    <!-- Slide Item -->
                    <li class="slide-item">
                    	<img src="<?php echo e(asset('images/image-1.jpg')); ?>">
                        
                    </li>

                    <!-- Slide Item -->
                    <li class="slide-item">
                    	<img src="<?php echo e(asset('images/image-2.jpg')); ?>">
                     
                    </li>
                    <!-- Slide Item -->
                    <li class="slide-item">
                    	<img src="<?php echo e(asset('images/image-3.jpg')); ?>">
                       
                    </li>
                   

                </ul>
                <ul class="thumbs-carousel owl-carousel owl-theme">
                    <li class="thumb-box">
                        <figure><img src="<?php echo e(asset('images/image-1.jpg')); ?>" alt=""></figure>
                    </li>
                    <li class="thumb-box">
                        <figure><img src="<?php echo e(asset('images/image-2.jpg')); ?>" alt=""></figure>
                    </li>
                    <li class="thumb-box">
                        <figure><img src="<?php echo e(asset('images/image-3.jpg')); ?>" alt=""></figure>
                    </li>
                   
                </ul>
            </div>
        </div>

        <div class="social-links">
            <ul class="social-icon-three">
                  <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                <li><a href="#"><i class="fab fa-skype"></i></a></li>
                <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
            </ul>
        </div>
    </section><?php /**PATH D:\xampp\htdocs\aquatic\resources\views/frontend-layout/banner.blade.php ENDPATH**/ ?>