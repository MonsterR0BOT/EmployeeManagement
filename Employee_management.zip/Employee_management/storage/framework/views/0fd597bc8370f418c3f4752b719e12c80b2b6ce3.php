<?php $__env->startSection('title', 'DISCIPLINARY'); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
   <!-- Content Header (Page header) -->
   <section class="content-header">
      <h1>Edit Disciplinary Request</h1>
      <ol class="breadcrumb">
         <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
         <li><a href="#">User</a></li>
         <li class="active">Edit Disciplinary</li>
      </ol>
   </section>
   <!-- Main content -->
      <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="bs-example">
                    <div class="accordion" id="accordionExample">
                        <div class="box">

                            <div class="card-header" id="headingOne">
                                <a data-toggle="collapse" data-target="#collapseOne" class="accordianheading">
                                    <div class="row">
                                        <div class="col-md-11">
                                            <h5>OPSC Information</h5></div>
                                        <div class="col-md-1"><i class="fa faicon acrdplus fa-plus-circle"></i></div>
                                    </div>
                                </a>

                            </div>
                            <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                                <div class="card-body">
                                    <div class="box-body">
                                        <div class="formsec row">
                                            <div class="col-md-3">
                                                <div class="paddingsmlmin">1.</div> <div class="paddingsmlmax">Name of the delinquent officer</div>
                                            </div>
                                            <div class="col-md-3">
                                                <input type="text" class="form-control" id="" name="" value="Sukanta Ranasingh">
                                            </div>
                                            <div class="col-md-3">
                                                <div class="paddingsmlmin">2.</div> <div class="paddingsmlmax">Date of birth:</div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                                                    </div>
                                                    <input type="text" class="form-control pull-right datepicker" id="" value="15/04/2018">
                                                </div>

                                            </div>
                                        </div>
                                        <div class="formsecalt row">
                                             <div class="col-md-3">
                                                  <div class="paddingsmlmin">3.</div> 
                                                  <div class="paddingsmlmax">Name(s) of the Department</div>
                                             </div>
                                             <div class="col-md-3">
                                                   <select class="form-control" name="userStatus" id="userStatus">
                                                      <option value="">Agriculture &amp; F.E Department</option>
                                                      <option value="">Commerce &amp; Transport (Commerce)</option>
                                                      <option value="">Home Department</option>
                                                   </select>
                                             </div>
                                             <div class="col-md-3">
                                                    <div class="paddingsmlmin">4.</div> 
                                                    <div class="paddingsmlmax">Employee ID(HRMS)</div>
                                             </div>
                                             <div class="col-md-3">
                                                  <input type="text" class="form-control" id="" name="name" value="ID123">
                                             </div>
                                         </div>
                                        <div class="formsec row">
                                            <div class="col-md-3">
                                                <div class="paddingsmlmin">5.</div> <div class="paddingsmlmax">i)Present designation</div>
                                            </div>
                                            <div class="col-md-3">
                                                <select class="form-control" name="userStatus" id="userStatus" onclick="showAddPostModal(this.value);">
                                                  <option value="">--Select--</option>
                                                  <option value="" selected="selected">Secretary</option>
                                                  <option value="">Dy.Secretary</option>
                                                  <option value="">Comissioner</option>
                                                  <option value="new">Add New</option>
                                               </select>
                                            </div>
                                            <div class="col-md-3">
                                                <label>ii)Designation when the delinquency was commited</label>
                                            </div>
                                            <div class="col-md-3">
                                                 <select class="form-control" name="userStatus" id="userStatus" onclick="showAddPostModal(this.value);">
                                                  <option value="">--Select--</option>
                                                  <option value="">Secretary</option>
                                                  <option value="" selected="selected">Dy.Secretary</option>
                                                  <option value="">Comissioner</option>
                                                  <option value="new">Add New</option>
                                               </select>
                                            </div>
                                        </div>
                                        <div class="formsecalt row">
                                            <div class="col-md-6">
                                                <div class="paddinglessmin">6.</div> <div class="paddinglessmax">Period during which the delinquency was commited</div>
                                            </div>
                                            <div class="col-md-6">
                                                <textarea class="form-control rounded-0" id="exampleFormControlTextarea2" rows="3">The Odisha Public Service Commission was constituted on 1st April, 1949</textarea>
                                            </div>
                                        </div>
                                        <div class="formsec row">
                                            <div class="col-md-6">
                                                <div class="paddinglessmin">7.</div> <div class="paddinglessmax">Whether the officer was suspended,if so,the date(s) of Suspension and re-instatement, if any (if not applicable, write NA) :</div>
                                                
                                            </div>
                                            <div class="col-md-6">
                                                 <div class="row">
                                                <div class="col-md-4"><input name="" type="text" class="form-control"  value="NA" /></div>
                                                <div class="col-md-4">
                                                     <div class="input-group">
                                                            <div class="input-group-prepend">
                                                                <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                                                            </div>
                                                            <input type="text" class="form-control pull-right datepicker" id="" value="07/11/2018">
                                                        </div>
                                                </div>
                                                  <div class="col-md-4">
                                                     <div class="input-group">
                                                            <div class="input-group-prepend">
                                                                <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                                                            </div>
                                                            <input type="text" class="form-control pull-right datepicker" id="" value="10/11/2018">
                                                        </div>
                                                </div>
                                                </div>
                                            </div>
                                            <div class="clearfix"></div>
                                           
                                            <div class="col-md-6">
                                            <div class="txtindenting"> Provision of the OCS(CC&A) Rules, 1962 and OCS(Pension) Rules 1992 under which proceeding has been initiated (Tick the appropriate box) :</div></div>
                                            <div  class="col-md-6">
                                               <div class="row">
                                                    <div class="col-md-3"> 
                                                        <input type="radio" name="" checked="checked" /> Rule 15
                                                    </div>
                                                    <div class="col-md-3">
                                                        <input type="radio" name=""> Rule 16
                                                    </div>
                                                    <div class="col-md-6">
                                                        <input type="radio" name="rdRules"> Rule 7
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="formsecalt row">
                                            <div class="col-md-6">
                                                <div class="paddinglessmin">8.</div> <div class="paddinglessmax">Date of communication of charge(s) along with statement of allegation/inputation (Copy of the same to be enclosed) :</div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                       <div class="row">
                                                        <div class="col-md-6">
                                                          <input type="text" class="form-control" value="No.15317/F&E">
                                                        </div>
                                                        <div class="col-md-6">
                                                        <div class="input-group">
                                                            <div class="input-group-prepend">
                                                                <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                                                            </div>
                                                            <input type="text" class="form-control pull-right datepicker" id="" value="14/08/2012">
                                                        </div>
                                                      </div>
                                                      </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                      <a href="#" data-toggle="modal" data-target="#myModal_one" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> Upload File</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="formsec row">
                                            <div class="col-md-6">
                                                <div class="paddinglessmin">9.</div> <div class="paddinglessmax">Date of submission of written statement of defence by the delinquent officer (Copy of the same to be enclosed) :</div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="input-group">
                                                            <div class="input-group-prepend">
                                                                <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                                                            </div>
                                                            <input type="text" class="form-control pull-right datepicker" id="" value="26/02/2019">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                       <a href="#" data-toggle="modal" data-target="#myModal_one" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> Upload File</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="formsecalt row">
                                            <div class="col-md-6">
                                                <div class="paddinglessmin">10.</div> <div class="paddinglessmax">Whether enquiry was conducted (Tick the appropriate box) :</div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-3">
                                                        <input type="radio" name="" checked=""> Yes
                                                    </div>
                                                    <div class="col-md-3">
                                                        <input type="radio" name=""> No
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="formsec row">
                                            <div class="col-md-6">
                                                <div class="paddinglessmin">11.</div> <div class="paddinglessmax">If yes, designation of the I.O and date of submission of his report (Copy of the report of I.O to be enclosed) :</div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <select class="form-control" name="userStatus" id="userStatus" onclick="showAddPostModal(this.value);">
                                                                  <option value="">--Select--</option>
                                                                  <option value="" selected="selected">Secretary</option>
                                                                  <option value="">Dy.Secretary</option>
                                                                  <option value="">Comissioner</option>
                                                                  <option value="new">Add New</option>
                                                               </select>
                                                            </div>
                                                            <div class="col-md-6">
                                                            <div class="input-group">
                                                            <div class="input-group-prepend">
                                                                <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                                                            </div>
                                                            <input type="text" class="form-control pull-right datepicker" id="" value="12/06/2017">
                                                              </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                       <a href="#" data-toggle="modal" data-target="#myModal_one" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> Upload File</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="formsecalt row">
                                            <div class="col-md-6">
                                                <div class="paddinglessmin">12.</div> <div class="paddinglessmax">Whether report of the I.O was sent to the delinquent officer along with show cause notice calling him to submit his presentation within 15 days as required under Rule 15(10)(i)(a)of the O.C.S (C.C.&A) Rules,1962(Tick the appropriate box). (Copy of notice to be enclosed) :</div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-3">
                                                        <input type="radio" name="" checked=""> Yes
                                                    </div>
                                                    <div class="col-md-3">
                                                     <input type="radio" name=""> No
                                                        </div>

                                                      <div class="col-md-6">
                                                  <a href="#" data-toggle="modal" data-target="#myModal_one" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> Upload File</a>

                                            </div>
                                             </div>
                                                </div>

                                        </div>
                                    <div class="formsec row ">
                                        <div class="col-md-6 ">
                                           <div class="paddinglessmin">13.</div> <div class="paddinglessmax">Date of represenation of the D.O.in response to the notice required under Rule 15(10) (i) (a) of the O.C.S (C.C. &A) Rules, 1962 (Copy of represenation to be enclosed) :</div>
                                        </div>
                                        <div class="col-md-6 ">
                                            <div class="row ">
                                                <div class="col-md-6 ">
                                                    <div class="input-group ">
                                                        <div class="input-group-prepend ">
                                                            <span class="input-group-text "><i class="fa fa-calendar "></i></span>
                                                        </div>
                                                        <input type="text " class="form-control pull-right datepicker " id=" " value="18/04/18">
                                                    </div>
                                                </div>
                                                <div class="col-md-6 ">
                                                   <a href="#" data-toggle="modal" data-target="#myModal_one" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> Upload File</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="formsecalt row ">
                                        <div class="col-md-6 ">
                                            <div class="paddinglessmin">14.</div> <div class="paddinglessmax"> Penalty imposed by the Disciplinary Authority before the issue of 2nd show cause notice (Copy of detailed finding and order of Disciplinary Authority and Govt. to be enclosed).</div>
                                        </div>
                                        <div class="col-md-6 ">
                                            <div class="row ">
                                              <div class="col-md-6 ">
                                               <label>a) 5% of pension be withdrawn for one year</label>
                                              </div> 
                                              <div class="col-md-6 ">
                                             <a href="#" data-toggle="modal" data-target="#myModal_one" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> Upload File</a>
                                              </div>  
                                            </div>

                                        </div>
                                    </div>

                                        <div class="formsec row ">
                                            <div class="col-md-12">
                                                <div class="paddinglgmin">15.</div>
                                                <div class="paddinglgmax ">In case imposition of major penalty :-</div>
                                            </div>

                                            <div class="clearfix"></div>
                                            <div class="col-md-12">
                                                <div class="row">
                                                        <div class="col-md-6">
                                                        <div class="txtindenting">(a) Date of second show cause notice issued u/r 15(10) (i)(b) (Copy to be enclosed):</div></div>
                                                            <div class="col-md-3">
                                                                <div class="input-group">
                                                                    <div class="input-group-prepend">
                                                                        <span class="input-group-text"><i class="fa fa-calendar "></i></span>
                                                                    </div>
                                                                    <input type="text " class="form-control pull-right datepicker " id=" " value="30/08/18"> 
                                                                </div>
                                                            </div>
                                                            <div class="col-md-3">
                                                               <a href="#" data-toggle="modal" data-target="#myModal_one" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> Upload File</a>
                                                            </div>
                                                     </div>
                                                     <div class="row">
                                                    <div class="col-md-6"> <div class="txtindenting">(b) Date of explanation received from the delinquent officer in reply to 2nd show causes notice (Copy of explanation of D.O to be enclosed)</div></div>
                                                            <div class="col-md-3">
                                                                <div class="input-group">
                                                                    <div class="input-group-prepend ">
                                                                        <span class="input-group-text "><i class="fa fa-calendar "></i></span>
                                                                    </div>
                                                                    <input type="text" class="form-control pull-right datepicker " id=" " value="05/11/18">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-3">
                                                              <a href="#" data-toggle="modal" data-target="#myModal_one" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> Upload File</a>
                                                            </div>
                                                    </div>

                                            </div>
                                        </div>
                                        <div class="formsecalt row">
                                        <div class="col-md-6 ">
                                            <div class="paddinglessmin">16.</div> <div class="paddinglessmax">Incase of disagreement with the finding of recommendation of I.O. whether reasons for the same has been recorded (Copy of order of Disciplinary Authority to be enclosed) :</div>
                                        </div>
                                            <div class="col-md-6 ">
                                                    <div class="row ">
                                                        <div  class="col-md-3 ">
                                                            <input type="radio" name="" checked=""> Yes
                                                        </div>
                                                        <div class="col-md-3">
                                                        <input type="radio" name=""> No
                                                    </div>

                                                    <div class="col-md-6">
                                                       <a href="#" data-toggle="modal" data-target="#myModal_one" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> Upload File</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="formsec row">
                                            <div class="col-md-6">
                                                <div class="paddinglessmin">17.</div> <div class="paddinglessmax">In the event of joint proceedings u/r 17 of the OCS (CC&A) Rules, 1962, is concurrence of disciplinary authorities of all the Depts to which delinquent officers belong to have been taken?
                                            </div>
                                            </div>
                                            <div class="col-md-6">
                                           <div class="row">
                                                <div class="col-md-3">
                                                    <input type="radio" name="" checked=""> Yes
                                                </div>
                                                <div class="col-md-3">
                                                    <input type="radio" name=""> No
                                                </div> 
                                                <div class="col-md-6">
                                                   <input type="radio" name=""> Not Applicable
                                                </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="formsecalt row">
                                            <div class="col-md-6">
                                               <div class="paddinglessmin">18.</div> <div class="paddinglessmax">In case of proposal for imposition of penalty on the DO whether orders of Govt.have been taken?</div>
                                            </div>
                                            <div class="col-md-6">
                                              <div class="row">
                                                <div class="col-md-3">
                                                    <input type="radio" name="" checked=""> Yes
                                                </div>
                                                <div class="col-md-3">
                                                    <input type="radio" name=""> No
                                                </div> 
                                                <div class="col-md-6">
                                                   <input type="radio" name=""> Not Applicable
                                                </div>
                                                </div>

                                                </div>
                                                
                                            <div class="col-md-6">
                                                <div class="txtindenting">Copy of the Notes & Order sheet of Govt. from appropriate level to be enclosed :</div>
                                            </div>
                                            <div class="col-md-6">

                                                <div class="row">
                                                <div class="col-md-3">
                                                    <input type="radio" name=" " checked=""> Yes
                                                </div>
                                                <div class="col-md-3">
                                                    <input type="radio" name=" "> No
                                                </div> 
                                                <div class="col-md-6">
                                                <a href="#" data-toggle="modal" data-target="#myModal_one" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> Upload File</a>
                                                </div>

                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div align="right" class="col-md-12 mrt_10">
                                            <a href="<?php echo e(url('manage-disciplinary-request')); ?>" class="btn btn-danger">Cancel</a>
                                            <button class="btn btn-primary">Save &#38 Next</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="box">
                            <div class="card-header" id="headingThree">
                                <a data-toggle="collapse" data-target="#collapseThree" class="accordianheading">
                                    <div class="row">
                                        <div class="col-md-11">
                                            <h5>Document Check List</h5></div>
                                        <div class="col-md-1"><i class="fa faicon acrdplus fa-plus-circle"></i></div>
                                    </div>
                                </a>
                            </div>
                            <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                                <div class="card-body">
                                    <div class="col-md-12">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="row listview">
                                                    <div class="col-md-11">1. Copy of statement of allegation</div>
                                                    <div class="col-md-1 listicon">
                                                        <label>
                                                            <input type="checkbox" class="minimal" checked="">
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row listview">
                                                    <div class="col-md-11">2. Copy of written statement by DO</div>
                                                    <div class="col-md-1 listicon">
                                                        <label>
                                                            <input type="checkbox" class="minimal" checked="">
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="row listview">
                                                    <div class="col-md-11">3. Copy of the report of IO</div>
                                                    <div class="col-md-1 listicon">
                                                        <label>
                                                            <input type="checkbox" class="minimal" checked="">
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row listview">
                                                    <div class="col-md-11">4. Copy of the representation of the DO</div>
                                                    <div class="col-md-1 listicon">
                                                        <label>
                                                            <input type="checkbox" class="minimal" checked="">
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="row listview">
                                                    <div class="col-md-11">5. Copy of the order of DA along with all the findings</div>
                                                    <div class="col-md-1 listicon">
                                                        <label>
                                                            <input type="checkbox" class="minimal" checked="">
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row listview">
                                                    <div class="col-md-11">6. Copy of the second show cause notice</div>
                                                    <div class="col-md-1 listicon">
                                                        <label>
                                                            <input type="checkbox" class="minimal" checked="">
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="row listview">
                                                    <div class="col-md-11">7. Copy of the explanation received by DO for 2nd show cause notice</div>
                                                    <div class="col-md-1 listicon">
                                                        <label>
                                                            <input type="checkbox" class="minimal" checked="">
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row listview">
                                                    <div class="col-md-11">8. Copy of the order of DA, in case of disagreement with the findings of IO</div>
                                                    <div class="col-md-1 listicon">
                                                        <label>
                                                            <input type="checkbox" class="minimal" checked="">
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="row listview">
                                                    <div class="col-md-11">9. Copy of note and order sheet of Government</div>
                                                    <div class="col-md-1 listicon">
                                                        <label>
                                                            <input type="checkbox" class="minimal" checked="">
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                               <div class="paddinglessmin">
                                                <input name="" type="checkbox" value="">
                                              </div>
                                                <div class="paddinglessmax">
                                                <textarea class="form-control">I certify that all information/documents given above have been checked by me and found to be correct and all copies of relevant documents, as mentioned above, have benn enclosed</textarea> </div>
                                             </div>
                                    </div>
                               
                                <div class="clearfix"></div>
                                <div align="right" class="col-md-12 mrt_10 mrb_10">
                                            <a href="<?php echo e(url('manage-disciplinary-request')); ?>" class="btn btn-danger">Cancel</a>
                                            <button class="btn btn-primary">Save &#38 Next</button>
                                        </div>

                                 <div class="clearfix"></div>
                               </div>
                            </div>
                        </div>
                    </div>
                    </div>
</div>
                    <!-- /.box -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.box -->
    </section>
   <!-- /.content -->

    <div class="modal" id="myModal_one">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <!-- Modal body -->
        <div class="modal-body">
          <div class="col-lg-12">
              <div> 
                <div align="right">
                     <button class="btn btn-primary button-add1" type="button"><i class="fa fa-plus"></i></button> 
                </div>
             </div>
             <div class="form-group uploadone">
             <div></div>
             <div class="row">
                <div class="col-lg-5">
                    <label>Select File Type</label>
                   <select name="" class="form-control">
                       <option>--Select---</option>
                       <option>Copy of the report of I.O</option>
                       <option>Copy of the report of IO</option>
                       <option>Copy of the second show cause notice</option>
                       <option>Copy of written statement by DO</option>
                       <option>Copy of statement of allegation</option>
                    </select>
                </div>
                <div class="col-lg-6">
                    <label>Upload File</label> 
                    <div class="input-group">
                    <input type="file" class="custom-file-input" id="" name="filename">
                    <label class="custom-file-label" for="customFile">Choose file</label>
                    </div>
                </div>
                <div class="col-lg-1 mrt_30" align="right">
                    <button class="btn btn-warning button-remove1" type="button"><i class="fa fa-minus"></i></button> 
                </div>
                </div>
            </div>
          </div>
          <div class="col-md-12">
          <div class="row">
              <div class="col-md-4"><i class="fa fa-pdf-o"></i>1578062897.pdf <span class="label label-primary"><i class="fa fa-eye"></i></span> <span class="label label-warning"><i class="fa fa-close"></i></span></div>
              <div class="col-md-4"><i class="fa fa-pdf-o"></i>1578062897.pdf <span class="label label-primary"><i class="fa fa-eye"></i></span> <span class="label label-warning"><i class="fa fa-close"></i></span></div>
              <div class="col-md-4"><i class="fa fa-pdf-o"></i>1578062897.pdf <span class="label label-primary"><i class="fa fa-eye"></i></span> <span class="label label-warning"><i class="fa fa-close"></i></span></div>
          </div>
          </div>
        </div>
        <!-- Modal footer -->
        <div class="modal-footer" align="center">
           <button class="btn btn-primary">Submit</button>
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>
</div>


 <div class="modal" id="addPostModal">
    <div class="modal-dialog">
      <div class="modal-content">
        <!-- Modal Header -->
        <div class="modal-header">
           <h4 class="modal-title">Add New</h4>
           <!-- <button type="button" class="close" data-dismiss="modal">×</button> -->
        </div>
        <!-- Modal body -->
        <div class="modal-body" id="addPostBody">
            
        </div>
        <!-- Modal footer -->
        <div class="modal-footer" align="center">
           <button class="btn btn-primary">Submit</button>
          <button type="button" class="btn btn-danger" onclick="closeModal()">Close</button>
        </div>
        
      </div>
    </div>
  </div>
<!-- /.content-wrapper -->
<?php $__env->startPush('scripts'); ?> 


<script>
    $(document).ready(function(){
        // Add minus icon for collapse element which is open by default
        $(".collapse.show").each(function(){
          $(this).prev(".card-header").find(".fa faicon").addClass("fa-minus-circle").removeClass("fa-plus-circle");
        });
        
        // Toggle plus minus icon on show hide of collapse element
        $(".collapse").on('show.bs.collapse', function(){
          $(this).prev(".card-header").find(".fa faicon").removeClass("fa-plus-circle").addClass("fa-minus-circle");
        }).on('hide.bs.collapse', function(){
          $(this).prev(".card-header").find(".fa faicon").removeClass("fa-minus-circle").addClass("fa-plus-circle");
        });
    });
</script>







 <script>
$(document).ready(function() {
    $('.button-add').click(function(){
        //we select the box clone it and insert it after the box
        $('.vigilance:first').clone().insertAfter(".vigilance:last");
    });
    $(document).on("click", ".button-remove", function() {
          if($(".vigilance").length !=1){                                              
        $(this).closest(".vigilance").remove();
       }else{
        swal("Sorry! You can't delete default row.");
      } 
    });
});
</script>
<script>
$(document).ready(function() {
    $('.button-add1').click(function(){
        //we select the box clone it and insert it after the box
        $('.upload:first').clone().insertAfter(".upload:last");
    });
    $(document).on("click", ".button-remove1", function() {
          if($(".upload").length !=1){                                             
        $(this).closest(".upload").remove();
       }else{
        swal("Sorry! You can't delete default row.");
      } 
    });
});

function showAddPostModal(index){
    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
      }
    });
    $("#addPostBody").empty();
    if(index=='new'){
        $.ajax({
              type: "GET",
              url:"ajaxGetAddPostForm",
              success: function(response) {
            console.log(response);
              $("#addPostBody").append(response.html);
              $("#addPostModal").modal('show');
              },
              error: function(data) {
               
              }
          })
    }else{
        $("#addPostModal").modal('hide');
    }
    if(index=='newref'){
        $.ajax({
              type: "GET",
              url:"ajaxGetAddRefNoForm",
              success: function(response) {
            console.log(response);
              $("#addPostBody").append(response.html);
              $("#addPostModal").modal('show');
              },
              error: function(data) {
               
              }
          })
    }else{
        $("#addPostModal").modal('hide');
    }

    if(index=='newrule'){
        $.ajax({
              type: "GET",
              url:"ajaxGetRecruitmentRuleForm",
              success: function(response) {
            console.log(response);
              $("#addPostBody").append(response.html);
              $("#addPostModal").modal('show');
              },
              error: function(data) {
               
              }
          })
    }else{
        $("#addPostModal").modal('hide');
    }
   
  }
  function closeModal(){
      $("#addPostModal").modal('hide');
   
  } 

</script>



<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-demo\resources\views/department/edit-disciplinary.blade.php ENDPATH**/ ?>