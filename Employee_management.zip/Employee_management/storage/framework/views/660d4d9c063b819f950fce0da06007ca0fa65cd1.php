<section class="page_topline ds table_section table_section_lg section_padding_top_15 section_padding_bottom_15 columns_margin_0">
     <div class="container-fluid">
        <div class="row">
           <div class="col-lg-4 col-md-4 col-sm-4">
              <div class="inline-content big-spacing">
                 <div class="page_social">
                   <?php ($socialarr = Helper::getSocialIcons()); ?>
                    <?php $__currentLoopData = $socialarr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($val->TSM_Social_Link); ?>" target="_blank"><i class="social-icon  <?php echo e($val->TSM_Social_Icon); ?>"  title="<?php echo e($val->TSM_Social_Name); ?>"></i></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- <a href="#"><i class="social-icon  fa fa-twitter" href="#" title="Twitter"></i></a>
                    <a href="#"><i class="social-icon  fa fa-google" href="#" title="Google Plus"></i></a>
                    <a href="#"><i class="social-icon  fa fa-linkedin" href="#" title="Linkedin"></i></a>
                    <a href="#"><i class="social-icon  fa fa-youtube" href="#" title="Youtube"></i></a> -->
                 </div>
                  <?php ($contactus = Helper::getContactaddress()); ?>
                 <div class="xs-block">
                 <i class="fa fa-map-marker highlight3 rightpadding_5" aria-hidden="true"></i>
                    <?php echo e($contactus->TCM_Contact_Name); ?>

                 </div> 
              </div>
           </div>
           <div class="col-lg-8 col-md-8 col-sm-8">
              <div class="row">
                    <div class="col-md-6 xs-block">
                    <i class="fa fa-pencil highlight3 rightpadding_5" aria-hidden="true"></i>
                    <a href="#"> <?php echo e($contactus->TCM_Contact_Email); ?></a>
                    </div>
                    <?php if(Session::has('memberId')): ?>
                    <div class="col-md-6 xs-block">
                       <ul class="inline-list menu greylinks">
                          <li>
                             <a href="<?php echo e(url('home/editMember')); ?>">
                             <i class="fa fa-user" aria-hidden="true"></i>
                             <?php echo e(Helper::getMemberName()); ?>

                             </a>
                          </li>
                          <li>
                             <a href="<?php echo e(url('member-dashboard')); ?>">
                             <i class="fa fa-table" aria-hidden="true"></i>
                             Dashboard
                             </a>
                          </li>
                          <li>
                             <a href="<?php echo e(url('member-logout')); ?>">
                             <i class="fa fa-key" aria-hidden="true"></i>
                             Log Out
                             </a>
                          </li>
                            
                       </ul>
                    </div>
                    <?php endif; ?>
                 </div>
              </div>
           </div>
        </div>
  </section>
  <header class="page_header header_white toggler_xs_right columns_margin_0">
      <div class="container-fluid">
          <div class="row">
              <div class="col-sm-12 display_table">
                  <div class="header_left_logo display_table_cell">
                      <a href="<?php echo e(url('/')); ?>" class="logo logo_with_text">
                          <img src="<?php echo e(asset('images/logo.png')); ?>" alt="">
                      </a>
                  </div>
                  <div class="header_mainmenu display_table_cell text-center">

                    <nav class="navbar navbar-expand-sm   navbar-light ">
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
                              <span class="navbar-toggler-icon"></span>
                            </button>

                            <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
                              <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                                <li class="nav-item">
                                  <a class="nav-link" href="<?php echo e(url('/')); ?>">Home <span class="sr-only">(current)</span></a>
                                </li>
                                <li class="nav-item"> <a class="nav-link" href="<?php echo e(url('home/showServices')); ?>">Services</a></li>
                                <li class="nav-item"> <a class="nav-link" href="<?php echo e(url('home/showGallery')); ?>">Gallery</a></li>
                                <li class="nav-item"> <a class="nav-link" href="<?php echo e(url('home/showBlog')); ?>">Blog</a></li>
                                <li class="nav-item"> <a class="nav-link" href="<?php echo e(url('home/showEvent')); ?>">Event</a></li>
                                <li class="nav-item"> <a class="nav-link" href="<?php echo e(url('home/showNews')); ?>">News</a></li>
                                <li class="nav-item"> <a class="nav-link" href="<?php echo e(url('home/showContact')); ?>">Contact Us</a></li>
                                <!-- <li class="nav-item dropdown dmenu">
                                <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                                  Our Service
                                </a>
                                <div class="dropdown-menu sm-menu">
                                  <a class="dropdown-item" href="#">service2</a>
                                  <a class="dropdown-item" href="#">service 2</a>
                                  <a class="dropdown-item" href="#">service 3</a>
                                </div>
                              </li> -->
                            
                             
                            
                              </ul>
                            
                            </div>
                          </nav>
                     <!--  <nav class="mainmenu_wrapper">
                          <ul class="mainmenu nav sf-menu">
                              <li class="active"> <a href="index.php">Home</a></li>
                              <li> <a href="services.php">Services</a></li>
                              
                              <li> <a href="gallery.php">Gallery</a></li>
                              <li> <a href="blog.php">Blog</a></li>
                              <li> <a href="event.php">Event</a></li>
                              <li> <a href="news.php">News</a></li>
                              <li> <a href="contact.php">Contact Us</a></li>
                               <li> <a href="matrimony.php">Matrimony</a></li>
                           </ul>
                      </nav> -->
                      <!-- <span class="toggle_menu"><span></span></span> -->
                  </div>
                  <?php if(!Session::has('memberId')): ?>
                  <div class="header_right_buttons display_table_cell text-right hidden-xs"><a href="<?php echo e(url('/login-member')); ?>" class="theme_button color2 margin_0">Login</a>   <a href="<?php echo e(url('home/showJoinus')); ?>" class="theme_button color2 margin_0">Join Us</a>  </div>
                  <?php endif; ?>
              </div>
          </div>
      </div>
  </header><?php /**PATH D:\xampp\htdocs\wethefamily\resources\views/frontend-layout/frontend-navigation.blade.php ENDPATH**/ ?>