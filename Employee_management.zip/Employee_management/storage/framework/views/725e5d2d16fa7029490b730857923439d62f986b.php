 
 <?php $__env->startSection('title', 'FAQ'); ?>
 <?php $__env->startSection('content'); ?>
 <!-- faq_area_start -->
<div class="our_department_area">
  <div class="container">
     <div class="row">
        <div class="col-xl-12">
           <div class="section_title text-center mb-55">
              <h3>OPSC FAQ</h3>
           </div>
        </div>
     </div>
    <div class="row">
      <div class="col-md-12">
       <div class="panel-group" id="accordion">
        <?php $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="panel panel-default">
            <div class="panel-heading">
                <h4 class="panel-title">
                    <a class="card-link" data-toggle="collapse" href="#<?php echo e($val->TFM_Faq); ?>"> <?php echo e($val->TFM_Faq_Question); ?> </a>
                </h4>
            </div>
            <div id="<?php echo e($val->TFM_Faq); ?>" class="panel-collapse collapse " data-parent="#accordion">
                <div class="panel-body">
                 <?php echo e($val->TFM_Faq_Answer); ?>

                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

       </div>
      </div>
    </div>
  </div>
</div>
<!-- faq_area_end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend-layout.frontend-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/faq.blade.php ENDPATH**/ ?>