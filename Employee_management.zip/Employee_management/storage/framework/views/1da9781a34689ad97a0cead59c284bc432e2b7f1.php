
<div class="formsec row">
   <?php 
   $officerID=$officerDtls->TPO_PromotionOfficer;
   $promotionType=$officerDtls->TPO_PromotionType;
   $category=$officerDtls->TPO_OfficerCaste;
   $post=$officerDtls->TPO_Promotion_Post;
   $group=$officerDtls->TPO_Promotion_Group;
   $scale=$officerDtls->TPO_PostPayScale;
   $designation=$officerDtls->TPO_FeederPostDesignation;


   $ifOfficerRegularOnGrade=$officerDtls->TPO_IsOfficerRegular;
   $ifOfficerSelectedForPromotion=$officerDtls->TPO_IsOfficerSelected_AsperRule;
   $ifAnyDisciplinaryPending=$officerDtls->TPO_IsCriminalCasePending;
   $ifAvailabilityOfCCRPAR=$officerDtls->TPO_IsCCRAvailable;
   $ifOfficerGivenProDPCSB=$officerDtls->TPO_IsOfficerGivenAdhcPromotion;
   $modeId=$mode[0];

   ?>
   <div class="col-md-3"> 
    <input name="hdOfficerID" id="hdOfficerID" type="hidden" value="<?php echo e($officerID); ?>"/>
    
      <div class="form-group">
         <label >Name of the eligible officers in the zone of</label>
      </div>
   </div>
 
   <div class="col-md-3">
      <div class="form-group">
         <input name="eligible_m" id="eligible_m" type="text" class="form-control" value="<?php echo e($officerDtls->TPO_OfficerName); ?>"/>
      </div>
   </div>

   <div class="col-md-3">
         <label >Type of promotion (Regular/Retrospective)</label>
   </div>
   <div class="col-md-3">
     <select class="form-control" name="promotionType_m" id="promotionType_m" >
       <option value="">--Select--</option>
        <?php $__currentLoopData = $proTypelist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($val->TTPM_PromotionType); ?>" <?php if($promotionType == $val->TTPM_PromotionType): ?> selected="selected" <?php endif; ?>><?php echo e($val->TTPM_PromotionTypeName); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </select>
   </div>

    <div class="col-md-3">
      <div class="form-group">
         <label >Employee ID(HRMS)</label>
      </div>
   </div>
 
   <div class="col-md-3">
      <div class="form-group">
         <input name="empHrmsId_m" id="empHrmsId_m" type="text" class="form-control" value="<?php echo e($officerDtls->TPO_HRMSID); ?>"/>
      </div>
   </div>

   <div class="col-md-3">
         <label >Date Of Birth</label>
   </div>
   <div class="col-md-3">
      <div class="input-group">
       <div class="input-group-prepend">
          <span class="input-group-text"><i class="fa fa-calendar"></i></span>
       </div>
       <input type="text" class="form-control pull-right datepicker" id="dob_m" 
       name="dob_m" value="<?php echo e($officerDtls->TPO_OfficerDOB); ?>">
    </div> 
   </div>

   <div class="clearfix"></div> 
   <div class="col-md-3">
         <label>Caste (SC/ST/General)</label>
   </div>
   <div class="col-md-3">
         <select class="form-control" name="categoryId_m" id="categoryId_m">
           <option value="">--Select--</option>
            <?php $__currentLoopData = $catlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($val->TCM_Category); ?>"  <?php if($category == $val->TCM_Category): ?> selected="selected" <?php endif; ?>><?php echo e($val->TCM_CategoryName); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </select>
   </div>
   <div class="col-md-3">
      <div class="form-group">
         <label>Name of the post to be filled up</label>
      </div>
   </div>
   <div class="col-md-3"> 
          <select class="form-control" name="OffPostId_m" id="OffPostId_m" disabled="disabled">
            <option value="">--Select--</option>
            <?php $__currentLoopData = $postList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($val->TPM_Post); ?>" <?php if($post == $val->TPM_Post): ?> selected="selected" <?php endif; ?>><?php echo e($val->TPM_Post_Name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </select>
   </div>
   <div class="clearfix"></div> 
   <div class="col-md-3">
         <label >Group of the promotional post</label>
   </div>
   <div class="col-md-3"> 
         <select class="form-control" name="groupId_m" id="groupId_m" disabled="disabled">
           <option value="">--Select--</option>
          <?php $__currentLoopData = $grouplist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($val->TGM_Group); ?>" <?php if($group == $val->TGM_Group): ?> selected="selected" <?php endif; ?>><?php echo e($val->TGM_GroupName); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </select>
   </div>
   <div class="col-md-3">
         <label >Scale of Pay</label>
   </div>
   <div class="col-md-3">
         <select class="form-control" name="scaleType_m" id="scaleType_m" disabled="disabled">
           <option value="">--Select--</option>
            <?php $__currentLoopData = $paylist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($val->TPLM_Level); ?>"  <?php if($scale == $val->TPLM_Level): ?> selected="selected" <?php endif; ?>><?php echo e($val->TPLM_Payband); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>         
        </select>
   </div>
  <div class="clearfix"></div>
  
   <div class="col-md-3">
         <label >Mention the back Period of Availability</label>
   </div>
   <div class="col-md-3">
         <input type="text" class="form-control" name="availabilityPeriod_m" id="availabilityPeriod_m" value="<?php echo e($officerDtls->TPO_MentionBackPeriodAvail); ?>">
   </div> 
   <div class="col-md-3">
         <label>Designation as per the feeder post/grade</label>
   </div>
   <div class="col-md-3">
      <select class="form-control" name="designationPost_m" id="designationPost_m" disabled="disabled">
        <option value="">--Select--</option>
        <?php $__currentLoopData = $postList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($val->TPM_Post); ?>" <?php if($designation == $val->TPM_Post): ?> selected="selected" <?php endif; ?>><?php echo e($val->TPM_Post_Name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </select>
   </div>
   <div class="clearfix"></div>
   <div class="col-md-3">
         <label >Is the officer regular on feeder grade</label>
   </div>
   <div class="col-md-3">
      <div class="row">
         <div class="col-md-6">
         <label>
         <input type="radio" name="ifOfficerRegularOnGrade_m"  <?php echo e(($ifOfficerRegularOnGrade=="1")? "checked" : ""); ?>  value="1" >
         Yes
         </label>
      </div>
      <div class="col-md-6">
         <label>
         <input type="radio" name="ifOfficerRegularOnGrade_m" <?php echo e(($ifOfficerRegularOnGrade=="0")? "checked" : ""); ?> value="0" >
         No
         </label>
      </div>
   </div>
   </div>
 
   <div class="col-md-3">
         <label >Is the officer selected for promotion as per the recruitment rule.</label>
   </div>
   <div class="col-md-3">
     <div class="row">
      <div class="col-md-6">
         <label>
         <input type="radio" <?php echo e(($ifOfficerSelectedForPromotion=="1")? "checked" : ""); ?> name="ifOfficerSelectedForPromotion_m" value="1">
         Yes
         </label>
      </div>
      <div class="col-md-6">
         <label>
         <input type="radio" <?php echo e(($ifOfficerSelectedForPromotion=="0")? "checked" : ""); ?> name="ifOfficerSelectedForPromotion_m"  value="0">
         No
         </label>
      </div>
   </div>
 </div>
   <div class="clearfix"></div>  
   <div class="col-md-3">
         <label >Is there any criminal case/disciplinary proceedings/vigilance case is pending</label>
   </div>
   <div class="col-md-3 mrb_10">
      <div class="row">
         <div class="col-md-6">
         <label>
         <input type="radio" <?php echo e(($ifAnyDisciplinaryPending=="1")? "checked" : ""); ?> name="ifAnyDisciplinaryPending_m" value="1">
         Yes
         </label>
      </div>
      <div class="col-md-6">
         <label>
         <input type="radio" <?php echo e(($ifAnyDisciplinaryPending=="0")? "checked" : ""); ?> name="ifAnyDisciplinaryPending_m"  value="0">
         No
         </label>
      </div>
      </div>
      <div class="input-group" id="divVigilance_m">
        <a href="javascript:void(0)" onClick="showCCRUpload('vigilance','1')" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> Upload File</a>
       </div> 
   </div>
   <div class="col-md-3">
         <label>Availability of CCRs & PARs</label>
   </div>
   <div class="col-md-3">
      <div class="row">
         <div class="col-md-6">
         <label>
         <input type="radio" <?php echo e(($ifAvailabilityOfCCRPAR=="1")? "checked" : ""); ?> name="ifAvailabilityOfCCRPAR_m" value="1">
         Yes
         </label>
      </div>
      <div class="col-md-6">
         <label>
         <input type="radio" <?php echo e(($ifAvailabilityOfCCRPAR=="0")? "checked" : ""); ?> name="ifAvailabilityOfCCRPAR_m" value="0">
         No
         </label>
      </div>
      </div>
   </div>
   <div class="clearfix"></div>
   <div class="col-md-3">
         <label >Period of Availability of CCRs & PARs</label>
   </div>
   <div class="col-md-3">
         <textarea name="periodAvailCCRPAR_m" id="periodAvailCCRPAR_m" cols="" rows="" class="form-control"><?php echo e($officerDtls->TPO_CCRAvailable_Period); ?></textarea>
   </div>
   
   <div class="col-md-3">
         <label >Is the officer given adhoc promotion DPC/SB</label>
   </div>
   <div class="col-md-3">
      <div class="row">
         <div class="col-md-6">
         <label>
         <input type="radio" <?php echo e(($ifOfficerGivenProDPCSB=="1")? "checked" : ""); ?> name="ifOfficerGivenProDPCSB_m" value="1">
         Yes
         </label>
      </div>
      <div class="col-md-6">
         <label>
         <input type="radio" <?php echo e(($ifOfficerGivenProDPCSB=="0")? "checked" : ""); ?> name="ifOfficerGivenProDPCSB_m" value="0">
         No
         </label>
      </div>
      </div>
   </div>
   <div class="clearfix"></div>  
   <div class="col-md-3">
         <label >Period of CCRs perused by DPC/SB</label>
   </div>
   <div class="col-md-3">
         <input type="text" class="form-control" name="periodCCRPPerusedDPCSB_m" id="periodCCRPPerusedDPCSB_m" value="<?php echo e($officerDtls->TPO_CCRPeriod_PersuedByDPC); ?>">
   </div>
   
   <div class="col-md-3">
      <div>
           <label><strong>Upload CCR</strong></label> 
        </div>
     </div>
    <div class="col-md-3 mrb_10">
    <!-- <a href="#" data-toggle="modal" data-target="#myModal_six" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> Upload File</a> -->
    <a href="javascript:void(0)" onClick="showCCRUpload('ccr','1')" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> Upload File</a>
   </div>
  <div class="col-md-12">
      <div class="row">
        <?php $__currentLoopData = $offDocListCRR; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-3 bg-color1"><?php echo e($val->TPCD_FinancialYear); ?>  <?php echo e($val->docName); ?></div>
          <div class="col-md-3"><a href="<?php echo e(url('public/storage/promotional_files')); ?>/<?php echo e($val->TPCD_DocumentName); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a> &nbsp; &nbsp; <a href="javascript:void(0)" onclick="delThisDocFromDBOfficer('<?php echo e($val->docType); ?>','<?php echo e($val->TPCD_PromotionOfficer); ?>','<?php echo e($val->TPCD_FinancialYear); ?>','<?php echo e($modeId); ?>')" class="label label-danger"><i class="fa fa-close"></i></a></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>
  </div> 
<?php if(count($offDocListNotCRR)>0): ?>
 <div class="formsubhd">Vigilance/Criminal/Disciplinary Proceedings</div>
  <div class="col-md-12">
      <div class="row">
        <?php $__currentLoopData = $offDocListNotCRR; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
          <div class="col-md-3 bg-color1"><?php echo e($val->TPCD_FinancialYear); ?>  <?php echo e($val->docName); ?></div>
          <div class="col-md-3"><a href="<?php echo e(url('public/storage/promotional_files')); ?>/<?php echo e($val->TPCD_DocumentName); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a> &nbsp; &nbsp; <a href="javascript:void(0)" onclick="delThisDocFromDBOfficer('<?php echo e($val->docType); ?>','<?php echo e($val->TPCD_PromotionOfficer); ?>','<?php echo e($val->TPCD_FinancialYear); ?>','<?php echo e($modeId); ?>')" class="label label-danger"><i class="fa fa-close"></i></a></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
      </div>
  </div>
  <?php endif; ?>
</div>
<script>
   $(function () {
       //Date picker
    $('.datepicker').datepicker({
      dateFormat: 'dd-mm-yy',
      autoclose: true
    })
    $("input[type='radio'][name='ifAnyDisciplinaryPending_m']").on("click",function(){
     
      if($(this).val()==1)
        $("#divVigilance_m").show();
      else
        $("#divVigilance_m").hide();
    })

   });
  </script><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/promotional/ajax-officer-details.blade.php ENDPATH**/ ?>