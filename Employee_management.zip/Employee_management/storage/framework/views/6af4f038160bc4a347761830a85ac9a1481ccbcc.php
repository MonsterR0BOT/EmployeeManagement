<?php $__env->startSection('title', 'WING'); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>Manage Wing</h1>
   
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="#">Master</a></li>
      <li class="active">View Wing</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <!-- Default box -->
    <div class="box">
      <?php if(Session::has('message')): ?>
        <div class="alert alert-success">                        
            <i class="fa fa-check"></i> <?php echo e(Session::get('message')); ?> 
        </div>
        <?php endif; ?>
      <div class="box-header">
        <!--<h3 class="box-title">Data Table With Full Features</h3>-->
        <!-- <div class="pull-right"><a href="<?php echo e(url('add-sms')); ?>" class="btn btn-primary pull">Add New</a></div> -->
      </div>
      <!-- /.box-header -->
    
      <div class="box-body">
        <div id="demo">
            <div class="search-field">
                <div class="row">
                    <div class="col-md-2">
                        <div class="org-name">Wing Name</div>
                    </div>
                    <div class="col-md-3">
                        <input class="form-control" type="text" placeholder="" name="" id="param1">
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <button class="btn btn-primary" onClick="searchData()">Search</button>
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="form-group pull-right">
                            <a href="<?php echo e(url('wing/showAddWing')); ?>"><button class="btn btn-primary">Add Wing</button></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <table id="listAllData" class="table table-bordered table-striped">
          <thead>
            <tr>
              <th>Wing Name</th>
              <th>Wing Name Odia</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            
          </tbody>
        </table>
       
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->startPush('styles'); ?>
<!--Extra styles can written here -->
<?php $__env->stopPush(); ?>  
<?php $__env->startPush('scripts'); ?>

<script>
  $(function () {
  $('#listAllData').DataTable({
    'processing' : true,
    'serverSide' : true,
    'searching' : false,
    'ordering' : false,
    "ajax" : {
      'url' : "<?php echo e(url('wing/viewWingthroughAjax')); ?>",
      'data' : function(d) {
        d.param1 = $('#param1').val();
      }
    },
    'dataSrc' : "",
    'columns' : [ {
      'data' : 'TWM_Wing_Name'
    }, {
      'data' : 'TWM_Wing_Name_Odia'
    },{
      'data' : 'action'
    }

    ]
  });
  
  });
  //Method For Searching Records In The List
  function searchData() {
    $('#listAllData').DataTable().draw();
  }
 
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\wethefamily\resources\views/master/manage-wing-master.blade.php ENDPATH**/ ?>