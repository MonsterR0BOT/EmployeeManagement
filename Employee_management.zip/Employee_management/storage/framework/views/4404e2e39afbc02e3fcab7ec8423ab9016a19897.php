<footer class="footer">
<div class="copy-right_text">
    <div class="container">
        <!-- <div class="row" align="center">
           <div class="footer-menu-all text-center" align="center">
            <div class="row footer-menu">
               <div class="col-md-3">
                <a href="<?php echo e(url('home/viewDepartment')); ?>">Departments</a>
                </div>
                <div class="col-md-3">
                <a href="<?php echo e(url('home/viewNotification')); ?>">Notifications</a>
                </div>
                <div class="col-md-3">
                <a href="<?php echo e(url('home/viewFaq')); ?>">FAQ</a>
               </div>
                <div class="col-md-3">
                <a href="<?php echo e(url('home/viewContact')); ?>">Contact</a>
            </div>
            </div>
        </div>
        </div> -->
        <div class="row">
            <div class="col-xl-12">
                <p class="copy_right text-center">Copyright &copy;All rights reserved  by <a href="<?php echo e(url('/')); ?>">OPSC</a>
                </p>
            </div>
        </div>
    </div>
</div>
</footer><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/frontend-layout/frontend-footer.blade.php ENDPATH**/ ?>