<?php $__env->startSection('title', 'Blog'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Manage Blog
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">User</a></li>
        <li class="active">Manage Member</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box">
           <!-- <div class="box-header">
              <h3 class="box-title">Data Table With Full Features</h3>
            </div>-->
            <!-- /.box-header -->
            <div class="box-body">
              <div id="demo" >
                <div class="search-field">
                <!--  <div class="row">
                  <div class="col-md-12">
                            <div class="form-group pull-right">
                                <a href="<?php echo e(url('user/showAddUser')); ?>"><button class="btn btn-primary">Add User</button></a>
                            </div>
                        </div>
                  </div> -->
                    <div class="row">
    
                        <div class="col-md-2">
                            <div class="org-name">Blog Title</div>
                        </div>
                        <div class="col-md-2">
                            <input class="form-control" type="text" name="title" id="param1">
                        </div>
                        
                       <!--  <div class="col-md-1">
                            <div class="org-name">Mobile</div>
                        </div>
                        <div class="col-md-2">
                            <input class="form-control" type="text" id="param2">
                        </div>
                        
                        <div class="col-md-1">
                            <div class="org-name">Email</div>
                        </div>
                        <div class="col-md-2">
                            <input class="form-control" type="text" id="param3">
                        </div> -->
                        <div class="col-md-2">
                            <div class="form-group">
                                <button class="btn btn-primary" onClick="searchData()">Search</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
           <!-- <a data-toggle="collapse" data-target="#demo"
                class="showhideangelbg"><i class="fa fa-angle-double-down"></i>
            </a>-->
              <table id="listAllUser" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Blog Title</th>
                  <th>Blog Date</th>
                  <th>Created By</th>
                  <th>Approve Status</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
    
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('styles'); ?>
<!--Extra styles can written here -->
<?php $__env->stopPush(); ?>  
<?php $__env->startPush('scripts'); ?>

<script>
  $(function () {
  $('#listAllUser').DataTable({
    'processing' : true,
    'serverSide' : true,
    'searching' : false,
    'ordering' : false,
    "ajax" : {
      'url' : "<?php echo e(url('manageblog/viewBlogthroughAjax')); ?>",
      'data' : function(d) {
        d.param1 = $('#param1').val();
        /*d.param2 = $('#param2').val();
        d.param3 = $('#param3').val();*/

      }
    },
    'dataSrc' : "",
    'columns' : [ {
      'data' : 'TBM_Blog_Name'
    }, {
      'data' : 'TBM_Blog_Date'
    }, {
      'data' : 'TMM_Member_Name'
    },{
      'data' : 'TBM_Blog_Approve'
    }, {
      'data' : 'action'
    }

    ]
  });
  
  });
  //Method For Searching Records In The List
  function searchData() {
    $('#listAllUser').DataTable().draw();
  }
  //Deleting user
  function deleteBlog(id){
    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
      }
    });
    swal.fire({
        title: "Do you want to delete the Member?",
        text: "Once deleted, can't revert back !",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#e7b63a',
        confirmButtonText: 'Delete',
        reverseButtons : true,
      }).then((result) => {
        if(result.value){
         $.ajax({
              type: "POST",
              url:"<?php echo e(url('manageblog/deleteBlogthroughAjax')); ?>",
              data:{'id':id},
              success: function(response) {
            console.log(response);
            //return false;
                  if (response.message == "success") {
                    swal({
                      title: "Record deleted successfully.",
                      type: "success"
                    }).then(function(){
                       location.reload();
                    })
                  
                    
                  } else {
                      swal({
                          title: 'Unsuccess',
                          text: response.code
                      })
                  }
              },
              error: function(data) {
               
              }
          })
        }
        
      });
  }
  //unblock user
  function unblockBlog(id){
    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
      }
    });
    swal.fire({
        title: "Do you want to Approve the Blog?",
        text: "Once Approve, can't revert back !",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#e7b63a',
        confirmButtonText: 'Approved',
        reverseButtons : true,
      }).then((result) => {
        if(result.value){
         $.ajax({
              type: "POST",
              url:"<?php echo e(url('manageblog/approveBlogthroughAjax')); ?>",
              data:{'id':id},
              success: function(response) {
            console.log(response);
            //return false;
                  if (response.message == "success") {
                    swal({
                      title: "Blog Approve successfully.",
                      type: "success"
                    }).then(function(){
                       location.reload();
                    })
                  
                    
                  } else {
                      swal({
                          title: 'Unsuccess',
                          text: response.code
                      })
                  }
              },
              error: function(data) {
               
              }
          })
        }
        
      });
  }
 
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\wethefamily\resources\views/manageuser/manage-blog.blade.php ENDPATH**/ ?>