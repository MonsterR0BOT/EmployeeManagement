<section class="services-section style-two" style="background-image: url(images/bg9.jpg);">
        <div class="auto-container">
            <div class="services-box row clearfix">
                <div class="services-carousel-two owl-carousel owl-theme">
                    <!-- Service Block -->
                    <div class="service-block">
                        <div class="inner-box">
                            <div class="lower-content">
                                <h3><a href="#">Complete Bathroom Solutions</a></h3>
                                <div class="text">A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which.</div>
                                <div class="link-box">
                                    <a href="#">Read More <i class="fa fa-angle-double-right"></i></a>
                                </div>
                            </div>
                            <div class="number-slide">01</div>
                        </div>
                    </div>
                    <!-- Service Block -->
                    <div class="service-block">
                        <div class="inner-box">
                            <div class="lower-content">
                                <h3><a href="#">Smartly Execute</a></h3>
                                <div class="text">A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which.</div>
                                <div class="link-box">
                                    <a href="#">Read More <i class="fa fa-angle-double-right"></i></a>
                                </div>
                            </div>
                            <div class="number-slide">02</div>
                        </div>
                    </div>
                    <!-- Service Block -->
                    <div class="service-block">
                        <div class="inner-box">
                            <div class="lower-content">
                                <h3><a href="#">Customer Service</a></h3>
                                <div class="text">A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which.</div>
                                <div class="link-box">
                                    <a href="#">Read More <i class="fa fa-angle-double-right"></i></a>
                                </div>
                            </div>
                            <div class="number-slide">03</div>
                        </div>
                    </div>
                </div>
            </div>  
        </div>
    </section><?php /**PATH E:\xampp\htdocs\Employee_management\resources\views/frontend-layout/service.blade.php ENDPATH**/ ?>