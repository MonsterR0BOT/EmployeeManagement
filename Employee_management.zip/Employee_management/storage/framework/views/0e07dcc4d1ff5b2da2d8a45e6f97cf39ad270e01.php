<?php $__env->startSection('title', 'JOINUS'); ?>
<?php $__env->startSection('content'); ?> 

<?php
//print_r($caste_list);exit;

?>
<section id="" class="ls section_padding_top_40 columns_padding_30 community-join">
  <div class="container">
     <div class="row">
        <div class="col-md-8 offset-md-2 login-bg" data-animation="fadeInUp" data-delay="600">
           <h2>Member Registration</h2>
          <form role="form" method="post" action="<?php echo e(url('Home/addMember')); ?>"  onSubmit="return validateForm()" autocomplete="off" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
          <div class="box-body">
            <?php if(Session::has('errors')): ?>
                <div class="col-md-12 alert alert-warning">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($error); ?><br/>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
           <div class="row">

              <div class="col-md-4">
                 <label>Full Name :</label>
                 <input type="text" class="form-control" id="Name" placeholder="Your Name" name="Name" value="">
              </div>

               <div class="col-md-4">
                 <label>Father's Name :</label>
                 <input type="Text" class="form-control" id="fathername" placeholder="Your Name" name="fathername">
              </div>
               <div class="col-md-4">
                 <label>Mother's Name :</label>
                 <input type="Text" class="form-control" id="mothername" placeholder="Your Name" name="mothername">
              </div>

              <div class="col-md-4">
                 <label>Email :</label>
                 <input type="Email" class="form-control" id="email" placeholder="Enter email" name="email" value="">
              </div>
              <div class="col-md-4">
                 <label >Mobile Number :</label>
                 <input type="text" class="form-control" id="no" placeholder="Mobile Number" name="no" maxlength="10" value="">
              </div>
              <div class="col-md-4">
                 <label>Date Of Birth :</label>
                 <input type="date" class="form-control" id="dob" placeholder="Date Of Birth" name="dob" value="">
              </div>
              <div class="col-md-4">
                 <label>Qualification :</label>
                 <select class="form-control" name="qualification" id="qualification">
                  <option value="">--Select--</option>
                  <?php $__currentLoopData = $qualification_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qual): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <option value="<?php echo e($qual->TQM_Qualification); ?>" ><?php echo e($qual->TQM_Qualification_Name); ?></option> 
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
              </div>
              <div class="col-md-4">
                 <label >Ocupation :</label>
                <select class="form-control" name="ocupation" id="ocupation">
                         <option value="">--Select--</option>
                        <?php $__currentLoopData = $occupation_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $occp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($occp->TOM_Occupation); ?>" ><?php echo e($occp->TOM_Occupation_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </select>
              </div>
              <div class="col-md-4">
                 <label>Religion :</label>
                  <select class="form-control" name="religion" id="religion">
                         <option value="">--Select--</option>
                        <?php $__currentLoopData = $religion_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $religion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($religion->TRM_Religion); ?>" ><?php echo e($religion->TRM_Religion_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </select>
              </div>
                <div class="col-md-4">
                 <label>Caste :</label>
                 <select class="form-control" name="caste" id="caste">
                    <option value="">--Select--</option>
                        <?php $__currentLoopData = $caste_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caste): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($caste->TCM_Caste); ?>"><?php echo e($caste->TCM_Caste_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </select>
              </div>
              <div class="col-md-4">
                 <label>Member Type:</label>
                 <select class="form-control" name="MemberType" id="MemberType">
                    <option value="">Select</option>
                    <option value="1">Main Member</option>
                    <option value="2">Business Member</option>
                    <option value="3">Student Member</option>
                 </select>
              </div>
              <div class="col-md-4">
                 <label for="pwd">User Id :</label>
                 <input type="Text" class="form-control" id="userid" placeholder="Enter userid" name="userid" value="">
              </div>
              <div class="col-md-4">
                 <label for="pwd">Password :</label>
                 <input type="password" class="form-control" id="password" placeholder="Enter password" name="password" value="" >
              </div>
              <div class="col-md-4">
                 <label >Gender :  </label>
                 <label class="radio-inline">
                 <input type="radio" name="gender" value="1" checked="checked"> Male
                 </label>
                 <label class="radio-inline">
                 <input type="radio" name="gender"value="2"> Female
                 </label>
              </div>
               <div class="col-md-4"> <label class="custom-file-upload" for="memberImage"><i class="fa fa-cloud-upload"></i> Upload Photo</label>
                 <input id="memberImage" name="memberImage" type="file" class="form-control" accept="image/*" >
              </div>
          
           </div>
           

          <div class="row">
                 <div class="col-md-12">
                    <div class="sub-heading">Present Address</div>
                 </div>
                  <div class="col-md-4">
                 <label>House/Plot No :</label>
                 <input type="text" class="form-control" id="prHouseNo" placeholder="House No" name="prHouseNo">
              </div>
              <div class="col-md-4">
                 <label>Location :</label>
                 <input type="text" class="form-control" id="prLocation" placeholder="Location" name="prLocation" value="">
              </div>

              <div class="col-md-4">
                 <label>City :</label>
                 <input type="text" class="form-control" id="prCity" placeholder="Location" name="prCity" value="">
                  <!--  <select class="form-control" name="prCity" id="prCity">
                         <option value="">--Select--</option>
                        <?php $__currentLoopData = $city_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($city->TDM_city_Name); ?>"><?php echo e($city->TDM_city_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </select> -->
              </div>
              <div class="col-md-4">
                 <label>District :</label>
                 <select class="form-control" name="prDistrict" id="prDistrict">
                    <option value="">--Select--</option>
                        <?php $__currentLoopData = $district_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($district->TDM_District); ?>"><?php echo e($district->TDM_Dist_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </select>
              </div>
               <div class="col-md-4">
                 <label >Select State :</label>
                      <select class="form-control" name="prState" id="prState">
                         <option value="">--Select--</option>
                        <?php $__currentLoopData = $state_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($state->TSM_State); ?>"><?php echo e($state->TSM_State_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </select>
              </div>
               <div class="col-md-4">
                 <label>PIN :</label>
                 <input type="text" class="form-control" maxlength="6" id="prPin" placeholder="PIN" name="prPin">
              </div>
             
           </div>
                <div class="row">
                 <div class="col-md-12">
                    <div class="sub-heading">Permanet Address</div>
                 </div>
                <div class="col-md-4">
                 <label>House/Plot No :</label>
                 <input type="text" class="form-control" id="peHouseNo" placeholder="House No" name="peHouseNo">
              </div>
               <div class="col-md-4">
                 <label>Location :</label>
                 <input type="text" class="form-control" id="peLocation" placeholder="Location" name="peLocation">
              </div>
               <div class="col-md-4">
                 <label>City :</label>
                 <input type="text" class="form-control" id="peCity" placeholder="Location" name="peCity" value="">
              </div>
              <div class="col-md-4">
                 <label>District :</label>
                 <select class="form-control" name="peDistrict" id="peDistrict">
                    <option value="">--Select--</option>
                        <?php $__currentLoopData = $district_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($district->TDM_District); ?>"><?php echo e($district->TDM_Dist_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </select>
              </div>
              <div class="col-md-4">
                 <label >Select State :</label>
                  <select class="form-control" name="peState" id="peState">
                         <option value="">--Select--</option>
                        <?php $__currentLoopData = $state_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($state->TSM_State); ?>"><?php echo e($state->TSM_State_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </select>
              </div> 
               <div class="col-md-4">
                 <label>PIN :</label>
                 <input type="text" class="form-control" maxlength="6" id="pePin" placeholder="PIN" name="pePin">
              </div>
           </div>
          <div class="row">
           <div class="col-md-12">
              <button type="button" href="#demo" class="btn btn-primary" data-toggle="collapse">Reference Person One </button>
              <div class="clearfix"></div>
                <div id="demo" class="collapse">
                 <div class="row">
                  <div class="col-md-4">
                 <label>Full Name :</label>
                 <input type="text" class="form-control" id="rNameOne" placeholder="Reference Person Name" name="rNameOne">
               </div>
               <div class="col-md-4">
                 <label>Father's Name :</label>
                 <input type="Text" class="form-control" id="rFatherOne" placeholder="Father's Name" name="rFatherOne">
              </div>
               <div class="col-md-4">
                 <label>Mother's Name :</label>
                 <input type="Text" class="form-control" id="rMotherOne" placeholder="Mother's Name" name="rMotherOne">
              </div>
              <div class="col-md-4">
                 <label>Email :</label>
                 <input type="Email" class="form-control" id="rMailOne" placeholder="Enter email" name="rMailOne">
              </div>
              <div class="col-md-4">
                 <label >Mobile Number :</label>
                 <input type="text" class="form-control" maxlength="10" id="rMobileOne" placeholder="Mobile Number" name="rMobileOne">
              </div>
              <div class="col-md-4">
                 <label>Date Of Birth :</label>
                 <input type="date" class="form-control" id="rDobOne" placeholder="Date Of Birth" name="rDobOne">
              </div>
              <div class="col-md-4">
                 <label>Qualification :</label>
                 <select class="form-control" name="rQualificationOne" id="rQualificationOne">
                         <option value="">--Select--</option>
                        <?php $__currentLoopData = $qualification_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qual): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <option value="<?php echo e($qual->TQM_Qualification); ?>" ><?php echo e($qual->TQM_Qualification_Name); ?></option> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </select>
              </div>
              <div class="col-md-4">
                 <label >Ocupation :</label>
                 <select class="form-control" name="rOcupationOne" id="rOcupationOne">
                         <option value="">--Select--</option>
                        <?php $__currentLoopData = $occupation_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $occp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($occp->TOM_Occupation); ?>" ><?php echo e($occp->TOM_Occupation_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </select>
              </div>
              <div class="col-md-4">
                 <label>Religion :</label>
                 <select class="form-control" name="rReligionOne" id="rReligionOne">
                         <option value="">--Select--</option>
                        <?php $__currentLoopData = $religion_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $religion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($religion->TRM_Religion); ?>" ><?php echo e($religion->TRM_Religion_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </select>
              </div>
               <div class="col-md-4">
                 <label>Caste :</label>
                 <select class="form-control" name="rCasteOne" id="rCasteOne">
                    <option value="">--Select--</option>
                        <?php $__currentLoopData = $caste_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caste): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($caste->TCM_Caste); ?>"><?php echo e($caste->TCM_Caste_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </select>
              </div>
                <div class="col-md-4">
                 <label>Member Type :</label>
                 <select class="form-control" name="rMemberTypeOne" id="rMemberTypeOne">
                    <option value="">Select</option>
                    <option value="1">Main Member</option>
                    <option value="2">Business Member</option>
                    <option value="3">Student Member</option>
                 </select>
              </div>
           </div>
         </div>
      </div>
          <div class="col-md-12">
               <button type="button" href="#demo1" class="btn btn-primary" data-toggle="collapse">Reference Person two </button>
                <div id="demo1" class="collapse">
                <div class="row">
             <div class="col-md-4">
                 <label>Full Name :</label>
                 <input type="text" class="form-control" id="rNameTwo" placeholder="Reference Person Name" name="rNameTwo">
              </div>
               <div class="col-md-4">
                 <label>Father's Name :</label>
                 <input type="text" class="form-control" id="rFatherTwo" placeholder="Father's Name" name="rFatherTwo">
              </div>
               <div class="col-md-4">
                 <label>Mother's Name :</label>
                 <input type="text" class="form-control" id="rMotherTwo" placeholder="Mother's Name" name="rMotherTwo">
              </div>
              <div class="col-md-4">
                 <label>Email :</label>
                 <input type="text" class="form-control" id="rMailTwo" placeholder="Enter email" name="rMailTwo">
              </div>
              <div class="col-md-4">
                 <label >Mobile Number :</label>
                 <input type="text" class="form-control" id="rMobileTwo" placeholder="Mobile Number" name="rMobileTwo">
              </div>
              <div class="col-md-4">
                 <label>Date Of Birth :</label>
                 <input type="date" class="form-control" id="rDobTwo" placeholder="Date Of Birth" name="rDobTwo">
              </div>
              <div class="col-md-4">
                 <label>Qualification :</label>
                 <select class="form-control" name="rQualificationTwo" id="rQualificationTwo">
                         <option value="">--Select--</option>
                        <?php $__currentLoopData = $qualification_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qual): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <option value="<?php echo e($qual->TQM_Qualification); ?>" ><?php echo e($qual->TQM_Qualification_Name); ?></option> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </select>
              </div>
              <div class="col-md-4">
                 <label >Ocupation :</label>
                 <select class="form-control" name="rOcupationTwo" id="rOcupationTwo">
                         <option value="">--Select--</option>
                        <?php $__currentLoopData = $occupation_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $occp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($occp->TOM_Occupation); ?>"><?php echo e($occp->TOM_Occupation_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </select>
              </div>
              <div class="col-md-4">
                 <label>Religion :</label>
                 <select class="form-control" name="rReligionTwo" id="rReligionTwo">
                         <option value="">--Select--</option>
                        <?php $__currentLoopData = $religion_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $religion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($religion->TRM_Religion); ?>" ><?php echo e($religion->TRM_Religion_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </select>
              </div>
               <div class="col-md-4">
                 <label>Caste :</label>
                 <select class="form-control" name="rCasteTwo" id="rCasteTwo">
                   <option value="">--Select--</option>
                        <?php $__currentLoopData = $caste_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caste): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($caste->TCM_Caste); ?>"><?php echo e($caste->TCM_Caste_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </select>
              </div>
                <div class="col-md-4">
                 <label>Member Type :</label>
                 <select class="form-control" name="rMemberTypeTwo" id="rMemberTypeTwo">
                    <option value="">Select</option>
                    <option value="1">Main Member</option>
                    <option value="2">Business Member</option>
                    <option value="3">Student Member</option>
                 </select>
              </div>
                   </div>
              </div>
             </div>
              
          </div>

           <div class="row">
              <div class="col-md-4 col-md-offset-4">
                 <div class="d-flex justify-content-center links">
                    Already a member? <a href="<?php echo e(url('login-member')); ?>" class="ml-2">Sign In</a>
                 </div>
              </div>
           </div>


           <div class="row">
              <div class="col-md-8 offset-md-4">
                <input type="hidden" name="hidMemberId" id="hidMemberId" value=""/>
                  <a href="<?php echo e(url('/')); ?>"><button type="button" class="btn btn-default">Cancel</button></a>
                  <button type="submit" class="btn btn-primary" >Save</button>
              </div>
              </div>
              </form>
           </div>
        </div>
     </div>
</section>

<?php $__env->startPush('scripts'); ?>  
  <script>
    /* $(function () {
       $('input').iCheck({
         checkboxClass: 'icheckbox_square-blue',
         radioClass: 'iradio_square-blue',
         increaseArea: '20%' 
       });
     });*/
     function validateForm(){ //alert("here"); return false;
            if (!blankValidation("Name", "TextField","Name is required"))
           return false;
         if (!blankValidation("fathername", "TextField","fathername is required"))
           return false;
         if (!blankValidation("mothername", "TextField","mothername is required"))
           return false;
         if (!blankValidation("email", "TextField","Email is required"))
           return false;
         if (!RemoveSQLCharacter("email"))
           return false;
         if (!checkEmailId("email","Invalid email id !!!"))
           return false;
         
         if (!blankValidation("no", "TextField","Mobile No is required"))
           return false; 

         if (!blankValidation("dob", "TextField","Date of Birth is required"))
           return false;
         if (!blankValidation("qualification", "TextField","Qualification is required"))
           return false;
         if (!blankValidation("ocupation", "TextField","Ocupation is required"))
           return false; 

        if (!blankValidation("religion", "TextField","Religion is required"))
           return false; 
        if (!blankValidation("caste", "TextField","Caste is required"))
           return false;
        if (!blankValidation("MemberType", "TextField","Member Type is required"))
           return false; 

        if (!blankValidation("userid", "TextField","userid is required"))
           return false; 
        if (!blankValidation("password", "TextField","Password is required"))
           return false; 

        if (!blankValidation("memberImage", "TextField","Image is required"))
           return false;

         if (!blankValidation("prHouseNo", "TextField","House No is required"))
           return false; 

         if (!blankValidation("prLocation", "TextField","Location is required"))
           return false;
         if (!blankValidation("prCity", "TextField","City is required"))
           return false;
         if (!blankValidation("prDistrict", "TextField","District is required"))
           return false; 
         if (!blankValidation("prState", "TextField","State is required"))
           return false; 
         if (!blankValidation("prPin", "TextField","Pin is required"))
           return false; 
         
         
        if (!blankValidation("peHouseNo", "TextField","House No is required"))
           return false; 

         if (!blankValidation("peLocation", "TextField","Location is required"))
           return false;
         if (!blankValidation("peCity", "TextField","City is required"))
           return false;
         if (!blankValidation("peDistrict", "TextField","District is required"))
           return false; 
         if (!blankValidation("peState", "TextField","State is required"))
           return false; 
         if (!blankValidation("pePin", "TextField","Pin is required"))
           return false; 


        if (!blankValidation("rNameOne", "TextField"," Refernce Name is required"))
           return false; 
        if (!blankValidation("rFatherOne", "TextField","Father name is required"))
           return false;
        if (!blankValidation("rMotherOne", "TextField","Mother Name is required"))
           return false;
        if (!blankValidation("rMailOne", "TextField","Refernce Mail is required"))
           return false; 
        if (!blankValidation("rMobileOne", "TextField","Refernce Mobile is required"))
           return false;
        if (!blankValidation("rDobOne", "TextField","Date of Birth is required"))
           return false;
        if (!blankValidation("rQualificationOne", "TextField","Qualification is required"))
           return false;
        if (!blankValidation("rOcupationOne", "TextField","Ocupation is required"))
           return false; 
        if (!blankValidation("rReligionOne", "TextField","Religion is required"))
           return false;
        if (!blankValidation("rCasteOne", "TextField","Caste is required"))
           return false;
        if (!blankValidation("rMemberTypeOne", "TextField","Member Type is required"))
           return false;

        if (!blankValidation("rNameTwo", "TextField"," Refernce Name is required"))
           return false; 
         if (!blankValidation("rFatherTwo", "TextField","Father name is required"))
           return false;
         if (!blankValidation("rMotherTwo", "TextField","Mother Name is required"))
           return false;
         if (!blankValidation("rMailTwo", "TextField","Refernce Mail is required"))
           return false; 
        if (!blankValidation("rMobileTwo", "TextField","Refernce Mobile is required"))
           return false;
         if (!blankValidation("rDobTwo", "TextField","Date of Birth is required"))
           return false;
         if (!blankValidation("rQualificationTwo", "TextField","Qualification is required"))
           return false;
          if (!blankValidation("rOcupationTwo", "TextField","Ocupation is required"))
           return false; 
        if (!blankValidation("rReligionTwo", "TextField","Religion is required"))
           return false;
         if (!blankValidation("rCasteTwo", "TextField","Caste is required"))
           return false;
         if (!blankValidation("rMemberTypeTwo", "TextField","Member Type is required"))
           return false;
     }
    
  </script>
 
<!-- <script >
jQuery(document).ready(function(){
    jQuery('#referencep1').on('click', function(event) {        
        jQuery('#referencep1div').toggle('show');
    });
});
</script> -->
 
  <!--FOR CHANGE LANGUAGE-->
<?php $__env->stopPush(); ?>
       <?php $__env->stopSection(); ?> 
<?php echo $__env->make('frontend-layout.frontend-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\wethefamily\resources\views/joinus.blade.php ENDPATH**/ ?>