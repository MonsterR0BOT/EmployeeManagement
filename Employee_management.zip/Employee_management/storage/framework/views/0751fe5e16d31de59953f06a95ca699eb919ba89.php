<?php $__env->startSection('title', 'TERM&CONDITION'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1> Edit Term&Condition</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Edit Term&Condition</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <?php //print_r($emailDetails);exit;?>
      <!-- Default box -->
      <div class="box">
        <form role="form" id="emailForm" method="post" autocomplete="off" action="<?php echo e(url('content/saveTermCondition')); ?>">
          <?php echo e(csrf_field()); ?>

          <div class="box-body">
             <?php if(Session::has('errors')): ?>
                  <div class="col-md-12 alert alert-warning">
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php echo e($error); ?><br/>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
              <?php endif; ?>
            <div class="row">
                <div class="col-md-6">
                  <?php
                        if(!empty($data)){
                            $termconditionId = $data[0]->TTM_Termcondition;
                            $TTM_Termcondition_Name  = $data[0]->TTM_Termcondition_Name ;
                            $TTM_Termcondition_Description = $data[0]->TTM_Termcondition_Description;
                            $TTM_Termcondition_Active = $data[0]->TTM_Termcondition_Active;
                        }else{
                            $termconditionId = '';
                            $TTM_Termcondition_Name  = '' ;
                            $TTM_Termcondition_Description = '';
                            $TTM_Termcondition_Active = 1;
                        }
                    ?>
                    <input type="hidden" name="hdTermconditionId" id="hdTermconditionId" value="<?php echo e($termconditionId); ?>"> 
                    <div class="form-group">
                      <label for="name">Term&Condition Name</label>
                      <input type="text" class="form-control" name="termconditionName" id="termconditionName" value="<?php echo e($TTM_Termcondition_Name); ?>"> 
                    </div>

                  
                </div>
            <!--      <div class="col-md-6">
                  <div class="col-md-6">
                       <div class="form-group form-bg">
                          <label>Do you want to Write in Odia ? </label>
                       </div>
                    </div>
                    <div class="col-md-6">
                       <div class="form-group">
                          <div class="checkbox">
                             <input type="checkbox" id="checkboxId" onClick="javascript:checkboxClickHandler()">
                            <select id="languageDropDown" name="languageDropDown" onChange="javascript:languageChangeHandler()"></select>                                                   
                          </div> 
                       </div>
                    </div>
                </div> -->
                <div class="col-md-12">    
                    <div class="form-group">
                      <label for="description">Term&Condition Description</label>
                      <textarea class="form-control" name="termconditionDescription" id="termconditionDescription"><?php echo e($TTM_Termcondition_Description); ?></textarea> 
                    </div>
                     
                </div>
         
            </div>
          </div>
          <!-- /.box-body -->
          <div class="box-footer">
            <button type="button" class="btn btn-primary" onclick="validateForm();">Save</button>
             <a href="<?php echo e(url('content/viewTermCondition')); ?>"><button type="button" class="btn btn-warning" >Cancel</button></a>
          </div>
        </form>
      </div>
      <!-- /.box -->
      
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('scripts'); ?> 
<script type="text/javascript">
   function validateForm(){
      if (!blankValidation("termconditionName","TextField", "Termcondition Name can not be left blank"))
          return false; 
      $('#emailForm').submit();
   }  
   $(function () {
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    CKEDITOR.replace('termconditionDescription')
    //CKEDITOR.replace('contentDescriptionOdia')
    $("#checkboxId").click();
  })
</script>
<!--FOR CHANGE LANGUAGE-->
<script type="text/javascript" src="https://www.google.com/jsapi"></script>
  <script type="text/javascript">
    google.load("elements", "1", {
      packages: "transliteration"
    });

    var transliterationControl;
    function onLoad() {
      var options = {
        sourceLanguage: 'en',
        destinationLanguage: ['or'],
        transliterationEnabled: false,
        shortcutKey: 'ctrl+g'
      };
      // Create an instance on TransliterationControl with the required
      // options.
      transliterationControl =
      new google.elements.transliteration.TransliterationControl(options);

      // Enable transliteration in the textfields with the given ids.
      var ids = [  "contentNameOdia", "contentDescriptionOdia"];
      transliterationControl.makeTransliteratable(ids);

      // Add the STATE_CHANGED event handler to correcly maintain the state
      // of the checkbox.
      transliterationControl.addEventListener(
      google.elements.transliteration.TransliterationControl.EventType.STATE_CHANGED,
      transliterateStateChangeHandler);

      // Add the SERVER_UNREACHABLE event handler to display an error message
      // if unable to reach the server.
      transliterationControl.addEventListener(
      google.elements.transliteration.TransliterationControl.EventType.SERVER_UNREACHABLE,
      serverUnreachableHandler);

      // Add the SERVER_REACHABLE event handler to remove the error message
      // once the server becomes reachable.
      transliterationControl.addEventListener(
      google.elements.transliteration.TransliterationControl.EventType.SERVER_REACHABLE,
      serverReachableHandler);

      // Set the checkbox to the correct state.
      document.getElementById('checkboxId').checked =
      transliterationControl.isTransliterationEnabled();

      // Populate the language dropdown
      var destinationLanguage =
      transliterationControl.getLanguagePair().destinationLanguage;
      var languageSelect = document.getElementById('languageDropDown');
      var supportedDestinationLanguages =
      google.elements.transliteration.getDestinationLanguages(
      google.elements.transliteration.LanguageCode.ENGLISH);
      for (var lang in supportedDestinationLanguages) {
        var opt = document.createElement('option');
        opt.text = lang;
        if (lang=="ORIYA" ){
          opt.value = supportedDestinationLanguages[lang];
          if (destinationLanguage == opt.value) {
            opt.selected = true;
          }
          try {
            languageSelect.add(opt, null);
          } catch (ex) {
            languageSelect.add(opt);
          }
        }//End of if
      }
       //english bydefault
        //var opt_enlang=document.createElement('option');
        //opt_enlang.text='ENGLISH';
        //opt_enlang.value='en';
        //languageSelect.add(opt_enlang);
       
    }
    function transliterateStateChangeHandler(e) {
      document.getElementById('checkboxId').checked = e.transliterationEnabled;
    }
    function checkboxClickHandler() {
      transliterationControl.toggleTransliteration();
    }
    function languageChangeHandler() {
      var dropdown = document.getElementById('languageDropDown');
      transliterationControl.setLanguagePair(
      google.elements.transliteration.LanguageCode.ENGLISH,
      dropdown.options[dropdown.selectedIndex].value);
    }

    function serverUnreachableHandler(e) {
      document.getElementById("errorDiv").innerHTML =
      "Transliteration Server unreachable";
    }
    function serverReachableHandler(e) {
      document.getElementById("errorDiv").innerHTML = "";
    }
    google.setOnLoadCallback(onLoad);
  </script>
  <!--FOR CHANGE LANGUAGE-->  
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\wethefamily\resources\views/content/edit-termcondition.blade.php ENDPATH**/ ?>