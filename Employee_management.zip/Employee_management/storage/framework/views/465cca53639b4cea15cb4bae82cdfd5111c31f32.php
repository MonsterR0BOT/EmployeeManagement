<!DOCTYPE html>
<html>
<head>
<?php echo $__env->make('frontend-layout.metacss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
    <div class="modal" tabindex="-1" role="dialog" aria-labelledby="search_modal" id="search_modal">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">
            <i class="rt-icon2-cross2"></i>
        </span>
        </button>
        <div class="widget widget_search">
            <form method="get" class="searchform search-form form-inline" action="./">
                <div class="form-group bottommargin_0">
                    <input type="text" value="" name="search" class="form-control" placeholder="Search keyword" id="modal-search-input"> </div>
                <button type="submit" class="theme_button no_bg_button">Search</button>
            </form>
        </div>
    </div>
    <div class="modal fade" tabindex="-1" role="dialog" id="messages_modal">
        <div class="fw-messages-wrap ls with_padding">
        </div>
    </div>
    <div id="canvas">
        <div id="box_wrapper">
            <?php echo $__env->make('frontend-layout.frontend-navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
            <?php echo $__env->make('frontend-layout.frontend-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <!-- eof #box_wrapper -->
    </div>
    <!-- eof #canvas -->
    <?php echo $__env->make('frontend-layout.includejs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- <script src="js/switcher.js"></script>
</body> -->

</html><?php /**PATH E:\xampp\htdocs\wethefamily\resources\views/frontend-layout/frontend-master.blade.php ENDPATH**/ ?>