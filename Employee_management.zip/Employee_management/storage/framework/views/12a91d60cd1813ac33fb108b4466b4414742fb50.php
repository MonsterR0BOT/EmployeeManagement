 
<?php $__env->startSection('title', 'NEWS'); ?>
<?php $__env->startSection('content'); ?>
 <section class="page_breadcrumbs ds background_cover section_padding_top_65 section_padding_bottom_65">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 text-center">
                            <h2>Our Latest News</h2>
                        </div>
                    </div>
                </div>
            </section>
        <section class="ls section_padding_top_100 section_padding_bottom_100">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12">
               
                            <div class="isotope_container isotope row masonry-layout columns_margin_bottom_20" style="position: relative; height: 1098.75px;">
                 <?php $__currentLoopData = $news_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                 <?php
                 $TNM_News_Image = $data->TNM_News_Image;
                 ?>
                                <div class="isotope-item col-lg-4 col-md-6 col-sm-12" >
                                    <article class="post vertical-item content-padding with_border bottom_color_border loop-color">
                                        <div class="item-media entry-thumbnail"> <img src="<?php echo e(asset('news_image/orig/'.$TNM_News_Image)); ?>" alt=""> </div>
                                        <div class="item-content">
                                            <header class="entry-header">
                                                <h4 class="entry-title small"> <a href="blog-single-full.html" rel="bookmark"><?php echo e($data->TNM_News_Name); ?></a> </h4>
                                                <div class="entry-meta inline-content greylinks"> <span>
                                    <i class="fa fa-calendar highlight rightpadding_5" aria-hidden="true"></i>
                                    <a href="blog-single-right.html">
                                        <time datetime="2017-10-03T08:50:40+00:00">
                                        <?php echo e(date("d M,Y",strtotime($data->TNM_News_CreatedOn))); ?></time>
                                    </a>
                                </span></div>
                                            </header>
                                            <div class="entry-content content-3lines-ellipsis">
                                                <p><?php echo e($data->TNM_News_Desc); ?></p>
                                            </div>
                                        </div>
                                    </article>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
                            </div>
                           
                        </div>
                    </div>
                </div>
            </section>
                <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend-layout.frontend-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\wethefamily\resources\views/news.blade.php ENDPATH**/ ?>