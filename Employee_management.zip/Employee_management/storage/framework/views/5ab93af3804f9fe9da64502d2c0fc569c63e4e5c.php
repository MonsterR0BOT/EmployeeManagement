<?php $__env->startSection('title', 'PASSWORD'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>User Login Setting</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Setting</a></li>
        <li class="active">Set User Login Setting</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      
      <!-- Default box -->
      <div class="box"> 
        <!-- form start -->
        
        <form role="form" method="post" action="<?php echo e(url('post-user-login-setting')); ?>"  onsubmit="return validateForm()" autocomplete="off">
          <?php echo csrf_field(); ?>
              <div class="box-body">
                <div class="col-md-6">
                <div class="row">

                     <div style="height:20px;">
                      <?php if(session()->exists('success')): ?>
                          <span style="color:#090;">User Login Setting Updated Successfully.</span>
                      <?php endif; ?>
                      
                      <?php if(session()->exists('blank')): ?>
                          <span style="color:#F00;">Please Enter all required values.</span>
                      <?php endif; ?>
                    </div>

                  <div class="col-md-12">
                    <div class="row">

                        <?php //print "<pre>"; print_r($data);exit;?>
                        <?php
                          if(!empty($data)){
                              $userId = $data[0]->TULS_User;
                              $TULS_Login_Attempt = $data[0]->TULS_Login_Attempt;
                              $TULS_Login_Block_Dur = $data[0]->TULS_Login_Block_Dur;
                              $TULS_User_Active = $data[0]->TULS_User_Active;  
                              
                          }else{
                              $userId = '';
                              $TULS_Login_Attempt = '';
                              $TULS_Login_Block_Dur = '';
                              $TULS_Login_Block_Dur = '';
                              $TULS_User_Active = '';                   }
                          ?>  
                     <div class="col-md-6">
                       <label for="exampleInputEmail1">No. of Login Attempt</label>
                     </div>
                     <div class="col-md-6">
                        <div class="form-group">
                        	 <input type="text" class="form-control" name="logAttempt" id="logAttempt" value="<?php echo e($TULS_Login_Attempt); ?>">
                        </div>
                     </div> 

                      <div class="col-md-6">
                       <label for="exampleInputEmail1">Login Block Duration</label>
                     </div>
                     <div class="col-md-6">
                        <div class="form-group">
                        	 <input type="text" class="form-control" name="lBlockDur" id="lBlockDur" value="<?php echo e($TULS_Login_Block_Dur); ?>">
                         
                     </div>  

                   </div>
                  </div> 
                   

                     <div class="col-md-12">
                        <a href="<?php echo e(url('dashboard')); ?>" class="btn btn-danger">Cancel</a>
                        <button class="btn btn-primary">Update</button> 
                     </div>
                  </div>
                </div>
             </div>
        </form>
      </div>
      <!-- /.box -->
      
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('scripts'); ?> 
<script type="text/javascript">
   function validateForm(){
    //alert("alert");return false;
    
    if (!blankValidation("logAttempt","TextField", "No. of Login Attempt can not be left blank"))
      return false;

    if (!blankValidation("lBlockDur","TextField", "Login Attempt Duration Can Not be Null"))
      return false;
    
   }  

</script>  
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-demo\resources\views/setting/manage-user-login.blade.php ENDPATH**/ ?>