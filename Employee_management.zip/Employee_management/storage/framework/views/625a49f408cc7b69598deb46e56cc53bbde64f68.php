<?php $__env->startSection('title', 'DISCIPLINARY'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Disciplinary Request
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Diciplinary</a></li>
        <li class="active">Disciplinary Request</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
           <!-- <div class="box-header">
              <h3 class="box-title">Data Table With Full Features</h3>
            </div>-->
            <!-- /.box-header -->
            <div class="box-body">
              <div id="demo" >
                <div class="search-field">
                    <div class="row">
    
                        <div class="col-md-2">
                            <div class="org-name">From Date</div>
                        </div>
                        <div class="col-md-2">
                            <input class="form-control" type="text" id="param1">
                        </div>
                        
                        <div class="col-md-1">
                            <div class="org-name">To Date</div>
                        </div>
                        <div class="col-md-2">
                            <input class="form-control" type="text" id="param2">
                        </div>
                        
                        <div class="col-md-1">
                            <div class="org-name">Department</div>
                        </div>
                        <div class="col-md-2">
                            <select class="form-control processNameCls">
                              <option value="">--Select--</option>
                              <option value="">Agriculture & F.E. Department</option>
                              <option value="">Commerce & Transport</option>
                              <option value="">Co-Operation Department</option>
                              <option value="">Exise Department</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <button class="btn btn-primary" onClick="searchData()">Search</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
           <!-- <a data-toggle="collapse" data-target="#demo"
                class="showhideangelbg"><i class="fa fa-angle-double-down"></i>
            </a>-->
              <table id="listAllUser" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Request Ref#</th>
                  <th>Department</th>
                  <th>Delinquent Officer</th>
                  <th>Designation</th>
                  <th>Date Time</th>
                  <th>Assign Assistant</th>
                  <th>ASO/JA Status</th>
                  <th>Assigned Date</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                  <td><a title="view" href="<?php echo e(url('view-so-disciplinary-request-opsc')); ?>">DISCP/2019-20/001</a></td>
                  <td>Agriculture & F.E. Department</td>
                  <td>Shyma Prasad</td>
                  <td>Dy. Secretary</td>
                  <td>23/12/2019 10:00:23</td>
                  <td>
                    <select class="form-control processNameCls">
                      <option value="">--Select--</option>
                      <option value="">ASO</option>
                      <option value="">JA</option>
                    </select>
                  </td>
                  <td>Pending</td>
                  <td>24/12/2019</td>
                  <td><span class="label label-info">Open</span></td>
                  <td><a title="view" href="<?php echo e(url('view-so-disciplinary-request-opsc')); ?>"><i class="fa fa-eye"></i></a>&nbsp;&nbsp;<a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false"><i class="fa fa-clock-o"></i></a>
                  </td>
                </tr>
                <tr>
                  <td><a title="view" href="<?php echo e(url('view-so-disciplinary-request-opsc')); ?>">DISCP/2019-20/002</a></td>
                  <td>Commerce & Transport</td>
                  <td>Monalisha Kar</td>
                  <td>Dy. Secretary</td>
                  <td>24/12/2019 10:12:20</td>
                  <td>
                    <select class="form-control processNameCls">
                        <option value="">--Select--</option>
                        <option value="">ASO</option>
                        <option value="">JA</option>
                      </select>
                  </td>
                  <td>Pending</td>
                  <td>24/12/2019</td>
                  <td><span class="label label-info">Open</span></td>
                  <td><a title="view" href="<?php echo e(url('view-so-disciplinary-request-opsc')); ?>"><i class="fa fa-eye"></i></a>&nbsp;&nbsp;<a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false"><i class="fa fa-clock-o"></i></a>
                  </td>
                </tr>
                <tr>
                 <td><a title="view" href="<?php echo e(url('view-so-disciplinary-request-opsc')); ?>">DISCP/2019-20/003</a></td>
                  <td>Co-Operation Department</td>
                  <td>Jagamohan Kar</td>
                  <td>Registar</td>
                  <td>24/12/2019 10:20:30</td>
                  <td>
                    <select class="form-control processNameCls">
                        <option value="">ASO</option>
                        <option value="">JA</option>
                      </select>
                  </td>
                  <td>In Progress</td>
                  <td>24/12/2019</td>
                  <td><span class="label label-info">Open</span></td>
                  <td><a title="view" href="<?php echo e(url('view-so-disciplinary-request-opsc')); ?>"><i class="fa fa-eye"></i></a>&nbsp;&nbsp;<a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false"><i class="fa fa-clock-o"></i></a>
                  </td>
                </tr>
                <tr>
                  <td><a title="view" href="<?php echo e(url('view-so-disciplinary-request-opsc')); ?>">DISCP/2019-20/004</a></td>
                  <td>Excise Department</td>
                  <td>Dinesh Kumar</td>
                  <td>AGM</td>
                  <td>24/12/2019 12:30:25</td>
                  <td>
                    <select class="form-control processNameCls">
                        <option value="">JA</option>
                        <option value="">ASO</option>
                      </select>
                  </td>
                  <td>In Progress</td>
                  <td>24/12/2019</td>
                  <td><span class="label label-info">Open</span></td>
                  <td><a title="view" href="<?php echo e(url('view-so-disciplinary-request-opsc')); ?>"><i class="fa fa-eye"></i></a>&nbsp;&nbsp;<a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false"><i class="fa fa-clock-o"></i></a>
                  </td>
                </tr>

                <tr>
                  <td><a title="view" href="<?php echo e(url('view-so-disciplinary-request-opsc')); ?>">DISCP/2019-20/005</a></td>
                  <td>Energy Department</td>
                  <td>Sunanda Swain</td>
                  <td>Executive Eng.</td>
                  <td>24/12/2019 12:23:34</td>
                  <td>
                    <select class="form-control processNameCls">
                        <option value="">ASO</option>
                        <option value="">JA</option>
                      </select>
                  </td>
                  <td>Completed</td>
                  <td>24/12/2019</td>
                  <td><span class="label label-info">Open</span></td>
                  <td><a title="view" href="<?php echo e(url('view-so-disciplinary-request-opsc')); ?>"><i class="fa fa-eye"></i></a>&nbsp;&nbsp;<a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false"><i class="fa fa-clock-o"></i></a>
                  </td>
                </tr>
                <tr>
                  <td><a href="<?php echo e(url('view-so-disciplinary-request-opsc')); ?>">DISCP/2019-20/006</a></td>
                  <td>Electronic & I.T.</td>
                  <td>Malaya Mishra</td>
                  <td>Dy. Secretary</td>
                  <td>24/12/2019 10:20:23</td>
                  <td>
                    <select class="form-control processNameCls">
                        <option value="">ASO</option>
                        <option value="">JA</option>
                      </select>
                  </td>
                  <td>Completed</td>
                  <td>24/12/2019</td>
                  <td><span class="label label-success">Approved</span></td>
                  <td><a title="view" href="<?php echo e(url('view-so-disciplinary-request-opsc')); ?>"><i class="fa fa-eye"></i></a>&nbsp;&nbsp;<a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false"><i class="fa fa-clock-o"></i></a>
                  </td>
                </tr>

                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <!-- Modal Start-->
  <div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg">
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Proceeding Status</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <div class="col-md-12">
                  <!-- The timeline -->
                  <ul class="timeline timeline-inverse">
                      <!-- timeline time label -->
                      <li class="time-label"> <span class="bg-red">10 Dec. 2019</span>
                      </li>
                      <!-- /.timeline-label -->
                      <!-- timeline item -->
                      <li>
                          <i class="fa fa-user bg-blue"></i>
                          <div class="timeline-item"><span class="time"><i class="fa fa-clock-o"></i> 10 Dec. 2019 12:05:20</span>
                              <h3 class="timeline-header"><a href="#">Prasanna Behera</a>, Office Asst, Agriculture & F.E Department</h3>
                              <div class="timeline-body">I certify that all information given above have been checked by me and found to be correct & all copies of relevant documents as mentioned above have been enclosed. </div>
                              <!-- <div class="timeline-footer">     <a class="btn btn-primary btn-xs">Read more</a>     <a class="btn btn-danger btn-xs">Delete</a>   </div> -->
                          </div>
                      </li>
                      <!-- END timeline item -->
                      <!-- timeline item -->
                      <li>
                          <i class="fa fa-comments bg-yellow"></i>
                          <div class="timeline-item"><span class="time"><i class="fa fa-clock-o"></i> 10 Dec. 2019 15:20:35</span>
                              <h3 class="timeline-header"><a href="#">Prakash Nayak</a>, HOD Dept, Agriculture & F.E Department</h3>
                              <div class="timeline-body"> The proceeding is verified and found ok and send to OPSC for further verification. </div>
                          </div>
                      </li>
                      <!-- END timeline item -->
                      <!-- timeline item -->
                      <li>
                          <i class="fa fa-comments bg-yellow"></i>
                          <div class="timeline-item"><span class="time"><i class="fa fa-clock-o"></i> 10 Dec. 2019 10:27:00</span>
                              <h3 class="timeline-header"><a href="#">Golak Roy</a>, SO, OPSC</h3>
                              <div class="timeline-body"> Checked the proceeding and assigned to ASO for further verification </div>
                              <!-- <div class="timeline-footer">     <a class="btn btn-warning btn-flat btn-xs">View comment</a>   </div> -->
                          </div>
                      </li>
                      <!-- END timeline item -->
                      <!-- timeline time label -->
                      <li class="time-label"> <span class="bg-green">12 Dec. 2019</span>
                      </li>
                      <!-- /.timeline-label -->
                      <!-- timeline item -->
                      <li>
                          <i class="fa fa-comments bg-yellow"></i>
                          <div class="timeline-item"><span class="time"><i class="fa fa-clock-o"></i> 12 Dec. 2019 9:27:35</span>
                              <h3 class="timeline-header"><a href="#">Yudhistir Nayak</a>, Dy. Secretary, OPSC</h3>
                              <div class="timeline-body"> Checked the proceeding and assigned to ASO for further verification </div>
                              <!-- <div class="timeline-footer">     <a class="btn btn-warning btn-flat btn-xs">View comment</a>   </div> -->
                          </div>
                      </li>
                      <!-- END timeline item -->
                      <!-- timeline item -->
                      <li>
                          <i class="fa fa-comments bg-yellow"></i>
                          <div class="timeline-item"><span class="time"><i class="fa fa-clock-o"></i> 12 Dec. 2019 11:30:45</span>
                              <h3 class="timeline-header"><a href="#">Subodha Nayak</a>, Secretary, OPSC</h3>
                              <div class="timeline-body"> Checked the proceeding and assigned to ASO for further verification </div>
                              <!-- <div class="timeline-footer">     <a class="btn btn-warning btn-flat btn-xs">View comment</a>   </div> -->
                          </div>
                      </li>
                      <!-- END timeline item -->
                      <li> <i class="fa fa-clock-o bg-gray"></i></li>
                  </ul>
          </div>
        </div>
        <div class="modal-footer" align="center">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
  <!-- Modal End-->
<?php $__env->startPush('styles'); ?>
<!--Extra styles can written here -->
<?php $__env->stopPush(); ?>  
<?php $__env->startPush('scripts'); ?>

<script type="text/javascript">
  $(function () {
    $('#listAllUser').DataTable({
      "ordering": false,
      'searching' : false,
    }).draw();
  })
  
  /*$(function () {
  $('#listAllUser').DataTable({
    'processing' : true,
    'serverSide' : true,
    'searching' : false,
    'ordering' : false,
    "ajax" : {
      'url' : 'view-user-throughAjax',
      'data' : function(d) {
        d.param1 = $('#param1').val();
        d.param2 = $('#param2').val();
        d.param3 = $('#param3').val();

      }
    },
    'dataSrc' : "",
    'columns' : [ {
      'data' : 'TUM_User_Name'
    }, {
      'data' : 'TUT_UserTypeName'
    }, {
      'data' : 'TUM_User_IMEI'
    }, {
      'data' : 'TUM_User_Mobile'
    }, {
      'data' : 'TUM_User_Email'
    }, {
      'data' : 'TCM_Country_Name'
    }, {
      'data' : 'TSM_State_Name'
    }, {
      'data' : 'TDM_Dist_Name'
    }, {
      'data' : 'TUM_User_Pin'
    }, {
      'data' : 'TUM_User_Status'
    }, {
      'data' : 'action'
    }

    ]
  });
  
  });*/
  //Method For Searching Records In The List
  function searchData() {
    $('#listAllUser').DataTable().draw();
  }
 
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/disciplinary/manage-so-diciplinary.blade.php ENDPATH**/ ?>