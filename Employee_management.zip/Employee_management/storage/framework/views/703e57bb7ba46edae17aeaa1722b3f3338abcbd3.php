<?php $__env->startSection('title', 'OPSC Hierarchical'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       View OPSC Hierarchical Structure
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">User</a></li>
        <li class="active">Manage Hierarchy</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box">
           <!-- <div class="box-header">
              <h3 class="box-title">Data Table With Full Features</h3>
            </div>-->
            <!-- /.box-header -->
            <div class="box-body">
              
            <!-- <a data-toggle="collapse" data-target="#demo"
                class="showhideangelbg"><i class="fa fa-angle-double-down"></i>
            </a>-->
             
             <div id="treeview"></div>
              
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
      <!-- Modal Start-->
   
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('styles'); ?>
<!--Extra styles can written here -->
<script src="<?php echo e(asset('css/bootstrap-treeview.min.css')); ?>"></script>
<?php $__env->stopPush(); ?>  
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/bootstrap-treeview.min.js')); ?>"></script>
<script type="text/javascript">
  $(function () {
    //$('#listAllUser').DataTable().draw();
 
    var HeiarchicalData = [{"id":"1","name":"Commissioner","text":"Commissioner","parent_id":"0","nodes":[{"id":"2","name":"Secretary","text":"Secretary","parent_id":"1","nodes":[{"id":"3","name":"DeputySecretary","text":"DeputySecretary","parent_id":"2","nodes":[{"id":"4","name":"SectionOfficer","text":"SectionOfficer","parent_id":"3","nodes":[{"id":"5","name":"JuniorAssistant","text":"JuniorAssistant","parent_id":"4"},{"id":"6","name":"Asst.SectionOfficer","text":"Asst.SectionOfficer","parent_id":"4"}]}]}]}]}];

    $('#treeview').treeview({data: HeiarchicalData});
   
    /*$.ajax({
              type: "GET",
              url:"Hierarchical/getHierchicalLevelData",
              success: function(response) {
                $('#treeview').treeview({data: HeiarchicalData});
              },
              error: function(data) {
               
              }
          })*/

  })
  

  function deleteUser(id){
    swal.fire({
        title: "Are you sure want to Delete?",
        text: "Once Deleted,Can't revert back !",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#e7b63a',
        confirmButtonText: 'Delete',
        reverseButtons : true
        
      }).then((result) => {
        if(result.value){
         $.ajax({
              type: "GET",
              url:"master/delete-user?id="+ id,
              success: function(response) {
            console.log(response);
            //return false;
                  if (response.message == "success") {
                    swal({
                      title: "Record Deleted Successfully.",
                      type: "success"
                    }).then(function(){
                       location.reload();
                    })
                  
                    
                  } else {
                      swal({
                          title: 'Unsuccess',
                          text: response.code
                      })
                  }
              },
              error: function(data) {
               
              }
          })
        }
        
      });
  }
  /* VIEW IN MODEL USER DATA */
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\wethefamily\resources\views/hierarchical/view-opsc-hierchical.blade.php ENDPATH**/ ?>