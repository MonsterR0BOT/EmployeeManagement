 
<?php $__env->startSection('title', 'CHART'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Department Wise Promotional Cases Charts
        <small>Preview sample</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">MIS REPORTS </a></li>
        <li class="active">Promotional Cases Charts</li>
      </ol>
      <a href="#" id="downloadPdf" ><button type="button" style="color: blue;"> Download as PDF</button></a>
    </section>

    <!-- Main content -->
    <section class="content">
      <div id="reportPage">
      <div class="row">
         <!-- /.col (LEFT) -->
        
        <div class="col-md-12">

          <!-- BAR CHART -->
          <div class="box box-success">
            <div class="box-header with-border">
              <h3 class="box-title">Promotional Cases Charts</h3>
             <!--    <h3 class="box-title">Monthly Chart</h3> -->

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <div class="box-body">
              <div class="chart">
                <canvas id="canvas"></canvas>
              </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

        </div> 
       
      </div>
    </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('scripts'); ?>
  <script> 
  //  $(document).ready(function(){
        var color = Chart.helpers.color;
        var horizontalBarChartData = { 
        labels: [<?php echo $Department;?>],
        datasets: [{
          label: 'No. of Cases Disposed of',
          backgroundColor:'rgba(97,50,105,0.9)',
          borderColor:'rgba(97,50,105,0.9)',
          borderWidth: 1,
          data: [<?php echo $totalDepartment;?>]
        } ]

      };
  //  });
    

    window.onload = function() {
      var ctx = document.getElementById('canvas').getContext('2d');
      window.myHorizontalBar = new Chart(ctx, {
        type: 'horizontalBar',
        data: horizontalBarChartData,
        options: {
          elements: {
            rectangle: {
              borderWidth: 2,
            }
          },
           hover: {
            mode: 'nearest',
            "animationDuration": 0,
            intersect: true
          },

          "animation": {
              "duration": 1,
              "onComplete": function () {
                var chartInstance = this.chart,
                ctx = chartInstance.ctx;
                
                ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
                ctx.textAlign = 'left';
                ctx.textBaseline = 'top';

                this.data.datasets.forEach(function (dataset, i) {
                  var meta = chartInstance.controller.getDatasetMeta(i);
                  meta.data.forEach(function (bar, index) {
                    var data = dataset.data[index];                            
                    ctx.fillText(data, bar._model.x, bar._model.y - 5);
                  });
                });
              }
          },
          responsive: true,
          legend: {
            position: 'right',
          },
          title: {
            display: true,
            text: 'Department Wise Promotional Cases'
          },
          scales: {
              xAxes: [{
                  ticks: {
                      beginAtZero: true,
                      barThickness : 13
                  }
              }]

              
          }
        }
        
      });
    };

    $('#downloadPdf').click(function(event) {
    // get size of report page
    var reportPageHeight = $('#reportPage').innerHeight();
    var reportPageWidth = $('#reportPage').innerWidth();
    
    // create a new canvas object that we will populate with all other canvas objects
    var pdfCanvas = $('<canvas />').attr({
      id: "canvaspdf",
      width: reportPageWidth,
      height: reportPageHeight
    });
    
    // keep track canvas position
    var pdfctx = $(pdfCanvas)[0].getContext('2d');
    var pdfctxX = 0;
    var pdfctxY = 0;
    var buffer = 100;
    
    // for each chart.js chart
    $("canvas").each(function(index) {
      // get the chart height/width
      var canvasHeight = $(this).innerHeight();
      var canvasWidth = $(this).innerWidth();
      
      // draw the chart into the new canvas
      pdfctx.drawImage($(this)[0], pdfctxX, pdfctxY, canvasWidth, canvasHeight);
      pdfctxX += canvasWidth + buffer;
      
      // our report page is in a grid pattern so replicate that in the new canvas
      if (index % 2 === 1) {
        pdfctxX = 0;
        pdfctxY += canvasHeight + buffer;
      }
    });
    
    // create new pdf and add our new canvas as an image
    var pdf = new jsPDF('l', 'pt', [reportPageWidth, reportPageHeight]);
    pdf.addImage($(pdfCanvas)[0], 'PNG', 0, 0);
    
    // download the pdf
    pdf.save('promotional-Dept-Wise.pdf');
  });
  </script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/mis/manage-dept-mis-chart-promotional.blade.php ENDPATH**/ ?>