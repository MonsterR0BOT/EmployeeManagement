<?php $__env->startSection('title', 'CHART'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
         Disciplinary Drill Down Chart
        <small>Drill Down Chart sample</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">MIS Reports</a></li>
        <li class="active">Charts</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
    	
	<div id="reportPage">

      <div class="row">
      	 <!-- /.col (LEFT) -->
      	 <div class="col-md-8" id="searchDivision">
      	 <!--  <div id="demo" > -->
      	 <div class="search-field">
                   
            <div class="row">  
                <div class="col-md-2">
                    <div class="org-name">Year</div>
                </div>
                <div class="col-md-2">
                  <div class="input-group">
                        <select name="financialYear" id="financialYear" class="form-control">
	                         <?php $y= date('Y'); ?> 
	                         <?php for($i =1; $i <= 7; $i++): ?>
	                              <option value="<?php echo e($y); ?>"><?php echo e($y); ?></option>
	                            <?php ($y--); ?>  
	                         <?php endfor; ?> 
	                     </select>
                  </div>
                </div>

                <div class="col-md-1">
                    <div class="form-group">
                        <button class="btn btn-primary" onClick="searchData()">Search</button>
                    </div>
                </div>
            </div> 
          </div>
            <!-- </div> -->
        </div>
        <a href="#" id="downloadPdf" ><button type="button" style="color: blue;"> Download as PDF</button></a>
        
        <div class="col-md-12" id="parentDiv">

          <!-- BAR CHART -->
          <div class="box box-success">
            <div class="box-header with-border">
              <div class="box-tools pull-right">
              </div>
            </div>
            <div class="box-body">
              <div class="chart">
                <canvas id="chartarea" style="height:350px"></canvas>
              </div>
            </div>
            <!-- /.box-body -->
          </div>

        </div>

      </div>
  </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper  
  -->
<?php $__env->startPush('scripts'); ?>
<script> 
	  var config = {
      type: 'pie',
      data: {
        datasets: [{
          data: [<?php echo $newCountPie;?>,<?php echo $openCountPie;?>,<?php echo $approvedCountPie;?>,<?php echo $returnCountPie;?>,<?php echo $rejectedCountPie;?>,<?php echo $acceptedCountPie;?>],
          backgroundColor: [
          'rgba(60,141,188,1)',
          'rgba(0,192,239,1)',
          'rgba(243,156,18,1)',
          'rgba(221,75,57,1)',
          'rgba(0,166,90,1)',
          'rgba(100,168,10,1)'
          ],
          label: 'Pie Chart'
        }],
        labels: ['New','Open','Approved','Returned','Rejected', 'Accepted'],

      },
      options: {
        responsive: true,
      }
    };

		$(function () { 
			var ctx = document.getElementById('chartarea').getContext('2d');
			window.myPie = new Chart(ctx, config); 

			chartarea.onclick = function(evt) { 
			       var activePoints = myPie.getElementsAtEvent(evt);
			       if (activePoints[0]) {
			         var chartData = activePoints[0]['_chart'].config.data;
			         var idx = activePoints[0]['_index'];

			         var label = chartData.labels[idx];
			         var value= chartData.datasets[0].data[idx];
			         var color = chartData.datasets[0].backgroundColor[idx]; 
			        // alert('hello------'+label+" "+<?php echo $financialYearPie;?>);  
			         showDepartmentWiseDisciplineChart(label,<?php echo $financialYearPie;?>);
			       } 
			    }; 
		}); 

		

		function ReturnDisciplinaryShowDepartmentWiseChart(levelVal,financialYear){  
			 

			 if(financialYear!=''){ 
		       $.ajaxSetup({
		        headers: {
		          'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
		        }
		      }); 
	          $.ajax({
		        type : "POST",
		        url : '<?php echo e(url("DisciplinaryMIS/viewDisciplineDepartWiseMISYearlyAjax")); ?>', 
		        dataType : 'json', 
		        data : {"levelVal":levelVal,"financialYear":financialYear},
		        success : function(response) {//alert(response.html);
		            // console.log(response);
		          if (response.message == "success") {
		            console.log('response from controller---',response); 
		           
		            $('#parentDiv').html(response.html);
		             
		          }
		        },
		        error : function(data) {
		        }
	     	  }) 
		  	}

		
		}


	 

		function showDepartmentWiseDisciplineChart(label,financialYear){  
			$("#financialYear").prop('disabled', true);
			 var levelVal=0;
			 if(label == 'New'){
			 	var levelVal=1;
			 }else if(label == 'Open'){
			 	var levelVal=2;
			 }else if(label == 'Approved'){
			 	var levelVal=3;
			 }else if(label == 'Returned'){
			 	var levelVal=4;
			 }else if(label == 'Rejected'){
			 	var levelVal=5;
			 }else if(label == 'Accepted'){
			 	var levelVal=6;
			 }  

			 if(financialYear!=''){ 
		       $.ajaxSetup({
		        headers: {
		          'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
		        }
		      }); 
	          $.ajax({
		        type : "POST",
		        url : '<?php echo e(url("DisciplinaryMIS/viewDisciplineDepartWiseMISYearlyAjax")); ?>', 
		        dataType : 'json', 
		        data : {"levelVal":levelVal,"financialYear":financialYear},
		        success : function(response) {//alert(response.html);
		            // console.log(response);
		          if (response.message == "success") {
		            console.log('response from controller---',response); 
		           
		            $('#parentDiv').html(response.html);
		             
		          }
		        },
		        error : function(data) {
		        }
	     	  }) 
		  	}

		
		}

		function returnToParentDisciplinary(financialYear){
			$("#financialYear").prop('disabled', false);
		      $.ajaxSetup({
		        headers: {
		          'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
		        }
		      }); 
	          $.ajax({
		        type : "POST",
		        url : '<?php echo e(url("DisciplinaryMIS/viewDisciplinaryDrillDownAjax")); ?>', 
		        dataType : 'json', 
		        data : {"financialYear":financialYear},
		        success : function(response) {//alert(response.html);
		            // console.log(response);
		          if (response.message == "success") {
		            console.log('response from controller---',response); 
		           
		            $('#parentDiv').html(response.html);
		             
		          }
		        },
		        error : function(data) {
		        }
	     	  }) 
		  	
		}


			function showDisciplinaryPostWiseChart(id,financialYear,levelValue){ 
		 	  if(financialYear!=''){ 
		       $.ajaxSetup({
		        headers: {
		          'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
		        }
		      }); 
	          $.ajax({
		        type : "POST",
		        url : '<?php echo e(url("DisciplinaryMIS/viewDisciplinaryPostWiseMISYearlyAjax")); ?>', 
		        dataType : 'json', 
		        data : {"financialYear":financialYear,"deptId":id,"levelValue":levelValue},
		        success : function(response) {//alert(response.html);
		            // console.log(response);
		          if (response.message == "success") {
		            console.log('response from controller---',response); 
		            $('#parentDiv').html(response.html);
		          }
		        },
		        error : function(data) {
		        }
	     	  }) 
		  	} 
		}

		function searchData(){ 
	    var financialYear=$("#financialYear").val();  
	    if(financialYear!=''){ 
	       $.ajaxSetup({
	        headers: {
	          'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
	        }
	      }); 
          $.ajax({
	        type : "POST",
	        url : '<?php echo e(url("DisciplinaryMIS/viewDisciplinaryDrillDownAjax")); ?>',  
	        dataType : 'json', 
	        data : {"financialYear":financialYear},
	        success : function(response) {
	            // console.log(response);
	          if (response.message == "success") {
	            console.log('response from controller---',response); 
	           
	            $('#parentDiv').html(response.html);
	             
	          }
	        },
	        error : function(data) {
	        }
     	  }) 
	  	}
	} 


	$('#downloadPdf').click(function(event) {
	  // get size of report page
	  var reportPageHeight = $('#reportPage').innerHeight();
	  var reportPageWidth = $('#reportPage').innerWidth();
	  
	  // create a new canvas object that we will populate with all other canvas objects
	  var pdfCanvas = $('<canvas />').attr({
	    id: "canvaspdf",
	    width: reportPageWidth,
	    height: reportPageHeight
	  });
	  
	  // keep track canvas position
	  var pdfctx = $(pdfCanvas)[0].getContext('2d');
	  var pdfctxX = 0;
	  var pdfctxY = 0;
	  var buffer = 100;
	  
	  // for each chart.js chart
	  $("canvas").each(function(index) {
	    // get the chart height/width
	    var canvasHeight = $(this).innerHeight();
	    var canvasWidth = $(this).innerWidth();
	    
	    // draw the chart into the new canvas
	    pdfctx.drawImage($(this)[0], pdfctxX, pdfctxY, canvasWidth, canvasHeight);
	    pdfctxX += canvasWidth + buffer;
	    
	    // our report page is in a grid pattern so replicate that in the new canvas
	    if (index % 2 === 1) {
	      pdfctxX = 0;
	      pdfctxY += canvasHeight + buffer;
	    }
	  });
	  
	  // create new pdf and add our new canvas as an image
	  var pdf = new jsPDF('l', 'pt', [reportPageWidth, reportPageHeight]);
	  pdf.addImage($(pdfCanvas)[0], 'PNG', 0, 0);
	  
	  // download the pdf
	  pdf.save('disciplinary-Drilldown-Year-Wise.pdf');
	});

		/*function showCategoryWiseChart(id,financialYear,levelValue,deptId){ 
			//alert('hello------'+id+" "+financialYear+" "+levelValue+" "+deptId);
		 	  if(financialYear!=''){ 
		       $.ajaxSetup({
		        headers: {
		          'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
		        }
		      }); 
	          $.ajax({
		        type : "POST",
		        url : '<?php echo e(url("PromotionalMIS/viewPromotionalCategoryWiseMISYearlyAjax")); ?>', 
		        dataType : 'json', 
		        data : {"financialYear":financialYear,"deptId":deptId,"levelValue":levelValue,"postId":id},
		        success : function(response) {//alert(response.html);
		            // console.log(response);
		          if (response.message == "success") {
		            console.log('response from controller---',response); 
		            $('#parentDiv').html(response.html);
		          }
		        },
		        error : function(data) {
		        }
	     	  }) 
		  	} 
		} 
*/


		/*function ReturnShowDepartmentWise(deptId,financialYear,levelValue){
			//alert('hello------'+deptId+" "+financialYear+" "+levelValue);
			 if(financialYear!=''){ 
		       $.ajaxSetup({
		        headers: {
		          'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
		        }
		      }); 
	          $.ajax({
		        type : "POST",
		        url : '<?php echo e(url("PromotionalMIS/viewPromotionalPostWiseMISYearlyAjax")); ?>', 
		        dataType : 'json', 
		        data : {"financialYear":financialYear,"deptId":deptId,"levelValue":levelValue},
		        success : function(response) {//alert(response.html);
		            // console.log(response);
		          if (response.message == "success") {
		            console.log('response from controller---',response); 
		            $('#parentDiv').html(response.html);
		          }
		        },
		        error : function(data) {
		        }
	     	  }) 
		  	}
		}*/
		 

 

	
 

	/*	function onclickPieYealy(value,label,financialYear,levelVal){  
	    if(financialYear!=''){ 
	       $.ajaxSetup({
	        headers: {
	          'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
	        }
	      }); 
          $.ajax({
	        type : "POST",
	        url : '<?php echo e(url("PromotionalMIS/viewPromotionalDepartWiseMISYearlyAjax")); ?>', 
	        dataType : 'json', 
	        data : {"levelVal":levelVal,"financialYear":financialYear,"value":value},
	        success : function(response) {
	            // console.log(response);
	          if (response.message == "success") {
	            console.log('response from controller---',response); 
	           
	            $('.chartareaExp').html(response.html);
	             
	          }
	        },
	        error : function(data) {
	        }
     	  }) 
	  	}
	} */
	</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/mis/manage-mis-drill-chart-disciplinary.blade.php ENDPATH**/ ?>