  
  <?php $__env->startSection('title', 'Add Work Flow'); ?>
  <?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h1>Add Workflow</h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
          <li><a href="#">Master</a></li>
          <li class="active">Add Workflow</li>
        </ol>
      </section>
      <!-- Main content -->
      <section class="content">
        <!-- Default box -->
        <div class="box">
         <!-- <div class="box-header">
            <h3 class="box-title">Quick Example</h3>
          </div>-->
          <!-- /.box-header -->
          <!-- form start -->
          <form role="form" action="" onsubmit="return validateForm()" autocomplete="off">
            <?php echo csrf_field(); ?>
            <div class="box-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Wing Name</label>
                      <select class="form-control processNameCls" id="wingName" name="wingName">
                       <option value="">--Select--</option>
                          <?php $__currentLoopData = $wing_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($wing->TWM_Wing); ?>"><?php echo e($wing->TWM_Wing_Name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                </div>
            </div>
          </div>
            <?php echo csrf_field(); ?>
            <table class="table" id="myTable" width="100%" border="0" cellspacing="2" cellpadding="5">
              <thead>
                <tr>
                  <th style="width:15%;" align="center">User Role</th>
                  <th style="width:40%;"align="center">User Name</th>
                  <th style="width:15%;" align="center">Approval Action</th>
                  <th style="width:8%;" align="center">TAT</th>
                  <th style="width:12%;" align="center">Stage</th>
                  <th style="width:10%;" align="center">Action</th>
                </tr>
              </thead>
              <!-- for edit -->
              <tbody id="tbodyData">
                <tr class="tr_clone">
                  <td valign="top">
                    <select class="form-control userRoleNameCls" id="userRole_0" name="userRole" onchange="getRolewiseUser(this);">
                      <option value="">--Select--</option>
                        <?php $__currentLoopData = $parent_role_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($val->TURM_UserRole); ?>"><?php echo e($val->TURM_URole_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                  </td>
                  <td valign="top">
                    <select class="form-control userNameCls scroll-x" multiple="multiple" id="userNameId_0">

                    </select>
                  </td>
                  <td valign="top" >
                    <select class="form-control userApprovalActivity" multiple="multiple" id="approvalId_0">
                      <?php $__currentLoopData = $approval_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aprvl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($aprvl->TAM_Approval); ?>"><?php echo e($aprvl->TAM_ActionName); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </td>
                  <td valign="top" >
                    <input type="text" class="form-control tatClass" id="pageLevel_0">
                  </td>
                  <td valign="top" >
                    <label><strong>  Stage-<input type="text" class="numberInc" readonly  style="border: none;width:40px;" id="number_0" value="1"></strong>  </label>
                  </td>

                  <td valign="top">
                    <button type="button" class="btn btn-primary button-add tr_clone_add" name="add" onclick="addMore();">
                      <i class="fa fa-plus"></i>
                    </button>&nbsp;
                    <button style="display: none" type="button" class="btn btn-warning button-remove rmv" name="Remove">
                      <i class="fa fa-minus"></i>
                    </button>
                  </td>
                </tr>
                <!-- for add  -->
              </tbody>
            </table>
            <div class="box-footer">
            <button type="button" class="btn btn-primary" id="submtBtn">Submit</button>
            <a href="<?php echo e(url('dashboard')); ?>"><button type="button" class="btn btn-warning">Cancel</button></a>
          </div>
        </form>
      </div>
        <!-- /.box -->
    </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
  <?php $__env->startPush('scripts'); ?> 
  <script type="text/javascript">
    /* Function for adding more Table row */
    $(document).ready(function(){
      var lengthOfTableRow = $("#tbodyData").children('tr').length;
      var lengthOfTableCol = $("#tbodyData").children('colspan').length;
      
      $('#myTable').on('click', '.rmv', function () {
        $(this).closest('tr').remove();
        $("#myTable tbody tr:last").find('td:last').html('');
        var add='<button type="button" class="btn btn-primary tr_clone_add" name="add" onclick="addMore();"><i class="fa fa-plus"></i></button>&nbsp;'
        var remove = '<button type="button" class="btn btn-warning button-remove rmv" name="Remove"><i class="fa fa-minus"></i></button>';
        if($("#tbodyData").children('tr').length > 1){
          $("#myTable tbody tr:last").find('td:last').append(add);
          $("#myTable tbody tr:last").find('td:last').append(remove);
        }else{
          $("#myTable tbody tr:last").find('td:last').append(add);
        }
        //displayTable();
         var stageVal=1;  
       var v=1;
         $(".tr_clone").each(function(){
         // alert('hello');
           $(this).find('.numberInc').val(v);

           v++; 
         })
      });
    });
    
    function addMore(){
      //console.log('here==');
      var lengthOfTableRow = $("#tbodyData").children('tr').length;
      var lengthOfTableCol = $("#tbodyData").children('colspan').length;
      var cloneHtml = $("#myTable tbody tr:first").clone();
      $("#myTable tbody tr:last").find('td:last').html('');
      $("#myTable tbody").append($("#myTable tbody tr:first").clone());
      $("#myTable tbody tr td:last").html("");
      var addMore='<button type="button" class="btn btn-primary tr_clone_add" name="add" onclick="addMore();"><i class="fa fa-plus"></i></button>&nbsp;'
      var removeMore = '<button type="button" class="btn btn-warning button-remove rmv" name="Remove"><i class="fa fa-minus"></i></button>';

      $("#myTable tbody tr:last").find('td:last').append(addMore);
      $("#myTable tbody tr:last").find('td:last').append(removeMore);
      $("#myTable tbody tr:last").find('.userRoleNameCls').val("");
      $("#myTable tbody tr:last").find('.userApprovalActivity').find('option').attr('selected',false);
      $("#myTable tbody tr:last").find('.tatClass').val("");
      $("#myTable tbody tr:last").find('.numberInc').val("");
      $("#myTable tbody tr:last").find('.userNameCls').html("");

      var editTr = 0;

      if(lengthOfTableRow>editTr){
        $("#myTable tbody tr").eq(lengthOfTableRow-1).find('td:last').append(removeMore);
      }

     /* BLANK FIELD START */
      $("#myTable tbody tr:last").find(".userRoleNameCls").val("");
      $("#myTable tbody tr:last").find(".checkClass").hide();
      $("#myTable tbody tr:last").find(".checkClass1").hide();
      
      if($("#myTable tbody tr:last").find(".userRoleNameCls").val("")){
        $("#myTable tbody tr:last").find(".checkClass").empty();
      } 
       
      var stageVal=1;  
       var v=1;
         $(".tr_clone").each(function(){
         // alert('hello');
           $(this).find('.numberInc').val(v);

           v++; 
         })

      $("#myTable > tbody > tr").each(function(i){
      
        //alert(i);
        var selectInput = $(this).find('select');
        var textInput = $(this).find('input') ;
        var divInput = $(this).find('div') ;
     //   var checkBox = $(this).find('input:checkbox:first').attr('checked', 'checked');
        var buttonInput = $(this).find('button') ;
        
        selectInput.eq(0).attr('id',"userRole_"+i);
        selectInput.eq(1).attr('id',"userNameId_"+i); 
        selectInput.eq(2).attr('id',"approvalId_"+i);
        textInput.eq(0).attr('id',"pageLevel_"+i);   
        textInput.eq(textInput.length-1).attr('id',"TAT_"+i);
        textInput.eq(textInput.length-1).attr('id',"number_"+i);
       // $("#number_"+i).val(i+stageVal);

      })
}
function validateForm(){
     var lengthOfTableRow = $("#tbodyData").children('tr').length;
     //alert(lengthOfTableRow);
      if (!blankValidation("wingName","SelectBox", "Wing Name can not be left blank"))
        return false;

      for(var i=0; i<(lengthOfTableRow); i++){

         if (!blankValidation("userRole_"+i,"SelectBox", "Please select role"))
             return false;
         if (!blankValidation("userNameId_"+i,"SelectBox", "Please select user name"))
             return false;
         if (!blankValidation("approvalId_"+i,"SelectBox", "Please select Approval Action"))
             return false;
         if (!blankValidation("pageLevel_"+i,"TextField", "Please select TAT"))
             return false;
      }
     return true;
 }
$( document ).ready(function() {
  $("#submtBtn").click(function(){
      if(validateForm()){
          var dataset = [];
          $("#tbodyData > tr").each(function(i){
              data = {};
              data['wingName'] = $("#wingName").val();
              data['userRole'] = $("#userRole_"+i).val();
              data['userNameId'] = $("#userNameId_"+i).val();
              data['approvalId'] = $("#approvalId_"+i).val();
              data['pageLevel'] = $("#pageLevel_"+i).val();
              data['number'] = $("#number_"+i).val();
             
              dataset.push(data);
        
            }); 
          //console.log('dataSet value',dataset);
          submitSetAuthority(dataset);
      }else{
        return false;
      }
    
    });
});
function submitSetAuthority (data){
    $.ajaxSetup({
      headers: {
      'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
      }
    });
    swal.fire({
      title: "Do you want to submit?",
      text: "",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#e7b63a',
      confirmButtonText: 'Submit',
      reverseButtons : true 
    }).then((result) => {
    if(result.value){
        $.ajax({
          type : "POST",
          url : '<?php echo e(url("master/AddSetAuthority")); ?>',
          dataType : "json",
          contentType : "application/json",
          data : JSON.stringify(data),
          success : function(response){
            //console.log("response ",response);
            if(response.message=="success"){
           
                swal({
                  title:"Data saved successfully.",
                  type: "success",
                }).then(function(){
                  location.reload();
                })
            }else{
               swal({
                  title:"Sorry ! Some required fileds are missing",
                  //text: response.message,
                  type:"warning"
                })
            }
          },
          error:function(xhr, status, error){
            var err = eval("(" + xhr.responseText + ")");
            //console.log(err)
            swal(err.message.slice(err.message.indexOf('>:'),err.message.indexOf('(SQL:')).replace('>:',''));  
          }
        }) //ajax ends
    }

});

}
$("select[name='wingName']").change(function () {
   var wingID = $(this).val();
   $.ajaxSetup({
      headers: {
      'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
      }
    });
    $.ajax({
      url:'<?php echo e(url("master/getWorkFlow")); ?>',
      type: "POST",
      data: {"id":wingID},
      success: function (response){
          $("#myTable tbody  tr:not(:last)").remove();
          //$("#userNameId_"+counter).empty();
          if (response.message == "success") {
             $("#myTable tbody").html(response.html);
          } else {
             
          }
      },
      error:function(xhr, status, error){
        var err = eval("(" + xhr.responseText + ")");
        console.log(err)
        swal(err.message.slice(err.message.indexOf('>:'),err.message.indexOf('(SQL:')).replace('>:',''));  
      }
    })
});

function getRolewiseUser(sel){
  $.ajaxSetup({
      headers: {
      'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
      }
    });
 // alert($(sel).attr('id'));
    var currentId=$(sel).attr('id');
    var l = currentId.split("_");
    var counter = l[1];
    //alert(counter);
    var roleID = $(sel).val();
     //var id = $(sel).attr('id');
   // alert(roleID);
    $.ajax({
      url:'<?php echo e(url("master/getUserName")); ?>',
      type: "POST",
      data: {"id":roleID},
      success: function (response){
       console.log(response);
          //$("#tbodyData").html(response.html);
          $("#userNameId_"+counter).empty();
          //$("#userNameId_"+counter).prepend(response.html);
          if (response.message == "success") {
          //var option = $("<option></option>");
          //$(option).val(null);
          $("#userNameId_"+counter).append(option);
          for (var i = 0; i < response.userDetails.length; i++) {
              var option = $("<option></option>");
              $(option).val(response.userDetails[i].TUM_User);
              $(option).html(response.userDetails[i].TUM_User_Name);
              $("#userNameId_"+counter).append(option);
            }
          } else {
             
          }
      },
      error:function(xhr, status, error){
          var err = eval("(" + xhr.responseText + ")");
          console.log(err)
          swal(err.message.slice(err.message.indexOf('>:'),err.message.indexOf('(SQL:')).replace('>:',''));  
      }
    
    })
}
</script>  
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/master/add-setauthority-master.blade.php ENDPATH**/ ?>