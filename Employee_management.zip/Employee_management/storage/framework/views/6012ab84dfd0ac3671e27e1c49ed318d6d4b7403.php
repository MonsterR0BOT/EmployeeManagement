<?php $__env->startSection('title', 'MODULE'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Add/Edit Module</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Add/Edit Module</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      
      <!-- Default box -->
      <div class="box">
       <!-- <div class="box-header">
          <h3 class="box-title">Quick Example</h3>
        </div>-->
        <!-- /.box-header -->
        <!-- form start -->
        <form role="form" method="post" action="<?php echo e(url('module/addModule')); ?>"  onsubmit="return validateForm()" autocomplete="off">
          <?php echo csrf_field(); ?>
          <div class="box-body">
              <?php if(Session::has('errors')): ?>
                  <div class="col-md-12 alert alert-warning">
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php echo e($error); ?><br/>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
              <?php endif; ?>
            <div class="row">
                <div class="col-md-6">
                  <?php
                    if(!empty($data)){
                       $dataId = $data[0]->TMM_Module;
                        $TMM_Modl_Name  = $data[0]->TMM_Modl_Name ;
                        $TMM_Modl_Name_Odia = $data[0]->TMM_Modl_Name_Odia;
                        $TMM_Modl_Status = $data[0]->TMM_Modl_Status;
                    }else{
                        $dataId = '';
                        $TMM_Modl_Name  = '' ;
                        $TMM_Modl_Name_Odia = '';
                        $TMM_Modl_Status = 1;
                    }
                    ?>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Module Name</label>
                      <input type="text" class="form-control" name="moduleName" id="moduleName" value="<?php echo e($TMM_Modl_Name); ?>">
                    </div>
                   
                    <div class="form-group">
                      <label for="exampleInputFile">Status</label>
                      <select class="form-control" name="moduleActive" id="moduleActive">
                        <option value="">--Select--</option>
                        <option value="1" <?php if($TMM_Modl_Status ==1): ?> selected="selected" <?php endif; ?>>Active</option>
                        <option value="0" <?php if($TMM_Modl_Status ==0): ?> selected="selected" <?php endif; ?>>Inactive</option>
                      </select>
                    </div>
                </div>
                
            </div>
          </div>
          <!-- /.box-body -->
          <div class="box-footer">
            <input type="hidden" name="hidDataId" value="<?php echo e($dataId); ?>"/>
            <button type="submit" class="btn btn-primary">Submit</button>
          <a href="<?php echo e(url('module/viewModule')); ?>">  <button type="button" class="btn btn-warning">Cancel</button>
          </div>
        </form>
      </div>
      <!-- /.box -->
      
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('scripts'); ?> 
<script type="text/javascript">
   function validateForm(){
    //alert("alert");return false;
    if (!blankValidation("moduleName","TextField", "Module Name can not be left blank"))
      return false;
    if (!blankValidation("moduleActive","TextField", "Status  can not be left blank"))
      return false;
   }  


</script>

<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\wethefamily\resources\views/master/add-module-master.blade.php ENDPATH**/ ?>