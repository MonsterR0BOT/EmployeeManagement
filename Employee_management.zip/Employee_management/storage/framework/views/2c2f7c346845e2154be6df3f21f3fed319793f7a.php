<?php $__env->startSection('title', 'USER'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Manage User
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">User</a></li>
        <li class="active">Manage User</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box">
           <!-- <div class="box-header">
              <h3 class="box-title">Data Table With Full Features</h3>
            </div>-->
            <!-- /.box-header -->
            <div class="box-body">
            	<div id="demo" >
                <div class="search-field">
                	<div class="row">
            			<div class="col-md-12">
                            <div class="form-group pull-right">
                                <a href="<?php echo e(url('user/showAddUser')); ?>"><button class="btn btn-primary">Add User</button></a>
                            </div>
                        </div>
                	</div>
                    <div class="row">
    
                        <div class="col-md-2">
                            <div class="org-name">User Name</div>
                        </div>
                        <div class="col-md-2">
                            <input class="form-control" type="text" id="param1">
                        </div>
                        
                        <div class="col-md-1">
                            <div class="org-name">Mobile</div>
                        </div>
                        <div class="col-md-2">
                            <input class="form-control" type="text" id="param2">
                        </div>
                        
                        <div class="col-md-1">
                            <div class="org-name">Email</div>
                        </div>
                        <div class="col-md-2">
                            <input class="form-control" type="text" id="param3">
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <button class="btn btn-primary" onClick="searchData()">Search</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
           <!-- <a data-toggle="collapse" data-target="#demo"
                class="showhideangelbg"><i class="fa fa-angle-double-down"></i>
            </a>-->
              <table id="listAllUser" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>User Name</th>
                  <th>Mobile No</th>
                  <th>Email</th>
                 <!--  <th>Designation</th>
                  <th>Department</th> -->
                  <th>Role</th>
                  <th>Status</th>
                  <th>Block Status</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
    	<!-- Modal Start-->
		<div id="myModal" class="modal fade" role="dialog">
			<div class="modal-dialog">
				<!-- Modal content-->
				<div class="modal-content" style="width: 750px;">
					<div class="modal-header">
						<h4 class="modal-title">View Details of User Management</h4>
						<button type="button" class="close" data-dismiss="modal">&times;</button>
					</div>
					<div class="modal-body">
						<table id="table1"
							class="table table-striped table-bordered" width="100%"
							border="0">
							<thead>
								<tr>
									<th>User Name</th>
									<th>Mobile No</th>
									<th>Email</th>
									<!-- <th>User Role</th> -->
									<th>Country</th>
									<th>State</th>
									<th>District</th>
									<th>PIN</th>
									<th>Status</th>
								</tr>
							</thead>
							<tbody>
								
							</tbody>
						</table>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
		</div>
		<!-- Modal End-->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('styles'); ?>
<!--Extra styles can written here -->
<?php $__env->stopPush(); ?>  
<?php $__env->startPush('scripts'); ?>

<script>
  $(function () {
	$('#listAllUser').DataTable({
		'processing' : true,
		'serverSide' : true,
		'searching' : false,
		'ordering' : false,
		"ajax" : {
			'url' : "<?php echo e(url('user/viewUserthroughAjax')); ?>",
			'data' : function(d) {
				d.param1 = $('#param1').val();
				d.param2 = $('#param2').val();
				d.param3 = $('#param3').val();

			}
		},
		'dataSrc' : "",
		'columns' : [ {
			'data' : 'TUM_User_Name'
		}, {
			'data' : 'TUM_User_Mobile'
		}, {
			'data' : 'TUM_User_Email'
		}, /*{
			'data' : 'TDM_Desig_Name'
		}, {
			'data' : 'TDM_Dept_Name'
		},*/{
			'data' : 'userrole'
		}, {
			'data' : 'TUM_User_Status'
		},{
			'data' : 'TUM_User_LoginAttempt'
		}, {
			'data' : 'action'
		}

		]
	});
	
  });
  //Method For Searching Records In The List
	function searchData() {
		$('#listAllUser').DataTable().draw();
	}
	//Deleting user
	function deleteUser(id){
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
			}
		});
		swal.fire({
			  title: "Do you want to delete the user?",
			  text: "Once deleted, can't revert back !",
			  type: "warning",
			  showCancelButton: true,
			  confirmButtonColor: '#d33',
			  cancelButtonColor: '#e7b63a',
			  confirmButtonText: 'Delete',
			  reverseButtons : true,
			}).then((result) => {
				if(result.value){
				 $.ajax({
					    type: "POST",
					    url:"<?php echo e(url('user/deleteUserthroughAjax')); ?>",
					    data:{'id':id},
					    success: function(response) {
						console.log(response);
						//return false;
					        if (response.message == "success") {
					        	swal({
					        		title: "Record deleted successfully.",
					        		type: "success"
					        	}).then(function(){
					        		 location.reload();
					        	})
					        
					        	
					        } else {
					            swal({
					                title: 'Unsuccess',
					                text: response.code
					            })
					        }
					    },
					    error: function(data) {
				       
					    }
					})
				}
			  
			});
	}
	//unblock user
	function unblockUser(id){
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
			}
		});
		swal.fire({
			  title: "Do you want to unblock the user?",
			  text: "Once unblock, can't revert back !",
			  type: "warning",
			  showCancelButton: true,
			  confirmButtonColor: '#d33',
			  cancelButtonColor: '#e7b63a',
			  confirmButtonText: 'Unblock',
			  reverseButtons : true,
			}).then((result) => {
				if(result.value){
				 $.ajax({
					    type: "POST",
					    url:"<?php echo e(url('user/unblockUserthroughAjax')); ?>",
					    data:{'id':id},
					    success: function(response) {
						console.log(response);
						//return false;
					        if (response.message == "success") {
					        	swal({
					        		title: "User unblocked successfully.",
					        		type: "success"
					        	}).then(function(){
					        		 location.reload();
					        	})
					        
					        	
					        } else {
					            swal({
					                title: 'Unsuccess',
					                text: response.code
					            })
					        }
					    },
					    error: function(data) {
				       
					    }
					})
				}
			  
			});
	}
	/* VIEW IN MODEL USER DATA */
	function viewInModel(index) {
	 	$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
			}
		});
	//var id = window.atob(index);
		$('#table1').empty();
		$.ajax({
			type : "POST",
			url : "<?php echo e(url('user/ViewUserModal')); ?>",
			dataType : 'json',
			//contentType : 'application/json',
			data : {"userId":index},
			success : function(response) {
				if (response.message == "success") {
					console.log(response.userData.userStatus);
					var status = "";
					if (response.userData.TUM_User_Status) {
						status = "Active";
					} else {
						status = "InActive";
					}
					table = '<tr><td>User Name :</td>' + '<td align="left">'
							+ response.userData.TUM_User_Name + '</td>'
							+ '</tr><tr><td>User Role :</td>' + '<td align="left">'
							+ response.userData.userRoleName + '</td>'
							+ '</tr><tr><td>IMEI Number</td><td align="left">'
							+ response.userData.TUM_User_IMEI
							+ '</td></tr><tr><td>Mobile Number</td><td align="left">'
							+ response.userData.TUM_User_Mobile
							+ '</td></tr><tr><td>Email</td><td align="left">'
							+ response.userData.TUM_User_Email
							+ '</td></tr><tr><td>Country</td><td align="left">'
							+ response.userData.TCM_Country_Name
							+ '</td></tr><tr><td>State</td><td align="left">'
							+ response.userData.TSM_State_Name
							+ '</td></tr><tr><td>District</td><td align="left">'
							+ response.userData.TDM_Dist_Name
							+ '</td></tr><tr><td>PIN</td><td align="left">'
							+ response.userData.TUM_User_Pin
							+ '</td></tr><tr><td>Status</td><td align="left">'
							+ status
							+ '</td></tr>';
					$('#myModal').modal('show');
					$('#table1').append(table);
				}
			},
			error : function(data) {
				console.log(data);
			}
		})

	} 
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\wethefamily\resources\views/user/manage-user-master.blade.php ENDPATH**/ ?>