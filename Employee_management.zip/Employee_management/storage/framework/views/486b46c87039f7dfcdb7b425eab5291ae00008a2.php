<?php $__env->startSection('title', 'ACTIVITY'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Add/Edit Activity</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Add/Edit Activity</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      
      <!-- Default box -->
      <div class="box">
       <!-- <div class="box-header">
          <h3 class="box-title">Quick Example</h3>
        </div>-->
        <!-- /.box-header -->
        <!-- form start -->
        <form role="form" method="post" action="<?php echo e(url('activity/addActivity')); ?>"  onsubmit="return validateForm()" autocomplete="off">
          <?php echo csrf_field(); ?>
          <div class="box-body">
            <?php if(Session::has('errors')): ?>
                  <div class="col-md-12 alert alert-warning">
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php echo e($error); ?><br/>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
              <?php endif; ?>
            <div class="row">
                <div class="col-md-6">
                  <?php
                    if(!empty($data)){
                        $dataId = $data[0]->TAM_Activity;
                        $TAM_Module = $data[0]->TAM_Module;
                        $TAM_Function = $data[0]->TAM_Function;
                        $TAM_Actvty_Name  = $data[0]->TAM_Actvty_Name ;
                        $TAM_Actvty_Name_Odia = $data[0]->TAM_Actvty_Name_Odia;
                        $TAM_Actvty_Status = $data[0]->TAM_Actvty_Status;
                    }else{
                        $dataId = '';
                        $TAM_Module = '';
                        $TAM_Function = '';
                        $TAM_Actvty_Name  = '' ;
                        $TAM_Actvty_Name_Odia = '';
                        $TAM_Actvty_Status = 1;
                    }
                    ?>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Module Name</label>
                      <select class="form-control" name="activityModule" id="activityModule" onchange="showFunction()">
                        <option value="">--Select--</option>
                        <?php $__currentLoopData = $module_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($val->TMM_Module); ?>" <?php if($TAM_Module == $val->TMM_Module): ?> selected="selected" <?php endif; ?> ><?php echo e($val->TMM_Modl_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Function Name</label>
                      <select class="form-control" name="activityFunction" id="activityFunction">
                        <option value="">--Select--</option>
                        <?php $__currentLoopData = $function_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($val->TFM_Function); ?>" <?php if($TAM_Function == $val->TFM_Function): ?> selected="selected" <?php endif; ?> ><?php echo e($val->TFM_Functn_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Activity Name</label>
                      <input type="text" class="form-control" name="activityName" id="activityName" value="<?php echo e($TAM_Actvty_Name); ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputFile">Status</label>
                      <select class="form-control" name="activityStatus" id="activityStatus">
                        <option value="">--Select--</option>
                        <option value="1" <?php if($TAM_Actvty_Status ==1): ?> selected="selected" <?php endif; ?>>Active</option>
                        <option value="0" <?php if($TAM_Actvty_Status ==0): ?> selected="selected" <?php endif; ?>>Inactive</option>
                      </select>
                    </div>
                </div>
                
            </div>
          </div>
          <!-- /.box-body -->
          <div class="box-footer">
            <input type="hidden" name="hidDataId" value="<?php echo e($dataId); ?>"/>
            <button type="submit" class="btn btn-primary">Submit</button>
           <a href="<?php echo e(url('activity/viewActivity')); ?>"> <button type="button" class="btn btn-warning" >Cancel</button></a>
          </div>
        </form>
      </div>
      <!-- /.box -->
      
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('scripts'); ?> 
<script type="text/javascript">
   function validateForm(){
    //alert("alert");return false;
    if (!blankValidation("activityModule","SelectBox", "Module Name can not be left blank"))
      return false;
    if (!blankValidation("activityFunction","SelectBox", "Function Name can not be left blank"))
      return false;
    if (!blankValidation("activityName","TextField", "Activity Name can not be left blank"))
      return false;
   
    if (!blankValidation("activityStatus","TextField", "Status  can not be left blank"))
      return false;
   }  
function showFunction() {
  $.ajaxSetup({
    headers: {
      'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
    }
  });
  if($("#activityModule").val()!=''){
    $.ajax({
      type : "POST",
      url : "<?php echo e(url('activity/showModuleFunctionList')); ?>",
      dataType : 'json',
      //contentType : 'application/json',
      data : {"moduleId":$("#activityModule").val()},
      success : function(response) {
        if (response.message == "success") {
          console.log(response);
          $("#activityFunction").empty();
          var option = $("<option></option>");
          $(option).val(null);
          $(option).html("--Select--");
          $("#activityFunction").append(option);
          for (var i = 0; i < response.functionList.length; i++) {
            var option = $("<option></option>");
            $(option).val(response.functionList[i].TFM_Function);
            $(option).html(response.functionList[i].TFM_Functn_Name);
            $("#activityFunction").append(option);
          }
  
        }
      },
      error : function(data) {
        console.log(data);
      }
    })
  }else{
    $("#activityFunction").empty();
    var option = $("<option></option>");
    $(option).val(null);
    $(option).html("--Select--");
    $("#activityFunction").append(option);
  }
}

</script>

<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\wethefamily\resources\views/master/add-activity-master.blade.php ENDPATH**/ ?>