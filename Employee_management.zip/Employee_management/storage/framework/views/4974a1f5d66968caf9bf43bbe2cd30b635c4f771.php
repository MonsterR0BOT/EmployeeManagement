<section class="skill-section">
        <div class="auto-container">
            <div class="row">
                <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
                    <div class="inner-column">
                        <div class="image-column wow fadeInLeft animated" style="visibility: visible; animation-name: fadeInUp;">
                        <figure class="image-box"><img src="<?php echo e(asset('images/bg11.jpg')); ?>" alt=""></figure>
                        </div>
                    </div>
                </div>
                <!--Skills Column-->
                <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                    <div class="skills-column">
                        <div class="sec-title text-left">
                            <h2>Our Expertise</h2>
                        </div>
                        <div class="inner-box">
                            <!--Progress Levels-->
                            <div class="progress-levels">
                                <!--Progress Box-->
                                <div class="progress-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="0ms">
                                    <div class="box-title">PVC Shower Tube</div>
                                    <div class="inner">
                                        <div class="bar">
                                            <div class="bar-innner"><div class="bar-fill" data-percent="85"><div class="percent"></div></div></div>
                                        </div>
                                    </div>
                                </div>
                                    
                                <!--Progress Box-->
                                <div class="progress-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="0ms">
                                    <div class="box-title">Waste Coupling-HT/FT</div>
                                    <div class="inner">
                                        <div class="bar">
                                            <div class="bar-innner"><div class="bar-fill" data-percent="75"><div class="percent"></div></div></div>
                                        </div>
                                    </div>
                                </div>
                                    
                                <!--Progress Box-->
                                <div class="progress-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="0ms">
                                    <div class="box-title">Sink Waste ABS</div>
                                    <div class="inner">
                                        <div class="bar">
                                            <div class="bar-innner"><div class="bar-fill" data-percent="95"><div class="percent"></div></div></div>
                                        </div>
                                    </div>
                                </div> 

                                <!--Progress Box-->
                                <div class="progress-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="0ms">
                                    <div class="box-title">Soap Dish-Brass</div>
                                    <div class="inner">
                                        <div class="bar">
                                            <div class="bar-innner"><div class="bar-fill" data-percent="82"><div class="percent"></div></div></div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section><?php /**PATH D:\xampp\htdocs\aquatic\resources\views/frontend-layout/skill.blade.php ENDPATH**/ ?>