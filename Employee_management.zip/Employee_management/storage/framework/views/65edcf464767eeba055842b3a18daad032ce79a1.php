<?php $__env->startSection('title', 'DEPARTMENT'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Add Department</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Add Department</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      
      <!-- Default box -->
      <div class="box">
       <!-- <div class="box-header">
          <h3 class="box-title">Quick Example</h3>
        </div>-->
        <!-- /.box-header -->
        <!-- form start -->
        <form role="form" method="post" action="<?php echo e(url('department/addDepartment')); ?>"  onsubmit="return validateForm()" autocomplete="off" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="box-body">
            <?php if(Session::has('errors')): ?>
                  <div class="col-md-12 alert alert-warning">
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php echo e($error); ?><br/>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
              <?php endif; ?>
            <div class="row">
                <div class="col-md-6">
                  <?php
                        if(!empty($data)){
                            $dataId = $data[0]->TDM_Dept;
                            $TDM_Dept_Name  = $data[0]->TDM_Dept_Name ;
                            $TDM_Dept_Name_Odia  = $data[0]->TDM_Dept_Name_Odia ;
                            $TDM_Dept_Description = $data[0]->TDM_Dept_Description;
                            $TDM_Dept_Description_Odia = $data[0]->TDM_Dept_Description_Odia;
                            $TDM_Dept_Country = $data[0]->TDM_Dept_Country;
                            $TDM_Dept_State = $data[0]->TDM_Dept_State;
                            $TDM_Dept_Dist = $data[0]->TDM_Dept_Dist;
                            $TDM_Dept_Zipcode = $data[0]->TDM_Dept_Zipcode;
                            $TDM_Dept_Address = $data[0]->TDM_Dept_Address;
                            $TDM_Dept_Parent = $data[0]->TDM_Dept_Parent;
                            $TDM_Dept_Active = $data[0]->TDM_Dept_Active;
                        }else{
                            $dataId = '';
                            $TDM_Dept_Name  = '' ;
                            $TDM_Dept_Name_Odia = '';
                            $TDM_Dept_Description = '';
                            $TDM_Dept_Description_Odia = '';
                            $TDM_Dept_Country = '';
                            $TDM_Dept_State = '';
                            $TDM_Dept_Dist = '';
                            $TDM_Dept_Zipcode = '';
                            $TDM_Dept_Address = '';
                            $TDM_Dept_Parent = '';
                            $TDM_Dept_Active = 1;

                        }
                    ?>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Department Name</label>
                      <span class="text-danger">*</span> 
                      <input type="text" class="form-control" name="departmentName" id="departmentName" value="<?php echo e($TDM_Dept_Name); ?>">
                     <!--  <span class="text-danger"><?php echo e($errors->first('departmentName')); ?></span> -->
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Department Name Odia</label>
                      <span class="text-danger">*</span> 
                      <input type="text" class="form-control" name="departmentNameOdia" id="departmentNameOdia" value="<?php echo e($TDM_Dept_Name_Odia); ?>">
                      <!-- <span class="text-danger"><?php echo e($errors->first('departmentNameOdia')); ?></span> -->
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Description</label>
                      <span class="text-danger">*</span> 
                      <textarea class="form-control" name="departmentDescrptn" id="departmentDescrptn"><?php echo e($TDM_Dept_Description); ?></textarea>
                     <!--  <span class="text-danger"><?php echo e($errors->first('departmentDescrptn')); ?></span> -->
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Description Odia</label>
                      <span class="text-danger">*</span> 
                      <textarea class="form-control" name="departmentDescrptnOdia" id="departmentDescrptnOdia"><?php echo e($TDM_Dept_Description_Odia); ?></textarea>
                     <!--  <span class="text-danger"><?php echo e($errors->first('departmentDescrptnOdia')); ?></span> -->
                    </div>
                    <div class="form-group">
                      <label for="exampleInputFile">Status</label>
                      <span class="text-danger">*</span> 
                      <select class="form-control" name="departmentActive" id="departmentActive">
                        <option value="">--Select--</option>
                        <option value="1" <?php if($TDM_Dept_Active ==1): ?> selected="selected" <?php endif; ?>>Active</option>
                        <option value="0" <?php if($TDM_Dept_Active ==0): ?> selected="selected" <?php endif; ?>>Inactive</option>
                      </select>
                     <!--  <span class="text-danger"><?php echo e($errors->first('departmentActive')); ?></span> -->
                    </div>
                    
                </div>
                <div class="col-md-6">
                   <div class="form-group">
                      <label for="exampleInputPassword1">Parent Department</label>
                      <select class="form-control" name="parentDepartment" id="parentDepartment">
                        <option value="">--Select--</option>
                        <?php $__currentLoopData = $parent_dept_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($val->TDM_Dept); ?>" <?php if($TDM_Dept_Parent == $val->TDM_Dept): ?> selected="selected" <?php endif; ?> ><?php echo e($val->TDM_Dept_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                       <!-- <span class="text-danger"><?php echo e($errors->first('parentDepartment')); ?></span> -->
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Country</label>
                      <span class="text-danger">*</span> 
                      <select class="form-control" name="userCountry" id="userCountry" onchange="countryChange()">
                        <option value="">--Select--</option>
                        <?php $__currentLoopData = $country_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($val->TCM_Country); ?>" <?php if($TDM_Dept_Country == $val->TCM_Country): ?> selected="selected" <?php endif; ?> ><?php echo e($val->TCM_Country_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                      <!-- <span class="text-danger"><?php echo e($errors->first('userCountry')); ?></span> -->
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">State</label>
                      <span class="text-danger">*</span> 
                      <select class="form-control" name="userState" id="userState" onchange="stateChange()">
                        <option value="">--Select--</option>
                        <?php $__currentLoopData = $state_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($state->TSM_State); ?>" <?php if($TDM_Dept_State == $state->TSM_State): ?> selected="selected" <?php endif; ?> ><?php echo e($state->TSM_State_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                     <!--  <span class="text-danger"><?php echo e($errors->first('userState')); ?></span> -->
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">District</label>
                      <span class="text-danger">*</span> 
                      <select class="form-control" name="userDistrict" id="userDistrict">
                        <option value="">--District--</option>
                        <?php $__currentLoopData = $district_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($val->TDM_District); ?>" <?php if($TDM_Dept_Dist == $val->TDM_District): ?> selected="selected" <?php endif; ?> ><?php echo e($val->TDM_Dist_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                      <!-- <span class="text-danger"><?php echo e($errors->first('userDistrict')); ?></span> -->
                    </div>
                     <div class="form-group">
                      <label for="exampleInputPassword1">PIN/Zipcode</label>
                      <span class="text-danger">*</span> 
                      <input type="text" class="form-control" name="userPINno" id="userPINno" value="<?php echo e($TDM_Dept_Zipcode); ?>">
                      <!-- <span class="text-danger"><?php echo e($errors->first('userPINno')); ?></span> -->
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Address</label>
                      <span class="text-danger">*</span> 
                      <textarea class="form-control" name="userAddress" id="userAddress"><?php echo e($TDM_Dept_Address); ?></textarea>
                      <!-- <span class="text-danger"><?php echo e($errors->first('userAddress')); ?></span>  -->
                    </div>
                </div>
            </div>
          </div>
          <!-- /.box-body -->
          <div class="box-footer">
            <input type="hidden" name="hidDataId" value="<?php echo e($dataId); ?>"/>
            <button type="submit" class="btn btn-primary">Submit</button>
            <a href="<?php echo e(url('department/viewDepartment')); ?>"><button type="button" class="btn btn-warning">Cancel</button></a>
          </div>
        </form>
      </div>
      <!-- /.box -->
      
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('scripts'); ?> 
<script type="text/javascript">
     function validateForm(){
        //alert("alert");return false;
      if (!blankValidation("departmentName","TextField", "Department Name can not be left blank"))
          return false;
      if (!blankValidation("departmentNameOdia","TextField", "Department Name Odia can not be left blank"))
          return false; 
      if (!blankValidation("departmentDescrptn","TextArea", "Description can not be left blank"))
          return false;
       if (!blankValidation("departmentDescrptnOdia","TextArea", "Description Odia can not be left blank"))
          return false;  
      if (!blankValidation("departmentActive","TextField", "Status  can not be left blank"))
          return false;
      if (!blankValidation("userCountry","SelectBox", "Please Select Country"))
        return false;
      if (!blankValidation("userState","SelectBox", "Please Select State"))
        return false;
      if (!blankValidation("userDistrict","SelectBox", "Please Select District"))
        return false; 
      if (!blankValidation("userPINno", "TextField","Zipcode is required"))
        return false; 
      if (!blankValidation("userAddress", "TextArea","Address is required"))
        return false;  
     }  
function countryChange() {
  $.ajaxSetup({
    headers: {
      'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
    }
  });
  if($("#userCountry").val()!=''){
    $.ajax({
      type : "POST",
      url : "<?php echo e(url('user/AddUserStateList')); ?>",
      dataType : 'json',
      //contentType : 'application/json',
      data : {"countryId":$("#userCountry").val()},
      success : function(response) {
        if (response.message == "success") {
          console.log(response);
          $("#userState").empty();
          var option = $("<option></option>");
          $(option).val(null);
          $(option).html("--Select--");
          $("#userState").append(option);
          for (var i = 0; i < response.stateList.length; i++) {
            var option = $("<option></option>");
            $(option).val(response.stateList[i].TSM_State);
            $(option).html(response.stateList[i].TSM_State_Name);
            $("#userState").append(option);
          }
  
        }
      },
      error : function(data) {
        console.log(data);
      }
    })
  }else{
    $("#userState").empty();
    var option = $("<option></option>");
    $(option).val(null);
    $(option).html("--Select--");
    $("#userState").append(option);
  }
}
function stateChange() {
  $.ajaxSetup({
    headers: {
      'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
    }
  });
  //alert($("#userState").val());
  if($("#userState").val()!=''){
    $.ajax({
      type : "POST",
      url : "<?php echo e(url('user/AddUserDistrictList')); ?>",
      dataType : 'json',
      //contentType : 'application/json',
      data : {"stateId":$("#userState").val()},
      success : function(response) {
        if (response.message == "success") {
          console.log(response);
          $("#userDistrict").empty();
          var option = $("<option></option>");
          $(option).val(null);
          $(option).html("--Select--");
          $("#userDistrict").append(option);
          for (var i = 0; i < response.districtList.length; i++) {
            var option = $("<option></option>");
            $(option).val(response.districtList[i].TDM_District);
            $(option).html(response.districtList[i].TDM_Dist_Name);
            $("#userDistrict").append(option);
          }
  
        }
      },
      error : function(data) {
        console.log(data);
      }
    })
  }else{
    $("#userDistrict").empty();
    var option = $("<option></option>");
    $(option).val(null);
    $(option).html("--Select--");
    $("#userDistrict").append(option);
  }
} 
</script>  
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/department/add-department.blade.php ENDPATH**/ ?>