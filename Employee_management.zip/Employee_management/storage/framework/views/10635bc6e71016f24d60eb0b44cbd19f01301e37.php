<?php $__env->startSection('title', 'DASHBOARD'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        User Profile
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Examples</a></li>
        <li class="active">User profile</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-md-3">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body box-profile">
              <img class="profile-user-img img-responsive img-circle" src="<?php echo e(asset('dist/img/user4-128x128.jpg')); ?>" alt="User profile picture">

              <h3 class="profile-username text-center">Sukanta Ranasingh</h3>

              <p class="text-muted text-center">Asst. Section Officer</p>

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b>Status</b> <a class="pull-right">Active</a>
                </li>
                <li class="list-group-item">
                  <b>Department</b> <a class="pull-right">Home</a>
                </li>
                <li class="list-group-item">
                  <b>Role</b> <a class="pull-right">ASO</a>
                </li>
                <li class="list-group-item">
                  <b>Created On</b> <a class="pull-right">23 Dec 2019</a>
                </li>
              </ul>

              <a href="#" class="btn btn-primary btn-block"><b>Change Profile Photo</b></a>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
        <div class="col-md-9">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#settings" data-toggle="tab">Profile</a></li>
              <!-- <li><a href="#timeline" data-toggle="tab">Timeline</a></li>
              <li><a href="#settings" data-toggle="tab">Settings</a></li> -->
            </ul>
            <div class="tab-content">

              <div class="tab-pane active" id="settings">
                <form role="form" method="post" action="<?php echo e(url('post-user-profile')); ?>"  onsubmit="return validateForm()" autocomplete="off">
                <?php echo csrf_field(); ?>
                <div class="box-body">
                  <div class="row">
                      <div class="col-md-6">
                      <?php //print "<pre>"; print_r($data);exit;?>
                        <?php
                          if(!empty($data)){
                            $userId = $data[0]->TUM_User;
                              $TUM_User_Name = $data[0]->TUM_User_Name;
                              $TUM_User_Lname = $data[0]->TUM_User_Lname;
                              $TUM_User_Mobile = $data[0]->TUM_User_Mobile;
                              $TUM_User_Email = $data[0]->TUM_User_Email;
                              $TUM_User_Desig = $data[0]->TUM_User_Desig;
                              $TUM_User_Dept = $data[0]->TUM_User_Dept;
                              $TUM_User_Status = $data[0]->TUM_User_Status;
                              $TUM_User_Password = $data[0]->TUM_User_Password;
                              $TUM_User_AltEmail = $data[0]->TUM_User_AltEmail;
                              $TUM_User_AltMobile = $data[0]->TUM_User_AltMobile;
                              $TURA_UserRole = $data[0]->TURA_UserRole;
                              $roleArr = explode(",",$TURA_UserRole);
                              
                          }else{
                             $userId = '';
                              $TUM_User_Name = '';
                              $TUM_User_Lname = '';
                              $TUM_User_Mobile = '';
                              $TUM_User_Email = '';
                              $TUM_User_Desig = '';
                              $TUM_User_Dept = '';
                              $TUM_User_Status = 1;
                              $TUM_User_Password = '';
                              $TUM_User_AltEmail = '';
                              $TUM_User_AltMobile = '';
                              $TURA_UserRole = '';
                              $roleArr = array();
                          }
                          ?>
                          
                          <div class="form-group">
                            <label for="exampleInputEmail1">First Name</label>
                            <input type="text" class="form-control" name="userName" id="userName" value="<?php echo e($TUM_User_Name); ?>">
                          </div>
                          
                          <div class="form-group">
                            <label for="exampleInputPassword1">Email</label>
                            <input type="text" class="form-control" name="userEmail" id="userEmail" value="<?php echo e($TUM_User_Email); ?>">
                          </div>
                          <div class="form-group">
                            <label for="exampleInputPassword1">Mobile Number</label>
                            <input  class="form-control" name="userMobile" id="userMobile" value="<?php echo e($TUM_User_Mobile); ?>" maxlength="10">
                          </div>
                      </div>
                      
                      <div class="col-md-6">
                          <div class="form-group">
                            <label for="exampleInputEmail1">Last Name</label>
                            <input type="text" class="form-control" name="userLastName" id="userLastName" value="<?php echo e($TUM_User_Lname); ?>">
                          </div>
                          <div class="form-group">
                            <label for="exampleInputPassword1">Alt Mobile Number</label>
                            <input  class="form-control" name="userAltMobile" id="userAltMobile" value="<?php echo e($TUM_User_AltMobile); ?>" maxlength="10">
                          </div>
                          <div class="form-group">
                            <label for="exampleInputPassword1">Alt Email</label>
                            <input  class="form-control" name="userAltEmail" id="userAltEmail" value="<?php echo e($TUM_User_AltEmail); ?>">
                          </div>
                         
                      </div>
                      
                  </div>
                </div>
                <!-- /.box-body -->
                <div class="box-footer">
                  <input type="hidden" name="hidUser" value="<?php echo e($userId); ?>"/>
                  <button type="submit" class="btn btn-primary">Submit</button>
                  <button type="button" class="btn btn-warning" onclick="window.location.href='dashboard'">Cancel</button>
                </div>
              </form>
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-demo\resources\views/edit-profile.blade.php ENDPATH**/ ?>