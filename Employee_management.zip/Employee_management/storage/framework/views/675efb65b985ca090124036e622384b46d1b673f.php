<?php $__env->startSection('title', 'AUDIT'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Department Dispatched Report
      </h1> 
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">MIS Report</a></li>
        <li class="active">Department Dispatched Report</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box">
            <div class="box-header">
              <!-- <h3 class="box-title">Data Table With Full Features</h3> -->
                 <div class="search-field">
                    <div class="row">
    
                        <div class="col-md-2">
                            <div class="org-name">From Date</div>
                        </div>
                        <div class="col-md-2">
                            <input class="form-control" type="text" id="param1">
                        </div>
                        
                        <div class="col-md-1">
                            <div class="org-name">To Date</div>
                        </div>
                        <div class="col-md-2">
                            <input class="form-control" type="text" id="param2">
                        </div>
                        
                        <div class="col-md-1">
                            <div class="org-name">Department</div>
                        </div>
                        <div class="col-md-2">
                            <input class="form-control" type="text" id="param3">
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <button class="btn btn-primary" onClick="searchData()">Search</button>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12" align="right">
                        <a href="#" target="_blank" class="btn btn-default"><i class="fa fa-print"></i> Print</a>
                        <a href="#" target="_blank" class="btn btn-default"><i class="fa fa-file-pdf-o"></i> PDF</a>
                    </div>
                    </div>
                </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
           <!-- <a data-toggle="collapse" data-target="#demo"
                class="showhideangelbg"><i class="fa fa-angle-double-down"></i>
            </a>-->
              <table id="listAllUser" class="table table-bordered table-striped">
                <thead>
                <tr> 
                  <th>Department</th> 
                  <th>Year</th> 
                  <th>No of Dispatched Application</th>
                   
                </tr>
                </thead>
                <tbody>
                 <tr>  
                  <td>Education</td>
                  <td>2018-2019</td>
                  <td>36</td>
                    
                 </tr> 
                 <tr>
                  <td>Health</td>
                  <td>2018-2019</td>
                  <td>34</td>
                   
                </tr>
                <tr>
                  <td>Agriculture</td>
                  <td>2018-2019</td>
                  <td>74</td>
                    
                </tr>
                <tr>
                 <td>Production</td>
                  <td>2018-2019</td>
                  <td>36</td>
                   
                </tr>
                <tr>
                  <td>Education</td>
                  <td>2018-2019</td>
                  <td>36</td>
                   
                </tr>
                <tr>
                 <td>Education</td>
                  <td>2018-2019</td>
                  <td>36</td>
                   
                </tr>
                <tr>
                  <td>Education</td>
                  <td>2018-2019</td>
                  <td>36</td>
                   
                </tr>
             
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
           <!--   <div class="box-footer" align="center">
	            <button type="button" class="btn btn-warning" onclick="window.location.href='manage-mis-annual-report'">Return Back</button>
	          </div> -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
    	 
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('styles'); ?>
<!--Extra styles can written here -->
<?php $__env->stopPush(); ?>  
<?php $__env->startPush('scripts'); ?>

<script>
 
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/mis/manage-mis-dept-dispatch-report.blade.php ENDPATH**/ ?>