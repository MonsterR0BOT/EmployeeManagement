<footer class="page_footer template_footer ds ms parallax overlay_color section_padding_top_30 section_padding_bottom_30 columns_padding_25">
    <div class="container">
        <div class="row">
         
            <div class="col-md-4 col-sm-6 col-xs-12 col-md-push-4">
                <div class="widget widget_text widget_about">
                    <div class="logo logo_with_text bottommargin_10"> <img src="<?php echo e(asset('images/logo1.png')); ?>" alt=""> <!-- <span class="logo_text">
                Diversify
                <small class="highlight4">lgbt community center</small> 
            </span>--> </div>
                    <?php ($aboutus = Helper::getAboutUs()); ?>
                    <p><?php echo Helper::cut( $aboutus->TCM_Content_Description,200); ?></p>
                    <p class="topmargin_25">
                        <?php ($socialarr = Helper::getSocialIcons()); ?>
                        <?php $__currentLoopData = $socialarr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e($val->TSM_Social_Link); ?>" target="_blank"><i class="social-icon border-icon rounded-icon <?php echo e($val->TSM_Social_Icon); ?>"  title="<?php echo e($val->TSM_Social_Name); ?>"></i></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- <i class="social-icon border-icon rounded-icon fa fa-facebook" href="#" title="Facebook"></i>
                        <i class="social-icon border-icon rounded-icon fa fa-twitter" href="#" title="Twitter"></i>
                        <i class="social-icon border-icon rounded-icon fa fa-google" href="#" title="Google Plus"></i>
                        <i class="social-icon border-icon rounded-icon fa fa-linkedin" href="#" title="Linkedin"></i>
                        <i class="social-icon border-icon rounded-icon fa fa-youtube" href="#" title="Youtube"></i> -->
                    </p>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12 col-md-pull-4">
                <div class="widget widget_text">
                    <h3 class="widget-title">Our Contacts</h3>
                    <?php ($contactus = Helper::getContactaddress()); ?>
                    <ul class="list-unstyled greylinks">
                        <li class="media"> <i class="fa fa-map-marker highlight rightpadding_5" aria-hidden="true"></i><?php echo e($contactus->TCM_Contact_Name); ?></li>
                        <li class="media"> <i class="fa fa-phone highlight rightpadding_5" aria-hidden="true"></i><?php echo e($contactus->TCM_Contact_Phone); ?></li>
                        <li class="media"> <i class="fa fa-pencil highlight rightpadding_5" aria-hidden="true"></i> <a href="mailto:contact@wethefamily.in"><?php echo e($contactus->TCM_Contact_Email); ?></a> </li>
                       <!--  <li class="media"> <i class="fa fa-clock-o highlight rightpadding_5" aria-hidden="true"></i> Mon-Fri: 9:00-19:00, Sat: 10:00-17:00 </li> -->
                    </ul>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12 hidden-xs hidden-sm">
                <div class="widget widget_recent_posts">
                    <h3 class="widget-title">Recent Blogs</h3>
                    <?php ($recentblog = Helper:: getLatestBlog()); ?>
                    <ul class="list-unstyled greylinks">
                        <?php $__currentLoopData = $recentblog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <p> <a href="<?php echo e(url('home/showBlog')); ?>"><?php echo e(Helper::cut($val->TBM_Blog_Desc,100)); ?></a> </p>
                            <div class="entry-meta inline-content greylinks"> <span>
                            <i class="fa fa-calendar highlight3 rightpadding_5" aria-hidden="true"></i>
                            <a href="<?php echo e(url('home/showBlog')); ?>">
                                <time datetime="2017-10-03T08:50:40+00:00">
                               <?php echo e(date("d M,Y",strtotime($val->TBM_Blog_Date))); ?></time>
                            </a>
                            </span> 
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       <!--  <li>
                            <p> <a href="blog-single-left.html">Ball tip leberkas salami jowl ham pork  tri-tip tail.</a> </p>
                            <div class="entry-meta inline-content greylinks"> <span>
                        <i class="fa fa-calendar highlight3 rightpadding_5" aria-hidden="true"></i>
                            <a href="blog-single-right.html">
                                <time datetime="2017-10-03T08:50:40+00:00">
                                17 jan, 2018</time>
                            </a>
                            </span>  
                            </div>
                        </li> -->
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>
<section class="ds ms parallax page_copyright overlay_color section_padding_top_30 section_padding_bottom_30">
    <div class="container">
        <div class="row">
        <div class="col-sm-6">
            <p>&copy; Copyright 2020. All Rights Reserved.</p>
        </div>
        <div class="col-sm-6" align="right">
            <p>Powered By : <a href="https://nirmalyalabs.com/" target="blank">Nirmalyalabs Pvt. Ltd.</a></p>
        </div>
        </div>
    </div>
</section><?php /**PATH D:\xampp\htdocs\wethefamily\resources\views/frontend-layout/frontend-footer.blade.php ENDPATH**/ ?>