<?php $cnt=0; $cntn=1;?>

 <?php $__currentLoopData = $work_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php
    $cntn=count($work_data)+1;
    $approvalArr = explode(',', $work->TSA_ApprovalAction);
    $userIdArr = explode(',', $work->TSA_User);
  ?>
 
 <tr class="tr_clone">
    <td valign="top">
      <select class="form-control userRoleNameCls" id="userRole_<?php echo e($cnt); ?>" name="userRole" onchange="getRolewiseUser(this);">
        <option value="">--Select--</option>
          <?php $__currentLoopData = $parent_role_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($val->TURM_UserRole); ?>" <?php if("$val->TURM_UserRole" ==$work->TSA_UserRole): ?> selected="selected" <?php endif; ?>><?php echo e($val->TURM_URole_Name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </td>
    <td valign="top">
      <select class="form-control userNameCls" multiple="multiple" id="userNameId_<?php echo e($cnt); ?>">
      <?php $__currentLoopData = $user_data[$work->TSA_UserRole]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $udtls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($udtls->TUM_User); ?>" <?php if(in_array($udtls->TUM_User, $userIdArr, TRUE)): ?> selected="selected" <?php endif; ?>><?php echo e($udtls->TUM_User_Name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </td>
    <td valign="top">
      <select class="form-control userApprovalActivity" multiple="multiple" id="approvalId_<?php echo e($cnt); ?>">
        <?php $__currentLoopData = $approval_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aprvl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($aprvl->TAM_Approval); ?>" <?php if(in_array($aprvl->TAM_Approval, $approvalArr, TRUE)): ?> selected="selected" <?php endif; ?>><?php echo e($aprvl->TAM_ActionName); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </td>
    <td valign="top">
      <input type="text" class="form-control tatClass" size="5" id="pageLevel_<?php echo e($cnt); ?>" value="<?php echo e($work->TSA_SetAuthority_TAT); ?>">
    </td>
    <td valign="top">
      <label  ><strong>  Stage-<input type="text" class="numberInc" readonly style="border:none;width:40px;" id="number_<?php echo e($cnt); ?>" value="<?php echo e($work->TSA_SetAuthority_StageNo); ?>"></strong>  </label>
    </td>

    <td valign="top">
      <button style="display: none" type="button" class="btn btn-primary button-add tr_clone_add" name="add" onclick="addMore();">
        <i class="fa fa-plus"></i>
      </button>&nbsp;
      <button type="button" class="btn btn-warning button-remove rmv" name="Remove">
        <i class="fa fa-minus"></i>
      </button>
    </td>
  </tr>
<?php $cnt++ ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<tr class="tr_clone">
  <td valign="top">
    <select class="form-control userRoleNameCls" id="userRole_<?php echo e($cnt); ?>" name="userRole" onchange="getRolewiseUser(this);">
      <option value="">--Select--</option>
        <?php $__currentLoopData = $parent_role_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($val->TURM_UserRole); ?>"><?php echo e($val->TURM_URole_Name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
  </td>
  <td valign="top">
    <select class="form-control userNameCls" multiple="multiple" id="userNameId_<?php echo e($cnt); ?>">

    </select>
  </td>
  <td valign="top">
    <select class="form-control userApprovalActivity" multiple="multiple" id="approvalId_<?php echo e($cnt); ?>">
      <?php $__currentLoopData = $approval_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aprvl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($aprvl->TAM_Approval); ?>"><?php echo e($aprvl->TAM_ActionName); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </td>
  <td valign="top">
    <input type="text" class="form-control tatClass" size="5" id="pageLevel_<?php echo e($cnt); ?>">
  </td>
  <td valign="top">
    <label  ><strong>  Stage-<input type="text" class="numberInc" readonly  style="border:none;width:40px;" id="number_<?php echo e($cnt); ?>" value="<?php echo e($cntn); ?>"></strong>  </label>
  </td>

  <td valign="top">
    <button type="button" class="btn btn-primary button-add tr_clone_add" name="add" onclick="addMore();">
      <i class="fa fa-plus"></i>
    </button>&nbsp;
    <button type="button" class="btn btn-warning button-remove rmv" name="Remove">
      <i class="fa fa-minus"></i>
    </button>
  </td>
</tr><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/master/ajax-setauthority-master.blade.php ENDPATH**/ ?>