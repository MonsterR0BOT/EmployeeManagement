 <section class="services-section" style="background-image: url(images/bg1.jpg);">
        <div class="auto-container">    
            <div class="sec-title text-center">
                <h2>Our Series</h2>
            </div>
            <div class="services-box row clearfix">
                <div class="services-carousel owl-carousel owl-theme">
                    <!-- Service Block -->
                    <!-- Service Block -->
                    <?php $__currentLoopData = $seriesDetiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                     <?php 
                        $filename = asset('series_image/thumb/'.$val->TSM_series_iamge); 
                     ?>
                    <div class="service-block">
                        <div class="inner-box">
                            <div class="icon-box" align="center">
                                <img src="<?php echo e($filename); ?>">
                            </div>
                            <div class="lower-content">
                                <h3><a href="#"><?php echo e($val->TSM_series_name); ?></a></h3>
                                <div class="text"><?php echo e($val->TSM_series_description); ?></div>
                                <div class="link-box">
                                    <a href="#">Read More <i class="fa fa-chevron-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
            </div>
        </div>
    </section><?php /**PATH E:\xampp\htdocs\Employee_management\resources\views/frontend-layout/series.blade.php ENDPATH**/ ?>