<?php $__env->startSection('title', 'CHART'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Department Wise Relaxation Cases Charts
        <small>Preview sample</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">MIS REPORTS </a></li>
        <li class="active">Relaxation Cases Charts</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
         <!-- /.col (LEFT) -->
        
        <div class="col-md-12">

          <!-- BAR CHART -->
          <div class="box box-success">
            <div class="box-header with-border">
              <h3 class="box-title">Relaxation Cases Charts</h3>
             <!--    <h3 class="box-title">Monthly Chart</h3> -->

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <div class="box-body">
              <div class="chart">
                <canvas id="canvas"></canvas>
              </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

        </div> 
       
      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('scripts'); ?>
  <script> 
  //  $(document).ready(function(){
        var color = Chart.helpers.color;
        var horizontalBarChartData = { 
        labels: [<?php echo $Department;?>],
        datasets: [{
          label: 'No. of Cases Disposed of',
          backgroundColor:'rgba(97,50,105,0.9)',
          borderColor:'rgba(97,50,105,0.9)',
          borderWidth: 1,
          data: [<?php echo $totalDepartment;?>]
        } ]

      };
  //  });
    

    window.onload = function() {
      var ctx = document.getElementById('canvas').getContext('2d');
      window.myHorizontalBar = new Chart(ctx, {
        type: 'horizontalBar',
        data: horizontalBarChartData,
        options: {
          elements: {
            rectangle: {
              borderWidth: 2,
            }
          },
           hover: {
            mode: 'nearest',
            "animationDuration": 0,
            intersect: true
          },

          "animation": {
              "duration": 1,
              "onComplete": function () {
                var chartInstance = this.chart,
                ctx = chartInstance.ctx;
                
                ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
                ctx.textAlign = 'left';
                ctx.textBaseline = 'top';

                this.data.datasets.forEach(function (dataset, i) {
                  var meta = chartInstance.controller.getDatasetMeta(i);
                  meta.data.forEach(function (bar, index) {
                    var data = dataset.data[index];                            
                    ctx.fillText(data, bar._model.x, bar._model.y - 5);
                  });
                });
              }
          },
          responsive: true,
          legend: {
            position: 'right',
          },
          title: {
            display: true,
            text: 'Department Wise Disciplinary Cases'
          },
          scales: {
              xAxes: [{
                  ticks: {
                      beginAtZero: true,
                      barThickness : 13
                  }
              }]

              
          }
        }
        
      });
    };
  </script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/mis/manage-dept-mis-chart-relaxation.blade.php ENDPATH**/ ?>