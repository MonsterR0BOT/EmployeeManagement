<?php $__env->startSection('title', 'MODULE'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       District Master
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">District Master</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="box">
         <!-- <div class="box-header">
            <h3 class="box-title">Data Table With Full Features</h3>
          </div>-->
          <!-- /.box-header -->
          <div class="box-body">
          	<div id="demo">
                  <div class="search-field">
                      <div class="row">
                          <div class="col-md-2">
                              <div class="org-name">District Name</div>
                          </div>
                          <div class="col-md-2">
                              <input class="form-control" type="text" placeholder="" name="" id="param1">
                          </div>
                          <div class="col-md-2">
                              <div class="org-name">State</div>
                          </div>
                          <div class="col-md-2">
                              <select class="form-control" name="" id="param2">
                                  <option value="">--Select--</option>
                                  <?php $__currentLoopData = $state_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($state->TSM_State); ?>"><?php echo e($state->TSM_State_Name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </select>
                          </div>
                          <div class="col-md-2">
                              <div class="form-group">
                                  <button class="btn btn-primary" onClick="searchData()">Search</button>
                              </div>
                          </div>
                          <div class="col-md-2">
                              <div class="form-group pull-right">
                                  <a href="<?php echo e(url('district/showAddDistrict')); ?>"><button class="btn btn-primary">Add District</button></a>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
              <!--<a data-toggle="collapse" data-target="#demo"
                  class="showhideangelbg"><i class="fa fa-angle-double-down"></i>
              </a>-->
            <table id="listAllDist" class="table table-bordered table-striped">
              <thead>
              <tr>
                <th>State</th>
                <th>District Name</th>
             <!--    <th>District Name Odia</th> -->
                <th>Status</th>
                <th>Action</th>
              </tr>
              </thead>
              <tbody>
            
              </tbody>
            </table>
          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('styles'); ?>
<!--Extra styles can written here -->
<?php $__env->stopPush(); ?>  
<?php $__env->startPush('scripts'); ?>

<script>
  $(function () {
	$('#listAllDist').DataTable({
		'processing' : true,
		'serverSide' : true,
		'searching' : false,
		'ordering' : false,
		"ajax" : {
			'url' : "<?php echo e(url('district/viewDistricthroughAjax')); ?>",
			'data' : function(d) {
				d.param1 = $('#param1').val();
				d.param2 = $('#param2').val();

			}
		},
		'dataSrc' : "",
		'columns' : [ {
			'data' : 'TSM_State_Name'
		}, {
			'data' : 'TDM_Dist_Name'
		}, /*{
      'data' : 'TDM_Dist_NameOdia'
    },*/ {
			'data' : 'TDM_Dist_Status'
		}, {
			'data' : 'action'
		}

		]
	});
	
  });
  //Method For Searching Records In The List
	function searchData() {
		$('#listAllDist').DataTable().draw();
	}
	//Deleting the Country

	function deleteDistrict(id){
           $.ajaxSetup({
        headers: {
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                 }
                });    
		swal.fire({
			  title: "Are you sure want to Delete?",
			  text: "Once Deleted,Can't revert back !",
			  type: "warning",
			  showCancelButton: true,
			  confirmButtonColor: '#d33',
			  cancelButtonColor: '#e7b63a',
			  confirmButtonText: 'Delete',
			  reverseButtons : true
			  
			}).then((result) => {
				if(result.value){
				 $.ajax({
					    type: "POST",
              url:"<?php echo e(url('district/deleteDistrictthroughAjax')); ?>",
              data:{'id':id},  
					    success: function(response) {
						console.log(response);
						//return false;
					        if (response.message == "success") {
					        	swal({
					        		title: "Record Deleted Successfully.",
					        		type: "success"
					        	}).then(function(){
					        		 location.reload();
					        	})
					        
					        	
					        } else {
					            swal({
					                title: 'Unsuccess',
					                text: response.code
					            })
					        }
					    },
					    error: function(data) {
				       
					    }
					})
				}
			  
			});
	} 
	

</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\wethefamily\resources\views/master/district-master.blade.php ENDPATH**/ ?>