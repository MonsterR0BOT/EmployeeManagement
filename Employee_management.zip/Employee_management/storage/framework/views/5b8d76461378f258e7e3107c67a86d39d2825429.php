 <section class="testimonial-section">
        <div class="outer-container clearfix">
            <div class="testmonial-outer">
                <!--Image Column-->
                <div class="image-column wow fadeInLeft animated" style="background-image: url('public/images/bg7.jpg'); visibility: visible; animation-name: fadeInLeft;">
                    <figure class="image-box"><img src="<?php echo e(asset('images/bg7.jpg')); ?>" alt=""></figure>
                </div>

                <!--Image Column-->
                <div class="image-column-two wow fadeInRight animated" style="background-image: url('public/images/6.jpg;'); visibility: visible; animation-name: fadeInRight;">
                    <figure class="image-box"><img src="<?php echo e(asset('images/6.jpg')); ?>" alt=""></figure>
                </div>
        </div>

                <!-- Testimonial Column -->
                <div class="auto-container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="testimonial-column clearfix">
                                <div class="inner-column">
                                    <div class="sec-title text-left">
                                        <h2>Clients Testimonials</h2>
                                    </div>
                                    <div class="testimonial-carousel owl-carousel owl-theme">
                                        <!-- Testimonial Block -->
                                        <div class="testimonial-block">
                                            <div class="inner-box">
                                                <div class="text">A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart. I am alone, and feel the charm of existence in this spot, which was created for the bliss of souls like mine. I am so happy, my dear friend, so absorbed in the exquisite sense of me.
                                                </div>

                                                <div class="info-box">
                                                    <div class="image-box"><img src="<?php echo e(asset('images/testimonial/2.jpg')); ?>" alt=""></div>
                                                    <div class="text-box">
                                                        <h5 class="name">Client Name</h5>
                                                        <span class="designation">Designation, InDesign</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Testimonial Block -->
                                        <div class="testimonial-block">
                                            <div class="inner-box">
                                                <div class="text">A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart. I am alone, and feel the charm of existence in this spot, which was created for the bliss of souls like mine. I am so happy, my dear friend, so absorbed in the exquisite sense of me.
                                                </div>

                                                <div class="info-box">
                                                    <div class="image-box"><img src="<?php echo e(asset('images/testimonial/3.jpg')); ?>" alt=""></div>
                                                    <div class="text-box">
                                                        <h5 class="name">Client Name</h5>
                                                        <span class="designation">Designation, InDesign</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Testimonial Block -->
                                        <div class="testimonial-block">
                                            <div class="inner-box">
                                                <div class="text">A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart. I am alone, and feel the charm of existence in this spot, which was created for the bliss of souls like mine. I am so happy, my dear friend, so absorbed in the exquisite sense of me.
                                                </div>

                                                <div class="info-box">
                                                    <div class="image-box"><img src="<?php echo e(asset('images/testimonial/1.jpg')); ?>" alt=""></div>
                                                    <div class="text-box">
                                                        <h5 class="name">Client Name</h5>
                                                        <span class="designation">Designation, InDesign</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Testimonial Block -->
                                        <div class="testimonial-block">
                                            <div class="inner-box">
                                                <div class="text">A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart. I am alone, and feel the charm of existence in this spot, which was created for the bliss of souls like mine. I am so happy, my dear friend, so absorbed in the exquisite sense of me.
                                                </div>

                                                <div class="info-box">
                                                    <div class="image-box"><img src="<?php echo e(asset('images/testimonial/2.jpg')); ?>" alt=""></div>
                                                    <div class="text-box">
                                                        <h5 class="name">Client Name</h5>
                                                        <span class="designation">Designation, InDesign</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Testimonial Block -->
                                        <div class="testimonial-block">
                                            <div class="inner-box">
                                                <div class="text">A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart. I am alone, and feel the charm of existence in this spot, which was created for the bliss of souls like mine. I am so happy, my dear friend, so absorbed in the exquisite sense of me.
                                                </div>

                                                <div class="info-box">
                                                    <div class="image-box"><img src="<?php echo e(asset('images/testimonial/3.jpg')); ?>" alt=""></div>
                                                    <div class="text-box">
                                                        <h5 class="name">Client Name</h5>
                                                        <span class="designation">Designation, InDesign</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        
    </section><?php /**PATH E:\xampp\htdocs\Employee_management\resources\views/frontend-layout/testimonial.blade.php ENDPATH**/ ?>