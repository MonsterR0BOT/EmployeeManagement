  
 <?php $__env->startSection('title', 'DISCIPLINARY'); ?> 
 <?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>View Disciplinary Request</h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">User</a></li>
            <li class="active">View Disciplinary Request</li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="bs-example">
                    <div class="accordion" id="accordionExample">
                       <div class="box">
                            <div class="card-header" id="headingOne">
                                <a data-toggle="collapse" data-target="#collapseOne" class="accordianheading">
                                    <div class="row">
                                        <div class="col-md-11">
                                            <h5>OPSC Information</h5></div>
                                        <div class="col-md-1"><i class="fa faicon acrdplus fa-plus-circle"></i></div>
                                    </div>
                                </a>
                            </div>
                            <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                                <div class="card-body">
                                    <div class="box-body">
                                        <div class="formsec row">
                                            <div class="col-md-3 bg-color1">
                                                <div class="paddingsmlmin">1.</div>
                                                <div class="paddingsmlmax">Name of the delinquent officer</div>
                                            </div>
                                            <div class="col-md-3">
                                             <div class="form-group">
                                              <label>Sukanta Ranasingh</label>   
                                             </div>
                                            </div>
                                            <div class="col-md-3 bg-color1">
                                                <div class="paddingsmlmin">2.</div>
                                                <div class="paddingsmlmax">Date of birth:</div>
                                            </div>
                                            <div class="col-md-3">
                                              <div class="form-group">
                                                    <label>14/02/2015</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="formsecalt row">
                                             <div class="col-md-3 bg-color1">
                                                  <div class="paddingsmlmin">3.</div> 
                                                  <div class="paddingsmlmax">Name(s) of the Department</div>
                                             </div>
                                             <div class="col-md-3">
                                                 <label>Agriculture &amp; F.E Department</label>
                                             </div>
                                             <div class="col-md-3 bg-color1">
                                                    <div class="paddingsmlmin">4.</div> 
                                                    <div class="paddingsmlmax">Employee ID(HRMS)</div>
                                             </div>
                                             <div class="col-md-3">
                                                  <label>Id 123</label>
                                             </div>
                                         </div>
                                        <div class="formsec row">
                                            <div class="col-md-3 bg-color1">
                                                <div class="paddingsmlmin">5.</div>
                                                <div class="paddingsmlmax">i)Present designation</div>
                                            </div>
                                            <div class="col-md-3">
                                              <div class="form-group">
                                                    <label>Executive Engg.</label>
                                                </div>
                                            </div>
                                            <div class="col-md-3 bg-color1">
                                                <div class="paddingsmlmax">ii)Designation when the delinquency was commited</div>
                                            </div>
                                            <div class="col-md-3">
                                              <div class="form-group">
                                                    <label>Deputy Director</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="formsecalt row">
                                            <div class="col-md-6 bg-color1">
                                                 <div class="paddinglessmin">6.</div>
                                                 <div class="paddinglessmax">Period during which the delinquency was commited</div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>14/02/2015</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="formsec row">
                                            <div class="col-md-6 bg-color1">
                                                <div class="paddinglessmin">7.</div> <div class="paddinglessmax">Whether the officer was suspended,if so,the date(s) of Suspension and re-instatement, if any (if not applicable, write NA) :</div>
                                                
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row">
                                                <div class="col-md-6">NA</div>
                                                <div class="col-md-6">
                                                     <div class="input-group">12.12.2019</div>
                                                </div>
                                                </div>
                                            </div>
                                            <div class="clearfix"></div>
                                           
                                            <div class="col-md-6 bg-color1">
                                            <div class="txtindenting"> Provision of the OCS(CC&A) Rules, 1962 and OCS(Pension) Rules 1992 under which proceeding has been initiated (Tick the appropriate box) :</div></div>
                                            <div  class="col-md-3">
                                               <div class="row">
                                                    <div class="col-md-6"> 
                                                       Rule 15
                                                    </div>
                                                    
                                               </div>
                                            </div>
                                        </div>
                                        <div class="formsecalt row">
                                            <div class="col-md-6 bg-color1">
                                                <div class="paddinglessmin">8.</div>
                                                <div class="paddinglessmax">Date of communication of charge(s) along with statement of allegation/inputation (Copy of the same to be enclosed) :</div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                      <div class="form-group">
                                                        <label>No.15317/F&E</label> <label>15/02/2019</label>
                                                      </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                      <div class="form-group"> <a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> View File</a>
                                                </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="formsec row">
                                            <div class="col-md-6 bg-color1">
                                                 <div class="paddinglessmin">9.</div>
                                                  <div class="paddinglessmax">Date of submission of written statement of defence by the delinquent officer (Copy of the same to be enclosed) :</div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                        <label>15/02/2015</label>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group"><a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> View File</a>
                                                </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="formsecalt row">
                                            <div class="col-md-6 bg-color1">
                                                <div class="paddinglessmin">10.</div>
                                                <div class="paddinglessmax">Whether enquiry was conducted (Tick the appropriate box) :</div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-3">
                                                       Yes
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="formsec row">
                                            <div class="col-md-6 bg-color1">
                                                 <div class="paddinglessmin">11.</div>
                                                <div class="paddinglessmax">If yes, designation of the I.O and date of submission of his report (Copy of the report of I.O to be enclosed) :</div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                            DFO, Koraput Division 24/08/2018
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                       <div class="form-group"><a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> View File</a>
                                                </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="formsecalt row">
                                            <div class="col-md-6 bg-color1">
                                                 <div class="paddinglessmin">12.</div>
                                                <div class="paddinglessmax">Whether report of the I.O was sent to the delinquent officer along with show cause notice calling him to submit his presentation within 15 days as required under Rule 15(10)(i)(a)of the O.C.S (C.C.&A) Rules,1962 (Tick the appropriate box). (Copy of notice to be enclosed) :</div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                      Yes
                                                    </div>
                                                    

                                                      <div class="col-md-6">
                                                    <div class="form-group"> <a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> View File</a>
                                                </div>

                                            </div>
                                             </div>
                                                </div>

                                        </div>
                                    <div class="formsec row ">
                                        <div class="col-md-6 bg-color1 ">
                                             <div class="paddinglessmin">13.</div>
                                                <div class="paddinglessmax">Date of represenation of the D.O.in response to the notice required under Rule 15(10) (i) (a) of the O.C.S (C.C. &A) Rules, 1962 (Copy of represenation to be enclosed) :</div>
                                        </div>
                                        <div class="col-md-6 ">
                                            <div class="row ">
                                                <div class="col-md-6 ">
                                                    <div class="form-group">
                                                    <label>14/01/2014</label>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                  <div class="form-group"><a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> View File</a>
                                                </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="formsecalt row ">
                                        <div class="col-md-6 bg-color1 ">
                                             <div class="paddinglessmin">14.</div>
                                                <div class="paddinglessmax"> Penalty imposed by the Disciplinary Authority before the issue of 2nd show cause notice (Copy of detailed finding and order of Disciplinary Authority and Govt. to be enclosed).</div>
                                        </div>
                                        <div class="col-md-6 ">
                                            <div class="row ">
                                              <div class="col-md-6">
                                               <label>a) 5% of pension be withdrawn for one year</label>
                                              </div> 
                                              <div class="col-md-6">
                                               <div class="form-group"> <a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> View File</a>
                                                </div>  
                                              </div>  
                                            </div>

                                        </div>
                                    </div>

                                        <div class="formsec row ">
                                            <div class="col-md-6  bg-color1 ">
                                                 <div class="paddinglessmin">15.</div>
                                                 <div class=" paddinglessmax">In case imposition of major penalty :-</div>
                                                 <div class="txtindentingone">
                                                    (a) Date of second show cause notice issued u/r 15(10) (i)(b) (Copy to be enclosed):
                                                   </div>
                                                   </div>
                                                <div class="col-md-3">
                                                 <div class="form-group">
                                                 <label>15/05/2015</label>
                                                 </div>
                                                </div>
                                                <div class="col-md-3">
                                                  <div class="form-group"> <a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> View File</a>
                                            </div>
                                                </div>
                                         <div class="clearfix"></div>
                                        <div class="col-md-6 bg-color1">
                                        <div class="txtindentingone">
                                        (b) Date of explanation received from the delinquent officer in reply to 2nd show causes notice (Copy of explanation of D.O to be enclosed)
                                    </div>
                                        </div>
                                                <div class="col-md-3">
                                                   <div class="form-group">
                                                    <label>14/02/2015</label>
                                                   </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group"> <a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> View File</a>
                                                    </div>
                                                            </div>
                                                    </div>

                                        <div class="formsecalt row">
                                        <div class="col-md-6 bg-color1">
                                             <div class="paddinglessmin">16.</div>
                                                <div class="paddinglessmax">Incase of disagreement with the finding of recommendation of I.O. whether reasons for the same has been recorded (Copy of order of Disciplinary Authority to be enclosed) :</div>
                                        </div>
                                            <div class="col-md-6 ">
                                                    <div class="row ">
                                                        <div  class="col-md-6">
                                                           Yes
                                                        </div>

                                                    <div class="col-md-6">
                                                        <div class="form-group"> <a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> View File</a>
                                                </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="formsec row">
                                            <div class="col-md-6 bg-color1">
                                                 <div class="paddinglessmin">17.</div>
                                                <div class="paddinglessmax">In the event of joint proceedings u/r 17 of the OCS (CC&A) Rules, 1962, is concurrence of disciplinary authorities of all the Depts to which delinquent officers belong to have been taken?</div>
                                            </div>
                                            <div class="col-md-6">
                                           <div class="row">
                                                <div class="col-md-3">
                                                  Yes
                                                </div>
                                               
                                                </div>
                                            </div>
                                        </div>
                                        <div class="formsecalt row">
                                            <div class="col-md-6 bg-color1">
                                                 <div class="paddinglessmin">18.</div>
                                                <div class="paddinglessmax">In case of proposal for imposition of penalty on the DO whether orders of Govt.have been taken?</div>
                                            </div>
                                            <div class="col-md-6"> Yes</div>

                                            <div class="col-md-6 bg-color1">
                                                <div class="txtindenting">Copy of the Notes & Order sheet of Govt. from appropriate level to be enclosed :</div>
                                            </div>
                                            <div class="col-md-6">

                                                <div class="row">
                                                <div class="col-md-6">
                                                   Yes
                                                </div>
                                                
                                                <div class="col-md-6">
                                                   <div class="form-group"> <a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> View File</a>
                                                </div>
                                                </div>

                                                </div>
                                            </div>
                                        </div>
                                       
                                        <div align="right" class="col-md-12 mrt_10">
                                            <a href="<?php echo e(url('manage-disciplinary-request')); ?>" class="btn btn-danger">Cancel</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="box">
                            <div class="card-header" id="headingThree">
                                <a data-toggle="collapse" data-target="#collapseThree" class="accordianheading">
                                    <div class="row">
                                        <div class="col-md-11">
                                            <h5>Document Check List</h5></div>
                                        <div class="col-md-1"><i class="fa faicon acrdplus fa-plus-circle"></i></div>
                                    </div>
                                </a>
                            </div>
                            <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                                <div class="card-body">
                                    <div class="col-md-12">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="row listview">
                                                    <div class="col-md-11">1. Copy of statement of allegation</div>
                                                    <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row listview">
                                                    <div class="col-md-11">2. Copy of written statement by DO</div>
                                                    <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="row listview">
                                                    <div class="col-md-11">3. Copy of the report of IO</div>
                                                    <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row listview">
                                                    <div class="col-md-11">4. Copy of the representation of the DO</div>
                                                    <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="row listview">
                                                    <div class="col-md-11">5. Copy of the order of DA along with all the findings</div>
                                                    <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row listview">
                                                    <div class="col-md-11">6. Copy of the second show cause notice</div>
                                                    <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="row listview">
                                                    <div class="col-md-11">7. Copy of the explanation received by DO for 2nd show cause notice</div>
                                                    <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row listview">
                                                    <div class="col-md-11">8. Copy of the order of DA, in case of disagreement with the findings of IO</div>
                                                    <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="row listview">
                                                    <div class="col-md-11">9. Copy of note and order sheet of Government</div>
                                                    <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                
                                <div class="clearfix"></div>
                                <div align="right" class="col-md-12 mrt_10">
                                            <a href="<?php echo e(url('diciplinary/viewSODiciplinary')); ?>" class="btn btn-danger">Cancel</a>
                                        </div>
                                  </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                        
                        <div class="box">
                        <div class="card-header" id="headingFour">
                            <a data-toggle="collapse" data-target="#collapseFour" class="accordianheading">
                                <div class="row">
                                    <div class="col-md-11">
                                        <h5>Officer Comments</h5>
                                    </div>
                                    <div class="col-md-1"><i class="fa fa-plus-circle faicon acrdplus"></i></div>
                                </div>
                                <div class="clearfix"></div>
                            </a>
                        </div>
                        <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
                            <div class="card-body">
                                <div class="box-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <!-- The timeline -->
                                            <ul class="timeline timeline-inverse">
                                                <!-- timeline time label -->
                                                <li class="time-label"> <span class="bg-red">10 Dec. 2019</span>
                                                </li>
                                                <!-- /.timeline-label -->
                                                <!-- timeline item -->
                                                <li>
                                                    <i class="fa fa-user bg-blue"></i>
                                                    <div class="timeline-item"><span class="time"><i class="fa fa-clock-o"></i> 10 Dec. 2019 12:05:20</span>
                                                        <h3 class="timeline-header"><a href="#">Prasanna Behera</a>, Office Asst, Agriculture & F.E Department</h3>
                                                        <div class="timeline-body">I certify that all information/documents given above have been checked by me and found to be correct and all copies of relevant documents, as mentioned above, have benn enclosed.</div>
                                                        <!-- <div class="timeline-footer">     <a class="btn btn-primary btn-xs">Read more</a>     <a class="btn btn-danger btn-xs">Delete</a>   </div> -->
                                                    </div>
                                                </li>
                                                <!-- END timeline item -->
                                                <!-- timeline item -->
                                                <li>
                                                    <i class="fa fa-comments bg-yellow"></i>
                                                    <div class="timeline-item"><span class="time"><i class="fa fa-clock-o"></i> 10 Dec. 2019 15:20:35</span>
                                                        <h3 class="timeline-header"><a href="#">Prakash Nayak</a>, HOD Dept, Agriculture & F.E Department</h3>
                                                        <div class="timeline-body"> The disciplinary case is verified and found ok and send to OPSC for further verification. </div>
                                                    </div>
                                                </li>
                                                <!-- END timeline item -->
                                                <!-- timeline item -->
                                                <li>
                                                    <i class="fa fa-comments bg-yellow"></i>
                                                    <div class="timeline-item"><span class="time"><i class="fa fa-clock-o"></i> 10 Dec. 2019 10:27:00</span>
                                                        <h3 class="timeline-header"><a href="#">Golak Roy</a>, SO, OPSC</h3>
                                                        <div class="timeline-body"> Checked the proceeding and assigned to ASO for further verification </div>
                                                        <!-- <div class="timeline-footer">     <a class="btn btn-warning btn-flat btn-xs">View comment</a>   </div> -->
                                                    </div>
                                                </li>
                                                <!-- END timeline item -->
                                                <!-- timeline time label -->
                                                <li class="time-label"> <span class="bg-green">12 Dec. 2019</span>
                                                </li>
                                                <!-- /.timeline-label -->
                                                <!-- timeline item -->
                                                <li>
                                                    <i class="fa fa-comments bg-yellow"></i>
                                                    <div class="timeline-item"><span class="time"><i class="fa fa-clock-o"></i> 12 Dec. 2019 9:27:35</span>
                                                        <h3 class="timeline-header"><a href="#">Yudhistir Nayak</a>, Dy. Secretary, OPSC</h3>
                                                        <div class="timeline-body"> Checked the proceeding forwarded to up level further verification </div>
                                                        <!-- <div class="timeline-footer">     <a class="btn btn-warning btn-flat btn-xs">View comment</a>   </div> -->
                                                    </div>
                                                </li>
                                                <!-- END timeline item -->
                                                <!-- timeline item -->
                                                <li>
                                                    <i class="fa fa-comments bg-yellow"></i>
                                                    <div class="timeline-item"><span class="time"><i class="fa fa-clock-o"></i> 12 Dec. 2019 11:30:45</span>
                                                        <h3 class="timeline-header"><a href="#">Subodha Mishra</a>, Secretary, OPSC</h3>
                                                        <div class="timeline-body"> Checked the proposal forwarded. </div>
                                                        <!-- <div class="timeline-footer">     <a class="btn btn-warning btn-flat btn-xs">View comment</a>   </div> -->
                                                    </div>
                                                </li>
                                                <!-- END timeline item -->
                                                <li> <i class="fa fa-clock-o bg-gray"></i></li>
                                            </ul>
                                            <div class="col-md-12 padding_10" align="right">
                                                <button class="btn btn-success" data-toggle="modal" data-target="#comments" data-backdrop="static" data-keyboard="false">Give your comments</button>
                                             <a href="<?php echo e(url('diciplinary/viewSODiciplinary')); ?>"><button class="btn btn-danger">Cancel</button></a>
                                            </div>
                                            <div class="clearfix"></div>
                                        </div>
                                        
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
                    </div>
                    <!-- /.box -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.box -->
    </section>
<!-- /.content -->
</div>
<div class="modal" id="myModal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <!-- Modal Header -->
     <div class="modal-header">
       <h4 class="modal-title">Upload Files</h4>
       <!-- <button type="button" class="close" data-dismiss="modal">×</button> -->
    </div>
      <!-- Modal body -->
      <div class="modal-body">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-4 bg-color1">Copy of the report of I.O</div>
                    <div class="col-md-2"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                    <div class="col-md-4 bg-color1">Copy of the second show cause notice</div>
                    <div class="col-md-2"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>" target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                    <div class="col-md-4 bg-color1">Copy of written statement by DO</div>
                    <div class="col-md-2"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>" target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                    <div class="col-md-4 bg-color1">Copy of statement of allegation</div>
                    <div class="col-md-2"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                    <div class="col-md-4 bg-color1">Written statement of defence</div>
                    <div class="col-md-2"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>" target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                    <div class="col-md-4 bg-color1">Copy of notice</div>
                    <div class="col-md-2"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>" target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                    <div class="col-md-4 bg-color1">Copy of represenation</div>
                    <div class="col-md-2"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>" target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                </div>
            </div>
      </div>
      <!-- Modal footer -->
      <div class="modal-footer" align="center">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!--Modal Start-->
<div class="modal" id="comments">
  <div class="modal-dialog">
    <div class="modal-content">
      <!-- Modal Header -->
        <div class="modal-header">
        <h4 class="modal-title">Give your comments</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <!-- Modal body -->
      <div class="modal-body">
     <div class="col-md-12">
        <div class="modalstyleheader">
         <div class="row">
          <div class="col-md-7">
            <div class="row mrt_10">
                <div class="col-md-6">
                    <input type="radio" name="rdApprove" class="minimal" value="1"> Forward 
                </div>
                <div class="col-md-6">
                    <input type="radio" name="rdApprove" class="minimal" value="0"> Reassign
                </div>
            </div>
           </div>
           <div class="col-md-5">
             <select class="form-control">
                <option>--Select--</option>
                <option>ASO</option>
                <option>JA</option>
            </select>
           </div>
       </div>
       </div>   
     
     <div class="row">
      <div class="col-md-12"><textarea name="" class="form-control" rows="5" placeholder="Give your comments... "></textarea>
      </div>
    </div>
    </div>
      </div>
      <!-- Modal footer -->
      <div class="modal-footer" align="center">
         <button class="btn btn-primary" onClick="submitComments()">Submit</button>
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<div class="modal modal-info" id="approveModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <!-- Modal Header -->
        <div class="modal-header">
        <h4 class="modal-title"></h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <!-- Modal body -->
      <div class="modal-body">
     <div class="col-md-12">
      
     <div class="row">
      <div class="col-md-12">
        <h4 id="txtmsg">Application forwaded successfully !</h4>
      </div>
    </div>
    </div>
      </div>
      <!-- Modal footer -->
      <div class="modal-footer" align="center">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!--Modal End-->
<!-- /.content-wrapper -->
<?php $__env->startPush('scripts'); ?>

<script>
   /* $(document).ready(function() {
        // Add minus icon for collapse element which is open by default
        $(".collapse.show").each(function() {
            $(this).prev(".card-header").find(".fa faicon").addClass("fa-minus-circle").removeClass("fa-plus-circle");
        });

        // Toggle plus minus icon on show hide of collapse element
        $(".collapse").on('show.bs.collapse', function() {
            $(this).prev(".card-header").find(".fa faicon").removeClass("fa-plus-circle").addClass("fa-minus-circle");
        }).on('hide.bs.collapse', function() {
            $(this).prev(".card-header").find(".fa faicon").removeClass("fa-minus-circle").addClass("fa-plus-circle");
        });
    });*/
    function submitComments(){
        //alert($("input[name='rdApprove']:checked").val());
        if($("input[name='rdApprove']:checked").val()==1){
            $("#comments").modal('hide');
            $("#approveModal").modal('show');
            $("#txtmsg").html("Application forwaded successfully !");
        }else{
            $("#comments").modal('hide');
            $("#approveModal").modal('show');
            $(".modal-title").html('');
            $("#txtmsg").html("Application returned back to ASO/JA !");
        }
    }
</script>
<?php $__env->stopPush(); ?> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-demo\resources\views/department/view-so-disciplinary-opsc.blade.php ENDPATH**/ ?>