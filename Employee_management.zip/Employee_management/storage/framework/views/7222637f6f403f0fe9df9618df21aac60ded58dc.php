<?php $__env->startSection('title', 'DESIGNATION'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Add/Edit Designation</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Add/Edit Designation</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      
      <!-- Default box -->
      <div class="box">
        <form role="form" id="webForm" method="post" autocomplete="off" action="<?php echo e(url('post-designation')); ?>">
          <?php echo e(csrf_field()); ?>

          <div class="box-body">
            <div class="row">
                <div class="col-md-6">
                   <?php
                    if(!empty($data)){
                        $dataId = $data[0]->TDM_Desig;
                        $TDM_Desig_Name  = $data[0]->TDM_Desig_Name;
                        $TDM_Desig_Name_Odia = $data[0]->TDM_Desig_Name_Odia;
                    }else{
                       $dataId = '';
                       $TDM_Desig_Name  = '';
                       $TDM_Desig_Name_Odia = '';
                    }
                    ?>
                    <div class="form-group">
                      <label for="name">Designation Name</label>
                      <input type="text" class="form-control" name="designationName" id="designationName" value="<?php echo!empty($TDM_Desig_Name) ? $TDM_Desig_Name : ''; ?>">
                    </div>
                    <div class="form-group">
                      <label for="name">Designation Name Odia</label>
                      <input type="text" class="form-control" name="designationNameOdia" id="designationNameOdia" value="<?php echo!empty($TDM_Desig_Name_Odia) ? $TDM_Desig_Name_Odia : ''; ?>">
                    </div>
                   
                </div>
            </div>
          </div>
          <!-- /.box-body -->
          <div class="box-footer">
            <input type="hidden" name="hidDataId" value="<?php echo e($dataId); ?>"/>
            <button type="button" class="btn btn-primary" onclick="validateForm();">Submit</button>
             <a href="<?php echo e(url('manage-designation-master')); ?>"><button type="button" class="btn btn-warning" >Cancel</button></a>
          </div>
        </form>
      </div>
      <!-- /.box -->
      
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('scripts'); ?> 
<script type="text/javascript">
   function validateForm(){
      if (!blankValidation("designationName","TextField", "Designation name can not be left blank"))
          return false;
      if (!blankValidation("designationNameOdia","TextField", "Designation name odia can not be left blank"))
        return false;
      $('#webForm').submit();
   }  

</script>  
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-demo\resources\views/master/add-designation-master.blade.php ENDPATH**/ ?>