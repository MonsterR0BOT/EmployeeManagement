<!-- Modal Header -->
  <div class="modal-header">
     <h4 class="modal-title">Add New</h4>
     <!-- <button type="button" class="close" data-dismiss="modal">×</button> -->
  </div>
  <!-- Modal body -->
  <div class="modal-body" >
      <div class="row">
        <div class="col-md-12">
            <div class="form-group">
              <label for="name">Designation Name</label>
              <input type="text" class="form-control" name="designationName" id="designationName" value="">
            </div>
        </div>
    </div>
  </div>
  <!-- Modal footer -->
  <div class="modal-footer" align="center">
    <button class="btn btn-primary" onClick="saveAjaxDesignation()">Submit</button>
    <button type="button" class="btn btn-danger" onclick="closeModal('newdesig')">Close</button>
  </div>
        


<?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/department/ajax-add-designation-form.blade.php ENDPATH**/ ?>