<?php $__env->startSection('title', 'RELAXATION'); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
   <!-- Content Header (Page header) -->
   <section class="content-header">
      <h1>Add Relaxation Request</h1>
      <ol class="breadcrumb">
         <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
         <li><a href="#">User</a></li>
         <li class="active">Add Relaxation Request</li>
      </ol>
   </section>
   <!-- Main content -->
   <section class="content">
       <?php  
        
        if(!empty($data)){ 
              $relaxationId = $data[0]->TRR_RelaxationRequest;

              $TRR_Department  = $data[0]->TRR_Department;

              $TRR_PromotionPost = $data[0]->TRR_PromotionPost;

              $TRR_PromotionDesignation  = $data[0]->TRR_PromotionDesignation ;

              $TRR_FeederPost = $data[0]->TRR_FeederPost;

              $TRR_FeederDesignation=$data[0]->TRR_FeederDesignation;


              $TRR_Recuritment_Rule = $data[0]->TRR_Recuritment_Rule;

              $TRR_Recuritment_No= $data[0]->TRR_Recuritment_No;

              $TRR_Resolution_Date =($data[0]->TRR_Resolution_Date!='') ?date("d-m-Y", strtotime($data[0]->TRR_Resolution_Date)):''; 

              $TRR_ServicPeriod_Prescribed  = $data[0]->TRR_ServicPeriod_Prescribed; 

              $TRR_ServicPeriod_Gained = $data[0]->TRR_ServicPeriod_Gained;

              $TRR_ServicPeriod_Proposed = $data[0]->TRR_ServicPeriod_Proposed; 

              $TRR_IsOfficerHold_Experience = $data[0]->TRR_IsOfficerHold_Experience; 

              $TRR_IsOfficerAvail_Relaxation = $data[0]->TRR_IsOfficerAvail_Relaxation;

              $TRR_RelaxatnOccasion_No = $data[0]->TRR_RelaxatnOccasion_No;

              $TRR_RelaxtnOcasion_Year  = $data[0]->TRR_RelaxtnOcasion_Year; 

              $TRR_RelaxtnOcasion_LetterNo = $data[0]->TRR_RelaxtnOcasion_LetterNo; 

              $TRR_RelaxtnConcurance_Date =($data[0]->TRR_RelaxtnConcurance_Date!='')?date("d-m-Y", strtotime($data[0]->TRR_RelaxtnConcurance_Date)):''; 
              $TRR_IsGovtOrder_Taken = $data[0]->TRR_IsGovtOrder_Taken;
              $TRR_IsFederGrade_SameCatgory = $data[0]->TRR_IsFederGrade_SameCatgory;
              $TRR_Approval_Status = $data[0]->TRR_Approval_Status;
              $modeId=$mode[0];  
          }else{
              $relaxationId = '';
              $TRR_RelaxationRequest = '';
              $TRR_Department  = '';
              $TRR_PromotionPost = '';
              $TRR_PromotionDesignation  ='';
              $TRR_FeederPost ='';
              $TRR_FeederDesignation='';
              $TRR_Recuritment_Rule=''; 
              $TRR_Recuritment_No='';
              $TRR_Resolution_Date  ='';
              $TRR_ServicPeriod_Prescribed =''; 
              $TRR_ServicPeriod_Gained ='';
              $TRR_ServicPeriod_Proposed = '';
              $TRR_IsOfficerHold_Experience =1 ; 
              $TRR_IsOfficerAvail_Relaxation =1 ;
              $TRR_RelaxatnOccasion_No  = ''; 
              $TRR_RelaxtnOcasion_Year ='';  
              $TRR_RelaxtnOcasion_LetterNo  =''; 
              $TRR_RelaxtnConcurance_Date ='';
              $TRR_IsGovtOrder_Taken=1 ;
              $TRR_IsFederGrade_SameCatgory=1;
              $TRR_Approval_Status = 7;
              $modeId='';
          }

      ?>
      <input type="hidden" name="hdRelaxationId" id="hdRelaxationId" value="<?php echo e($relaxationId); ?>">
      <input type="hidden" name="promotionDesigId" id="promotionDesigId" value="<?php echo e($TRR_PromotionDesignation); ?>">
      <input type="hidden" name="federDesigId" id="federDesigId" value="<?php echo e($TRR_FeederDesignation); ?>">
      <input type="hidden" name="promotionPostId" id="promotionPostId" value="<?php echo e($TRR_PromotionPost); ?>">
      <input type="hidden" name="federPostId" id="federPostId" value="<?php echo e($TRR_FeederPost); ?>">
      <input type="hidden" name="mode" id="mode" value="<?php echo e($modeId); ?>">
      <input type="hidden" name="approvalStatus" id="approvalStatus" value="<?php echo e($TRR_Approval_Status); ?>">
      <div class="row">
         <div class="col-md-12">
         <div class="bs-example">
        <div class="accordion" id="accordionExample">
        <div class="box">
                 
              <div class="card-header" id="headingOne">
                  <a  data-toggle="collapse" data-target="#collapseOne" class="accordianheading">
                  <div class="row"> 
                  <div class="col-md-11">
                  <h5>Form of Reference</h5></div> <div class="col-md-1"><i class="fa fa-plus-circle acrdplus"></i></div> 
                  </div>
                  </a>
                </div>
              <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                  <div class="card-body">
                      <div class="box-body">
                      <div class="formsecalt row">
                       <div class="col-md-6">
                            <div class="paddinglessmin">1.</div> 
                            <div class="paddinglessmax">Name of the Department</div>
                       </div>
                       <div class="col-md-3">
                          <div class="input-group">
                              <select class="form-control" name="departmentId" id="departmentId" onchange="showDeptWiseDesignation(),showDeptWisePost() ">
                                  <option value="">--Select--</option>
                                  <?php $__currentLoopData = $dept_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($val->TDM_Dept); ?>"<?php if($TRR_Department == $val->TDM_Dept): ?> selected="selected" <?php endif; ?> ><?php echo e($val->TDM_Dept_Name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                               </select>
                          </div>
                       </div>
                     </div>
                     <div class="formsec row">
                       <div class="col-md-6">
                              <div class="paddinglessmin">2.</div> 
                              <div class="paddinglessmax">Name Designation of the promotional Post service</div>
                       </div>
                       <div class="col-md-6">
                          <div class="row">
                          <div class="col-md-6">
                          <label>Designation</label>
                          <div class="input-group">
                              <select class="form-control" name="promotionalDesigntion" id="promotionalDesigntion" onclick="showAddPostModal(this.value);">
                                <option value="">--Select--</option>
                                <option value="newdesig">Add New</option>
                             </select>
                          </div>
                         </div>
                          <div class="col-md-6">
                          <label>Post</label>
                          <div class="input-group">
                             <select class="form-control" name="promotionalPost" id="promotionalPost" onclick="showAddPostModal(this.value);">
                                <option value="">--Select--</option>
                                <option value="newpost">Add New</option>
                             </select>
                          </div>
                         </div>
                       </div>
                       </div>
                       </div>
                        <div class="clearfix"></div>
                       <div class="formsecalt row">
                       <div class="col-md-6">
                           <div class="input-group">
                           <div class="paddinglessmin">3.</div>
                           <div class="paddinglessmax">Name Designation of the feeder post service for which relaxation of qualifying service</div>
                           </div>
                       </div>
                       <div class="col-md-6">
                          <div class="row">
                          <div class="col-md-6">
                          <label>Designation</label>
                          <div class="input-group">
                              <select class="form-control" name="feederDesigntion" id="feederDesigntion" onclick="showAddPostModal(this.value);">
                                <option value="">--Select--</option>
                                <option value="newdesig">Add New</option>
                             </select>
                          </div>
                         </div>

                          <div class="col-md-6">
                          <label>Post</label>
                          <div class="input-group">
                              <select class="form-control" name="feederPost" id="feederPost" onclick="showAddPostModal(this.value);">
                                <option value="">--Select--</option>
                                <option value="newpost">Add New</option>
                             </select>
                          </div>
                         </div>
                       </div>
                       </div>
                       <!--<div class="clearfix"></div>-->
                       </div>
                      
                       
                     <div class="formsec row">
                          <div class="col-md-12">
                             <div class="col-md-1 paddinglgmin">4.</div> <div class="col-md-11 paddinglgmax">Name of the recruitment Rules with number & clause of the Rules for which relaxation is required. If no such Rules exist, mention the number and date of Resolution/Notification/Office Memorandum prescribing eligibility criteria. (Copy of Rules/ G.O./Resolution/O.M./Notification to be appended in pdf/png/jpg format)</div>
                            
                          </div>
                          <div class="col-md-12 mrt_10">
                          <div class="row">
                          <div class="col-md-3">
                             
                                <label>Name of the recruitment Rules</label>
                                <div class="input-group">
                                <select class="form-control" name="recruitmentRule" id="recruitmentRule" onClick="showAddPostModal(this.value);">
                                   <option value="">--Select--</option>
                                    <?php $__currentLoopData = $rule_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vall): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($vall->TRM_Rules); ?>" <?php if($TRR_Recuritment_Rule == $vall->TRM_Rules): ?> selected="selected" <?php endif; ?>>
                                      <?php echo e($vall->TRM_Rules_Name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                  <option value="newrule">Add New</option>
                                </select>
                                </div>
                          </div>
                          <div class="col-md-3">
                             
                                <label>With number & clause of the Rules</label>
                                <div class="input-group">
                                <input type="text" class="form-control" name="recruitmentNo" id="recruitmentNo" value="<?php echo e($TRR_Recuritment_No); ?>">
                             </div>
                          </div>
                          <div class="col-md-3">
                          <label>Date of Resolution</label>
                             <div class="input-group">
                               <div class="input-group-prepend">
                                  <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                               </div>
                               <input type="text" class="form-control pull-right datepicker" name="resolutionDate" id="resolutionDate" value="<?php echo e($TRR_Resolution_Date); ?>">
                            </div> 
                          </div>
                          <div class="col-md-3">
                             <div class="input-group">
                                <label>Copy of Rules G.O./Resolution</label>
                                <a href="#" data-toggle="modal" data-target="#myModal_one" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> Upload File</a>
                             </div>
                          </div>
                          <div class="clearfix"></div>
                          </div>
                          </div>
                          <div class="clearfix"></div>
                       </div>
                          <div class="clearfix"></div>
                        <div class="formsecalt row">
                       <div class="col-md-6">
                          <div class="input-group">
                             <div class="paddinglessmin">5.</div> <div class=" paddinglessmax">Period of service prescribed in the recruitment Rules for promotion to the higher grade post.</div>
                          </div>
                       </div>
                          <div class="col-md-6">
                              <div class="input-group">
                             <textarea class="form-control" name='servicePeriodPrescribe' id='servicePeriodPrescribe'value="<?php echo e($TRR_ServicPeriod_Prescribed); ?>"> <?php echo e($TRR_ServicPeriod_Prescribed); ?> </textarea>
                          </div>
                          </div>
                          </div>
                          <div class="formsec row">
                           <div class="col-md-6"> 
                         
                             <div class="paddinglessmin">6.</div> <div class="paddinglessmax">Period of service already gained by the incumbents in the feeder post.</div>
                          </div>
                       
                          <div class="col-md-6">
                              <div class="input-group">
                              <textarea class="form-control" name="servicePeriodGain" id="servicePeriodGain"value="<?php echo e($TRR_ServicPeriod_Gained); ?>"> <?php echo e($TRR_ServicPeriod_Gained); ?></textarea>
                          </div>
                          </div>
                       <div class="clearfix"></div>
                       </div>
                       <div class="formsecalt row">
                       <div class="col-md-6">
                        
                            <div class="paddinglessmin"> 7.</div>
                             <div class=" paddinglessmax">(a)Period of service now proposed by Government for one time relaxation of qualifying service. (Such relaxation should not be more than 50% of the period of service prescribed in the Recruquitment Rules e.g., <strong>If the prescribed period of qualifying service is 10 years, the proposed relaxation should not exceed 05 years</strong>)</div>
                       </div>
                       <div class="col-md-6">
                           <div class="input-group">
                             <textarea class="form-control" id="servicPeriodProposed" name="servicPeriodProposed" value="<?php echo e($TRR_ServicPeriod_Proposed); ?>"> <?php echo e($TRR_ServicPeriod_Proposed); ?></textarea>
                          </div>
                       </div>
                        <div class="col-md-6">
                             <div class="txtindenting">(b)Whether the officers under consideration have gathered adequate experience & knowledge required to hold the promotional post after relaxation.</div>
                       </div>
                       <div class="col-md-3">
                           <div class="row">
                             <div class="col-md-6">
                             <input type="radio" <?php echo e(($TRR_IsOfficerHold_Experience=="1")? "checked" : ""); ?> name="rdOfficerHoldExperience" value="1" >
                             Yes
                             </div>
                             <div class="col-md-6">
                             <input type="radio"<?php echo e(($TRR_IsOfficerHold_Experience=="0")? "checked" : ""); ?> name="rdOfficerHoldExperience" value="0" >
                             No
                             </div>
                             </div>
                       </div>
                       <div class="clearfix"></div>
                       </div>
                       
                       <div class="formsec row">
                          <div class="col-md-6">
                             <div class="paddinglessmin">8.</div>
                                <div class="paddinglessmax">Whether the officers under consideration have already availed relaxation of qualifying service for promotion to the feeder grade.</div>
                            
                            </div>
                           <div class="col-md-3">
                           <div class="row">
                             <div class="col-md-6">
                             <input type="radio" <?php echo e(($TRR_IsOfficerAvail_Relaxation=="1")? "checked" : ""); ?> name="rdOfficerAvailRelaxation" value="1">
                             Yes
                             </div>
                             <div class="col-md-6">
                             <input type="radio" <?php echo e(($TRR_IsOfficerAvail_Relaxation=="0")? "checked" : ""); ?> name="rdOfficerAvailRelaxation" value="0">
                             No
                             </div>
                             </div>
                       </div>

                          <div class="clearfix"></div>
                       </div>
                       <div class="formsecalt row">
                       <div class="col-md-12">
                             <div class="paddinglgmin">9.</div>
                              <div class="paddinglgmax">Number of occasions already availed by Govt. for relaxation of qualifying service for promotion to the proposed higher grade during the last three years. (Copy of letters containing concurrence of the OPSC need to be furnished)</div>
                       </div>
                           <div class="col-md-2">
                            <label>No of occasions</label>
                                <div class="input-group">
                                <input type="text" class="form-control" name="RelaxatnOccasionNo" id="RelaxatnOccasionNo" value="<?php echo e($TRR_RelaxatnOccasion_No); ?>">
                             </div>
                          </div>
                          <div class="col-md-2">
                           <label>Year</label>
                              <div class="input-group">
                              <select class="form-control" name="RelaxtnOcasionYear" id="RelaxtnOcasionYear">
                                <option value="">--Select--</option>
                                <option value="2017"<?php if($TRR_RelaxtnOcasion_Year == 2017): ?> selected="selected" <?php endif; ?>>2017</option>
                                <option value="2018"<?php if($TRR_RelaxtnOcasion_Year == 2018): ?> selected="selected" <?php endif; ?>>2018</option>
                                <option value="2019"<?php if($TRR_RelaxtnOcasion_Year == 2019): ?> selected="selected" <?php endif; ?>>2019</option>
                             </select>
                          </div>
                          </div>
                          <div class="col-md-2">
                           <label>Letter No.</label>
                            <div class="input-group">
                                <input type="text" class="form-control" name="RelaxtnOcasionLetterNo" id="RelaxtnOcasionLetterNo" value="<?php echo e($TRR_RelaxtnOcasion_LetterNo); ?>">
                             </div>
                          </div>
                         <div class="col-md-3">
                           <label>Date</label>
                            <div class="input-group">
                               <div class="input-group-prepend">
                                  <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                               </div>
                               <input type="text" class="form-control pull-right datepicker" id="RelaxtnConcuranceDate" value="<?php echo e($TRR_RelaxtnConcurance_Date); ?>">
                            </div>
                          </div>
                          <div class="col-md-3">
                             <label>Copy of letters </label>
                            <div class="input-group">
                                <a href="#" data-toggle="modal" data-target="#myModal_one" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> Upload File</a>
                            </div>
                          </div>

                       </div>
                       <div class="clearfix"></div>
                       <div class="formsec row">
                        <div class="col-md-6">
                          <div class="input-group">
                             <div class="paddinglessmin">10.</div>
                              <div class="paddinglessmax">Whether orders of the Govt. have been taken for the proposed relaxation (Copy of Notification / order list sheet need to furnished)</div>
                          </div>
                       </div>
                           <div class="col-md-3">
                           <div class="row">
                             <div class="col-md-6">
                             <input type="radio" <?php echo e(($TRR_IsGovtOrder_Taken=="1")? "checked" : ""); ?> name="rdGovtOrderTaken" value="1">
                             Yes
                             </div>
                             <div class="col-md-6">
                             <input type="radio" <?php echo e(($TRR_IsGovtOrder_Taken=="0")? "checked" : ""); ?> name="rdGovtOrderTaken" value="0">
                             No
                             </div>
                             </div>
                           </div>
                            <div class="col-md-3">
                            <a href="#" data-toggle="modal" data-target="#myModal_one" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> Upload File</a>
                           </div>
                             </div>
                          <div class="clearfix"></div>
                      
                       <div class="formsecalt row">
                          <div class="col-md-6">
                                <div class="paddinglessmin">11.</div>
                                <div class="paddinglessmax">Whether relaxation sought for the officer from the feeder grade belongs to the same category (Direct Recruitment Departmental Promotional) in which vacancy is proposed to be filled up.</div>
                            </div>
                              <div class="col-md-3">
                           <div class="row">
                             <div class="col-md-6">
                             <input type="radio" <?php echo e(($TRR_IsFederGrade_SameCatgory=="1")? "checked" : ""); ?> name="rdFederGradeSameCatgory" value="1">
                             Yes
                             </div>
                             <div class="col-md-6">
                             <input type="radio" <?php echo e(($TRR_IsFederGrade_SameCatgory=="0")? "checked" : ""); ?> name="rdFederGradeSameCatgory" value="0">
                             No
                             </div>
                             </div>
                           </div>
                           </div>
                           <div align="right" class="col-md-12">
                          <a href="<?php echo e(url('relaxationRequest/viewRelaxationOthers')); ?>" class="btn btn-danger">Cancel</a>
                          <button class="btn btn-warning"id="saveAsDraft">Save To Draft</button>
                          <button class="btn btn-primary"id="saveAndNext1">Save &#38 Next</button> 
                       </div>
                    </div>
                     </div>
                 </div>
        </div>
        <div class="box">
              <div class="card-header" id="headingThree">
                   <a  data-toggle="collapse" data-target="#collapseThree" class="accordianheading"> <div class="row"> <div class="col-md-11"><h5>Document Check List</h5></div> <div class="col-md-1"><i class="fa fa-plus-circle acrdplus"></i></div> </div></a>                     
              </div>
              <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                  <div class="card-body">
                  <div class="col-md-12">
                  <div class="row">
                          <?php $sl=1; 
                          // $arrColumns='';
                          if(!empty($chk_doc_list)){
                          $arrColumns = array_column($chk_doc_list,'docType');
                          }
                          ?>
                          <?php $__currentLoopData = $doc_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6">
                                <div class="row listview">
                                  <div class="col-md-11"><?php echo e($sl.'. '); ?> <?php echo e($val->TDM_Doc_Name); ?></div>
                                  <div class="col-md-1 listicon">
                                  <label>
                        <input type="checkbox" class="minimal" id="checked<?php echo e($val->TDM_Doc); ?>" name="checked<?php echo e($val->TDM_Doc); ?>" value="<?php echo e($val->TDM_Doc); ?>" onchange="checkDataUploadedOrNot(this.value)"  <?php if(!empty($arrColumns)): ?><?php if(in_array($val->TDM_Doc,$arrColumns)): ?> checked="checked" <?php endif; ?> <?php endif; ?>>
                              </label>
                              </div>
                                </div>
                            </div> <?php $sl+=1; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

                     <div class="col-md-12">
                       <div class="paddinglessmin">
                           <input name="finalcheck" id="finalcheck" type="checkbox" value="">
                       </div>
                       <div class="paddinglessmax">
                        <div>I certify that all information/documents given above have been checked by me and found to be correct and all copies of relevant documents, as mentioned above, have benn enclosed. </div>
                       </div>
                     </div>
                    </div>      
                    </div>
                    <div class="clearfix"></div>
                          <div align="right" class="col-md-12 mrt_10 mrb_10">
                              <a href="<?php echo e(url('relaxationRequest/viewRelaxationOthers')); ?>" class="btn btn-danger">Cancel</a>
                               <a href="javascript:void(0)" id="finalSubmit" class="btn btn-primary">Submit</a>
                          </div> 
                          
                    <div class="clearfix"></div>
                 </div>
             </div>
        </div>
          <!-- /.box -->
         </div>
         <!-- /.col -->
      </div>
      <!-- /.box -->
      </div>
    </div>
   </section>
   <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <div class="modal" id="myModal_one">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <!-- Modal Header -->
        <div class="modal-header">
           <h4 class="modal-title">Upload File</h4>
           <!-- <button type="button" class="close" data-dismiss="modal">×</button> -->
        </div>
        <!-- Modal body -->
        <div class="modal-body">
          <div class="col-lg-12">
            
              
             <div class="form-group uploadone">
             <div></div>
             <div class="row">
                <div class="col-lg-5">
                    <label>Select File Type</label>
                    <select name="docType" id="docType" class="form-control">
                       <option value="">--Select--</option>
                        <?php $__currentLoopData = $doc_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($val->TDM_Doc); ?>"><?php echo e($val->TDM_Doc_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </select>
                </div>
                <div class="col-lg-6">
                    <label>Upload File</label> 
                    <div class="input-group">
                    <input type="file" class="custom-file-input"  name="UploadFile" id="UploadFile"> 
                    <label class="custom-file-label customFile" for="customFile" >Choose file</label> 
                  </div>
                </div>
                 <div class="col-lg-1 mrt_30" align="right">
                      <button class="btn btn-primary" type="button" id="saveFilesWithAjax"><i class="fa fa-upload"></i></button> 
                  </div>
              </div>
            </div>
          </div>
          <div class="col-md-12">
          <div class="row" id="previewDocs"> 
              
          </div>
          <div id="">
         <h4 id="uploadedFileCount" class="modal-title" style="display: none;">Uploaded Files:<span>0</span></h4>  

        </div>
       <div class="row" id="previewDocs1">
         
          
       </div>
          </div>
        </div>
        <!-- Modal footer -->
        <div class="modal-footer" align="center">
         <!--  <button class="btn btn-primary" id="saveFilesWithAjax">Submit</button> -->
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>
  <div class="modal" id="addPostModal">
    <div class="modal-dialog">
      <div class="modal-content" id="addPostBody">
        
        
      </div>
    </div>
  </div>
  <!--uload Modal End-->
<?php $__env->startPush('scripts'); ?> 
<script type="text/javascript">

    var mode=$('#mode').val();
    if(mode==1){
        $('#saveAsDraft').hide();
    } 

$("#finalSubmit").click(function(){ 
    
     var confirmCheck = $('input[name="finalcheck"]:checked').length;
     if(confirmCheck!=1){
        swal('Please check confirm checkbox');
        return  false;
     }
    var relaxationId=$("#hdRelaxationId").val();
    var mode=$("#mode").val();
    var data = new FormData(); 
    data.append('mode', mode);
    data.append('relaxationId',relaxationId);
    data.append('approvalStatus', $("#approvalStatus").val());
   // console.log(data); 
    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
      }
    }); 
        
      //return false;
      swal.fire({
        title: "Do you want to submit?",
        text: "",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#e7b63a',
        confirmButtonText: 'Submit',
        reverseButtons : true 
        
      }).then((result) => {
        $("#maskid").show();
        $.ajax({
            type: 'POST', 
            url:'<?php echo e(url("relaxationRequest/saveRelaxationFinalSubmit")); ?>', 
            data:data, 
            success: function(results) { 
                $("#maskid").hide(); 
                if(results.message =="success"){
                    window.location.href='<?php echo url("relaxationRequest/viewRelaxationOthers") ?>';
                    swal("Record submitted successfully.");
                }else{
                  swal("Record submitted failed.");
                }    
            }, 
            cache: false,
            contentType: false,
            processData: false
        }); 
    });   
        
});
     


function checkDataUploadedOrNot(val){
 //alert('hi');
//alert(val);
    var relaxationId=$("#hdRelaxationId").val();
    var mode=$("#mode").val();
    if(val =='' || val==null)  {
    swal('Data is Not Available');
    return false;
    }  
    var data = new FormData();  
    data.append('doc_type', val);
    data.append('relaxationId', relaxationId);
    data.append('mode',mode);
    $.ajaxSetup({
    headers: {
    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
    }
    });
    swal.fire({
      title: "Are you sure want to Check?",
      text: "Once Check,Can't revert back !",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#e7b63a',
      confirmButtonText: 'Check',
      reverseButtons : true

    }).then((result) => {
    if(result.value){
      $.ajax({
        type: 'POST',
        url : '<?php echo e(url("relaxationRequest/checkDocument")); ?>' ,
        data:data,
        success: function(results) { 
       // $("#maskid").hide();
        if(results =="0"){
          swal("Document Not Available");
          $('#checked'+val).prop('checked', false);
          
        }else{  
          swal("File checked successfully");
          $('#checked'+val).prop('checked', true)
        }
        }, 
        cache: false,
        contentType: false,
        processData: false
      });  
    }   
    });  

}


///////////////////////////////////////////////////working code 
  function showDeptWiseDesignation() {
     // alert('hello'+$("#departmentId").val());
      $.ajaxSetup({
        headers: {
          'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
        }
      });

      if($("#departmentId").val()!=''){
        $.ajax({
          type : "POST",
          url : "<?php echo e(url('relaxationRequest/designationList')); ?>",
          dataType : 'json',
          //contentType : 'application/json',
          data : {"deptId":$("#departmentId").val()},
          success : function(response) {
            if (response.message == "success") {
              console.log(response);
              $("#promotionalDesigntion").empty();
              var option = $("<option></option>");
              $(option).val(null);
              $(option).html("--Select--");
              $("#promotionalDesigntion").append(option);
              for (var i = 0; i < response.desigList.length; i++) {
                var option = $("<option></option>");
                $(option).val(response.desigList[i].TDM_Desig);
                $(option).html(response.desigList[i].TDM_Desig_Name);
                $("#promotionalDesigntion").append(option);
              }
              var option = $("<option></option>");
              $(option).val("newdesig");
              $(option).html("Add New");
              $("#promotionalDesigntion").append(option);

              $("#feederDesigntion").empty();
              var option = $("<option></option>");
              $(option).val(null);
              $(option).html("--Select--");
              $("#feederDesigntion").append(option);
              for (var i = 0; i < response.desigList.length; i++) {
                var option = $("<option></option>");
                $(option).val(response.desigList[i].TDM_Desig);
                $(option).html(response.desigList[i].TDM_Desig_Name);
                $("#feederDesigntion").append(option);
              }
              var option = $("<option></option>");
              $(option).val("newdesig");
              $(option).html("Add New");
              $("#feederDesigntion").append(option);
            }
          },
          error : function(data) {
            console.log(data);
          }
        })
      }else{
        $("#promotionalDesigntion").empty();
        var option = $("<option></option>");
        $(option).val(null);
        $(option).html("--Select--");
        $("#promotionalDesigntion").append(option);
       
       $("#feederDesigntion").empty();
        var option = $("<option></option>");
        $(option).val(null);
        $(option).html("--Select--");
        $("#feederDesigntion").append(option);  
      } 
    }  

  function showDeptWisePost() {
      //alert('hello'+$("#departmentId").val());
      $.ajaxSetup({
        headers: {
          'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
        }
      });

      if($("#departmentId").val()!=''){
        $.ajax({
          type : "POST",
          url : "<?php echo e(url('relaxationRequest/postList')); ?>",
          dataType : 'json',
          //contentType : 'application/json',
          data : {"deptId":$("#departmentId").val()},
          success : function(response) {
            if (response.message == "success") {
              console.log(response);
              $("#promotionalPost").empty();
              var option = $("<option></option>");
              $(option).val(null);
              $(option).html("--Select--");
              $("#promotionalPost").append(option);
              for (var i = 0; i < response.postList.length; i++) {
                var option = $("<option></option>");
                $(option).val(response.postList[i].TPM_Post);
                $(option).html(response.postList[i].TPM_Post_Name);
                $("#promotionalPost").append(option);
              }
              var option = $("<option></option>");
              $(option).val("newpost");
              $(option).html("Add New");
              $("#promotionalPost").append(option);

              $("#feederPost").empty();
              var option = $("<option></option>");
              $(option).val(null);
              $(option).html("--Select--");
              $("#feederPost").append(option);
              for (var i = 0; i < response.postList.length; i++) {
                var option = $("<option></option>");
                $(option).val(response.postList[i].TPM_Post);
                $(option).html(response.postList[i].TPM_Post_Name);
                $("#feederPost").append(option);
              }
              var option = $("<option></option>");
              $(option).val("newpost");
              $(option).html("Add New");
              $("#feederPost").append(option);
            }
          },
          error : function(data) {
            console.log(data);
          }
        })
      }else{
        $("#promotionalPost").empty();
        var option = $("<option></option>");
        $(option).val(null);
        $(option).html("--Select--");
        $("#promotionalPost").append(option);
       
       $("#feederPost").empty();
        var option = $("<option></option>");
        $(option).val(null);
        $(option).html("--Select--");
        $("#feederPost").append(option);  
      } 
    } 

    function delThisDoc(val){      
      if(val =='' || val==null)  {
      swal('Data is Not Available');
      return false;
      }
      // var URL = '<?php echo e(url("del-uploaded-file")); ?>';
      var data = new FormData();  
      data.append('doc_type', val);

      $.ajaxSetup({
      headers: {
      'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
      }
      });
      swal.fire({
        title: "Are you sure want to Delete?",
        text: "Once Deleted,Can't revert back !",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#e7b63a',
        confirmButtonText: 'Delete',
        reverseButtons : true

      }).then((result) => {
      if(result.value){
        $.ajax({
        type: 'POST',
        'url' : '<?php echo e(url("relaxationRequest/delUploadedFile")); ?>' ,
        data:data,
        success: function(results) { 
        $("#maskid").hide();
        if(results =="0"){
          swal("Invalid file extension");
        }else{  
          console.log('after delete:--',results);
          swal("File deleted successfully");
          $("#previewDocs").empty();
          $("#docType").val('');
          $("#UploadFile").val('');
          $(".customFile").html('Choose file'); 
          if(results.length>0){  
          for (var i = 0; i < results.length; i++) {
            var docType=results[i].docType;  
            var docText=results[i].docText; 
            var docName=results[i].docName; 

            var imageLink="<?php echo e(asset('storage/relaxation_files')); ?>/"+docName; 
            console.log(imageLink); 
            $('#previewDocs').prepend($('<div class="col-md-6"><i class="fa fa-pdf-o"></i>'+docText+'<a href="'+imageLink+'" target="_blank"><span class="label label-primary"><i class="fa fa-eye"></i></span></a> <a href="javascript:void(0)" onclick="delThisDoc('+docType+')" ><span class="label label-warning"><i class="fa fa-close"></i></span></a></div>')); 
          } 
        } 
        }
        }, 
        cache: false,
        contentType: false,
        processData: false
        });  
      }   
      });  
    } 

    function delThisDocFromDB(val){ 
      var relaxationId=$("#hdRelaxationId").val(); 
      var mode=$("#mode").val();
      if(val =='' || val==null)  {
        swal('Data is Not Available');
        return false;
      } 
      var data = new FormData();  
      data.append('doc_type', val);
      data.append('relaxationId', relaxationId);
      data.append('mode', mode);
      $.ajaxSetup({
        headers: {
        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
        }
      });
      swal.fire({
        title: "Are you sure want to Delete?",
        text: "Once Deleted,Can't revert back !",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#e7b63a',
        confirmButtonText: 'Delete',
        reverseButtons : true

      }).then((result) => {
      if(result.value){
        $.ajax({
          type: 'POST',
          url : '<?php echo e(url("relaxationRequest/deleteDocFromDB")); ?>' ,
          data:data,
          success: function(results) { 
            $("#maskid").hide();
             if (results.message == "success") {
                  console.log(results);
                  $("#previewDocs1").html(''); 
                  $("#docType").val('');
                  $("#UploadFile").val('');
                  $(".customFile").html('Choose file'); 
                  $("#uploadedFileCount span").text(results.docList.length); 
                  for (var i = 0; i < results.docList.length; i++) {
                    var docType=results.docList[i].docType;  
                    var docText=results.docList[i].docText; 
                    var docName=results.docList[i].docName;  
                    var imageLink="<?php echo e(asset('storage/relaxation_files')); ?>/"+docName;  
                    console.log(imageLink); 

                    $('#previewDocs1').prepend($('<div class="col-md-6"><i class="fa fa-pdf-o"></i>'+docText+'<a href="'+imageLink+'" target="_blank"><span class="label label-primary"><i class="fa fa-eye"></i></span></a> <a href="javascript:void(0)" onclick="delThisDocFromDB('+docType+')" ><span class="label label-warning"><i class="fa fa-close"></i></span></a></div>')); 
                  }
                }
          }, 
          cache: false,
          contentType: false,
          processData: false
        });  
      }   
      }); 
    }

    $(document).ready(function(){
    var departmentIdEdit=$("#departmentId").val(); 
    if(departmentIdEdit!=''){ 
      $("#uploadedFileCount").show();
      $('#departmentId').prop('disabled', true);
      $.ajaxSetup({
      headers: {
       'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
        }
       });
      if(departmentIdEdit!=''){
        $.ajax({
          type : "POST",
          url : '<?php echo e(url("relaxationRequest/designationList")); ?>', 
          dataType : 'json', 
          data : {"deptId":departmentIdEdit},
          success : function(response) {
            if (response.message == "success") {
              console.log(response);     
              $("#promotionalDesigntion").empty();
              var option = $("<option></option>");
              $(option).val(null);
              $(option).html("--Select--");
              $("#promotionalDesigntion").append(option);
              for (var i = 0; i < response.desigList.length; i++) {
                var option = $("<option></option>");
                $(option).val(response.desigList[i].TDM_Desig);
                $(option).html(response.desigList[i].TDM_Desig_Name);
                $("#promotionalDesigntion").append(option);
                var promotionDesigId=$("#promotionDesigId").val();
                if(promotionDesigId){ 
                  $('#promotionalDesigntion option[value='+promotionDesigId+']').attr('selected','selected');
                }
              }
              var option = $("<option></option>");
              $(option).val("newdesig");
              $(option).html("Add New");
              $("#promotionalDesigntion").append(option);   

               
              $("#feederDesigntion").empty();
              var option = $("<option></option>");
              $(option).val(null);
              $(option).html("--Select--");
              $("#feederDesigntion").append(option);
              for (var i = 0; i < response.desigList.length; i++) {
                var option = $("<option></option>");
                $(option).val(response.desigList[i].TDM_Desig);
                $(option).html(response.desigList[i].TDM_Desig_Name);
                $("#feederDesigntion").append(option);
                var federDesigId=$("#federDesigId").val();
                if(federDesigId){ 
                  $('#feederDesigntion option[value='+federDesigId+']').attr('selected','selected');
                }

              }
              var option = $("<option></option>");
              $(option).val("newdesig");
              $(option).html("Add New");
              $("#feederDesigntion").append(option);

            }
          },
          error : function(data) {
          //console.log(data);

          }
        })
      }
      else{
        $("#promotionalDesigntion").empty();
        var option = $("<option></option>");
        $(option).val(null);
        $(option).html("--Select--");
        $("#promotionalDesigntion").append(option);

        $("#feederDesigntion").empty();
        var option = $("<option></option>");
        $(option).val(null);
        $(option).html("--Select--");
        $("#feederDesigntion").append(option);  
      } 


      if(departmentIdEdit!=''){
        $.ajax({
          type : "POST",
          url : '<?php echo e(url("relaxationRequest/postList")); ?>', 
          dataType : 'json', 
          data : {"deptId":departmentIdEdit},
          success : function(response) {
            if (response.message == "success") {
              console.log(response);     
              $("#promotionalPost").empty();
              var option = $("<option></option>");
              $(option).val(null);
              $(option).html("--Select--");
              $("#promotionalPost").append(option);
              for (var i = 0; i < response.postList.length; i++) {
                var option = $("<option></option>");
                $(option).val(response.postList[i].TPM_Post);
                $(option).html(response.postList[i].TPM_Post_Name);
                $("#promotionalPost").append(option);
                 var promotionPostId=$("#promotionPostId").val();
                if(promotionPostId){ 
                  $('#promotionalPost option[value='+promotionPostId+']').attr('selected','selected');
                }
              }   
              var option = $("<option></option>");
              $(option).val("newpost");
              $(option).html("Add New");
              $("#promotionalPost").append(option);
               
              $("#feederPost").empty();
              var option = $("<option></option>");
              $(option).val(null);
              $(option).html("--Select--");
              $("#feederPost").append(option);
              for (var i = 0; i < response.postList.length; i++) {
                var option = $("<option></option>");
                $(option).val(response.postList[i].TPM_Post);
                $(option).html(response.postList[i].TPM_Post_Name);
                $("#feederPost").append(option);
                var federPostId=$("#federPostId").val();
                if(federPostId){ 
                  $('#feederPost option[value='+federPostId+']').attr('selected','selected');
                }
              }
              var option = $("<option></option>");
              $(option).val("newpost");
              $(option).html("Add New");
              $("#feederPost").append(option);

            }
          },
          error : function(data) {
            console.log(data);

          }
        })
      }
      else{
        $("#promotionalPost").empty();
        var option = $("<option></option>");
        $(option).val(null);
        $(option).html("--Select--");
        $("#promotionalPost").append(option);

        $("#feederPost").empty();
        var option = $("<option></option>");
        $(option).val(null);
        $(option).html("--Select--");
        $("#feederPost").append(option);  
      } 

    }
    var relaxationId=$("#hdRelaxationId").val();
    var mode=$("#mode").val();
    if(hdRelaxationId!=''){
      $.ajaxSetup({
      headers: {
      'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
      }
      });
      if(hdRelaxationId!=''){
      $.ajax({
      type : "POST",
      'url' : '<?php echo e(url("relaxationRequest/getRelaxationDocList")); ?>',
      dataType : 'json',
      //contentType : 'application/json',
      data : {"relaxationId":relaxationId,"mode":mode},
      success : function(response) {
      if (response.message == "success") {
        console.log(response);
        $("#previewDocs1").html('');
        //$("#previewDocs1").html('<div><h1>Uploaded Documents</h1></div>');
        $("#docType").val('');
        $("#UploadFile").val('');
        $(".customFile").html('Choose file'); 
        $("#uploadedFileCount span").text(response.docList.length);
      //  $('#previewDocs1').prepend($('<h1>Uploaded Documents</h1>'));
        for (var i = 0; i < response.docList.length; i++) {
          var docType=response.docList[i].docType;  
          var docText=response.docList[i].docText; 
          var docName=response.docList[i].docName;  
          var imageLink="<?php echo e(asset('storage/relaxation_files')); ?>/"+docName;  
          console.log(imageLink); 

          $('#previewDocs1').prepend($('<div class="col-md-6"><i class="fa fa-pdf-o"></i>'+docText+'<a href="'+imageLink+'" target="_blank"><span class="label label-primary"><i class="fa fa-eye"></i></span></a> <a href="javascript:void(0)" onclick="delThisDocFromDB('+docType+')" ><span class="label label-warning"><i class="fa fa-close"></i></span></a></div>')); 
        }

      }
      },
      error : function(data) {
      console.log(data);
      }
      })
      }else{

      }

    }



    //////////////////////////////////////////////////////
    /////////////////////////////////////////////////////
    $("#saveFilesWithAjax").click(function(){
    //var myObj = [];
    var docVal = $("#docType").val(); 
    var uploadVal = $("#UploadFile").val();
    //console.log('docVal---',docVal);
    // console.log('uploadVal---',uploadVal);
    if (!blankValidation("docType","SelectBox", "Please select Document Type"))
    return false;
    if(uploadVal==''){
    swal('Please Upload Document');
    return false;
    }

    $("#maskid").show();

    var URL = "<?php echo e(url('relaxationRequest/saveUploadFile')); ?>";
    var data = new FormData();

    var docTypeText =$("#docType option:selected").text();
    //alert(docTypeText);
    var docTypeId =$("#docType").val();
    data.append('imgfile', jQuery('#UploadFile')[0].files[0]);
    data.append('doc_type', docTypeId);
    data.append('doc_text', docTypeText);
    // console.log('Add time--',data);
    //data.append('old_userphoto', olduserphoto);
    $.ajaxSetup({
    headers: {
    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
    }
    });
    $.ajax({
    type: 'POST',
    url: URL ,
    data:data,
    success: function(results) { 
    $("#maskid").hide();
    if(results.message =="0"){
        swal("Invalid file extension");
    }else if(results.message =="1"){ 
        swal("File size exceeds 3 MB");
    }else{
      swal("File uploaded successfully");
    }

        //myObj.push(results);
        //console.log(results);
        
       // OpenDocs(myObj);
        $("#previewDocs").html('');
        $("#docType").val('');
        $("#UploadFile").val('');
        $(".customFile").html('Choose file');

        for (var i = 0; i < results.ImgArr.length; i++) {
          var docType=results.ImgArr[i].docType;  
          var docText=results.ImgArr[i].docText; 
          var docName=results.ImgArr[i].docName; 

          var imageLink="<?php echo e(asset('storage/relaxation_files')); ?>/"+docName;

         // console.log(imageLink); 
          

          $('#previewDocs').prepend($('<div class="col-md-6"><i class="fa fa-pdf-o"></i>'+docText+'<a href="'+imageLink+'" target="_blank"><span class="label label-primary"><i class="fa fa-eye"></i></span></a> <a href="javascript:void(0)" onclick="delThisDoc('+docType+')" ><span class="label label-warning"><i class="fa fa-close"></i></span></a></div>'));

        /*  $('#previewDocs').prepend($('<div class="col-md-6"><i class="fa fa-pdf-o"></i>'+docText+'<a href="'+imageLink+'" target="_blank"><span class="label label-primary"><i class="fa fa-eye"></i></span></a> <a href="'+imageLink+'" target="_blank"><span class="label label-warning"><i class="fa fa-close"></i></span></a></div>'));*/

        }

    },

    cache: false,
    contentType: false,
    processData: false
    }); 

    }); 

    $("#saveAsDraft").click(function(){
    var  data = {};
    data['relaxationId']=$("#hdRelaxationId").val();
    data['departmentId']=$("#departmentId").val();
    data['promotionalDesigntion']=$("#promotionalDesigntion").val();
    data['promotionalPost']=$("#promotionalPost").val();
    data['feederDesigntion']=$("#feederDesigntion").val();
    data['feederPost']=$("#feederPost").val();
    data['recruitmentRule']=$("#recruitmentRule").val();
    data['recruitmentNo']=$("#recruitmentNo").val();
    data['resolutionDate']=$("#resolutionDate").val();
    data['servicePeriodPrescribe']=$("#servicePeriodPrescribe").val();
    data['servicePeriodGain']=$("#servicePeriodGain").val();
    data['servicPeriodProposed']=$("#servicPeriodProposed").val();
    data['rdOfficerHoldExperience']=parseInt($("input[name='rdOfficerHoldExperience']:checked").val());
    data['rdOfficerAvailRelaxation']=parseInt($("input[name='rdOfficerAvailRelaxation']:checked").val());
    data['RelaxatnOccasionNo']=$("#RelaxatnOccasionNo").val();
    data['RelaxtnOcasionYear']=$("#RelaxtnOcasionYear").val(); 
    data['RelaxtnOcasionLetterNo']=$("#RelaxtnOcasionLetterNo").val();
    data['RelaxtnConcuranceDate']=$("#RelaxtnConcuranceDate").val(); 
    data['rdGovtOrderTaken']=parseInt($("input[name='rdGovtOrderTaken']:checked").val());
    data['rdFederGradeSameCatgory']=parseInt($("input[name='rdFederGradeSameCatgory']:checked").val());
    submitAsDraft(data);
    });
    $("#saveAndNext1").click(function(){   
      if (!blankValidation("departmentId","SelectBox", "Please select department"))
        return false; 
   
      if (!blankValidation("promotionalDesigntion","SelectBox", "Please Select Promotion Designation"))
          return false; 

      if (!blankValidation("promotionalPost","SelectBox", "Please Select Promotion Post"))
          return false; 
      if (!blankValidation("feederDesigntion","SelectBox", "Please Select Feeder Designation"))
          return false; 

      if (!blankValidation("feederPost","SelectBox", "Please Select Feeder Post"))
          return false; 
   
      if (!blankValidation("recruitmentRule","SelectBox", "Please Select Rule"))
          return false;
      if (!blankValidation("recruitmentNo","TextField", "Recruitment No Can Not Be Blanck"))
          return false;  
    var  data = {};
    data['mode']=$("#mode").val();
    data['relaxationId']=$("#hdRelaxationId").val();
    data['departmentId']=$("#departmentId").val();
    data['promotionalDesigntion']=$("#promotionalDesigntion").val();
    data['promotionalPost']=$("#promotionalPost").val();
    data['feederDesigntion']=$("#feederDesigntion").val();
    data['feederPost']=$("#feederPost").val();
    data['recruitmentRule']=$("#recruitmentRule").val();
    data['recruitmentNo']=$("#recruitmentNo").val();
    data['resolutionDate']=$("#resolutionDate").val();
    data['servicePeriodPrescribe']=$("#servicePeriodPrescribe").val();
    data['servicePeriodGain']=$("#servicePeriodGain").val();
    data['servicPeriodProposed']=$("#servicPeriodProposed").val();
    data['rdOfficerHoldExperience']=parseInt($("input[name='rdOfficerHoldExperience']:checked").val());
    data['rdOfficerAvailRelaxation']=parseInt($("input[name='rdOfficerAvailRelaxation']:checked").val());
    data['RelaxatnOccasionNo']=$("#RelaxatnOccasionNo").val();
    data['RelaxtnOcasionYear']=$("#RelaxtnOcasionYear").val(); 
    data['RelaxtnOcasionLetterNo']=$("#RelaxtnOcasionLetterNo").val();
    data['RelaxtnConcuranceDate']=$("#RelaxtnConcuranceDate").val(); 
    data['rdGovtOrderTaken']=parseInt($("input[name='rdGovtOrderTaken']:checked").val());
    data['rdFederGradeSameCatgory']=parseInt($("input[name='rdFederGradeSameCatgory']:checked").val());
    data['approvalStatus']=$("#approvalStatus").val(); 

    submitSaveAndNext(data); 
    });



    }); 

    function submitAsDraft(data){
    //console.log('submit as saveAsDraft --',data);
    // return false;
    $.ajaxSetup({
    headers: {
    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
    }
    });
    swal.fire({
    title: "Do you want to submit?",
    text: "",
    type: "warning",
    showCancelButton: true,
    confirmButtonColor: '#d33',
    cancelButtonColor: '#e7b63a',
    confirmButtonText: 'Submit',
    reverseButtons : true

    }).then((result) => {
    if(result.value){
    $.ajax({
    type: "POST",
    'url':'<?php echo e(url("relaxationRequest/saveRelaxationAsDraftTemp")); ?>',
    dataType  : "json",
    contentType : "application/json",
    data    : JSON.stringify(data),
    success   : function(response){
      console.log("response ",response);
      if(response.message=="success"){
        swal({
            title:"Data Saved Successfully.",
            type: "success",
        }).then(function(){
          //window.location.href='manage-relaxation-request'; 
           window.location.href='<?php echo url("relaxationRequest/viewRelaxationDraft") ?>';
        })
      }else{
        swal({
          title:response.code,
          text: response.message,
          type:"warning"
        })
      }
    },
    error : function(data) {
    console.log(data); 
    }
    })
    }

    });
    }

    function submitSaveAndNext(data){
    $.ajaxSetup({
    headers: {
    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
    }
    });
    swal.fire({
    title: "Do you want to submit?",
    text: "",
    type: "warning",
    showCancelButton: true,
    confirmButtonColor: '#d33',
    cancelButtonColor: '#e7b63a',
    confirmButtonText: 'Submit',
    reverseButtons : true

    }).then((result) => {
    if(result.value){
    $.ajax({
    type: "POST",
    'url':'<?php echo e(url("relaxationRequest/saveRelaxationSaveAndNext")); ?>',
    dataType  : "json",
    contentType : "application/json",
    data    : JSON.stringify(data),
    success   : function(response){
      console.log("response ",response);
      if(response.message=="success"){
        swal({
            title:"Data Saved Successfully.",
            type: "success",
        }).then(function(){
          //alert('hiiii');
          //window.location.href='manage-relaxation-request'; 
           window.location.href='<?php echo url("relaxationRequest/viewRelaxationOthers") ?>';
        })
      }else{
        swal({
          title:response.code,
          text: response.message,
          type:"warning"
        })
      }
    },
    //     error : function(xhr, status, error){
    //   var err = eval("(" + xhr.responseText + ")");
    //     console.log(err)

    //   swal(err.message);  
    // }
    })
    }

    });
  }

  function showAddPostModal(index){
    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
      }
    });
    $("#addPostBody").empty();
    if(index=='newpost'){
        $.ajax({
              type: "GET",
              url : '<?php echo e(url("department/showAddPostForm")); ?>',
              success: function(response) {
              //console.log(response);
              $("#addPostBody").append(response.html);
              $("#addPostModal").modal('show');
              },
              error: function(data) {
               
              }
          })
    }else{
        $("#addPostModal").modal('hide');
    }
    if(index=='newdesig'){
        $.ajax({
              type: "GET",
              url : '<?php echo e(url("department/showDesignationForm")); ?>',
              success: function(response) {
              console.log(response);
              $("#addPostBody").append(response.html);
              $("#addPostModal").modal('show');
              },
              error: function(data) {
               
              }
          })
    }else{
        $("#addPostModal").modal('hide');
    }

    if(index=='newrule'){
        $.ajax({
              type: "GET",
              url : '<?php echo e(url("department/showRecruitmentRuleForm")); ?>',
              success: function(response) {
              console.log(response);
              $("#addPostBody").append(response.html);
              $("#addPostModal").modal('show');
              },
              error: function(data) {
               
              }
          })
    }else{
        $("#addPostModal").modal('hide');
    }
   
}
function closeModal(index){
      if(index=='newpost'){
        $("#promotionalPost").val('');
        $("#feederPost").val('');
      } 
      if(index=='newdesig'){
        $("#promotionalDesigntion").val('');
        $("#feederDesigntion").val('');
      }
      if(index=='newrule'){
        $("#recruitmentRule").val('');
      }  
      
      $("#addPostModal").modal('hide');
} 

function saveAjaxPost (){
   if (!blankValidation("postName","TextField", "Post name can not be left blank"))
    return false;  

     $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
      }
    });
    var data = new FormData(); 
    data.append('Department', $("#departmentId").val());
    data.append('postName',$("#postName").val());
    console.log(data); 

   swal.fire({
        title: "Do you want to submit?",
        text: "",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#e7b63a',
        confirmButtonText: 'Submit',
        reverseButtons : true
        
      }).then((result) => {
        if(result.value){
            $.ajax({
            type  : "POST",
            url   : '<?php echo e(url("department/savePostAjax")); ?>', 
            //dataType  : "json",
            //contentType : "application/json",
            data    : data,
            success : function(response){
              $("#addPostModal").modal('hide');
              
              if(response.message=="success"){ 
                swal({
                    title:"Data added successfully.",
                    type: "success",
                }).then(function(){    
                 //for post applied 
                  console.log(response);
                  $("#promotionalPost").empty();
                  var option = $("<option></option>");
                  $(option).val(null);
                  $(option).html("--Select--");
                  $("#promotionalPost").append(option);
                  for (var i = 0; i < response.postList.length; i++) {
                    var option = $("<option></option>");
                    $(option).val(response.postList[i].TPM_Post);
                    $(option).html(response.postList[i].TPM_Post_Name);
                    $("#promotionalPost").append(option);
                  }
                  var option = $("<option></option>");
                  $(option).val("newpost");
                  $(option).html("Add New");
                  $("#promotionalPost").append(option);

                  $("#feederPost").empty();
                  var option = $("<option></option>");
                  $(option).val(null);
                  $(option).html("--Select--");
                  $("#feederPost").append(option);
                  for (var i = 0; i < response.postList.length; i++) {
                    var option = $("<option></option>");
                    $(option).val(response.postList[i].TPM_Post);
                    $(option).html(response.postList[i].TPM_Post_Name);
                    $("#feederPost").append(option);
                  }
                  var option = $("<option></option>");
                  $(option).val("newpost");
                  $(option).html("Add New");
                  $("#feederPost").append(option);

                 //location.reload();
                })
              }else{
                swal({
                  title:response.code,
                  text: response.message,
                  type:"warning"
                })
              }
            },error   : function(xhr, status, error){
              $("#addPostModal").modal('hide');
              var err = eval("(" + xhr.responseText + ")");
              //console.log(err);
              swal(err.message.slice(err.message.indexOf('>:'),err.message.indexOf('(SQL:')).replace('>:','')); 
            },
            cache: false,
            contentType: false,
            processData: false
          }) //ajax ends
        } 
      }); 
}
function saveAjaxDesignation (){
  if (!blankValidation("designationName","TextField", "Designation can not be left blank"))
    return false;  

    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
      }
    });
    var data = new FormData(); 
    data.append('designationName', $("#designationName").val());
    data.append('departmentId', $("#departmentId").val());
    //console.log(data); 

   swal.fire({
        title: "Do you want to submit?",
        text: "",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#e7b63a',
        confirmButtonText: 'Submit',
        reverseButtons : true
        
      }).then((result) => {
        if(result.value){
            $.ajax({
            type  : "POST",
            url   : '<?php echo e(url("designation/saveDesignationAjax")); ?>', 
            data    : data,
            success : function(response){
              $("#addPostModal").modal('hide');
              
              if(response.message=="success"){ 
                swal({
                    title:"Data added successfully.",
                    type: "success",
                }).then(function(){    
                  //console.log(response);
                  $("#promotionalDesigntion").empty();
                  var option = $("<option></option>");
                  $(option).val(null);
                  $(option).html("--Select--");
                  $("#promotionalDesigntion").append(option);
                  for (var i = 0; i < response.desigList.length; i++) {
                    var option = $("<option></option>");
                    $(option).val(response.desigList[i].TDM_Desig);
                    $(option).html(response.desigList[i].TDM_Desig_Name);
                    $("#promotionalDesigntion").append(option);
                  }
                  var option = $("<option></option>");
                  $(option).val("newdesig");
                  $(option).html("Add New");
                  $("#promotionalDesigntion").append(option);

                  $("#feederDesigntion").empty();
                  var option = $("<option></option>");
                  $(option).val(null);
                  $(option).html("--Select--");
                  $("#feederDesigntion").append(option);
                  for (var i = 0; i < response.desigList.length; i++) {
                    var option = $("<option></option>");
                    $(option).val(response.desigList[i].TDM_Desig);
                    $(option).html(response.desigList[i].TDM_Desig_Name);
                    $("#feederDesigntion").append(option);
                  }
                  var option = $("<option></option>");
                  $(option).val("newdesig");
                  $(option).html("Add New");
                  $("#feederDesigntion").append(option);

                 //location.reload();
                })
              }else{
                swal({
                  title:response.code,
                  text: response.message,
                  type:"warning"
                })
              }
            },error   : function(xhr, status, error){
              $("#addPostModal").modal('hide');
              var err = eval("(" + xhr.responseText + ")");
              //console.log(err);
              swal(err.message.slice(err.message.indexOf('>:'),err.message.indexOf('(SQL:')).replace('>:','')); 
            },
            cache: false,
            contentType: false,
            processData: false
          }) //ajax ends
        } 
      }); 
}
function saveAjaxRule (){
   if (!blankValidation("ruleName","TextField", "Rule name can not be left blank"))
    return false;  

     $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
      }
    });
    var data = new FormData(); 
    data.append('Department', $("#departmentId").val());
    data.append('ruleName',$("#ruleName").val());
    console.log(data); 

   swal.fire({
        title: "Do you want to submit?",
        text: "",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#e7b63a',
        confirmButtonText: 'Submit',
        reverseButtons : true
        
      }).then((result) => {
        if(result.value){
            $.ajax({
            type  : "POST",
            url   : '<?php echo e(url("department/saveRuleAjax")); ?>', 
            //dataType  : "json",
            //contentType : "application/json",
            data    : data,
            success : function(response){
              $("#addPostModal").modal('hide');
              
              if(response.message=="success"){ 
                swal({
                    title:"Data added successfully.",
                    type: "success",
                }).then(function(){    
                 //for post applied 
                  $("#recruitmentRule").empty();
                  var option = $("<option></option>");
                  $(option).val(null);
                  $(option).html("--Select--");
                  $("#recruitmentRule").append(option);
                  for (var i = 0; i < response.rulelist.length; i++) {
                    var option = $("<option></option>");
                    $(option).val(response.rulelist[i].TRM_Rules);
                    $(option).html(response.rulelist[i].TRM_Rules_Name);
                    $("#recruitmentRule").append(option);
                  
                  }
                  var option = $("<option></option>");
                  $(option).val("newrule");
                  $(option).html("Add New");
                  $("#recruitmentRule").append(option);
                 //location.reload();
                })
              }else{
                swal({
                  title:response.code,
                  text: response.message,
                  type:"warning"
                })
              }
            },error : function(xhr, status, error){
              $("#addPostModal").modal('hide');
              var err = eval("(" + xhr.responseText + ")");
              //console.log(err);
              swal(err.message.slice(err.message.indexOf('>:'),err.message.indexOf('(SQL:')).replace('>:','')); 
            },
            cache: false,
            contentType: false,
            processData: false
          }) //ajax ends
        } 
      }); 
}

</script>  


<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/relaxation/add-relaxation.blade.php ENDPATH**/ ?>