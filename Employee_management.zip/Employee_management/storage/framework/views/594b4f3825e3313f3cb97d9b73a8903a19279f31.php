<?php $__env->startSection('title', 'AQUATIC'); ?>
<?php $__env->startSection('content'); ?>
     <!--Page Title-->
    <section class="page-title" style="background-image:url(../public/images/innerbanner.jpg);">
        <div class="auto-container">
            <div class="inner-container clearfix">
                <div class="title-box">
                    <h1>Our Team</h1>
                </div>
                <ul class="bread-crumb clearfix">
                    <li><a href="index.html"><span class="fas fa-home"></span> Home</a></li>
                    <li><span class="far fa-arrow-alt-circle-right"></span>Our Team</li>
                </ul>
            </div>
        </div>
    </section>
    <!--End Page Title-->
    <section class="team-section">
        <div class="auto-container">
            <div class="row">
                <!-- Image Column -->
               <div class="team-block col-lg-3 col-md-6 col-sm-12">
                    <div class="inner-box">
                        <div class="image-box">
                            <div class="image"><a href="#"><img src="<?php echo e(asset('images/team/7.jpg')); ?>" alt="" class="img-thumbnail"></a></div>
                            <ul class="social-links">
                                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fab fa-skype"></i></a></li>
                                <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                            </ul>
                        </div>
                        <div class="info-box">
                            <h3 class="name"><a href="team.html">Member Name</a></h3>
                            <span class="designation">Designation</span>
                        </div>
                    </div>
                </div>

                 <div class="team-block col-lg-3 col-md-6 col-sm-12">
                    <div class="inner-box">
                        <div class="image-box">
                            <div class="image"><a href="#"><img src="<?php echo e(asset('images/team/8.jpg')); ?>" alt="" class="img-thumbnail"></a></div>
                            <ul class="social-links">
                                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fab fa-skype"></i></a></li>
                                <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                            </ul>
                        </div>
                        <div class="info-box">
                            <h3 class="name"><a href="team.html">Member Name</a></h3>
                            <span class="designation">Designation</span>
                        </div>
                    </div>
                </div>

                 <div class="team-block col-lg-3 col-md-6 col-sm-12">
                    <div class="inner-box">
                        <div class="image-box">
                            <div class="image"><a href="#"><img src="<?php echo e(asset('images/team/9.jpg')); ?>" alt="" class="img-thumbnail"></a></div>
                            <ul class="social-links">
                                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fab fa-skype"></i></a></li>
                                <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                            </ul>
                        </div>
                        <div class="info-box">
                            <h3 class="name"><a href="team.html">Member Name</a></h3>
                            <span class="designation">Designation</span>
                        </div>
                    </div>
                </div>

                 <div class="team-block col-lg-3 col-md-6 col-sm-12">
                    <div class="inner-box">
                        <div class="image-box">
                            <div class="image"><a href="#"><img src="<?php echo e(asset('images/team/10.jpg')); ?>" alt="" class="img-thumbnail"></a></div>
                            <ul class="social-links">
                                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fab fa-skype"></i></a></li>
                                <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                            </ul>
                        </div>
                        <div class="info-box">
                            <h3 class="name"><a href="team.html">Member Name</a></h3>
                            <span class="designation">Designation</span>
                        </div>
                    </div>
                </div>

                <div class="team-block col-lg-3 col-md-6 col-sm-12">
                    <div class="inner-box">
                        <div class="image-box">
                            <div class="image"><a href="#"><img src="<?php echo e(asset('images/team/7.jpg')); ?>" alt="" class="img-thumbnail"></a></div>
                            <ul class="social-links">
                                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fab fa-skype"></i></a></li>
                                <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                            </ul>
                        </div>
                        <div class="info-box">
                            <h3 class="name"><a href="team.html">Member Name</a></h3>
                            <span class="designation">Designation</span>
                        </div>
                    </div>
                </div>

                <div class="team-block col-lg-3 col-md-6 col-sm-12">
                    <div class="inner-box">
                        <div class="image-box">
                            <div class="image"><a href="#"><img src="<?php echo e(asset('images/team/8.jpg')); ?>" alt="" class="img-thumbnail"></a></div>
                            <ul class="social-links">
                                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fab fa-skype"></i></a></li>
                                <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                            </ul>
                        </div>
                        <div class="info-box">
                            <h3 class="name"><a href="team.html">Member Name</a></h3>
                            <span class="designation">Designation</span>
                        </div>
                    </div>
                </div>
                <div class="team-block col-lg-3 col-md-6 col-sm-12">
                    <div class="inner-box">
                        <div class="image-box">
                            <div class="image"><a href="#"><img src="<?php echo e(asset('images/team/9.jpg')); ?>" alt="" class="img-thumbnail"></a></div>
                            <ul class="social-links">
                                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fab fa-skype"></i></a></li>
                                <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                            </ul>
                        </div>
                        <div class="info-box">
                            <h3 class="name"><a href="team.html">Member Name</a></h3>
                            <span class="designation">Designation</span>
                        </div>
                    </div>
                </div>

                <div class="team-block col-lg-3 col-md-6 col-sm-12">
                    <div class="inner-box">
                        <div class="image-box">
                            <div class="image"><a href="#"><img src="<?php echo e(asset('images/team/10.jpg')); ?>" alt="" class="img-thumbnail"></a></div>
                            <ul class="social-links">
                                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fab fa-skype"></i></a></li>
                                <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                            </ul>
                        </div>
                        <div class="info-box">
                            <h3 class="name"><a href="team.html">Member Name</a></h3>
                            <span class="designation">Designation</span>
                        </div>
                    </div>
                </div>
              
            </div>
        </div>
    </section>   
 <?php $__env->startPush('scripts'); ?>
 <!-- Write down javascript here -->
 <?php $__env->stopPush(); ?>   
<?php $__env->stopSection(); ?>   
<?php echo $__env->make('frontend-layout.frontend-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\aquatic\resources\views/ourteam.blade.php ENDPATH**/ ?>