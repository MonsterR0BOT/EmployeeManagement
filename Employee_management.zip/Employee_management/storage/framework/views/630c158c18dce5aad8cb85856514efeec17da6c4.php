  <?php $__env->startSection('title', 'PROMOTION'); ?> <?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>View Promotion Request</h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Department Requisition</a></li>
            <li class="active">View Promotion</li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="bs-example">
                   <div class="accordion" id="accordionExample">
                    <div class="box">
                            <div class="card-header" id="headingOne">
                                <a data-toggle="collapse" data-target="#collapseOne" class="accordianheading">
                                    <div class="row">
                                        <div class="col-md-11">
                                            <h5>Form of Reference</h5>
                                        </div>
                                        <div class="col-md-1"><i class="fa fa-plus-circle faicon acrdplus"></i></div>
                                    </div>
                                </a>
                            </div>
                            <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                                <div class="card-body">
                                    <div class="box-body">
                                        <div class="formsecalt row">
                                            <div class="col-md-3 bg-color1">
                                                <div class="paddingsmlmin">1.</div>
                                                <div class="paddingsmlmax">Name(s) of the Department</div>
                                            </div>
                                            <div class="col-md-3">Agriculture & F.E Department
                                            </div>
                                            <div class="col-md-3 bg-color1">
                                                <div class="paddingsmlmin">2.</div>
                                                <div class="paddingsmlmax">Name of the posts to be filled up</div>
                                            </div>
                                            <div class="col-md-3">
                                                Assistant Executive Engineer
                                            </div>
                                            <div class="clearfix"></div>
                                        </div>
                                        <div class="formsec row">
                                            <div class="col-md-6 bg-color1">
                                                <div class="paddinglessmin">3.</div>
                                                <div class="paddinglessmax">Group to which promotional posts to ('A' Or 'B')with Scale of Pay &amp; G.P</div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label>Group A </label>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label>Lorem Ipsum has been </label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="formsecalt row">
                                            <div class="col-md-6 bg-color1">
                                                <div class="paddinglessmin">4.</div>
                                                <div class="paddinglessmax">Whether the previous proposal for such promotion has been finalised on recommendation of the O.P.S.C. If So</div>
                                            </div>
                                            <div class="col-md-2">Yes </div>
                                            <div class="col-md-4">
                                                <div align="left"> <span class="bg-color1">Ref. No. &amp; Date of D.P.C/S.B.</span> <span>11555AGHH</span> &amp; <span>12/9/2019</span> </div>
                                            </div>
                                        </div>
                                        <div class="formsecalt row">
                                            <div class="col-md-3 bg-color1">Ref. No. &amp; Date of reference to O.P.S.C.</div>
                                            <div class="col-md-3"><span>12234EWRSG</span> &amp; <span>15/05/2015</span></div>
                                            <div class="col-md-3 bg-color1">Ref. No. &amp; Date of recommendation of O.P.S.C.</div>
                                            <div class="col-md-3"><span>123DSAA</span> &amp; <span>12/05/2010</span></div>
                                        </div>
                                        <div class="formsec row">
                                            <div class="col-md-6 bg-color1">
                                                <div class="paddinglessmin">5.</div>
                                                <div class="paddinglessmax">Date of D.P.C/S.B. in respect of the present proposal (Attested copy of the proceeding of the DPC/SB to be furnished)</div>
                                            </div>
                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <label>14/02/2015</label>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group"> <a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> View File</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="formsecalt row">
                                            <div class="col-md-6 bg-color1">
                                                <div class="paddinglessmin">6.</div>
                                                <div class="paddinglessmax">Total no of sanctioned posts at the level of promotion grade</div>
                                            </div>
                                            <div class="col-md-6">58</div>
                                        </div>
                                        <div class="formsec row">
                                            <div class="col-md-6 bg-color1">
                                                <div class="paddinglessmin">7.</div>
                                                <div class="paddinglessmax">a) Number of vacancies for which the DPC/S.B. met (Category wise)</div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-3"><span><strong>SC</strong></span> : <span>6</span></div>
                                                    <div class="col-md-3"><span><strong>ST</strong></span> : <span>5</span></div>
                                                    <div class="col-md-3"><span><strong>UR</strong></span> : <span>4</span></div>
                                                    <div class="col-md-3"><span><strong>TOTAL</strong></span> : <span>15</span></div>
                                                </div>
                                            </div>
                                            <div class="clearfix"></div>
                                            <div class="col-md-6 bg-color1">
                                                <div class="txtindenting"> b) Number of vacancies now proposed to be filled up(Category-wise)</div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-3">
                                                        <div class="form-group"> <span><strong>SC</strong></span> : <span>7</span> </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="form-group"> <span><strong>ST</strong></span> : <span>5</span> </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="form-group"> <span><strong>UR</strong></span> : <span>2</span> </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="form-group"> <span><strong>TOTAL</strong></span> : <span>14</span> </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="clearfix"></div>
                                            <div class="col-md-6 bg-color1">
                                                <div class="txtindenting"> c) Number of vacancies set apart & unfilled for subsequent consideration due to non-availability CCRs of Senior Officers in the zone of consideration.</div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-3"> <span><strong>SC</strong></span> : <span>7</span> </div>
                                                    <div class="col-md-3"> <span><strong>ST</strong></span> : <span>5</span> </div>
                                                    <div class="col-md-3"> <span><strong>UR</strong></span> : <span>3</span> </div>
                                                    <div class="col-md-3"> <span><strong>TOTAL</strong></span> : <span>15</span> </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="formsecalt row">
                                            <div class="col-md-6 bg-color1">
                                                <div class="paddinglessmin">8.</div>
                                                <div class="paddinglessmax">Designation of feeder posts/grades from which officers are eligible for promotion</div>
                                            </div>
                                            <div class="col-md-6">Executive Engineer</div>
                                        </div>
                                        <div class="formsec row">
                                            <div class="col-md-6 bg-color1">
                                                <div class="paddinglessmin">9.</div>
                                                <div class="paddinglessmax">Name of the recruitment Rules regulatig the promotion proposed. If no such Rules exist. mention the number and date of Resolution/ Notification/ Office Memorandum proceeding eligibility criteria. (Copy of Rules with upto date ammendments/G.O./ Resolution/ OM/ Notification to be appended)</div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-3">Engineer</div>
                                                    <div class="col-md-3">AA12233</div>
                                                    <div class="col-md-3">12/02/2019</div>
                                                </div>
                                                <div class="row">
                                                 <div class="col-md-6"><a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> View Files</a></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="formsecalt row">
                                            <div class="col-md-6 bg-color1">
                                                <div class="paddinglessmin">10.</div>
                                                <div class="paddinglessmax">(a) Number of eligible officers in the zone of consideration as per relevant Rules</div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-3"><span><strong>SC</strong></span> : <span>3</span></div>
                                                    <div class="col-md-3"><span><strong>ST</strong></span> : <span>4</span></div>
                                                    <div class="col-md-3"><span><strong>UR</strong></span> : <span>7</span></div>
                                                    <div class="col-md-3"><span><strong>TOTAL</strong></span> : <span>8</span></div>
                                                </div>
                                            </div>
                                            <div class="clearfix"></div>
                                            <div class="col-md-6 bg-color1">
                                                <div class="txtindenting">(b) Number of officers found suitable for promotion</div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-3"><span><strong>SC</strong></span> : <span>2</span></div>
                                                    <div class="col-md-3"><span><strong>ST</strong></span> : <span>4</span></div>
                                                    <div class="col-md-3"><span><strong>UR</strong></span> : <span>5</span></div>
                                                    <div class="col-md-3"><span><strong>TOTAL</strong></span> : <span>11</span></div>
                                                </div>
                                            </div>
                                            <div class="clearfix"></div>
                                            <div class="col-md-6 bg-color1">
                                                <div class="txtindenting">(c) Number of officers in the zone of consideration</div>
                                                <div class="txtindentingone">i) Against whom Disciplinary Proceedings/Vigilance Cases/Criminal Case pending. (Copy of the report on Vigilance Case/Criminal Case/Disciplinary Proceedings to be enclosed)</div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-3"><span><strong>SC</strong></span> : <span>2</span></div>
                                                    <div class="col-md-3"><span><strong>ST</strong></span> : <span>3</span></div>
                                                    <div class="col-md-3"><span><strong>UR</strong></span> : <span>5</span></div>
                                                    <div class="col-md-3"><span><strong>TOTAL</strong></span> : <span>5</span></div>
                                                </div>
                                            </div>
                                            <div class="formsecalt row">
                                                <div class="col-md-6 bg-color1">
                                                    <div class="txtindentingone">ii) Not considered due to want of CCRs/PARs.</div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="row">
                                                        <div class="col-md-3"><span><strong>SC</strong></span> : <span>3</span></div>
                                                        <div class="col-md-3"><span><strong>ST</strong></span> : <span>4</span></div>
                                                        <div class="col-md-3"><span><strong>UR</strong></span> : <span>5</span></div>
                                                        <div class="col-md-3"><span><strong>TOTAL</strong></span> : <span>7</span></div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 bg-color1">
                                                    <div class="txtindentingone">iii) Not selected due to adverse remarks.</div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="row">
                                                        <div class="col-md-3"><span><strong>SC</strong></span> : <span>5</span></div>
                                                        <div class="col-md-3"><span><strong>ST</strong></span> : <span>2</span></div>
                                                        <div class="col-md-3"><span><strong>UR</strong></span> : <span>1</span></div>
                                                        <div class="col-md-3"><span><strong>TOTAL</strong></span> : <span>10</span></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- <div class="col-md-6">(Copy of the report on Vigilance Case/Criminal Case/Disciplinary Proceedings to be enclosed).</div>
                                            <div class="col-md-6"><a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> View pdf Files</a></div> -->
                                        </div>
                                        <div class="formsec row">
                                            <div class="col-md-6 bg-color1">
                                                <div class="paddinglessmin">11.</div>
                                                <div class="paddinglessmax">No. Of Officers after recommendation of DPC/SB given ad hoc promotion</div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-3"><span><strong>SC</strong></span> : <span>3</span></div>
                                                    <div class="col-md-3"><span><strong>ST</strong></span> : <span>5</span></div>
                                                    <div class="col-md-3"><span><strong>UR</strong></span> : <span>7</span></div>
                                                    <div class="col-md-3"><span><strong>TOTAL</strong></span> : <span>10</span></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="formsecalt row">
                                            <div class="col-md-6 bg-color1">
                                                <div class="paddinglessmin">12.</div>
                                                <div class="paddinglessmax">i) Whether 5 years CCRs dossiers of all officers recommended for promotion up to the junior-most officer nominated are enclosed.</div>
                                            </div>
                                            <div class="col-md-6">Yes</div>
                                            <div class="col-md-6 bg-color1">
                                                <div class="txtindenting">ii) Period of CCRs perused by the D.P.C/S.B.</div>
                                            </div>
                                            <div class="col-md-3">Yes</div>
                                            <div class="col-md-3"></div>
                                        </div>
                                        <div class="formsec row">
                                            <div class="col-md-6 bg-color1">
                                                <div class="paddinglessmin">13.</div>
                                                <div class="paddinglessmax">Whether all the officers under consideration are regular in the feeder grade on recommendation of the O.P.S.C.,where required?<br /> (Copy of the recommendation letter of the O.P.S.C. to be furnished)</div>
                                            </div>
                                            <div class="col-md-3"><span> Yes</span></div>
                                            <div class="col-md-3"><a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> View Files</a></div>
                                        </div>
                                        <div class="formsecalt row">
                                            <div class="col-md-6 bg-color1">
                                                <div class="form-group">
                                                    <div class="paddinglessmin">14.</div>
                                                    <div class="paddinglessmax">Whether the D.P.C/S.B. has used /perused the following documents (attested copies to be enclosed):-</div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">Yes</div>
                                            <div class="col-md-6 bg-color1">
                                                <div class="txtindenting"> i) Authenticated (duly signed) copy of the Final Gradation List as on the Date D.P.C/SB containing Date of Birth,Date of appointment to the feeder grade and other service particulars of the officers under consideration</div>
                                            </div>
                                            <div class="col-md-6"><a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> View Files</a></div>
                                            <div class="col-md-6 bg-color1">
                                                <div class="txtindenting">(ii)Statement (duly signed) showing assessment of CCRs of the officers under consideration</div>
                                            </div>
                                            <div class="col-md-3">Yes </div>
                                        </div>
                                        <div class="formsec row">
                                            <div class="col-md-6 bg-color1">
                                                <div class="col-md-1 paddinglessmin">15.</div>
                                                <div class="col-md-11 paddinglessmax">Whether reference made expected to reach Commission within 60 days of date of DPC/SB meeting.If not,reason thereof..</div>
                                                <div class="clearfix"></div>
                                            </div>
                                            <div class="col-md-6">Yes <br/>Lorem iplusm</div>
                                            <div class="clearfix"></div>
                                        </div>
                                        <div class="formsecalt row">
                                            <div class="col-md-6 bg-color1">
                                                <div class="col-md-1 paddinglessmin">16.</div>
                                                <div class="col-md-11 paddinglessmax">Form of reference duly filled and ink-signed is enclosed.</div>
                                            </div>
                                            <div class="col-md-6">Yes</div>
                                        </div>
                                        <div align="right">
                              <div class="mrt_10 mrb_10">
                                <a href="<?php echo e(url('view-promotion-print')); ?>" target="_blank" class="btn btn-secondary" id="printbtn"><i class="fa fa-print"></i> Print</a>
                                <a href="<?php echo e(url('manage-promotion-request-hod')); ?>"><button class="btn btn-danger">Cancel</button></a>
                              </div>
                            </div>
                            <div class="clearfix"></div>
                                    </div>
                                    
                                </div>
                            </div>
                    </div>
                    <div class="box">
                        <div class="card-header" id="headingTwo">
                            <a data-toggle="collapse" data-target="#collapseTwo" class="accordianheading">
                                <div class="row">
                                    <div class="col-md-11">
                                        <h5>Details of Eligible  Officer</h5>
                                    </div>
                                    <div class="col-md-1"><i class="fa fa-plus-circle faicon acrdplus"></i></div>
                                </div>
                                <div class="clearfix"></div>
                            </a>
                        </div>
                        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                            <div class="box-body">
                                
                                    <div class="col-md-12">
                                        <div class="row listview">
                                            <div class="col-md-2">1.<a href="#" data-toggle="modal" data-target="#officerModal" data-backdrop="static" data-keyboard="false">Amresh Sahoo</a></div>
                                            <div class="col-md-2 coldivider">Dy. Secy</div>
                                            <div class="col-md-2 coldivider">EMP14</div>
                                            <div class="col-md-2 coldivider">16/7/1981</div>
                                            <div class="col-md-2 coldivider"><a href="#" data-toggle="modal" data-target="#officerModal" data-backdrop="static" data-keyboard="false">View Details</a></div>
                                            <div class="col-md-2 coldivider"><a href="#" data-toggle="modal" data-target="#ccrModal" data-backdrop="static" data-keyboard="false">View Uploaded Files</a></div>
                                            
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-12">
                                        <div class="row listview">
                                            <div class="col-md-2">2.<a href="#" data-toggle="modal" data-target="#officerModal" data-backdrop="static" data-keyboard="false">Nilamani Khuntia</a></div>
                                            <div class="col-md-2 coldivider">Dy. Secy</div>
                                            <div class="col-md-2 coldivider">EMP14</div>
                                            <div class="col-md-2 coldivider">16/7/1981</div>
                                            <div class="col-md-2 coldivider"><a href="#" data-toggle="modal" data-target="#officerModal" data-backdrop="static" data-keyboard="false">View Details</a></div>
                                            <div class="col-md-2 coldivider"><a href="#" data-toggle="modal" data-target="#ccrModal" data-backdrop="static" data-keyboard="false">View Uploaded Files</a></div>
                                            
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-12">
                                        <div class="row listview">
                                            <div class="col-md-2">3.<a href="#" data-toggle="modal" data-target="#officerModal" data-backdrop="static" data-keyboard="false">Janardan Sahu</a></div>
                                            <div class="col-md-2 coldivider">Dy. Secy</div>
                                            <div class="col-md-2 coldivider">EMP14</div>
                                            <div class="col-md-2 coldivider">16/7/1981</div>
                                            <div class="col-md-2 coldivider"><a href="#" data-toggle="modal" data-target="#officerModal" data-backdrop="static" data-keyboard="false">View Details</a></div>
                                            <div class="col-md-2 coldivider"><a href="#" data-toggle="modal" data-target="#ccrModal" data-backdrop="static" data-keyboard="false">View Uploaded Files</a></div>
                                            
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-12">
                                        <div class="row listview">
                                            <div class="col-md-2">4.<a href="#" data-toggle="modal" data-target="#officerModal" data-backdrop="static" data-keyboard="false">Mahendra Dandapat</a></div>
                                            <div class="col-md-2 coldivider">Dy. Secy</div>
                                            <div class="col-md-2 coldivider">EMP14</div>
                                            <div class="col-md-2 coldivider">16/7/1981</div>
                                            <div class="col-md-2 coldivider"><a href="#" data-toggle="modal" data-target="#officerModal" data-backdrop="static" data-keyboard="false">View Details</a></div>
                                            <div class="col-md-2 coldivider"><a href="#" data-toggle="modal" data-target="#ccrModal" data-backdrop="static" data-keyboard="false">View Uploaded Files</a></div>
                                            
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-12">
                                        <div class="row listview">
                                            <div class="col-md-2">5.<a href="#" data-toggle="modal" data-target="#officerModal" data-backdrop="static" data-keyboard="false">Lalit Murti</a></div>
                                            <div class="col-md-2 coldivider">Dy. Secy</div>
                                            <div class="col-md-2 coldivider">EMP14</div>
                                            <div class="col-md-2 coldivider">16/7/1981</div>
                                            <div class="col-md-2 coldivider"><a href="#" data-toggle="modal" data-target="#officerModal" data-backdrop="static" data-keyboard="false">View Details</a></div>
                                            <div class="col-md-2 coldivider"><a href="#" data-toggle="modal" data-target="#ccrModal" data-backdrop="static" data-keyboard="false">View Uploaded Files</a></div>
                                            
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-12">
                                        <div class="row listview">
                                            <div class="col-md-2">6.<a href="#" data-toggle="modal" data-target="#officerModal" data-backdrop="static" data-keyboard="false">Sashibhusan Bag</a></div>
                                            <div class="col-md-2 coldivider">Dy. Secy</div>
                                            <div class="col-md-2 coldivider">EMP14</div>
                                            <div class="col-md-2 coldivider">16/7/1981</div>
                                            <div class="col-md-2 coldivider"><a href="#" data-toggle="modal" data-target="#officerModal" data-backdrop="static" data-keyboard="false">View Details</a></div>
                                            <div class="col-md-2 coldivider"><a href="#" data-toggle="modal" data-target="#ccrModal" data-backdrop="static" data-keyboard="false">View Uploaded Files</a></div>
                                            
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-12">
                                        <div class="row listview">
                                            <div class="col-md-2">7.<a href="#" data-toggle="modal" data-target="#officerModal" data-backdrop="static" data-keyboard="false">Santanu Muduli</a></div>
                                            <div class="col-md-2 coldivider">Dy. Secy</div>
                                            <div class="col-md-2 coldivider">EMP14</div>
                                            <div class="col-md-2 coldivider">16/7/1981</div>
                                            <div class="col-md-2 coldivider"><a href="#" data-toggle="modal" data-target="#officerModal" data-backdrop="static" data-keyboard="false">View Details</a></div>
                                            <div class="col-md-2 coldivider"><a href="#" data-toggle="modal" data-target="#ccrModal" data-backdrop="static" data-keyboard="false">View Uploaded Files</a></div>
                                            
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-12">
                                        <div class="row listview">
                                            <div class="col-md-2">8.<a href="#" data-toggle="modal" data-target="#officerModal" data-backdrop="static" data-keyboard="false">Amresh Sahoo</a></div>
                                            <div class="col-md-2 coldivider">Dy. Secy</div>
                                            <div class="col-md-2 coldivider">EMP14</div>
                                            <div class="col-md-2 coldivider">16/7/1981</div>
                                            <div class="col-md-2 coldivider"><a href="#" data-toggle="modal" data-target="#officerModal" data-backdrop="static" data-keyboard="false">View Details</a></div>
                                            <div class="col-md-2 coldivider"><a href="#" data-toggle="modal" data-target="#ccrModal" data-backdrop="static" data-keyboard="false">View Uploaded Files</a></div>
                                            
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-12">
                                        <div class="row listview">
                                            <div class="col-md-2">9.<a href="#" data-toggle="modal" data-target="#officerModal" data-backdrop="static" data-keyboard="false">Amresh Sahoo</a></div>
                                            <div class="col-md-2 coldivider">Dy. Secy</div>
                                            <div class="col-md-2 coldivider">EMP14</div>
                                            <div class="col-md-2 coldivider">16/7/1981</div>
                                            <div class="col-md-2 coldivider"><a href="#" data-toggle="modal" data-target="#officerModal" data-backdrop="static" data-keyboard="false">View Details</a></div>
                                            <div class="col-md-2 coldivider"><a href="#" data-toggle="modal" data-target="#ccrModal" data-backdrop="static" data-keyboard="false">View Uploaded Files</a></div>
                                            
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-12">
                                        <div class="row listview">
                                            <div class="col-md-2">10.<a href="#" data-toggle="modal" data-target="#officerModal" data-backdrop="static" data-keyboard="false">Amresh Sahoo</a></div>
                                            <div class="col-md-2 coldivider">Dy. Secy</div>
                                            <div class="col-md-2 coldivider">EMP14</div>
                                            <div class="col-md-2 coldivider">16/7/1981</div>
                                            <div class="col-md-2 coldivider"><a href="#" data-toggle="modal" data-target="#officerModal" data-backdrop="static" data-keyboard="false">View Details</a></div>
                                            <div class="col-md-2 coldivider"><a href="#" data-toggle="modal" data-target="#ccrModal" data-backdrop="static" data-keyboard="false">View Uploaded Files</a></div>
                                            
                                        </div>
                                    </div>
                                    <div align="right">
                                      <div class="mrt_10 mrb_10">
                                        <a href="<?php echo e(url('manage-promotion-request')); ?>"><button class="btn btn-danger">Cancel</button></a>
                                      </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                         </div>
                    </div>
                    <div class="box">
                        <div class="card-header" id="headingThree">
                            <a data-toggle="collapse" data-target="#collapseThree" class="accordianheading">
                                <div class="row">
                                    <div class="col-md-11">
                                        <h5>Document Checklist</h5>
                                    </div>
                                    <div class="col-md-1"><i class="fa fa-plus-circle faicon acrdplus"></i></div>
                                </div>
                            </a>
                        </div>
                        <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                          <div class="box-body">
                            <div class="card-body">
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="row listview">
                                            <div class="col-md-11">1. Recruitment Rule</div>
                                            <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="row listview">
                                            <div class="col-md-11">2. Govt Resolution/Order/Notification/Office Memorandum</div>
                                            <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="row listview">
                                            <div class="col-md-11">3. Previous DPC/SB proposal</div>
                                            <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="row listview">
                                            <div class="col-md-11">4. Previous concurrence of OPSC</div>
                                            <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="row listview">
                                            <div class="col-md-11">5. Proceedings of criminal /vigilance/court cases</div>
                                            <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="row listview">
                                            <div class="col-md-11">6. CCRs/PARs of the employee</div>
                                            <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="row listview">
                                            <div class="col-md-11">7. Present proceedings of DPC/SB</div>
                                            <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="row listview">
                                            <div class="col-md-11">8. Recommendation letter of OPSC related to feeder grade regularization</div>
                                            <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="row listview">
                                            <div class="col-md-11">9. Signed copy of final gradation list</div>
                                            <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="row listview">
                                            <div class="col-md-11">10. Duly signed copy of assessment of CCR statement</div>
                                            <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                                        </div>
                                    </div>
                                    
                                </div>
                              </div>
                            </div>
                             <div align="right">
                              <div class="mrt_10 mrb_10">
                                <a href="<?php echo e(url('manage-promotion-request-hod')); ?>"><button class="btn btn-danger">Cancel</button></a>
                              </div>
                            </div>
                            <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                    <div class="box">
                        <div class="card-header" id="headingFour">
                            <a data-toggle="collapse" data-target="#collapseFour" class="accordianheading">
                                <div class="row">
                                    <div class="col-md-11">
                                        <h5>Officer Comments</h5>
                                    </div>
                                    <div class="col-md-1"><i class="fa fa-plus-circle faicon acrdplus"></i></div>
                                </div>
                                <div class="clearfix"></div>
                            </a>
                        </div>
                        <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
                            <div class="card-body">
                                <div class="box-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <!-- The timeline -->
                                            <ul class="timeline timeline-inverse">
                                                <!-- timeline time label -->
                                                <li class="time-label"> <span class="bg-red">10 Dec. 2019</span>
                                                </li>
                                                <!-- /.timeline-label -->
                                                <!-- timeline item -->
                                                <li>
                                                    <i class="fa fa-user bg-blue"></i>
                                                    <div class="timeline-item"><span class="time"><i class="fa fa-clock-o"></i> 10 Dec. 2019 12:05:20</span>
                                                        <h3 class="timeline-header"><a href="#">Prasanna Behera</a>, Office Asst, Agriculture & F.E Department</h3>
                                                        <div class="timeline-body">A new promotional reqest is posted.</div>
                                                        <!-- <div class="timeline-footer">     <a class="btn btn-primary btn-xs">Read more</a>     <a class="btn btn-danger btn-xs">Delete</a>   </div> -->
                                                    </div>
                                                </li>
                                                <!-- END timeline item -->
                                                <!-- timeline item -->
                                                <li>
                                                    <i class="fa fa-comments bg-yellow"></i>
                                                    <div class="timeline-item"><span class="time"><i class="fa fa-clock-o"></i> 10 Dec. 2019 15:20:35</span>
                                                        <h3 class="timeline-header"><a href="#">Prakash Nayak</a>, HOD Dept, Agriculture & F.E Department</h3>
                                                        <div class="timeline-body"> The promotional request is verified and found ok and send to OPSC for further verification. </div>
                                                    </div>
                                                </li>
                                                <!-- END timeline item -->
                                               
                                                <li> <i class="fa fa-clock-o bg-gray"></i></li>
                                            </ul>
                                          <div align="right" class="mrt_10 mrb_10" >
                                            <button class="btn btn-success" data-toggle="modal" data-target="#comments" data-backdrop="static" data-keyboard="false" id="btnGiveComments">Give your comments</button>
                                             <a href="<?php echo e(url('view-promotion-print')); ?>" target="_blank" class="btn btn-secondary" id="printbtn"><i class="fa fa-print"></i> Print</a>
                                            <a href="<?php echo e(url('manage-promotion-request-hod')); ?>"><button class="btn btn-danger">Cancel</button></a>
                                            <div class="clearfix"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                	</div>
                <!-- /.box -->
            </div>
            <!-- /.col -->
            </div>
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<!-- View file Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <!-- Modal Header -->
     <div class="modal-header">
       <h4 class="modal-title">Upload Files</h4>
       <!-- <button type="button" class="close" data-dismiss="modal">×</button> -->
    </div>
      <!-- Modal body -->
      <div class="modal-body">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-4 bg-color1">DPC/SB</div>
                    <div class="col-md-2"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                    <div class="col-md-4 bg-color1">Recruitment Rules</div>
                    <div class="col-md-2"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                    <div class="col-md-4 bg-color1">OM</div>
                    <div class="col-md-2"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                    <div class="col-md-4 bg-color1">Notification</div>
                    <div class="col-md-2"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                    <div class="col-md-4 bg-color1">Gradation List</div>
                    <div class="col-md-2"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                    <div class="col-md-4 bg-color1">Recommendation Letter</div>
                    <div class="col-md-2"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                    <div class="col-md-4 bg-color1">Resolution</div>
                    <div class="col-md-2"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                </div>
            </div>
      </div>
      <!-- Modal footer -->
      <div class="modal-footer" align="center">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!-- View file Modal -->
<!--officer Modal-->
<div class="modal" id="officerModal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <!-- Modal Header -->
     <div class="modal-header">
       <h4 class="modal-title">Officer's Profile</h4>
       <button type="button" class="close" data-dismiss="modal">×</button>
    </div>
      <!-- Modal body -->
      <div class="modal-body">
            <div class="row">
                <div align="right" class="col-md-12">
                            <!-- /.box-header -->
                    <div class="box-body">
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-3 bg-color1" align="left">Name of the eligible officers in the zone of</div>
                            <div class="col-md-3" align="left">Amaresh Prasad</div>
                            <div class="col-md-3 bg-color1" align="left">Type of promotion (Regular/Retrospective)</div>
                            <div class="col-md-3" align="left"> Regular</div>
                        </div>
                        <div class="row">
                            <div class="col-md-3 bg-color1" align="left">Employee Id</div>
                            <div class="col-md-3" align="left">EMP15</div>
                            <div class="col-md-3 bg-color1" align="left">Date of Birth</div>
                            <div class="col-md-3" align="left">20/11/1976</div>
                        </div>
                        <div class="row">
                            <div class="col-md-3 bg-color1" align="left"> Caste(SC/ST/General)</div>
                            <div class="col-md-3" align="left">SC</div>
                            <div class="col-md-3 bg-color1" align="left"> Name of the post to be filled up</div>
                            <div class="col-md-3" align="left"> Assistant Section Officer </div>
                        </div>
                        <div class="row">
                            <div class="col-md-3 bg-color1" align="left">Group of the promotional post</div>
                            <div class="col-md-3" align="left">ction Officer</div>
                            <div class="col-md-3 bg-color1" align="left">Scale of Pay</div>
                            <div class="col-md-3 form-group" align="left">5,200-200</div>
                        </div>
                        <div class="row">
                            <div class="col-md-3 bg-color1" align="left">Mention the back Period of Availability</div>
                            <div class="col-md-3" align="left">10 months</div>
                            <div class="col-md-3 bg-color1" align="left">Designation as per the feeder post/grade</div>
                            <div class="col-md-3" align="left">Section Officer</div>
                        </div>
                        <div class="row">   
                            <div class="col-md-3 bg-color1" align="left">Is the officer regular on feeder grade</div>
                            <div class="col-md-3" align="left">es</div>
                            <div class="col-md-3  bg-color1" align="left">Is the officer selected for promotion as per the recruitment rule.</div>
                            <div class="col-md-3" align="left">Yes</div>
                        </div>
                        <div class="row">
                            <div class="col-md-3 bg-color1" align="left">Is there any criminal case/disciplinary proceedings/vigilance case is pending</div>
                            <div class="col-md-3" align="left">Yes</div>
                            <div class="col-md-3  bg-color1" align="left">Availability of CCRs & PARs</div>
                            <div class="col-md-3" align="left">Yes</div>
                        </div>
                        <div class="row">
                            <div class="col-md-3 bg-color1" align="left">Period of Availability of CCRs & PARs</div>
                            <div class="col-md-3" align="left">Related Small Description Text and content</div>
                            <div class="col-md-3 bg-color1" align="left"> Is the officer given adhoc promotion DPC/SB </div>
                            <div class="col-md-3" align="left">yes </div>
                        </div>
                        <div class="row">   
                            <div class="col-md-3  bg-color1" align="left">Period of CCRs perused by DPC/SB</div>
                            <div class="col-md-3" align="left">10 months</div>
                            
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
         </div>
      </div>
      <!-- Modal footer -->
      <div class="modal-footer" align="center">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!--officer Modal-->
<!--CCR Modal-->
<div class="modal" id="ccrModal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <!-- Modal Header -->
     <div class="modal-header">
       <h4 class="modal-title">View Uploaded Files</h4>
       <button type="button" class="close" data-dismiss="modal">×</button>
    </div>
      <!-- Modal body -->
      <div class="modal-body">
            <div class="col-md-12">
                <div class="row">
                    <h6>CCR Files</h6>
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-3 bg-color1">Year 2012-2013</div>
                            <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                            <div class="col-md-3 bg-color1"> Year 2013-2014</div>
                            <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                            <div class="col-md-3 bg-color1">Year 2014-2015</div>
                            <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                            <div class="col-md-3 bg-color1">Year 2015-2016</div>
                            <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                            <div class="col-md-3 bg-color1">Year 2016-2017</div>
                            <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                            <div class="col-md-3 bg-color1">Year 2017-2018</div>
                            <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                            <div class="col-md-3 bg-color1">Year 2018-2019</div>
                            <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                           
                        </div>
                    </div>
                    <h6>Vigilance Cases/Criminal Cases/Disciplinary Proceedings</h6>
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-3 bg-color1">Vigilance</div>
                            <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                            <div class="col-md-3 bg-color1"> Criminal</div>
                            <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                            <div class="col-md-3 bg-color1">Vigilance</div>
                            <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                            <div class="col-md-3 bg-color1">Disciplinary proceedings</div>
                            <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                            <div class="col-md-3 bg-color1">Vigilance</div>
                            <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                           
                        </div>
                    </div>
                </div>
            </div>
      </div>
      <!-- Modal footer -->
      <div class="modal-footer" align="center">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!--CCR Modal-->

<!--vigilance Modal-->
<div class="modal" id="vigilanceModal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <!-- Modal Header -->
     <div class="modal-header">
       <h4 class="modal-title">View Vigilance Files</h4>
       <!-- <button type="button" class="close" data-dismiss="modal">×</button> -->
    </div>
      <!-- Modal body -->
      <div class="modal-body">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-3 bg-color1">Vigilance</div>
                            <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                            <div class="col-md-3 bg-color1"> Criminal</div>
                            <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                            <div class="col-md-3 bg-color1">Vigilance</div>
                            <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                            <div class="col-md-3 bg-color1">Disciplinary proceedings</div>
                            <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                            <div class="col-md-3 bg-color1">Vigilance</div>
                            <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                           
                        </div>
                    </div>
                </div>
            </div>
      </div>
      <!-- Modal footer -->
      <div class="modal-footer" align="center">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!--vigilance Modal-->

<!--Comments Modal-->
<div class="modal" id="comments">
  <div class="modal-dialog">
    <div class="modal-content">
      <!-- Modal Header -->
        <div class="modal-header">
        <h4 class="modal-title">Give your comments</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <!-- Modal body -->
      <div class="modal-body">
     <div class="col-md-12">
        <div class="modalstyleheader">
         <div class="row">
          <div class="col-md-7">
            <div class="row mrt_10">
                <div class="col-md-6">
                    <input type="radio" name="rdApprove" class="minimal" value="1"> Forward 
                </div>
                <div class="col-md-6">
                    <input type="radio" name="rdApprove" class="minimal" value="0"> Reassign
                </div>
            </div>
           </div>
           <div class="col-md-5">
             <select class="form-control">
                <option>--Select--</option>
                <option>Pramod Behera(SO)</option>
                <option>Subash Sahoo(SO)</option>
            </select>
           </div>
       </div>
       </div>   
     
     <div class="row">
      <div class="col-md-12"><textarea name="" id="txaComments" class="form-control" rows="5" placeholder="Give your comments... "></textarea>
      </div>
    </div>
    </div>
      </div>
      <!-- Modal footer -->
      <div class="modal-footer" align="center">
         <button class="btn btn-primary" onClick="submitComments()">Submit</button>
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<div class="modal" id="approveModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <!-- Modal Header -->
        <div class="modal-header">
        <h4 class="modal-title">Reference Information</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <!-- Modal body -->
      <div class="modal-body">
     <div class="col-md-12">
      
     <div class="row">
      <div class="col-md-12">
        <div id="txtmsg">
            <div class="row">
                <div class="col-md-6 bg-color1">Department Name:</div>
                <div class="col-md-6">Works</div>
            </div>
            <div class="row">
                <div class="col-md-6 bg-color1">Reference No:</div>
                <div class="col-md-6"><h6>PRO/2018-2019/001</h6></div>
            </div>
            <div class="row">
                <div class="col-md-6 bg-color1">Date of submission:</div>
                <div class="col-md-6">12-12-2019 12:00:45</div>
            </div>
            <div class="row">
                <div class="col-md-6 bg-color1">No of officers attached:</div>
                <div class="col-md-6">25</div>
            </div>
        </div>
      </div>
    </div>
    </div>
      </div>
      <!-- Modal footer -->
      <div class="modal-footer" align="center">
        <a href="<?php echo e(url('promotion-reference-print')); ?>" target="_blank" class="btn btn-secondary" id="printbtn"><i class="fa fa-print"></i> Print</a>
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!--Comments Modal-->
<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function(){
        // Add minus icon for collapse element which is open by default
        $(".collapse.show").each(function(){
          $(this).prev(".card-header").find(".fa").addClass("fa-minus-circle").removeClass("fa-plus-circle");
        });
        
        // Toggle plus minus icon on show hide of collapse element
        $(".collapse").on('show.bs.collapse', function(){
          $(this).prev(".card-header").find(".fa").removeClass("fa-plus-circle").addClass("fa-minus-circle");
        }).on('hide.bs.collapse', function(){
          $(this).prev(".card-header").find(".fa").removeClass("fa-minus-circle").addClass("fa-plus-circle");
        });
    });
</script>


<script>
    function submitComments(){
        if(validateForm()){
            //alert($("input[name='rdApprove']:checked").val());
            if($("input[name='rdApprove']:checked").val()==1){
                $("#comments").modal('hide');
                $("#approveModal").modal('show');
                $(".modal-title").html('Reference Information');
                //$("#txtmsg").html("PRO/2018-2019/001");
                //disable the submit button
                $("#btnGiveComments").attr("disabled", true);
            }else{
                $("#comments").modal('hide');
                $("#approveModal").modal('show');
                $(".modal-title").html('');
                $("#txtmsg").html("<h4>Application returned back to department user!</h4>");
                $("#printbtn").hide();
                $("#btnGiveComments").attr("disabled", true);
            }
        }
    }
    function validateForm(){
        //alert("alert");return false;
      if (!blankValidation("rdApprove","RadioButton", "Please select one option"))
          return false; 
      if (!blankValidation("txaComments","TextArea", "Comments can not be left blank"))
          return false;

      return true;
     }  
</script>
<?php $__env->stopPush(); ?> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/promotional/view-promotion-hod.blade.php ENDPATH**/ ?>