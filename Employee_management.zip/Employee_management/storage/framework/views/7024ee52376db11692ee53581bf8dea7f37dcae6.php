<?php $__env->startSection('title', 'AUDIT'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       MIS Promotional Annual Report
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">MIS Report</a></li>
        <li class="active">MIS Promotional Annual Report</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box"> 

            <div class="box-body">
            	<div id="demo" >
                <div class="search-field">
                    <div class="row">
    
                        <div class="col-md-2">
                            <div class="org-name">From Date</div>
                        </div>
                        <div class="col-md-2">
                            <input class="form-control datepicker" type="text" id="param1">
                        </div>
                        
                        <div class="col-md-1">
                            <div class="org-name">To Date</div>
                        </div>
                        <div class="col-md-2">
                            <input class="form-control datepicker" type="text" id="param2">
                        </div>
                        
                        <div class="col-md-1">
                            <div class="org-name">Department</div>
                        </div>
                        <div class="col-md-2">
                           <select class="form-control">
                           <option value="">--Select--</option>
                            <?php $__currentLoopData = $dept_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($val->TDM_Dept); ?>" ><?php echo e($val->TDM_Dept_Name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <button class="btn btn-primary" onClick="searchData()">Search</button>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12" align="right">
                        <a href="#" target="_blank" class="btn btn-default"><i class="fa fa-print"></i> Print</a>
                        <a href="#" target="_blank" class="btn btn-default"><i class="fa fa-file-pdf-o"></i> PDF</a>
                    </div>
                    </div>
                </div>
            </div> 
           
            <table id="listAllAnnualPromotedMIS" class="table table-bordered table-striped">
                <thead>  
                <tr> 
                  <th>Department</th>
                  <th>Application Received</th>
                  <th>Application Open</th>
                  <th>Application Pending</th>
                  <th>Application Disposed</th>
                  <th>Application Rejected</th> 
                  <th>Application Returned</th>
                  <th>Application Reassign</th>
                <!--   <th>Officer Promoted</th>  -->
                </tr>
                </thead>
                <tbody>
                
                </tbody>
            </table>
          </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content --> 
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('styles'); ?>
<!--Extra styles can written here -->
<?php $__env->stopPush(); ?>  
<?php $__env->startPush('scripts'); ?>

<script>
 $(function () {
  $('#listAllAnnualPromotedMIS').DataTable({
    'processing' : true,
    'serverSide' : true,
    'searching' : false,
    'ordering' : false,
    "ajax" : {
      url : "<?php echo e(url('PromotionalMIS/viewAnnualPromotionalMISthroughAjax')); ?>",
      'data' : function(d) {
        d.param1 = $('#param1').val();
        d.param2 = $('#param2').val();
        d.param3 = $('#param3').val();
      /*  d.param4 = $('#grouplist').val();
        d.param5 = $('#deptId').val();
        d.param6 = $('#postlist').val();
        d.param7 = $('#statuslist').val();
        d.param8 = $('#catlist').val();*/
 
      }

      
         
    },
    'dataSrc' : "",
    'columns' : [ {
      'data' : 'Department'
    },{
      'data' : 'totalApplicationRcvd'
    }, {
      'data' : 'openCount'
    }, {
      'data' : 'pendingCount'
    }, {
      'data' : 'DisposedCount'
    }, {
      'data' : 'rejectedCount'
    }, {
      'data' : 'returnedCount'
    }, {
      'data' : 'reassignCount'
    }

    ]
  });
  
  });


  //Method For Searching Records In The List
  function searchData() {
    $('#listAllPrmotionalData').DataTable().draw();
  }
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/mis/manage-mis-annual-report.blade.php ENDPATH**/ ?>