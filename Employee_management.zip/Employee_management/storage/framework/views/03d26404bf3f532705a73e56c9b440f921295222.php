<?php $__env->startSection('title', 'LOGIN'); ?>
<?php $__env->startSection('content'); ?>  
          <section id="" class="ls section_padding_top_40 columns_padding_30 bg-img">
                <div class="container">
                    <div class="row">
                        <div class="col-md-4 col-md-offset-4 login-bg" data-animation="fadeInUp" data-delay="600">
                          <h2>Login</h2>
                           <form action="<?php echo e(url('memberlogin/domemberLogin')); ?>" method="post" onSubmit="return validateForm()" autocomplete="off"> 
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                              <label for="email">Email:</label>
                              <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
                            </div>
                            <div class="form-group">
                              <label for="pwd">Password:</label>
                              <input type="password" class="form-control" id="password" placeholder="Enter password" name="password">
                            </div>
                            <div class="checkbox">
                              <label><input type="checkbox" name="remember"> Remember me</label>
                            </div>
                            <div class="col-md-10 col-md-offset-1">
                            Don't have an account! <a href="<?php echo e(url('home/showJoinus')); ?>" class="ml-2">Sign Up Here</a>
                            </div>
                            <div class="row">
                            <div class="col-md-4 col-md-offset-4">
                            <button type="submit" class="btn btn-default" >Submit</button>
                           </div>
                         </from>
                        </div>
                        </div>
                </div>
              <!--   onclick="window.location='showDashboard'" -->
            </section>
 <?php $__env->startPush('scripts'); ?>  
  <script>
    /* $(function () {
       $('input').iCheck({
         checkboxClass: 'icheckbox_square-blue',
         radioClass: 'iradio_square-blue',
         increaseArea: '20%' 
       });
     });*/
     function validateForm(){ //alert("here"); return false;
         if (!blankValidation("email", "TextField","Email is required"))
           return false;
         if (!RemoveSQLCharacter("email"))
           return false;
         if (!checkEmailId("email","Invalid email id !!!"))
           return false;
         if (!blankValidation("password", "TextField","Password is required"))
           return false; 
     }
    
  </script>
  <?php $__env->stopPush(); ?>
            <?php $__env->stopSection(); ?> 
<?php echo $__env->make('frontend-layout.frontend-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\wethefamily\resources\views/Login2.blade.php ENDPATH**/ ?>