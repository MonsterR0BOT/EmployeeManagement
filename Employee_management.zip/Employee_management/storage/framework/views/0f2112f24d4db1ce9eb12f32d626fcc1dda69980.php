 <?php $__env->startSection('title', 'DISCIPLINARY'); ?> <?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header"> 
        <h1>Add Disciplinary Request</h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">User</a></li>
            <li class="active">Add Disciplinary Request</li>
        </ol>
    </section>  
             
          <!-- 
            [TDD_DocumentType] => 5
            [TDD_DocumentName] => nkMUUz2fSyrayyp1aPd7hStrvQ2kjMHxtDhs5NhX.jpeg -->
    <!-- Main content -->
    <section class="content">
        <?php  // print "<pre>"; print_r($data);exit;
           $loginUserInfo = Helper::getLoginUserInfo();
            if(!empty($data)){ 
                $displinaryId = $data[0]->TDR_DisciplinaryRequest;
                $TDR_Deliquency_OfficerName  = $data[0]->TDR_Deliquency_OfficerName;
                $TDR_Deliquency_HRMSID = $data[0]->TDR_Deliquency_HRMSID;
                $TDR_Department  = $data[0]->TDR_Department ;
                $TDR_Current_Designation = $data[0]->TDR_Current_Designation;
                $TDR_Deliquency_Designation=$data[0]->TDR_Deliquency_Designation;
                $TDR_Deliquency_DOB = ($data[0]->TDR_Deliquency_DOB !='')?date("d-m-Y", strtotime($data[0]->TDR_Deliquency_DOB)):'';   
                $TDR_Deliquency_Period = $data[0]->TDR_Deliquency_Period;
                $TDR_Suspension_Statement  = $data[0]->TDR_Suspension_Statement; 
                $TDR_Suspension_FromDate = ($data[0]->TDR_Suspension_FromDate !='')?date("d-m-Y", strtotime($data[0]->TDR_Suspension_FromDate)):''; 
                $TDR_Suspension_ToDate = ($data[0]->TDR_Suspension_ToDate !='')?date("d-m-Y", strtotime($data[0]->TDR_Suspension_ToDate)):''; 
                $TDR_OCS_Rule = $data[0]->TDR_OCS_Rule;
                $TDR_Allegation_Statement = $data[0]->TDR_Allegation_Statement; 
                $TDR_Allegation_Date = ($data[0]->TDR_Allegation_Date !='')?date("d-m-Y", strtotime($data[0]->TDR_Allegation_Date)):'';
                $TDR_DfenceStmtSubmison_Date = ($data[0]->TDR_DfenceStmtSubmison_Date !='')?date("d-m-Y", strtotime($data[0]->TDR_DfenceStmtSubmison_Date)):'';
                $TDR_IsEnquiry_Conducted = $data[0]->TDR_IsEnquiry_Conducted;
                $TDR_IO_Designation  = $data[0]->TDR_IO_Designation; 
                $TDR_IO_PostedArea = $data[0]->TDR_IO_PostedArea;  
                $TDR_IOReport_SubmisionDate = ($data[0]->TDR_IOReport_SubmisionDate !='')?date("d-m-Y", strtotime($data[0]->TDR_IOReport_SubmisionDate)):'';
                $TDR_IsIOReport_SentToOficer = $data[0]->TDR_IsIOReport_SentToOficer;
                $TDR_DORepresent_Date = ($data[0]->TDR_DORepresent_Date !='')?date("d-m-Y", strtotime($data[0]->TDR_DORepresent_Date)):'';
                $TDR_BfScndShwCausNotic_PenalityImposed = $data[0]->TDR_BfScndShwCausNotic_PenalityImposed; 
                $TDR_SecondShowCauseNotice_Date = ($data[0]->TDR_SecondShowCauseNotice_Date !='')?date("d-m-Y", strtotime($data[0]->TDR_SecondShowCauseNotice_Date)):'';
                $TDR_SecndCauseNotice_ExplanatnDate = ($data[0]->TDR_SecndCauseNotice_ExplanatnDate !='')?date("d-m-Y", strtotime($data[0]->TDR_SecndCauseNotice_ExplanatnDate)):'';
                $TDR_IsDisagrementReson_Recorded = $data[0]->TDR_IsDisagrementReson_Recorded;  
                $TDR_IsConcurrance_ByDisplinaryAuthority  = $data[0]->TDR_IsConcurrance_ByDisplinaryAuthority; 
                $TDR_IsPenalityImpositnOrder_HasTaken = $data[0]->TDR_IsPenalityImpositnOrder_HasTaken;
                $TDR_IsCopyOfNotesEnclosed = $data[0]->TDR_IsCopyOfNotesEnclosed;  
                $TDR_IsDeclarationChecked  = $data[0]->TDR_IsDeclarationChecked; 
                $TDR_Complete_Status  = $data[0]->TDR_Complete_Status; 
                $modeId=$mode[0];
            }else{
                $displinaryId = '';
                $TDR_Deliquency_OfficerName  = '';
                $TDR_Deliquency_HRMSID = '';
                $TDR_Department  = $loginUserInfo->TUM_User_Dept;
                $TDR_Current_Designation ='';
                $TDR_Deliquency_Designation='';
                $TDR_Deliquency_DOB =''; 
                $TDR_Deliquency_Period ='';
                $TDR_Suspension_Statement  ='';
                $TDR_Suspension_FromDate =''; 
                $TDR_Suspension_ToDate ='';
                $TDR_OCS_Rule = 1 ;
                $TDR_Allegation_Statement = ''  ; 
                $TDR_Allegation_Date = ''  ;
                $TDR_DfenceStmtSubmison_Date =''; 
                $TDR_IsEnquiry_Conducted =1;
                $TDR_IO_Designation  = ''; 
                $TDR_IO_PostedArea ='';  
                $TDR_IOReport_SubmisionDate  =''; 
                $TDR_IsIOReport_SentToOficer =1;
                $TDR_DORepresent_Date =''; 
                $TDR_BfScndShwCausNotic_PenalityImposed =''; 
                $TDR_SecondShowCauseNotice_Date ='';
                $TDR_SecndCauseNotice_ExplanatnDate  = '' ; 
                $TDR_IsDisagrementReson_Recorded = 1 ;  
                $TDR_IsConcurrance_ByDisplinaryAuthority  = 1; 
                $TDR_IsPenalityImpositnOrder_HasTaken = 1 ;
                $TDR_IsCopyOfNotesEnclosed = 1;
                $TDR_IsDeclarationChecked = 0;
                $TDR_Complete_Status  = 0;
                $modeId='';
            } 
        ?>
        <input type="hidden" name="hdDisplineId" id="hdDisplineId" value="<?php echo e($displinaryId); ?>">
        <input type="hidden" name="currentDesigId" id="currentDesigId" value="<?php echo e($TDR_Current_Designation); ?>">
        <input type="hidden" name="pastDesigId" id="pastDesigId" value="<?php echo e($TDR_Deliquency_Designation); ?>">
        <input type="hidden" name="IODesigId" id="IODesigId" value="<?php echo e($TDR_IO_Designation); ?>">
        <input type="hidden" name="mode" id="mode" value="<?php echo e($modeId); ?>">   
        <input type="hidden" name="confirmationCheckedId" id="confirmationCheckedId" value="<?php echo e($TDR_IsDeclarationChecked); ?>">
        <input type="hidden" id="TDR_Complete_Status" value="<?php echo e($TDR_Complete_Status); ?>">
        <div class="row">
            <div class="col-md-12">
              <div class="bs-example">
                <div class="accordion" id="accordionExample">
                    <div class="box"> 
                        <div class="card-header" id="headingOne">
                            <a data-toggle="collapse" data-target="#collapseOne" class="accordianheading">
                                <div class="row">
                                    <div class="col-md-11">
                                        <h5>Form of Reference</h5></div>
                                    <div class="col-md-1"><i class="fa faicon acrdplus fa-plus-circle"></i></div>
                                </div>
                            </a> 
                        </div>
                        
                        <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                            <div class="card-body" autocomplete="off">
                                <div class="box-body">
                                    <div class="formsec row">
                                        <div class="col-md-3">
                                            <div class="paddingsmlmin">1.</div>
                                            <div class="paddingsmlmax">Name of the delinquent officer</div>
                                        </div>
                                        <div class="col-md-3">
                                            <input type="text" class="form-control" id="officerName" name="officerName" value="<?php echo e($TDR_Deliquency_OfficerName); ?>" autocomplete="off">
                                        </div>
                                        <div class="col-md-3">
                                             <div class="paddingsmlmin">2.</div>
                                             <div class="paddingsmlmax">Date of birth:</div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                                                </div>
                                                <input type="text" class="form-control pull-right datepicker" id="officerDOB" name="officerDOB" value="<?php echo e($TDR_Deliquency_DOB); ?>" autocomplete="off">
                                            </div> 
                                        </div>
                                    </div>

                                    <div class="formsecalt row">
                                         <div class="col-md-3">
                                              <div class="paddingsmlmin">3.</div> 
                                              <div class="paddingsmlmax">Name(s) of the Department</div>
                                         </div>
                                         <div class="col-md-3">
                                          
                                               <select class="form-control" name="departmentId" id="departmentId" onchange="deptChange()">
                                                  <option value="">--Select--</option>
                                                  <?php $__currentLoopData = $dept_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  <option value="<?php echo e($val->TDM_Dept); ?>" <?php if($TDR_Department == $val->TDM_Dept): ?> selected="selected" <?php endif; ?> ><?php echo e($val->TDM_Dept_Name); ?></option>
                                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                               </select>
                                         </div>
                                         <div class="col-md-3">
                                                <div class="paddingsmlmin">4.</div> 
                                                <div class="paddingsmlmax">Employee ID(HRMS)</div>
                                         </div>
                                         <div class="col-md-3">
                                              <input type="text" class="form-control" id="empHrmsId" name="empHrmsId" value="<?php echo e($TDR_Deliquency_HRMSID); ?>" autocomplete="off">
                                         </div>
                                         </div>
                                    <div class="formsec row">
                                        <div class="col-md-3">
                                           <div class="paddingsmlmin">5.</div>
                                           <div class="paddingsmlmax">i)Present designation</div>
                                        </div>
                                        <div class="col-md-3"> 
                                             <select class="form-control DesigCls1" name="presentDesigntion" id="presentDesigntion" onclick="showAddPostModal(this.value);">
                                              <option value="">--Select--</option> 
                                           </select>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="paddingsmlmax">ii)Designation when the delinquency was commited</div>
                                        </div>
                                        <div class="col-md-3">
                                             <select class="form-control DesigCls2" name="pastDesigntion" id="pastDesigntion" onclick="showAddPostModal(this.value);">

                                              <option value="">--Select--</option> 
                                           </select>
                                        </div>
                                    </div>
                                    <div class="formsecalt row">
                                        <div class="col-md-6">
                                             <div class="paddinglessmin">6.</div>
                                             <div class="paddinglessmax">Period during which the delinquency was commited</div>
                                        </div>
                                        <div class="col-md-6">
                                            <textarea class="form-control rounded-0" name="delinquentPeriod" id="delinquentPeriod" rows="3" autocomplete="off"><?php echo e($TDR_Deliquency_Period); ?></textarea>
                                        </div>   
                                    </div>
                                    <div class="formsec row">
                                        <div class="col-md-6">
                                            <div class="paddinglessmin">7.</div>
                                            <div class="paddinglessmax">Whether the officer was suspended, if so, the date(s) of Suspension and re-instatement, if any (if not applicable, write NA) :
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                            <div class="col-md-4"><input name="IfNoTSuspension" id="IfNoTSuspension" type="text" class="form-control" value="<?php echo e($TDR_Suspension_Statement); ?>" autocomplete="off"/></div>
                                            <div class="col-md-4">
                                                 <div class="input-group">
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                                                        </div>
                                                        <input type="text" class="form-control pull-right datepicker" id="suspensionFromDate" name="suspensionFromDate" value="<?php echo e($TDR_Suspension_FromDate); ?>" autocomplete="off">
                                                    </div>
                                            </div>
                                              <div class="col-md-4">
                                                 <div class="input-group">
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                                                        </div>
                                                        <input type="text" class="form-control pull-right datepicker" id="suspensionToDate" name="suspensionToDate" value="<?php echo e($TDR_Suspension_ToDate); ?>" autocomplete="off">
                                                    </div>
                                            </div>
                                            </div>
                                        </div>
                                        <div class="clearfix"></div>
                                        <div class="col-md-6">
                                         <div class="txtindenting">Provision of the OCS(CC&A) Rules, 1962 and OCS(Pension) Rules 1992 under which proceeding has been initiated (Tick the appropriate box) :</div>
                                         </div>    
                                            <div class="col-md-6">
                                                <div class="row">
                                                <div class="col-md-3">
                                                    
                                                    <input type="radio" value="1" <?php echo e(($TDR_OCS_Rule=="1")? "checked" : ""); ?> name="pensionRuleType"> Rule 15
                                                </div>
                                                <div class="col-md-3"> 
                                                    <input type="radio" <?php echo e(($TDR_OCS_Rule=="2")? "checked" : ""); ?> value="2" name="pensionRuleType"> Rule 16
                                                </div>
                                                 <div class="col-md-6">
                                                    <input type="radio"  <?php echo e(($TDR_OCS_Rule=="3")? "checked" : ""); ?> value="3" name="pensionRuleType"> Rule 7
                                                </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="formsecalt row">
                                        <div class="col-md-6">
                                           <div class="paddinglessmin">8.</div> 
                                           <div class="paddinglessmax">Date of communication of charge(s) along with statement of allegation/imputation (Copy of statement of allegation to be enclosed) :</div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                             
                                                    <div class="col-md-4">
                                                      <input type="text" class="form-control" id="allegationNo" name="allegationNo" value="<?php echo e($TDR_Allegation_Statement); ?>" autocomplete="off">
                                                    </div>
                                                    <div class="col-md-4">
                                                    <div class="input-group">
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                                                        </div>
                                                        <input type="text" class="form-control pull-right datepicker" id="allegationNoDate" name="allegationNoDate" value="<?php echo e($TDR_Allegation_Date); ?>" autocomplete="off">
                                                    </div>
                                                  </div>
                                                  
                                                
                                                <div class="col-md-4">
                                                    <a href="#" data-toggle="modal" data-target="#myModal_one" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> Upload File</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="formsec row">
                                        <div class="col-md-6">
                                           <div class="paddinglessmin">9.</div>
                                           <div class="paddinglessmax">Date of submission of written statement of defence by the delinquent officer (Copy of written statement of defence by the DO to be enclosed) :</div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="input-group">
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                                                        </div>
                                                        <input type="text" class="form-control pull-right datepicker" id="writtenByDelinquentDate" name="writtenByDelinquentDate" value="<?php echo e($TDR_DfenceStmtSubmison_Date); ?>" autocomplete="off">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                   <a href="#" data-toggle="modal" data-target="#myModal_one" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> Upload File</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="formsecalt row">
                                        <div class="col-md-6">
                                            <div class="paddinglessmin">10.</div>
                                            <div class="paddinglessmax">Whether enquiry was conducted (Tick the appropriate box) :</div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <input type="radio"  <?php echo e(($TDR_IsEnquiry_Conducted=="1")? "checked" : ""); ?> name="isEnquiryConducted"  value="1" onclick="inquiryConduct(this.value)"  > Yes
                                                </div>
                                                <div class="col-md-3">
                                                    <input type="radio" <?php echo e(($TDR_IsEnquiry_Conducted=="0")? "checked" : ""); ?> name="isEnquiryConducted"  value="0" onclick="inquiryConduct(this.value)"> No
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="formsec row">
                                        <div class="col-md-6">
                                            <div class="paddinglessmin">11.</div>
                                            <div class="paddinglessmax">If yes, designation of the I.O and date of submission of his report (Copy of the report of I.O to be enclosed) :</div>
                                        </div>


                                        <div class="col-md-6">
                                         <div class="row">
                                          <div class="col-md-6" id="investigationOfficerIdDiv" style="display: none;">
                                              <select class="form-control DesigCls3" name="investigationOfficerId" id="investigationOfficerId" onclick="showAddPostModal(this.value);">
                                                              <option value="">--Select--</option> 
                                                           </select>
                                          </div>
                                          <div class="col-md-6" id="investigationOfficerAreaNameDiv" style="display: none;">
                                             <input type="text" class="form-control" name="investigationOfficerAreaName" id="investigationOfficerAreaName" placeholder="Area Name" value="<?php echo e($TDR_IO_PostedArea); ?>" autocomplete="off">
                                          </div>
                                          
                                          <div class="col-md-6" id="submissionDateIODiv" style="display: none;">
                                             <div class="input-group">
                                                <div class="input-group-prepend">
                                                   <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                                                </div>
                                                 <input type="text" class="form-control pull-right datepicker" id="submissionDateIO" name="submissionDateIO" value="<?php echo e($TDR_IOReport_SubmisionDate); ?>" autocomplete="off">
                                             </div>
                                          </div>
                                          <div class="col-md-6" id="UploadFile11thDiv" style="display: none;">
                                            <a href="#" data-toggle="modal" data-target="#myModal_one" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> Upload File</a>
                                          </div>
                                      
                                              
                                    </div>
                                 </div>

                                    </div>
                                    <div class="formsecalt row">
                                        <div class="col-md-6">
                                            <div class="paddinglessmin">12.</div>
                                            <div class="paddinglessmax"> Whether report of the I.O was sent to the delinquent officer along with show cause notice calling him to submit his presentation within 15 days as required under Rule 15(10)(i)(a) of the O.C.S (C.C.&A) Rules,1962(Tick the appropriate box). (Copy of notice to be enclosed) :</div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-3"> 
                                                    <input type="radio" <?php echo e(($TDR_IsIOReport_SentToOficer=="1")? "checked" : ""); ?> value="1" name="isSendReportToDelinOfficer" onclick="reportoIOSent(this.value)"> Yes
                                                </div>
                                                <div class="col-md-3">
                                                 <input type="radio"  <?php echo e(($TDR_IsIOReport_SentToOficer=="0")? "checked" : ""); ?> value="0" name="isSendReportToDelinOfficer" onclick="reportoIOSent(this.value)"> No
                                                    </div>

                                                  <div class="col-md-6" id="UploadFile12thDiv" style="display: none;">
                                                   <a href="#" data-toggle="modal" data-target="#myModal_one" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> Upload File</a>

                                                 </div>
                                              </div>
                                            </div>

                                    </div>
                                  <div class="formsec row ">
                                    <div class="col-md-6 ">
                                       <div class="paddinglessmin">13.</div>
                                       <div class="paddinglessmax">  Date of represenation of the D.O.in response to the notice required under Rule 15(10) (i) (a) of the O.C.S (C.C. &A) Rules, 1962 (Copy of representation of the D.O.in response to the notice to be enclosed) :</div>
                                    </div>
                                    <div class="col-md-6 ">
                                        <div class="row ">
                                            <div class="col-md-6 ">
                                                <div class="input-group ">
                                                    <div class="input-group-prepend ">
                                                        <span class="input-group-text "><i class="fa fa-calendar "></i></span>
                                                    </div>
                                                    <input type="text " class="form-control pull-right datepicker " id="represenationDODate" name="represenationDODate" value="<?php echo e($TDR_DORepresent_Date); ?>" autocomplete="off">
                                                </div>
                                            </div>
                                            <div class="col-md-6 ">
                                                <a href="#" data-toggle="modal" data-target="#myModal_one" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> Upload File</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="formsecalt row ">
                                    <div class="col-md-6 ">
                                        <div class="paddinglessmin">14. </div>
                                        <div class="paddinglessmax"> Penalty imposed by the Disciplinary Authority before the issue of 2nd show cause notice (Copy of detailed finding and order of Disciplinary Authority and Govt. to be enclosed).</div>
                                    </div>
                                    <div class="col-md-6 ">
                                        <div class="row ">
                                          <div class="col-md-6">
                                              <input name="" type="text" class="form-control" id="penalityImposedByAuthrty" name="penalityImposedByAuthrty" value="<?php echo e($TDR_BfScndShwCausNotic_PenalityImposed); ?>" autocomplete="off"/>
                                          </div> 
                                          <div class="col-md-6">
                                          <a href="#" data-toggle="modal" data-target="#myModal_one" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> Upload File</a>  
                                          </div>  
                                        </div>

                                    </div>
                                </div>

                            <div class="formsec row">
                       
                            <div class="col-md-6">
                                <div class="paddinglessmin">15.</div>
                                <div class="paddinglessmax">In case imposition of major penalty :-</div>
                           
                            
                                <div class="txtindenting">(a) Date of second show cause notice issued u/r 15(10) (i)(b) (Copy of the explanation received by DO for 2nd show cause notice to be enclosed):</div>
                                </div>
                                    <div class="col-md-3">
                                        <div class="input-group ">
                                            <div class="input-group-prepend ">
                                                <span class="input-group-text "><i class="fa fa-calendar "></i></span>
                                            </div>
                                            <input type="text " class="form-control pull-right datepicker " id="dateOfSecondShowNoticeDate" name="dateOfSecondShowNoticeDate" value="<?php echo e($TDR_SecondShowCauseNotice_Date); ?>" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="#" data-toggle="modal" data-target="#myModal_one" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> Upload File</a>
                                    </div>
                              
                                    <div class="clearfix"></div>
                                      <div class="col-md-6">
                                      <div class="txtindenting">(b) Date of explanation received from the delinquent officer in reply to 2nd show causes notice (Copy of order of Disciplinary Authority in Case of disagreement of IO to be enclosed)</div>
                                    </div>
                                            <div class="col-md-3">
                                                <div class="input-group">
                                                    <div class="input-group-prepend ">
                                                        <span class="input-group-text "><i class="fa fa-calendar "></i></span>
                                                    </div>
                                                    <input type="text" class="form-control pull-right datepicker " id="dateOfSecExplanaReceiveDate" name="dateOfSecExplanaReceiveDate" value="<?php echo e($TDR_SecndCauseNotice_ExplanatnDate); ?>" autocomplete="off"> 
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                               <a href="#" data-toggle="modal" data-target="#myModal_one" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> Upload File</a>
                                            </div>
                                    </div>
                                       
                                    <div class="formsecalt row">
                                    <div class="col-md-6">
                                        <div class="paddinglessmin">16.</div>
                                          <div class=" paddinglessmax">Incase of disagreement with the finding of recommendation of I.O. whether reasons for the same has been recorded (Copy of order of Disciplinary Authority to be enclosed):</div>
                                    </div>
                                        <div class="col-md-6 ">
                                                <div class="row ">
                                                    <div  class="col-md-3 "> 
                                                        <input type="radio" <?php echo e(($TDR_IsDisagrementReson_Recorded=="1")? "checked" : ""); ?> value="1" name="isIncaseOfDisagreement" onclick="isIncaseOfDisagreementIO(this.value)"> Yes
                                                    </div>
                                                    <div class="col-md-3">
                                                    <input type="radio" <?php echo e(($TDR_IsDisagrementReson_Recorded=="0")? "checked" : ""); ?> value="0" name="isIncaseOfDisagreement" onclick="isIncaseOfDisagreementIO(this.value)" > No
                                                   </div>

                                                    <div class="col-md-6" id="UploadFile16thDiv" style="display: none;">
                                                        <a href="#" data-toggle="modal" data-target="#myModal_one" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> Upload File</a>

                                                    </div>
                                               </div>
                                        </div>
                                    </div>
                                    <div class="formsec row">
                                        <div class="col-md-6">
                                            <div class="paddinglessmin">17.</div>
                                             <div class=" paddinglessmax "> In the event of joint proceedings u/r 17 of the OCS (CC&A) Rules, 1962, is concurrence of disciplinary authorities of all the Depts to which delinquent officers belong to have been taken?</div>
                                        </div>
                                        <div class="col-md-6">
                                       <div class="row">
                                            <div class="col-md-3">
                                                <input type="radio" <?php echo e(($TDR_IsConcurrance_ByDisplinaryAuthority=="1")? "checked" : ""); ?> value="1" name="isIncaseOfjointPreceedings"> Yes
                                            </div>
                                            <div class="col-md-3">
                                                <input type="radio" <?php echo e(($TDR_IsConcurrance_ByDisplinaryAuthority=="0")? "checked" : ""); ?> value="0" name="isIncaseOfjointPreceedings"> No
                                            </div> 
                                            <div class="col-md-6">
                                               <input type="radio" <?php echo e(($TDR_IsConcurrance_ByDisplinaryAuthority=="2")? "checked" : ""); ?> value="2" name="isIncaseOfjointPreceedings"  > Not Applicable
                                            </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="formsecalt row">
                                        <div class="col-md-6">
                                            <div class="paddinglessmin">18.</div>
                                                 <div class=" paddinglessmax">In case of proposal for imposition of penalty on the DO whether orders of Govt. have been taken?</div>
                                        </div>
                                        <div class="col-md-6">
                                          <div class="row">
                                            <div class="col-md-3">
                                                <input type="radio" <?php echo e(($TDR_IsPenalityImpositnOrder_HasTaken=="1")? "checked" : ""); ?> value="1" name="isIncaseOfPersonalImposition" > Yes
                                            </div>
                                            <div class="col-md-3">
                                                <input type="radio" <?php echo e(($TDR_IsPenalityImpositnOrder_HasTaken=="0")? "checked" : ""); ?> value="0" name="isIncaseOfPersonalImposition" > No
                                            </div> 
                                            <div class="col-md-6">
                                               <input type="radio" <?php echo e(($TDR_IsPenalityImpositnOrder_HasTaken=="2")? "checked" : ""); ?>  value="2" name="isIncaseOfPersonalImposition"  > Not Applicable
                                            </div>
                                            </div>
                                            </div>

                                        <div class="col-md-6">
                                             <div class="txtindenting">Copy of the Notes & Order sheet of Govt. from appropriate level to be enclosed :</div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                             <div class="col-md-3">
                                                <input type="radio" <?php echo e(($TDR_IsCopyOfNotesEnclosed=="1")? "checked" : ""); ?> value="1" name="isCopyOfTheNotesOrder" onclick="NotesOrdersheetofGovt(this.value)"> Yes
                                            </div>
                                            <div class="col-md-3">
                                                <input type="radio" <?php echo e(($TDR_IsCopyOfNotesEnclosed=="0")? "checked" : ""); ?> value="0" name="isCopyOfTheNotesOrder" onclick="NotesOrdersheetofGovt(this.value)"> No
                                            </div>  
                                            <div class="col-md-6" id="UploadFile18thDiv" style="display: none;">
                                                 <a href="#" data-toggle="modal" data-target="#myModal_one" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> Upload File</a>
                                            </div>

                                            </div>
                                        </div>
                                    </div>
                                   
                                    <div align="right" class="col-md-12 padding_10">
                                       <a href="<?php echo e(url('DisciplinaryRequest/viewDisciplinaryOthers')); ?>" class="btn btn-danger">Cancel</a>
                                       <button class="btn btn-warning" id="saveAsDraft">Save as Draft</button> 
                                       <button class="btn btn-primary" id="saveAndNext">Save &#38 Next</button>
                                    </div>
                                </div>
                        </div>
                      </div>
                   
                    <div class="box">
                        <div class="card-header" id="headingThree">
                            <a data-toggle="collapse" data-target="#collapseThree" class="accordianheading">
                                <div class="row">
                                    <div class="col-md-11">
                                        <h5>Document Check List</h5></div>
                                    <div class="col-md-1"><i class="fa faicon acrdplus fa-plus-circle"></i></div>
                                </div>
                            </a>
                        </div>
                        <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                            <div class="card-body" <?php if($TDR_Complete_Status==0): ?> style="display: none;" <?php endif; ?>>
                                <div class="col-md-12">
                                    <div class="row">
                                        <?php $sl=1; ?>
                                       <?php $__currentLoopData = $doc_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-6">
                                            <div class="row listview">
                                                <div class="col-md-11"><?php echo e($sl.'. '); ?> <?php echo e($val->TDM_Doc_Name); ?></div>
                                                <div class="col-md-1 listicon">
                                                    <label>
                                                        <input type="checkbox" class="minimal" id="checked<?php echo e($val->TDM_Doc); ?>" name="checked<?php echo e($val->TDM_Doc); ?>" value="<?php echo e($val->TDM_Doc); ?>" onchange="checkDataUploadedOrNot(this.value)">
                                                    </label>
                                                </div>
                                            </div>
                                         </div> <?php $sl+=1; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                        
                                       
                                    <div class="col-md-12">
                                         <div class="paddinglessmin">
                                          <input type="checkbox" id="confirmationChecked" name="confirmationChecked" value="1">
                                        </div>
                                          <div class="paddinglessmax">
                                          <div>I certify that all information/documents given above have been checked by me and found to be correct and all copies of relevant documents, as mentioned above, have benn enclosed</div> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div align="right" class="col-md-12 padding_10">
                                <a href="<?php echo e(url('DisciplinaryRequest/viewDisciplinaryOthers')); ?>" class="btn btn-danger">Cancel</a>
                               <a href="javascript:void(0)" class="btn btn-primary" id="finalSubmit">Submit</a>
                            </div>
                        </div>
                    </div>
                  </div> 
                 </div>
                </div>
                <!-- /.box -->
            </div>
            <!-- /.col -->
      </section>
    <!-- /.content -->
    </div>
  <!-- /.content-wrapper -->
  <div class="modal" id="myModal_one">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <!-- Modal Header -->
        <div class="modal-header">
           <h4 class="modal-title">Upload File</h4>
           <!-- <button type="button" class="close" data-dismiss="modal">×</button> -->
        </div>
        <!-- Modal body -->
        <div class="modal-body">
          <div class="col-lg-12">
            
              
             <div class="form-group uploadone">
             <div></div>
             <div class="row">
                <div class="col-lg-5">
                    <label>Select File Type</label>
                    <select name="docType" id="docType" class="form-control">
                       <option value="">--Select--</option>
                        <?php $__currentLoopData = $doc_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($val->TDM_Doc); ?>"><?php echo e($val->TDM_Doc_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </select>
                </div>
                <div class="col-lg-6">
                    <label>Upload File</label> 
                    <div class="input-group">
                    <input type="file" class="custom-file-input"  name="UploadFile" id="UploadFile"> 
                    <label class="custom-file-label customFile" for="customFile" >Choose file</label> 
                  </div>
                </div>
                 <div class="col-lg-1 mrt_30" align="right">
                      <button class="btn btn-primary" type="button" id="saveFilesWithAjax"><i class="fa fa-upload"></i></button> 
                  </div>
              </div>
            </div>
          </div>
          <div class="col-md-12">
          <div class="row" id="previewDocs"> 
          
          </div>
          <div id="">
             <h6 id="uploadedFileCount" class="modal-title" style="display: none;">Previous uploaded Files:</h6>  

          </div>
          <div class="row" id="previewDocs1">
             
              
          </div>
          </div>
        </div>
        <!-- Modal footer -->
        <div class="modal-footer" align="center">
         <!--  <button class="btn btn-primary" id="saveFilesWithAjax">Submit</button> -->
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>
 <div class="modal" id="addPostModal">
    <div class="modal-dialog">
      <div class="modal-content" id="addPostBody">
       
        
      </div>
    </div>
  </div>
<?php $__env->startPush('scripts'); ?>
<script>    

function checkDataUploadedOrNot(val){ 
    var disciplinaryId=$("#hdDisplineId").val();
    var mode=$("#mode").val();
    var data = new FormData(); 
    data.append('docType', val);
    data.append('disciplinaryId',disciplinaryId);
    data.append('mode',mode);
    console.log(data); 
    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
      }
    });
    swal.fire({
        title: "Do you want to check, this Document is Uploaded Or Not?",
        text: "",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#e7b63a',
        confirmButtonText: 'Yes',
        reverseButtons : true 
        
      }).then((result) => {
         if(result.value){
            $("#maskid").show();
            $.ajax({
                type: 'POST', 
                url : '<?php echo e(url("DisciplinaryRequest/checkUploadFile")); ?>', 
                data:data,
                success: function(results) { 
                    $("#maskid").hide();
                    if(results.message =="fail"){
                         $('#checked'+val).prop("checked",false);
                        swal("This document is not uploaded, please upload.");
                    }else{
                      $('#checked'+val).prop("checked",true);  
                      swal("It is uploaded,checked successfully");
                    } 
                      console.log(results);  
                }, 
                cache: false,
                contentType: false,
                processData: false
            }); 
        }else{
             $('#checked'+val).prop("checked",false);
        }
    });    
}    
function inquiryConduct(val){ 
    if(val>0){
        $("#investigationOfficerIdDiv").show();
        $("#investigationOfficerAreaNameDiv").show();     
        $("#submissionDateIODiv").show();          
        $("#UploadFile11thDiv").show();   
        $("#investigationOfficerId").val('');
        $("#investigationOfficerAreaName").val('');     
        $("#submissionDateIO").val('');     
    }
    else{
         $("#investigationOfficerIdDiv").hide();
         $("#investigationOfficerAreaNameDiv").hide();     
         $("#submissionDateIODiv").hide();          
         $("#UploadFile11thDiv").hide(); 
         $("#investigationOfficerId").val('');
         $("#investigationOfficerAreaName").val('');     
         $("#submissionDateIO").val(''); 
    } 
}     

function reportoIOSent(val){ 
    if(val>0){           
        $("#UploadFile12thDiv").show();       
    }
    else{           
         $("#UploadFile12thDiv").hide();  
    } 
}  

function isIncaseOfDisagreementIO(val){ 
    if(val>0){           
        $("#UploadFile16thDiv").show();       
    }
    else{           
         $("#UploadFile16thDiv").hide();  
    }  
} 

function NotesOrdersheetofGovt(val){ 
    if(val>0){           
        $("#UploadFile18thDiv").show();       
    }
    else{           
         $("#UploadFile18thDiv").hide();  
    }  
}  

function deptChange() { 
  $.ajaxSetup({
    headers: {
      'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
    }
  });
   if($("#departmentId").val()!=''){
    $.ajax({
      type : "POST",
      'url' : '<?php echo e(url("DisciplinaryRequest/getDesignationList")); ?>', 
      dataType : 'json', 
      data : {"deptId":$("#departmentId").val()},
      success : function(response) {
        if (response.message == "success") {
          console.log(response);
          $("#presentDesigntion").empty();
          var option = $("<option></option>");
          $(option).val(null);
          $(option).html("--Select--");
          $("#presentDesigntion").append(option);
          for (var i = 0; i < response.desigList.length; i++) {
            var option = $("<option></option>");
            $(option).val(response.desigList[i].TDM_Desig);
            $(option).html(response.desigList[i].TDM_Desig_Name);
            $("#presentDesigntion").append(option);
          }
          var option = $("<option></option>");
            $(option).val("newdesig");
            $(option).html("Add New");
            $("#presentDesigntion").append(option);

          $("#pastDesigntion").empty();
          var option = $("<option></option>");
          $(option).val(null);
          $(option).html("--Select--");
          $("#pastDesigntion").append(option);
          for (var i = 0; i < response.desigList.length; i++) {
            var option = $("<option></option>");
            $(option).val(response.desigList[i].TDM_Desig);
            $(option).html(response.desigList[i].TDM_Desig_Name);
            $("#pastDesigntion").append(option);
          }
          var option = $("<option></option>");
            $(option).val("newdesig");
            $(option).html("Add New");
            $("#pastDesigntion").append(option);

          $("#investigationOfficerId").empty();
          var option = $("<option></option>");
          $(option).val(null);
          $(option).html("--Select--");
          $("#investigationOfficerId").append(option);
          for (var i = 0; i < response.desigList.length; i++) {
            var option = $("<option></option>");
            $(option).val(response.desigList[i].TDM_Desig);
            $(option).html(response.desigList[i].TDM_Desig_Name);
            $("#investigationOfficerId").append(option);
          }
            var option = $("<option></option>");
            $(option).val("newdesig");
            $(option).html("Add New");
            $("#investigationOfficerId").append(option);
        }
      },
      error : function(data) {
        console.log(data);
      }
    })
  }else{
    $("#presentDesigntion").empty();
    var option = $("<option></option>");
    $(option).val(null);
    $(option).html("--Select--");
    $("#presentDesigntion").append(option);

    $("#pastDesigntion").empty();
     var option = $("<option></option>");
    $(option).val(null);
    $(option).html("--Select--");
    $("#pastDesigntion").append(option);

    $("#investigationOfficerId").empty();
    var option = $("<option></option>");
    $(option).val(null);
    $(option).html("--Select--");
    $("#investigationOfficerId").append(option);
  }
}  

function delThisDoc(val){      
    if(val =='' || val==null)  {
      swal('Data is Not Available');
      return false;
    } 
    var data = new FormData();  
    data.append('doc_type', val);
   $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
      }
    });
   swal.fire({
        title: "Are you sure want to Delete?",
        text: "Once Deleted,Can't revert back !",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#e7b63a',
        confirmButtonText: 'Delete',
        reverseButtons : true
        
      }).then((result) => {
        if(result.value){
        $.ajax({
            type: 'POST',
            'url' : '<?php echo e(url("DisciplinaryRequest/delUploadedFile")); ?>' ,
            data:data,
            success: function(results) { 
                $("#maskid").hide();
                if(results =="0"){
                    swal("Invalid file extension");
                }else{  
                    console.log('after delete:--',results);
                    swal("File deleted successfully");
                    $("#previewDocs").empty();
                    $("#docType").val('');
                    $("#UploadFile").val('');
                    $(".customFile").html('Choose file'); 
                    if(results.length>0){  
                    for (var i = 0; i < results.length; i++) {
                      var docType=results[i].docType;  
                      var docText=results[i].docText; 
                      var docName=results[i].docName; 

                      var imageLink="<?php echo e(asset('storage/disciplinary_files')); ?>/"+docName; 
                      console.log(imageLink); 
                      $('#previewDocs').prepend($('<div class="col-md-6"><i class="fa fa-pdf-o"></i>'+docText+'<a href="'+imageLink+'" target="_blank"><span class="label label-primary"><i class="fa fa-eye"></i></span></a> <a href="javascript:void(0)" onclick="delThisDoc('+docType+')" ><span class="label label-warning"><i class="fa fa-close"></i></span></a></div>')); 
                    } 
                  } 
                }
            }, 
            cache: false,
            contentType: false,
            processData: false
          });  
    }   
  });  
} 

function delThisDocFromDB(val){ 
    var disciplinaryId=$("#hdDisplineId").val();  
    var mode=$("#mode").val();  

    if(val =='' || val==null)  {
      swal('Data is Not Available');
      return false;
    } 
    var data = new FormData();  
    data.append('doc_type', val);
    data.append('disciplinaryId', disciplinaryId);
    data.append('mode', mode);

   $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
      }
    });
   swal.fire({
        title: "Are you sure want to Delete?",
        text: "Once Deleted,Can't revert back !",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#e7b63a',
        confirmButtonText: 'Delete',
        reverseButtons : true
        
      }).then((result) => {
        if(result.value){
        $.ajax({
            type: 'POST',
            url : '<?php echo e(url("DisciplinaryRequest/deleteDocFromDB")); ?>' ,
            data:data,
            success: function(results) { 
                $("#maskid").hide();
                 if (results.message == "success") {
                      console.log(results);
                      $("#previewDocs1").html(''); 
                      $("#docType").val('');
                      $("#UploadFile").val('');
                      $(".customFile").html('Choose file'); 
                      $("#uploadedFileCount span").text(results.docList.length); 
                      for (var i = 0; i < results.docList.length; i++) {
                        var docType=results.docList[i].docType;  
                        var docText=results.docList[i].docText; 
                        var docName=results.docList[i].docName;  
                        var imageLink="<?php echo e(asset('storage/disciplinary_files')); ?>/"+docName;  
                        console.log(imageLink); 

                        $('#previewDocs1').prepend($('<div class="col-md-6"><i class="fa fa-pdf-o"></i>'+docText+'<a href="'+imageLink+'" target="_blank"><span class="label label-primary"><i class="fa fa-eye"></i></span></a> <a href="javascript:void(0)" onclick="delThisDocFromDB('+docType+')" ><span class="label label-warning"><i class="fa fa-close"></i></span></a></div>')); 
                      }
                    }
            }, 
            cache: false,
            contentType: false,
            processData: false
          });  
        }   
    }); 
}

$(document).ready(function(){ 
    var departmentIdEdit=$("#departmentId").val(); 
    var confirmationCheckedVal=$("#confirmationCheckedId").val();
    if(departmentIdEdit!=''){ 
        if(confirmationCheckedVal!=0){ 
             $('#confirmationChecked').prop("checked",true);    
       }
    }
    //for hiding saveAsDraft at Disciplinary Time

    

    var mode=$('#mode').val();
    if(mode==1){
        $('#saveAsDraft').hide();
    } 


    // Start For checked if it is checked in Database//End Checked if it is checked in Database.
    
    
    var disciplinaryId=$("#hdDisplineId").val();
    var mode=$("#mode").val();
     if(departmentIdEdit!=''){ 
       $.ajaxSetup({
        headers: {
          'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
        }
      });
     var data = new FormData();  
     data.append('mode', mode);
     data.append('disciplinaryId', disciplinaryId);
     if(departmentIdEdit!=''){
      $.ajax({
        type : "POST",
        'url' : '<?php echo e(url("DisciplinaryRequest/getCheckedList")); ?>', 
        dataType : 'json', 
        data : {"disciplinaryId":disciplinaryId,"mode":mode},
        success : function(response) {
            // console.log(response);
          if (response.message == "success") {
            console.log(response);
            var checkedDocType=0;
             for (var i = 0; i < response.checkedList.length; i++) {
                checkedDocType=response.checkedList[i].docType;
                console.log('docType-----'+checkedDocType);
                $('#checked'+checkedDocType).prop("checked",true);   
            }
             
          }
        },
        error : function(data) {
          console.log(data); 
        }
      })
    }else{ 
    }  
  }
    //End Checked if it is checked in Database.  
     $("#investigationOfficerIdDiv").show();
     $("#investigationOfficerAreaNameDiv").show();     
     $("#submissionDateIODiv").show();          
     $("#UploadFile11thDiv").show();
     $("#UploadFile12thDiv").show();
     $("#UploadFile16thDiv").show();
     $("#UploadFile18thDiv").show(); 
     $("#uploadedId").show();
     var departmentIdEdit=$("#departmentId").val(); 
     if(departmentIdEdit!=''){ 
        $("#uploadedFileCount").show();
        $('#departmentId').prop('disabled', true);
       $.ajaxSetup({
        headers: {
          'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
        }
      });
     if(departmentIdEdit!=''){
      $.ajax({
        type : "POST",
        'url' : '<?php echo e(url("DisciplinaryRequest/getDesignationList")); ?>', 
        dataType : 'json', 
        data : {"deptId":departmentIdEdit},
        success : function(response) {
          if (response.message == "success") {
            console.log(response);
            $("#presentDesigntion").empty();
            var option = $("<option></option>");
            $(option).val(null);
            $(option).html("--Select--");
            $("#presentDesigntion").append(option);
            for (var i = 0; i < response.desigList.length; i++) {
              var option = $("<option></option>");
              $(option).val(response.desigList[i].TDM_Desig);
              $(option).html(response.desigList[i].TDM_Desig_Name);
              $("#presentDesigntion").append(option);
              var currentDesigId=$("#currentDesigId").val();
              if(currentDesigId){ 
                $('#presentDesigntion option[value='+currentDesigId+']').attr('selected','selected');
              }
            }
            var option = $("<option></option>");
            $(option).val("newdesig");
            $(option).html("Add New");
            $("#presentDesigntion").append(option);
             
            $("#pastDesigntion").empty();
            var option = $("<option></option>");
            $(option).val(null);
            $(option).html("--Select--");
            $("#pastDesigntion").append(option);
            for (var i = 0; i < response.desigList.length; i++) {
              var option = $("<option></option>");
              $(option).val(response.desigList[i].TDM_Desig);
              $(option).html(response.desigList[i].TDM_Desig_Name);
              $("#pastDesigntion").append(option);
              var pastDesigId=$("#pastDesigId").val();
              if(pastDesigId){  
                $('#pastDesigntion option[value='+pastDesigId+']').attr('selected','selected');
              }
            }
            var option = $("<option></option>");
            $(option).val("newdesig");
            $(option).html("Add New");
            $("#pastDesigntion").append(option);

            $("#investigationOfficerId").empty();
            var option = $("<option></option>");
            $(option).val(null);
            $(option).html("--Select--");
            $("#investigationOfficerId").append(option);
            for (var i = 0; i < response.desigList.length; i++) {
              var option = $("<option></option>");
              $(option).val(response.desigList[i].TDM_Desig);
              $(option).html(response.desigList[i].TDM_Desig_Name);
              $("#investigationOfficerId").append(option);
              var IODesigId=$("#IODesigId").val();
              if(IODesigId){ 
                $('#investigationOfficerId option[value='+IODesigId+']').attr('selected','selected');
              }
            }
            var option = $("<option></option>");
            $(option).val("newdesig");
            $(option).html("Add New");
            $("#investigationOfficerId").append(option);
          }
        },
        error : function(data) {
          console.log(data);
        }
      })
    }else{
      $("#presentDesigntion").empty();
      var option = $("<option></option>");
      $(option).val(null);
      $(option).html("--Select--");
      $("#presentDesigntion").append(option);

      $("#pastDesigntion").empty();
       var option = $("<option></option>");
      $(option).val(null);
      $(option).html("--Select--");
      $("#pastDesigntion").append(option);

      $("#investigationOfficerId").empty();
      var option = $("<option></option>");
      $(option).val(null);
      $(option).html("--Select--");
      $("#investigationOfficerId").append(option);
    }  
  }
 
   var disciplinaryId=$("#hdDisplineId").val();
   var mode=$("#mode").val();
    if(disciplinaryId!=''){
         $.ajaxSetup({
            headers: {
              'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            }
          });
           if(disciplinaryId!=''){
            $.ajax({
              type : "POST",
              'url' : '<?php echo e(url("DisciplinaryRequest/getDisciplinaryDocList")); ?>', 
              dataType : 'json', 
              data : {"disciplinaryId":disciplinaryId,"mode":mode},
              success : function(response) {
                if (response.message == "success") {
                  console.log(response);
                  $("#previewDocs1").html(''); 
                  $("#docType").val('');
                  $("#UploadFile").val('');
                  $(".customFile").html('Choose file'); 
                  $("#uploadedFileCount span").text(response.docList.length); 
                  for (var i = 0; i < response.docList.length; i++) {
                    var docType=response.docList[i].docType;  
                    var docText=response.docList[i].docText; 
                    var docName=response.docList[i].docName;  
                    var imageLink="<?php echo e(asset('storage/disciplinary_files')); ?>/"+docName;  
                    console.log(imageLink);  
                    $('#previewDocs1').prepend($('<div class="col-md-6"><i class="fa fa-pdf-o"></i>'+docText+'<a href="'+imageLink+'" target="_blank"><span class="label label-primary"><i class="fa fa-eye"></i></span></a> <a href="javascript:void(0)" onclick="delThisDocFromDB('+docType+')" ><span class="label label-warning"><i class="fa fa-close"></i></span></a></div>')); 
                  }
                
                }
              },
              error : function(data) {
                console.log(data);
              }
            })
          }else{
            
          }
         
    }
 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////   
       
$("#saveFilesWithAjax").click(function(){ 
     var docVal = $("#docType").val(); 
     var uploadVal = $("#UploadFile").val();
     if (!blankValidation("docType","SelectBox", "Please select Document Type"))
        return false;
     if(uploadVal==''){
        swal('Please Upload Document');
        return false;
     }
     
    $("#maskid").show(); 
    var data = new FormData(); 
    var docTypeText =$("#docType option:selected").text(); 
    var docTypeId =$("#docType").val();
    data.append('imgfile', jQuery('#UploadFile')[0].files[0]);
    data.append('doc_type', docTypeId);
    data.append('doc_text', docTypeText);
    console.log(data); 
    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
      }
    });
    $.ajax({
        type: 'POST', 
        'url' : '<?php echo e(url("DisciplinaryRequest/saveUploadFile")); ?>', 
        data:data,
        success: function(results) { 
            $("#maskid").hide();
            if(results.message =="0"){
                swal("Invalid file extension");
            }else if(results.message =="1"){ 
                swal("File size exceeds 3 MB");
            }else{
              swal("File uploaded successfully");
            } 
              console.log(results); 
              $("#previewDocs").html('');
              $("#docType").val('');
              $("#UploadFile").val('');
              $(".customFile").html('Choose file'); 
              for (var i = 0; i < results.ImgArr.length; i++) {
                var docType=results.ImgArr[i].docType;  
                var docText=results.ImgArr[i].docText; 
                var docName=results.ImgArr[i].docName;  
                var imageLink="<?php echo e(asset('storage/disciplinary_files')); ?>/"+docName;  
                console.log(imageLink);   
                $('#previewDocs').prepend($('<div class="col-md-6"><i class="fa fa-pdf-o"></i>'+docText+'<a href="'+imageLink+'" target="_blank"><span class="label label-primary"><i class="fa fa-eye"></i></span></a> <a href="javascript:void(0)" onclick="delThisDoc('+docType+')" ><span class="label label-warning"><i class="fa fa-close"></i></span></a></div>')); 
              } 
        }, 
        cache: false,
        contentType: false,
        processData: false
    }); 
  
 });  

$("#finalSubmit").click(function(){ 
    
     var confirmCheck = $('input[name="confirmationChecked"]:checked').length;
     if(confirmCheck != 1){
        swal('Please check confirm checkbox');
        return  false;
     }

       /*isEnquiryConducted          10
         isSendReportToDelinOfficer  12
         isIncaseOfDisagreement      16
         isCopyOfTheNotesOrder       18*/
    var disciplinaryId=$("#hdDisplineId").val();
    var mode=$("#mode").val();
    var data = new FormData(); 
    data.append('mode', mode);
    data.append('disciplinaryId',disciplinaryId);
    console.log(data); 
    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
      }
    }); 
        
        //return false;
    swal.fire({
        title: "Do you want to submit?",
        text: "",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#e7b63a',
        confirmButtonText: 'Submit',
        reverseButtons : true 
        
      }).then((result) => {
        if(result.value){
            $("#maskid").show();
            $.ajax({
                type: 'POST', 
                url : '<?php echo e(url("DisciplinaryRequest/saveDisciplinaryFinalSubmit")); ?>', 
                data:data, 
                success: function(results) { 
                    $("#maskid").hide(); 
                    if(results.message =="success"){
                        window.location.href='<?php echo url("DisciplinaryRequest/viewDisciplinaryOthers") ?>';
                        swal("Record submitted successfully.");
                    }else{
                      swal("Record submitted failed.");
                    }    
                }, 
                cache: false,
                contentType: false,
                processData: false
            }); 
        }
    });   
        
});
      
$("#saveAsDraft").click(function(){ 
        var  data = {};
        data['disciplinaryId']=$("#hdDisplineId").val();
        data['officerName']=$("#officerName").val();
        data['officerDOB']=$("#officerDOB").val();
        data['departmentId']=$("#departmentId").val();
        data['empHrmsId']=$("#empHrmsId").val();
        data['presentDesigntion']=$("#presentDesigntion").val();
        data['pastDesigntion']=$("#pastDesigntion").val();
        data['delinquentPeriod']=$("#delinquentPeriod").val();
        data['IfNoTSuspension']=$("#IfNoTSuspension").val();
        data['suspensionFromDate']=$("#suspensionFromDate").val();
        data['suspensionToDate']=$("#suspensionToDate").val();
        data['pensionRuleType']=parseInt($("input[name='pensionRuleType']:checked").val()); 
        data['allegationNo']=$("#allegationNo").val();
        data['allegationNoDate']=$("#allegationNoDate").val();
        data['writtenByDelinquentDate']=$("#writtenByDelinquentDate").val();
        data['isEnquiryConducted']=parseInt($("input[name='isEnquiryConducted']:checked").val());
        data['investigationOfficerId']=$("#investigationOfficerId").val();
        data['investigationOfficerAreaName']=$("#investigationOfficerAreaName").val();
        data['submissionDateIO']=$("#submissionDateIO").val();
        data['isSendReportToDelinOfficer']=parseInt($("input[name='isSendReportToDelinOfficer']:checked").val());
        data['represenationDODate']=$("#represenationDODate").val();
        data['penalityImposedByAuthrty']=$("#penalityImposedByAuthrty").val();
        data['dateOfSecondShowNoticeDate']=$("#dateOfSecondShowNoticeDate").val();
        data['dateOfSecExplanaReceiveDate']=$("#dateOfSecExplanaReceiveDate").val();
        data['isIncaseOfDisagreement']=  parseInt($("input[name='isIncaseOfDisagreement']:checked").val());
        data['isIncaseOfjointPreceedings']=parseInt($("input[name='isIncaseOfjointPreceedings']:checked").val());
        data['isIncaseOfPersonalImposition']=parseInt($("input[name='isIncaseOfPersonalImposition']:checked").val());
        data['isCopyOfTheNotesOrder']=parseInt($("input[name='isCopyOfTheNotesOrder']:checked").val());

         submitAsDraft(data); 
       });

$("#saveAndNext").click(function(){   

      if (!blankValidation("officerName","TextField", "Officer name can not be left blank"))
          return false; 

      if (!blankValidation("officerDOB","TextField", "Officer DOB can not be left blank"))
          return false;

      if (!blankValidation("departmentId","SelectBox", "Please select department"))
        return false; 

      if (!blankValidation("empHrmsId","TextField", "Employee HRMS Id can not be left blank"))
          return false; 

      if (!blankValidation("presentDesigntion","SelectBox", "Please select  present designtion"))
        return false;

      if (!blankValidation("pastDesigntion","SelectBox", "Please select past designtion"))
        return false;

      if (!blankValidation("delinquentPeriod","TextField", "Delinquency period can not be left blank"))
        return false;  

      if (!blankValidation("IfNoTSuspension","TextField","Suspension and re-instatement can not be left blank"))
        return false;

      if (!blankValidation("suspensionFromDate","TextField","Suspension from date can not be left blank"))
        return false;

      if (!blankValidation("suspensionToDate","TextField","Suspension to date can not be left blank"))
        return false;

      if (!blankValidation("allegationNo","TextField","Allegation no. can not be left blank"))
        return false;
      
      if (!blankValidation("allegationNoDate","TextField","Allegation date can not be left blank"))
        return false;

      if (!blankValidation("writtenByDelinquentDate","TextField","Written statement by the Officer can not be left blank"))
        return false;

      var enquiryConduct=parseInt($("input[name='isEnquiryConducted']:checked").val());
      if(enquiryConduct==1){ 

        if (!blankValidation("investigationOfficerId","SelectBox", "Please select investigation officer"))
            return false;

        if (!blankValidation("investigationOfficerAreaName","TextField","Area name can not be left blank"))
            return false;

        if (!blankValidation("submissionDateIO","TextField","Submission date can not be left blank"))
            return false;  

      }

      if (!blankValidation("represenationDODate","TextField","Represenation date can not be left blank"))
        return false;  

      if (!blankValidation("penalityImposedByAuthrty","TextField","penality imposed by authrty can not be left blank"))
        return false;

      if (!blankValidation("dateOfSecondShowNoticeDate","TextField","Second show notice date can not be left blank"))
        return false;  

      if (!blankValidation("dateOfSecExplanaReceiveDate","TextField","Second explanation receive date can not be left blank"))
        return false; 
       
       
        //var dataset = [];
        //  $("#tbodyData > tr").each(function(){
        var  data = {};
        data['mode']=$("#mode").val();
        data['disciplinaryId']=$("#hdDisplineId").val();
        data['officerName']=$("#officerName").val();
        data['officerDOB']=$("#officerDOB").val();
        data['departmentId']=$("#departmentId").val();
        data['empHrmsId']=$("#empHrmsId").val();
        data['presentDesigntion']=$("#presentDesigntion").val();
        data['pastDesigntion']=$("#pastDesigntion").val();
        data['delinquentPeriod']=$("#delinquentPeriod").val();
        data['IfNoTSuspension']=$("#IfNoTSuspension").val();
        data['suspensionFromDate']=$("#suspensionFromDate").val();
        data['suspensionToDate']=$("#suspensionToDate").val();
        data['pensionRuleType']=parseInt($("input[name='pensionRuleType']:checked").val()); 
        data['allegationNo']=$("#allegationNo").val();
        data['allegationNoDate']=$("#allegationNoDate").val();
        data['writtenByDelinquentDate']=$("#writtenByDelinquentDate").val();
        data['isEnquiryConducted']=parseInt($("input[name='isEnquiryConducted']:checked").val());
        data['investigationOfficerId']=$("#investigationOfficerId").val();
        data['investigationOfficerAreaName']=$("#investigationOfficerAreaName").val();
        data['submissionDateIO']=$("#submissionDateIO").val();
        data['isSendReportToDelinOfficer']=parseInt($("input[name='isSendReportToDelinOfficer']:checked").val());
        data['represenationDODate']=$("#represenationDODate").val();
        data['penalityImposedByAuthrty']=$("#penalityImposedByAuthrty").val();
        data['dateOfSecondShowNoticeDate']=$("#dateOfSecondShowNoticeDate").val();
        data['dateOfSecExplanaReceiveDate']=$("#dateOfSecExplanaReceiveDate").val();
        data['isIncaseOfDisagreement']=  parseInt($("input[name='isIncaseOfDisagreement']:checked").val());
        data['isIncaseOfjointPreceedings']=parseInt($("input[name='isIncaseOfjointPreceedings']:checked").val());
        data['isIncaseOfPersonalImposition']=parseInt($("input[name='isIncaseOfPersonalImposition']:checked").val());
        data['isCopyOfTheNotesOrder']=parseInt($("input[name='isCopyOfTheNotesOrder']:checked").val()); 
     
        submitSaveAndNext(data); 
      });
});
function submitAsDraft (data){
    console.log(data);
     $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
      }
    });
  //console.log('saveAsDraft---',data);

   swal.fire({
        title: "Do you want to submit?",
        text: "",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#e7b63a',
        confirmButtonText: 'Submit',
        reverseButtons : true
        
      }).then((result) => {
        if(result.value){
            $.ajax({
            type    : "POST",
             'url' : '<?php echo e(url("DisciplinaryRequest/saveDisciplinaryAsDraftTemp")); ?>', 
            
            dataType  : "json",
            contentType : "application/json",
            data    : JSON.stringify(data),
            success   : function(response){
              console.log("response ",response);
              if(response.message=="success"){ 
                swal({
                    title:"Data saved successfully.",
                    type: "success",
                }).then(function(){    
                  window.location.href='<?php echo url("DisciplinaryRequest/viewDisciplinaryDraft") ?>';
                })
              }else{
                swal({
                  title:response.code,
                  text: response.message,
                  type:"warning"
                })
              }
            },error   : function(xhr, status, error){
              var err = eval("(" + xhr.responseText + ")");
                console.log(err)
               swal(err.message.slice(err.message.indexOf('>:'),err.message.indexOf('(SQL:')).replace('>:',''));  
            }
          }) //ajax ends
        } 
      }); 
  }

function submitSaveAndNext(data){ 
    console.log(data);
    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
      }
    }); 
    swal.fire({
        title: "Do you want to submit?",
        text: "",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#e7b63a',
        confirmButtonText: 'Submit',
        reverseButtons : true
        
      }).then((result) => {
        if(result.value){
            $.ajax({
            type    : "POST", 
           'url' : '<?php echo e(url("DisciplinaryRequest/saveDisciplinarySaveAndNext")); ?>',
            dataType  : "json",
            contentType : "application/json",
            data    : JSON.stringify(data),
            success   : function(response){
              console.log("response ",response);
              if(response.message=="success"){ 
                swal({
                    title:"Data saved successfully.",
                    type: "success",
                }).then(function(){     
                  window.location.href='<?php echo url("DisciplinaryRequest/viewDisciplinaryOthers") ?>';
                })
              }else{
                swal({
                  title:response.code,
                  text: response.message,
                  type:"warning"
                })
              }
            },
            error:function(xhr, status, error){
              var err = eval("(" + xhr.responseText + ")");
              //console.log('Error log---',err.message);
              swal(err.message.slice(err.message.indexOf('>:'),err.message.indexOf('(SQL:')).replace('>:',''));  
            }
          }) //ajax ends
        }
        
      });
  }  

function showAddPostModal(index){
    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
      }
    });
    $("#addPostBody").empty();
    
    if(index=='newdesig'){
        $.ajax({
              type: "GET",
              url : '<?php echo e(url("department/showDesignationForm")); ?>',
              success: function(response) {
              console.log(response);
              $("#addPostBody").append(response.html);
              $("#addPostModal").modal('show');
              },
              error: function(data) {
               
              }
          })
    }else{
        $("#addPostModal").modal('hide');
    }
   
}
function closeModal(index){
      if(index=='newdesig'){
        $("#presentDesigntion").val('');
        $("#pastDesigntion").val('');
        $("#investigationOfficerId").val('');
      }
      
      $("#addPostModal").modal('hide');
} 

function saveAjaxDesignation (){
  if (!blankValidation("designationName","TextField", "Designation can not be left blank"))
    return false;  

    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
      }
    });
    var data = new FormData(); 
    data.append('designationName', $("#designationName").val());
    data.append('departmentId', $("#departmentId").val());
    //console.log(data); 

   swal.fire({
        title: "Do you want to submit?",
        text: "",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#e7b63a',
        confirmButtonText: 'Submit',
        reverseButtons : true
        
      }).then((result) => {
        if(result.value){
            $.ajax({
            type  : "POST",
            url   : '<?php echo e(url("designation/saveDesignationAjax")); ?>', 
            data    : data,
            success : function(response){
              $("#addPostModal").modal('hide');
              
              if(response.message=="success"){ 
                swal({
                    title:"Data added successfully.",
                    type: "success",
                }).then(function(){    
                  
                  //console.log(response);
                  $("#presentDesigntion").empty();
                  var option = $("<option></option>");
                  $(option).val(null);
                  $(option).html("--Select--");
                  $("#presentDesigntion").append(option);
                  for (var i = 0; i < response.desigList.length; i++) {
                    var option = $("<option></option>");
                    $(option).val(response.desigList[i].TDM_Desig);
                    $(option).html(response.desigList[i].TDM_Desig_Name);
                    $("#presentDesigntion").append(option);
                  }
                  var option = $("<option></option>");
                    $(option).val("newdesig");
                    $(option).html("Add New");
                    $("#presentDesigntion").append(option);

                  $("#pastDesigntion").empty();
                  var option = $("<option></option>");
                  $(option).val(null);
                  $(option).html("--Select--");
                  $("#pastDesigntion").append(option);
                  for (var i = 0; i < response.desigList.length; i++) {
                    var option = $("<option></option>");
                    $(option).val(response.desigList[i].TDM_Desig);
                    $(option).html(response.desigList[i].TDM_Desig_Name);
                    $("#pastDesigntion").append(option);
                  }
                  var option = $("<option></option>");
                    $(option).val("newdesig");
                    $(option).html("Add New");
                    $("#pastDesigntion").append(option);

                  $("#investigationOfficerId").empty();
                  var option = $("<option></option>");
                  $(option).val(null);
                  $(option).html("--Select--");
                  $("#investigationOfficerId").append(option);
                  for (var i = 0; i < response.desigList.length; i++) {
                    var option = $("<option></option>");
                    $(option).val(response.desigList[i].TDM_Desig);
                    $(option).html(response.desigList[i].TDM_Desig_Name);
                    $("#investigationOfficerId").append(option);
                  }
                    var option = $("<option></option>");
                    $(option).val("newdesig");
                    $(option).html("Add New");
                    $("#investigationOfficerId").append(option);
        

                 //location.reload();
                })
              }else{
                swal({
                  title:response.code,
                  text: response.message,
                  type:"warning"
                })
              }
            },error   : function(xhr, status, error){
              $("#addPostModal").modal('hide');
              var err = eval("(" + xhr.responseText + ")");
              //console.log(err);
              swal(err.message.slice(err.message.indexOf('>:'),err.message.indexOf('(SQL:')).replace('>:','')); 
            },
            cache: false,
            contentType: false,
            processData: false
          }) //ajax ends
        } 
      }); 
}

</script>

<?php $__env->stopPush(); ?> 
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/disciplinary/add-disciplinary.blade.php ENDPATH**/ ?>