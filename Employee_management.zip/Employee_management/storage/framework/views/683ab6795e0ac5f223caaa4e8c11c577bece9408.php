<!--  <script src="<?php echo e(asset('js/compressed.js')); ?>"></script>
<script src="<?php echo e(asset('js/selectize.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/main.js')); ?>"></script>  -->
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/sweetalert2.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/validate.js')); ?>"></script> 
 <!-- <script src="<?php echo e(asset('js/main.js')); ?>"></script> -->
<!-- validator js -->

<script src="<?php echo e(asset('js/jquery.fancybox.min.js')); ?>"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
<script>
 $('#refresh').click(function(){
      $.ajax({
         type:'GET',
         url:'<?php echo e(url("refresh-captcha")); ?>',
         success:function(data){
            $(".captcha span").html(data.captcha);
         }
      });
    });
</script><?php /**PATH D:\xampp\htdocs\wethefamily\resources\views/frontend-layout/includejs.blade.php ENDPATH**/ ?>