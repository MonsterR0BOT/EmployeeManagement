<?php $__env->startSection('title', 'EVENT'); ?>
<?php $__env->startSection('content'); ?>
<section class="page_breadcrumbs ds background_cover section_padding_top_65 section_padding_bottom_65">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 text-center">
                <h2>Event</h2>
            </div>
        </div>
    </div>
</section>
<section class="ls section_padding_top_100 section_padding_bottom_100 columns_padding_30">
    <div class="container">
        <div class="row">
             <?php $__currentLoopData = $event_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
             <?php
             $TEM_Event_Image = $data->TEM_Event_Image;
             ?>
            <div class="col-sm-12 col-md-6 col-lg-6">
                <article class="post side-item side-md content-padding with_border bottom_color_border left loop-color">
                    <div class="row">
                        <div class="col-md-5">
                            <div class="item-media"> <img src="<?php echo e(asset('event_image/orig/'.$TEM_Event_Image)); ?>" alt="">
                                <div class="media-links"> <a class="abs-link" title="" href="#"></a> </div>
                            </div>
                        </div>
                        <div class="col-md-7">
                            <div class="item-content">
                                <header class="entry-header">
                                    <div class="entry-meta greylinks inline-content"> <span>
                                        <i class="fa fa-calendar highlight" aria-hidden="true"></i>
                                        <time datetime="2017-10-03T08:50:40+00:00"><?php echo e(date("d M,Y AM",strtotime($data->TEM_Event_Date))); ?></time>
                                    </span> <span>
                                        <i class="fa fa-map-marker highlight" aria-hidden="true"></i>
                                        <?php echo e($data->TEM_Event_Location); ?>

                                    </span> </div>
                                    <h3 class="entry-title small"><?php echo e($data->TEM_Event_Name); ?></h3>
                                </header>
                                <p><?php echo e($data->TEM_Event_Desc); ?></p>
                            </div>
                        </div>
                    </div>
                </article>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend-layout.frontend-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\wethefamily\resources\views/event.blade.php ENDPATH**/ ?>