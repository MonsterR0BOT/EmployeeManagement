<section class="news-section">
        <div class="auto-container">
            <div class="sec-title text-left">
                <h2>Excellency Certificate</h2>
            </div>
            <div class="news-box row">
                <div class="news-carousel owl-theme">
                    <!-- News Block -->
                    <div class="news-block">
                        <div class="inner-box">
                            <div class="image-box">
                                <figure class="image"><img src="<?php echo e(asset('images/certificate1.jpg')); ?>" alt=""></figure>
                                <!-- <div class="overlay-box"><a href="#"><i class="fa fa-link"></i></a></div> -->
                            </div>
                            <div class="caption-box">
                                <div class="post-date">25 <span>JUN</span></div>
                                
                                <h3><a href="#">Certificate of ISO</a></h3>
                            </div>
                        </div>
                    </div>

                    <!-- News Block -->
                    <div class="news-block">
                        <div class="inner-box">
                            <div class="image-box">
                                <figure class="image"><img src="<?php echo e(asset('images/certificate2.jpg')); ?>" alt=""></figure>
                                <!-- <div class="overlay-box"><a href="#"><i class="fa fa-link"></i></a></div> -->
                            </div>
                            <div class="caption-box">
                                <div class="post-date">25 <span>JUN</span></div>
                                
                                <h3><a href="#">Certificate of MSME</a></h3>
                            </div>
                        </div>
                    </div>

                    <!-- News Block -->
                    <div class="news-block">
                        <div class="inner-box">
                            <div class="image-box">
                                <figure class="image"><img src="<?php echo e(asset('images/certificate3.jpg')); ?>" alt=""></figure>
                                <!-- <div class="overlay-box"><a href="#"><i class="fa fa-link"></i></a></div> -->
                            </div>
                            <div class="caption-box">
                                <div class="post-date">17 <span>FEB</span></div>
                               
                                <h3><a href="#">Certificate of Registration</a></h3>
                            </div>
                        </div>
                    </div>

                    <!-- News Block -->
                    <div class="news-block">
                        <div class="inner-box">
                            <div class="image-box">
                                <figure class="image"><img src="<?php echo e(asset('images/certificate1.jpg')); ?>" alt=""></figure>
                                <!-- <div class="overlay-box"><a href="#"><i class="fa fa-link"></i></a></div> -->
                            </div>
                            <div class="caption-box">
                                <div class="post-date">27 <span>MAR</span></div>
                               
                                <h3><a href="#">Certificate of Polution</a></h3>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section><?php /**PATH E:\xampp\htdocs\aquatic\resources\views/frontend-layout/certificates.blade.php ENDPATH**/ ?>