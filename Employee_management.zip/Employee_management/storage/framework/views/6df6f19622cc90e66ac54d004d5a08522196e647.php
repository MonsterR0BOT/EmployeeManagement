 <div class="row">
    <div align="right" class="col-md-12">
                <!-- /.box-header -->
        <div class="box-body">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-3 bg-color1" align="left">Name of the eligible officers in the zone of</div>
                    <div class="col-md-3" align="left"><?php echo e($officerDtls->TPO_OfficerName); ?></div>
                    <div class="col-md-3 bg-color1" align="left">Type of promotion (Regular/Retrospective)</div>
                    <div class="col-md-3" align="left"><?php echo e($officerDtls->TPO_PromotionType); ?></div>
                </div>
                <div class="row">
                    <div class="col-md-3 bg-color1" align="left">Employee ID(HRMS)</div>
                    <div class="col-md-3" align="left"><?php echo e($officerDtls->TPO_HRMSID); ?></div>
                    <div class="col-md-3 bg-color1" align="left">Date of Birth</div>
                    <div class="col-md-3" align="left"><?php echo e($officerDtls->TPO_OfficerDOB); ?></div>
                </div>
                <div class="row">
                    <div class="col-md-3 bg-color1" align="left"> Caste(SC/ST/General)</div>
                    <div class="col-md-3" align="left"><?php echo e($officerDtls->TPO_OfficerCaste); ?></div>
                    <div class="col-md-3 bg-color1" align="left"> Name of the post to be filled up</div>
                    <div class="col-md-3" align="left"> <?php echo e($officerDtls->TPO_Promotion_Post); ?> </div>
                </div>
                <div class="row">
                    <div class="col-md-3 bg-color1" align="left">Group of the promotional post</div>
                    <div class="col-md-3" align="left"><?php echo e($officerDtls->TPO_Promotion_Group); ?></div>
                    <div class="col-md-3 bg-color1" align="left">Scale of Pay</div>
                    <div class="col-md-3 form-group" align="left"><?php echo e($officerDtls->TPO_PostPayScale); ?></div>
                </div>
                <div class="row">
                    <div class="col-md-3 bg-color1" align="left">Mention the back Period of Availability</div>
                    <div class="col-md-3" align="left"><?php echo e($officerDtls->TPO_MentionBackPeriodAvail); ?></div>
                    <div class="col-md-3 bg-color1" align="left">Designation as per the feeder post/grade</div>
                    <div class="col-md-3" align="left"><?php echo e($officerDtls->TPO_FeederPostDesignation); ?></div>
                </div>
                <div class="row">   
                    <div class="col-md-3 bg-color1" align="left">Is the officer regular on feeder grade</div>
                    <div class="col-md-3" align="left"><?php if($officerDtls->TPO_IsOfficerRegular==1): ?> <?php echo e("Yes"); ?> <?php else: ?> <?php echo e("No"); ?> <?php endif; ?></div>
                    <div class="col-md-3  bg-color1" align="left">Is the officer selected for promotion as per the recruitment rule.</div>
                    <div class="col-md-3" align="left"><?php if($officerDtls->TPO_IsOfficerSelected_AsperRule==1): ?> <?php echo e("Yes"); ?> <?php else: ?> <?php echo e("No"); ?> <?php endif; ?></div>
                </div>
                <div class="row">
                    <div class="col-md-3 bg-color1" align="left">Is there any criminal case/disciplinary proceedings/vigilance case is pending</div>
                    <div class="col-md-3" align="left"><?php if($officerDtls->TPO_IsCriminalCasePending==1): ?> <?php echo e("Yes"); ?> <?php else: ?> <?php echo e("No"); ?> <?php endif; ?></div>
                    <div class="col-md-3  bg-color1" align="left">Availability of CCRs & PARs</div>
                    <div class="col-md-3" align="left"><?php if($officerDtls->TPO_IsCCRAvailable==1): ?> <?php echo e("Yes"); ?> <?php else: ?> <?php echo e("No"); ?> <?php endif; ?></div>
                </div>
                <div class="row">
                    <div class="col-md-3 bg-color1" align="left">Period of Availability of CCRs & PARs</div>
                    <div class="col-md-3" align="left"><?php echo e($officerDtls->TPO_CCRAvailable_Period); ?></div>
                    <div class="col-md-3 bg-color1" align="left"> Is the officer given adhoc promotion DPC/SB </div>
                    <div class="col-md-3" align="left"><?php if($officerDtls->TPO_IsOfficerGivenAdhcPromotion==1): ?> <?php echo e("Yes"); ?> <?php else: ?> <?php echo e("No"); ?> <?php endif; ?> </div>
                </div>
                <div class="row">   
                    <div class="col-md-3  bg-color1" align="left">Period of CCRs perused by DPC/SB</div>
                    <div class="col-md-3" align="left"><?php echo e($officerDtls->TPO_CCRPeriod_PersuedByDPC); ?></div>
                    
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/promotional/ajax-officer-details-view.blade.php ENDPATH**/ ?>