<?php $__env->startSection('title', 'AUDIT'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       MIS Annual Report of Promoted Officers
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">MIS Annual Report</a></li>
        <li class="active">Promoted Officers Reporters</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <!-- <h3 class="box-title">Data Table With Full Features</h3> -->
               <!--  <div class="row">
                  <div class="col-md-12" align="right">
                    <a href="#" target="_blank" class="btn btn-default"><i class="fa fa-print"></i> Print</a>
                    <a href="#" target="_blank" class="btn btn-default"><i class="fa fa-file-pdf-o"></i> PDF</a>
                  </div>
                </div> -->
                	<div id="demo" >
                <div class="search-field">
                    <div class="row">
    
                        <div class="col-md-2">
                            <div class="org-name">From Date</div>
                        </div>
                        <div class="col-md-2">
                            <input class="form-control" type="text" id="param1">
                        </div>
                        
                        <div class="col-md-1">
                            <div class="org-name">To Date</div>
                        </div>
                        <div class="col-md-2">
                            <input class="form-control" type="text" id="param2">
                        </div>
                        
                        <div class="col-md-1">
                            <div class="org-name">Department</div>
                        </div>
                        <div class="col-md-2">
                            <input class="form-control" type="text" id="param3">
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <button class="btn btn-primary" onClick="searchData()">Search</button>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12" align="right">
                        <a href="#" target="_blank" class="btn btn-default"><i class="fa fa-print"></i> Print</a>
                        <a href="#" target="_blank" class="btn btn-default"><i class="fa fa-file-pdf-o"></i> PDF</a>
                    </div>
                    </div>
                </div>
            </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
           <!-- <a data-toggle="collapse" data-target="#demo"
                class="showhideangelbg"><i class="fa fa-angle-double-down"></i>
            </a>-->
              <table id="listAllUser" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Application No.</th>
                  <th>Application Date Time</th>
                  <th>Department</th>
                  <th>Officer Name</th> 
                  <th>Current Designation</th>  
                  <th>Past Designation</th> 
                  <th>Current Pay Scale</th>
                  <th>Past Pay Scale</th>
                  <th>Current Grade Pay</th> 
                  <th>Past Grade Pay</th> 
                </tr>
                </thead>
                <tbody>
                 <tr> 
                  <td><a href="<?php echo e(url('manage-aging-report')); ?>" > PR000110011</a></td>
                  <td>2-12-2019 10:00:12</td>
                  <td>Police</td>
                  <td>Sachin Panda</td>
                  <td>Inspector</td>
                  <td>Sub Inspector</td>  
                  <td>9,300/- to 34,800/</td> 
                  <td>14,500/- to 48,800/</td>
                  <td>4200</td>
                  <td>4600</td>
                 </tr> 

                 <tr> 
                  <td><a href="<?php echo e(url('manage-aging-report')); ?>" > PR000110012</a></td>
                  <td>12-12-2019 10:00:12</td>
                  <td>Police</td>
                  <td>Akash Behera</td>
                  <td>Sub Inspector</td>
                  <td>Assistant Sub Inspector</td> 
                  <td>7,500/- to 28,800/</td> 
                  <td>9,300/- to 34,800/</td> 
                  <td>2800</td>
                  <td>4200</td> 
                 </tr>
                
                 <tr> 
                  <td><a href="<?php echo e(url('manage-aging-report')); ?>" > PR000110013</a></td>
                  <td>22-12-2019 10:00:12</td>
                  <td>Police</td>
                  <td>Ajay Sexena</td>
                  <td>Sub Inspector</td>
                  <td>Assistant Sub Inspector</td> 
                  <td>7,500/- to 28,800/</td> 
                  <td>9,300/- to 34,800/</td> 
                  <td>2800</td>
                  <td>4200</td> 
                 </tr>
                 
                 
                   <tr> 
                  <td><a href="<?php echo e(url('manage-aging-report')); ?>" > PR000110014</a></td>
                  <td>22-11-2019 10:00:12</td>
                  <td>Police</td>
                  <td>Ansul Sastri</td>
                  <td>Sub Inspector</td>
                  <td>Assistant Sub Inspector</td> 
                  <td>7,500/- to 28,800/</td> 
                  <td>9,300/- to 34,800/</td> 
                  <td>2800</td>
                  <td>4200</td> 
                 </tr>
                 
             
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
             <!-- <div class="box-footer" align="center">
	            <button type="button" class="btn btn-warning" onclick="window.location.href='manage-mis-annual-report'">Return Back</button>
	          </div> -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
    	 
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('styles'); ?>
<!--Extra styles can written here -->
<?php $__env->stopPush(); ?>  
<?php $__env->startPush('scripts'); ?>

<script>

 
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-demo\resources\views/mis/manage-promoted-report.blade.php ENDPATH**/ ?>