<?php $__env->startSection('title', 'SERVICES'); ?>
<?php $__env->startSection('content'); ?>   
    <section class="page_breadcrumbs ds background_cover section_padding_top_65 section_padding_bottom_65">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 text-center">
                        <h2>Services</h2>
                    </div>
                </div>
            </div>
    </section>
    <section class="ls section_padding_top_100 section_padding_bottom_100 columns_margin_bottom_20">
        <div class="container">
            <div class="row flex-wrap">

                 <?php $__currentLoopData = $service_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                 <?php
                 $TSM_Service_Image = $data->TSM_Service_Image;
                 ?>
                <div class="col-md-4 col-sm-6">
                    <article class="vertical-item content-padding big-padding with_border bottom_color_border loop-color text-center">
                        <div class="item-media"> 
                            <div class="item-media entry-thumbnail">
                            <img src="<?php echo e(asset('service_image/orig/'.$TSM_Service_Image)); ?>" alt="">
                            </div> </div>
                        <div class="item-content">
                            <header class="entry-header">
                                <h3 class="entry-title small"> <a href="#"><?php echo e($data->TSM_Service_Name); ?></a> </h3>
                            </header>
                            <p class="content-3lines-ellipsis"><?php echo e($data->TSM_Service_Desc); ?></p>
                        </div>
                    </article>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>    
<?php echo $__env->make('frontend-layout.frontend-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\wethefamily\resources\views/services.blade.php ENDPATH**/ ?>