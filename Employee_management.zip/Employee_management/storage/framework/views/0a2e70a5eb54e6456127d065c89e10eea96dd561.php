<?php $__env->startSection('title', 'CHART'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Promotion Charts
        <small>Preview sample</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Audit Trail</a></li>
        <li class="active">Charts</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
      	 <!-- /.col (LEFT) -->
        
        <div class="col-md-12">

          <!-- BAR CHART -->
          <div class="box box-success">
            <div class="box-header with-border">
              <h3 class="box-title">Monthly Chart</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <div class="box-body">
              <div class="chart">
                <canvas id="canvas" style="height:350px"></canvas>
              </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

        </div>
        

        <div class="col-md-12">

          <!-- BAR CHART -->
          <div class="box box-success">
            <div class="box-header with-border">
              <h3 class="box-title">Weekly Chart</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <div class="box-body">
              <div class="chart">
                <canvas id="barChart" style="height:350px"></canvas>
              </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

        </div>
       
      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('scripts'); ?>
<script>
		//var MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
		var config = {
			type: 'line',
			data: {
				labels: ['January', 'February', 'March', 'April', 'May', 'June','July','August','September','October','November','December'],
				datasets: [{
					label: 'Added',
					backgroundColor:'rgba(150,158,210,0.9)',
					borderColor: 'rgba(70,158,210,0.9)',
					data: [95, 125, 143, 68, 114, 73,85,148,159,85,96,120],
					fill: false,
				}, {
					label: 'Modified',
					fill: false,
					backgroundColor: 'rgba(150,158,210,0.9)',
					borderColor: 'rgba(150,158,210,0.9)',
					data: [85, 105, 133, 68, 94, 43,53,65,128,139,65,76,100],
				}, {
					label: 'Deleted',
					fill: false,
					backgroundColor: 'rgba(90,198,20,0.9)',
					borderColor: 'rgba(90,198,20,0.9)',
					data: [10, 20, 20, 0, 20, 30,20,20,20,20,20,20],
				}]
			},
			options: {
				responsive: true,
				title: {
					display: false,
					text: 'Audit Monthly Promotional Chart'
				},
				tooltips: {
					mode: 'index',
					intersect: false,
				},
				hover: {
					mode: 'nearest',
					intersect: true
				},
				scales: {
					xAxes: [{
						display: true,
						scaleLabel: {
							display: true,
							labelString: 'Monthly'
						}
					}],
					yAxes: [{
						display: true,
						scaleLabel: {
							display: true,
							labelString: 'Value'
						}
					}]
				}
			}
		};


		//var MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
		var color = Chart.helpers.color;
		var barChartData = {
			labels: ['Day 1', 'Day 2', 'Day 3', 'Day 4', 'Day 5', 'Day 6'],
			datasets: [
			{
				label: 'Added',
				backgroundColor:'rgba(150,158,210,0.9)',
				borderColor:'rgba(150,158,210,0.9)',
				borderWidth: 1,
				data: [95, 125, 143, 68, 114, 73 ],
			}, {
				label: 'Modified',
				backgroundColor: 'rgba(100,168,10,0.9)',
				borderColor: 'rgba(100,168,10,0.9)',
				borderWidth: 1,
				data:[85, 105, 133, 68, 94, 43 ],
			},{
				label: 'Deleted',
				backgroundColor: 'rgba(100,168,10,0.9)',
				borderColor: 'rgba(100,168,10,0.9)',
				borderWidth: 1,
				data:[10, 20, 10, 00, 20, 30 ],
			}]

		};


		$(function () {
			var ctx = document.getElementById('canvas').getContext('2d');
			window.myLine = new Chart(ctx, config);

			//////////////

			var ctx1 = document.getElementById('barChart').getContext('2d');
			window.myBar = new Chart(ctx1, {
				type: 'bar',
				data: barChartData,
				options: {
					responsive: true,
					legend: {
						position: 'top',
					},
					title: {
						display: false,
						text: 'Audit Weekly Promotional Chart'
					}
				}
			});
		}); 

		 

		 
		
	</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-demo\resources\views/audit/manage-audit-chart-promotion.blade.php ENDPATH**/ ?>