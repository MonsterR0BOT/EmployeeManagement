<?php $__env->startSection('title', 'MEMBER'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Manage Member
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">User</a></li>
        <li class="active">Manage Member</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box">
           <!-- <div class="box-header">
              <h3 class="box-title">Data Table With Full Features</h3>
            </div>-->
            <!-- /.box-header -->
            <div class="box-body">
            	<div id="demo" >
                <div class="search-field">
                <!-- 	<div class="row">
            			<div class="col-md-12">
                            <div class="form-group pull-right">
                                <a href="<?php echo e(url('user/showAddUser')); ?>"><button class="btn btn-primary">Add User</button></a>
                            </div>
                        </div>
                	</div> -->
                    <div class="row">
    
                        <div class="col-md-2">
                            <div class="org-name">User Name</div>
                        </div>
                        <div class="col-md-2">
                            <input class="form-control" type="text" id="param1">
                        </div>
                        
                        <div class="col-md-1">
                            <div class="org-name">Mobile</div>
                        </div>
                        <div class="col-md-2">
                            <input class="form-control" type="text" id="param2">
                        </div>
                        
                        <div class="col-md-1">
                            <div class="org-name">Email</div>
                        </div>
                        <div class="col-md-2">
                            <input class="form-control" type="text" id="param3">
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <button class="btn btn-primary" onClick="searchData()">Search</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
           <!-- <a data-toggle="collapse" data-target="#demo"
                class="showhideangelbg"><i class="fa fa-angle-double-down"></i>
            </a>-->
              <table id="listAllUser" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Member Name</th>
                  <th>Member Type</th>
                  <th>Mobile No</th>
                  <th>Email</th>
                  <th>Qualification </th>
                  <th>Ocupation</th>
                  <th>Location</th>
                  <th>Status</th>
                  <th>Approve Status</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
    
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('styles'); ?>
<!--Extra styles can written here -->
<?php $__env->stopPush(); ?>  
<?php $__env->startPush('scripts'); ?>

<script>
  $(function () {
	$('#listAllUser').DataTable({
		'processing' : true,
		'serverSide' : true,
		'searching' : false,
		'ordering' : false,
		"ajax" : {
			'url' : "<?php echo e(url('manageuser/viewMemberthroughAjax')); ?>",
			'data' : function(d) {
				d.param1 = $('#param1').val();
				d.param2 = $('#param2').val();
				d.param3 = $('#param3').val();

			}
		},
		'dataSrc' : "",
		'columns' : [ {
			'data' : 'TMM_Member_Name'
		}, {
			'data' : 'TMM_MemberType'
		}, {
			'data' : 'TMM_Member_Mobile'
		}, {
			'data' : 'TMM_Member_Email'
		}, {
			'data' : 'TQM_Qualification_Name'
		}, {
			'data' : 'TOM_Occupation_Name'
		},{
			'data' : 'TMM_Member_prLocation'
		}, {
			'data' : 'TMM_Member_Status'
		},{
			'data' : 'TMM_Member_Approve'
		}, {
			'data' : 'action'
		}

		]
	});
	
  });
  //Method For Searching Records In The List
	function searchData() {
		$('#listAllUser').DataTable().draw();
	}
	//Deleting user
	function deleteMember(id){
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
			}
		});
		swal.fire({
			  title: "Do you want to delete the Member?",
			  text: "Once deleted, can't revert back !",
			  type: "warning",
			  showCancelButton: true,
			  confirmButtonColor: '#d33',
			  cancelButtonColor: '#e7b63a',
			  confirmButtonText: 'Delete',
			  reverseButtons : true,
			}).then((result) => {
				if(result.value){
				 $.ajax({
					    type: "POST",
					    url:"<?php echo e(url('manageuser/deleteMemberthroughAjax')); ?>",
					    data:{'id':id},
					    success: function(response) {
						console.log(response);
						//return false;
					        if (response.message == "success") {
					        	swal({
					        		title: "Record deleted successfully.",
					        		type: "success"
					        	}).then(function(){
					        		 location.reload();
					        	})
					        
					        	
					        } else {
					            swal({
					                title: 'Unsuccess',
					                text: response.code
					            })
					        }
					    },
					    error: function(data) {
				       
					    }
					})
				}
			  
			});
	}
	//unblock user
	function unblockMember(id){
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
			}
		});
		swal.fire({
			  title: "Do you want to Approve the Member?",
			  text: "Once Approve, can't revert back !",
			  type: "warning",
			  showCancelButton: true,
			  confirmButtonColor: '#d33',
			  cancelButtonColor: '#e7b63a',
			  confirmButtonText: 'Approved',
			  reverseButtons : true,
			}).then((result) => {
				if(result.value){
				 $.ajax({
					    type: "POST",
					    url:"<?php echo e(url('manageuser/approveMemberthroughAjax')); ?>",
					    data:{'id':id},
					    success: function(response) {
						console.log(response);
						//return false;
					        if (response.message == "success") {
					        	swal({
					        		title: "Member Approve successfully.",
					        		type: "success"
					        	}).then(function(){
					        		 location.reload();
					        	})
					        
					        	
					        } else {
					            swal({
					                title: 'Unsuccess',
					                text: response.code
					            })
					        }
					    },
					    error: function(data) {
				       
					    }
					})
				}
			  
			});
	}
	/* VIEW IN MODEL USER DATA */
	function modalview(index) {
	 	$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
			}
		});
	//var id = window.atob(index);
		$('#table1').empty();
		$.ajax({
			type : "POST",
			url : "<?php echo e(url('manageuser/ViewMemberModal')); ?>",
			dataType : 'json',
			//contentType : 'application/json',
			data : {"memberId":index},
			success : function(response) {
				if (response.message == "success") {
					//console.log(response.userData.userStatus);
					var status = "";
					if (response.userData.TMM_Member_Status) {
						status = "Active";
					} else {
						status = "InActive";
					}
					table = '<tr><td>User Name :</td>' + '<td align="left">'
							+ response.userData.TMM_Member_Name + '</td>'
							+ '</tr><tr><td>User Role :</td>' + '<td align="left">'
							+ response.userData.TOM_Occupation_Name + '</td>'
							+ '</tr><tr><td>IMEI Number</td><td align="left">'
							+ response.userData.TQM_Qualification_Name
							+ '</td></tr><tr><td>Mobile Number</td><td align="left">'
							+ response.userData.TMM_Member_Mobile
							+ '</td></tr><tr><td>Email</td><td align="left">'
							+ response.userData.TMM_Member_Email
							+ '</td></tr><tr><td>Country</td><td align="left">'
							+ response.userData.TMM_Membe_prLocation
							+ '</td></tr><tr><td>State</td><td align="left">'
							+ response.userData.TMM_Membe_prLocation
							+ '</td></tr><tr><td>District</td><td align="left">'
							+ response.userData.TMM_Membe_prLocation
							+ '</td></tr><tr><td>PIN</td><td align="left">'
							+ response.userData.TMM_Membe_prLocation
							+ '</td></tr><tr><td>Status</td><td align="left">'
							+ status
							+ '</td></tr>';
					$('#myModal').modal('show');
					$('#table1').append(table);
				}
			},
			error : function(data) {
				console.log(data);
			}
		})

	} 
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\aquatic\resources\views/manageuser/manage-member.blade.php ENDPATH**/ ?>