<?php $cnt=0;?>
<?php $cntn=1;?>
 <?php $__currentLoopData = $pay_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <tr class="tr_clone">
  <td valign="top">
   <input type="text" id="paylevel_<?php echo e($cnt); ?>" class="form-control payLevelCls" size="2" value="<?php echo e($pay->TPLM_PayLevel); ?>">
  </td>
  <td valign="top">
    <input type="text" id="level_<?php echo e($cnt); ?>" class="form-control levelCls" size="2" value="<?php echo e($pay->TPLM_Level); ?>">
  </td>
  <td valign="top">
    <input type="text" id="gradepay_<?php echo e($cnt); ?>" class="form-control gradepayCls" size="2" value="<?php echo e($pay->TPLM_GradePay); ?>">
  </td>
  <td valign="top">
    <input type="text" name="" id="payband_<?php echo e($cnt); ?>" class="form-control paybandCls" size="2" value="<?php echo e($pay->TPLM_Payband); ?>">
  </td>
  <td valign="top">
    <button style="display: none" type="button" class="btn btn-primary button-add tr_clone_add" name="add" onclick="addMore();">
        <i class="fa fa-plus"></i>
      </button>&nbsp;
      <button type="button" class="btn btn-warning button-remove rmv" name="Remove">
        <i class="fa fa-minus"></i>
      </button>
  </td>
</tr>
<?php $cnt++ ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<tr class="tr_clone">
  <td valign="top">
   <input type="text" id="paylevel_<?php echo e($cnt); ?>" class="form-control payLevelCls" size="2" value="">
  </td>
  <td valign="top">
    <input type="text" id="level_<?php echo e($cnt); ?>" class="form-control levelCls" size="2" value="">
  </td>
  <td valign="top">
    <input type="text" id="gradepay_<?php echo e($cnt); ?>" class="form-control gradepayCls" size="2" value="">
  </td>
  <td valign="top">
    <input type="text" name="" id="payband_<?php echo e($cnt); ?>" class="form-control paybandCls" size="2">
  </td>
  <!-- <input type="hidden" name="txtusername" id="txtusername" value="<?php echo e(session()->get('userId')); ?>"> -->
  <td valign="top">
    <button type="button" class="btn btn-primary button-add tr_clone_add" name="add" onclick="addMore();">
      <i class="fa fa-plus"></i>
    </button>
    <button type="button" class="btn btn-warning button-remove rmv" name="Remove">
      <i class="fa fa-minus"></i>
    </button>
  </td>
</tr><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/master/ajax-pay-label-master.blade.php ENDPATH**/ ?>