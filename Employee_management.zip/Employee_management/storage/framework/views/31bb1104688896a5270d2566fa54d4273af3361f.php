<?php $__env->startSection('title', 'AUDIT'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       MIS Annual Report Of Department# EDUCATION
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">MIS Annual Report</a></li>
        <li class="active"> MIS Department Wise Annual Report</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box">
            <div class="box-header">
              <!-- <h3 class="box-title">Data Table With Full Features</h3> -->
                 <div class="search-field">
                    <div class="row">
    
                        <div class="col-md-2">
                            <div class="org-name">From Date</div>
                        </div>
                        <div class="col-md-2">
                            <input class="form-control datepicker" type="text" id="param1">
                        </div>
                        
                        <div class="col-md-1">
                            <div class="org-name">To Date</div>
                        </div>
                        <div class="col-md-2">
                            <input class="form-control datepicker" type="text" id="param2">
                        </div>
                        
                        <div class="col-md-1">
                            <div class="org-name">Department</div>
                        </div>
                        <div class="col-md-2">
                           <select class="form-control">
                            <option value="Home">Home</option>
                            <option value="Production">Production</option>
                            <option value="Education">Education</option>
                            <option value="Agriculture">Agriculture</option>
                            <option value="Water Resource">Water Resource</option>
                            <option value="Natural Resource">Natural Resource</option>
                            <option value="Electricity">Electricity</option>
                          </select>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <button class="btn btn-primary" onClick="searchData()">Search</button>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12" align="right">
                        <a href="#" target="_blank" class="btn btn-default"><i class="fa fa-print"></i> Print</a>
                        <a href="#" target="_blank" class="btn btn-default"><i class="fa fa-file-pdf-o"></i> PDF</a>
                    </div>
                    </div>
                </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
           <!-- <a data-toggle="collapse" data-target="#demo"
                class="showhideangelbg"><i class="fa fa-angle-double-down"></i>
            </a>-->
              <table id="listAllUser" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Application No.</th>
                  <th>Application Date Time</th>
                  <th>Department</th> 
                  <th>Status</th> 
                  <th>By Whom</th>
                  <th>Comments</th>
                  <th>IP Address</th>
                </tr>
                </thead>
                <tbody>
                 <tr> 
                  <td><a href="<?php echo e(url('manage-aging-report')); ?>" > PR00011001</a></td>
                  <td>2-12-2019 10:00:12</td>
                  <td>Education</td>
                  <td>Approved</td>
                  <td>Sahadev Sahoo</td>  
                  <td>The praposal is Approved and send to OPSC</td>
                  <td>213.123.0.13</td>
                 </tr> 
                 <tr>
                  <td><a href="<?php echo e(url('manage-aging-report')); ?>" > PR00011002</a></td>
                  <td>3-12-2019 10:00:12</td>
                  <td>Education</td>
                  <td>Approved</td> 
                  <td>Minati Panda</td>  
                  <td>The proposal is Approved and send to OPSC</td>
                  <td>192.123.0.12</td>
                </tr>
                <tr>
                  <td><a href="<?php echo e(url('manage-aging-report')); ?>" > PR00011003</a></td>
                  <td>3-12-2019 11:00:12</td>
                  <td>Education</td>
                  <td>Verified</td> 
                  <td>Golak Behera</td> 
                  <td>The proposal is verified and forwarded.</td>
                  <td>192.123.0.12</td>
                </tr>
                <tr>
                  <td><a href="<?php echo e(url('manage-aging-report')); ?>" > PR00011004</a></td>
                  <td>3-12-2019 10:00:12</td>
                  <td>Education</td>
                  <td>Approved</td> 
                  <td>Yudhistir Nayak</td> 
                  <td>The proposal is Approved and send to OPSC.</td>
                  <td>192.123.0.12</td>
                </tr>
                <tr>
                  <td><a href="<?php echo e(url('manage-aging-report')); ?>" > PR00011005</a></td>
                  <td>3-12-2019 10:00:12</td>
                  <td>Education</td>
                  <td>Rejected</td> 
                  <td>Yudhistir Nayak</td> 
                  <td>The proposal is Rejected.</td>
                  <td>192.123.0.12</td>
                </tr>
                <tr>
                  <td><a href="<?php echo e(url('manage-aging-report')); ?>" > PR00011006</a></td>
                  <td>4-12-2019 10:00:12</td>
                  <td>Education</td>
                  <td>Verified</td> 
                  <td>Mr. Amulya Mohanty</td> 
                  <td>The proposal is verified and forwarded.</td>
                  <td>192.123.0.12</td>
                </tr>
                <tr>
                  <td><a href="<?php echo e(url('manage-aging-report')); ?>" > PR00011007</a></td>
                  <td>1-12-2019 10:00:12</td>
                  <td>Education</td>
                  <td>Approved</td> 
                  <td>Sahadev Sahoo</td> 
                  <td>The praposal is Approved and send to OPSC</td>
                  <td>213.123.0.12</td>
                </tr>
             
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
             <div class="box-footer" align="center">
	            <button type="button" class="btn btn-warning" onclick="window.location.href='manage-mis-annual-report'">Return Back</button>
	          </div>
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
    	 
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('styles'); ?>
<!--Extra styles can written here -->
<?php $__env->stopPush(); ?>  
<?php $__env->startPush('scripts'); ?>

<script>

  /*$(function () {
	$('#listAllUser').DataTable({
		'processing' : true,
		'serverSide' : true,
		'searching' : false,
		'ordering' : false,
		"ajax" : {
			'url' : 'view-user-throughAjax',
			'data' : function(d) {
				d.param1 = $('#param1').val();
				d.param2 = $('#param2').val();
				d.param3 = $('#param3').val();

			}
		},
		'dataSrc' : "",
		'columns' : [ {
			'data' : 'TUM_User_Name'
		}, {
			'data' : 'TUT_UserTypeName'
		}, {
			'data' : 'TUM_User_IMEI'
		}, {
			'data' : 'TUM_User_Mobile'
		}, {
			'data' : 'TUM_User_Email'
		}, {
			'data' : 'TCM_Country_Name'
		}, {
			'data' : 'TSM_State_Name'
		}, {
			'data' : 'TDM_Dist_Name'
		}, {
			'data' : 'TUM_User_Pin'
		}, {
			'data' : 'TUM_User_Status'
		}, {
			'data' : 'action'
		}

		]
	});
	
  });*/
  //Method For Searching Records In The List
	/*function searchData() {
		$('#listAllUser').DataTable().draw();
	}*/
	
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/mis/manage-mis-deptwise-report.blade.php ENDPATH**/ ?>