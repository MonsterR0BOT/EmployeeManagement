<?php $__env->startSection('title', 'CATEGORY'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Add Category</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Add Category</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      
      <!-- Default box -->
      <div class="box">
       <!-- <div class="box-header">
          <h3 class="box-title">Quick Example</h3>
        </div>-->
        <!-- /.box-header -->
        <!-- form start -->
        <form role="form" method="post" action="<?php echo e(url('Content/addCategory')); ?>"  onsubmit="return validateForm()" autocomplete="off">
          <?php echo csrf_field(); ?>
          <div class="box-body">
            <?php if(Session::has('errors')): ?>
                  <div class="col-md-12 alert alert-warning">
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php echo e($error); ?><br/>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
              <?php endif; ?>
            <div class="row">
                <div class="col-md-6">
                  <?php
                    if(!empty($data)){
                      $categoryId = $data[0]->TCM_Category;
                        $TCM_Category_Name  = $data[0]->TCM_Category_Name;
                        $TCM_Category_Status = $data[0]->TCM_Category_Status;
                    }else{
                      $categoryId = '';
                        $TCM_Category_Name  = '';
                        $TCM_Category_Status = 1;
                    }
                    ?>
                 
                    <div class="form-group">
                      <label for="exampleInputEmail1">Category Name</label>
                      <input type="text" class="form-control" name="categoryName" id="categoryName" value="<?php echo e($TCM_Category_Name); ?>">
                    </div>
               
                    <div class="form-group">
                      <label for="exampleInputFile">Status</label>
                      <select class="form-control" name="categoryActive" id="categoryActive">
                        <option value="">--Select--</option>
                        <option value="1" <?php if($TCM_Category_Status ==1): ?> selected="selected" <?php endif; ?>>Active</option>
                        <option value="0" <?php if($TCM_Category_Status ==0): ?> selected="selected" <?php endif; ?>>Inactive</option>
                      </select>
                    </div>
                </div>
                <div class="col-md-6">
         
                </div>
            </div>
          </div>
          <!-- /.box-body -->
          <div class="box-footer">
          <input type="hidden" name="hidCategory" value="<?php echo e($categoryId); ?>"/>
            <button type="submit" class="btn btn-primary">Submit</button>
           <a href="<?php echo e(url('Content/viewAllCategory')); ?>"> <button type="button" class="btn btn-warning">Cancel</button> </a>
          </div>
        </form>
      </div>
      <!-- /.box -->
      
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('scripts'); ?> 
<script type="text/javascript">
   function validateForm(){
    //alert("alert");return false;
    /*if (!blankValidation("countryName","SelectBox", "Country Name can not be left blank"))
      return false;*/
    if (!blankValidation("categoryName","TextField", "Caste Name can not be left blank"))
      return false;
    if (!blankValidation("categoryActive","TextField", "Status  can not be left blank"))
      return false; 
   }  



    function serverUnreachableHandler(e) {
      document.getElementById("errorDiv").innerHTML =
      "Transliteration Server unreachable";
    }
    function serverReachableHandler(e) {
      document.getElementById("errorDiv").innerHTML = "";
    }
    google.setOnLoadCallback(onLoad);
  </script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\wethefamily\resources\views/content/add-category.blade.php ENDPATH**/ ?>