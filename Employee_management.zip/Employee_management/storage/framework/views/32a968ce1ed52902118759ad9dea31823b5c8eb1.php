<?php $__env->startSection('title', 'PROMOTION'); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
   <!-- Content Header (Page header) -->
   <section class="content-header">
      <h1>Edit Promotion Request</h1>
      <ol class="breadcrumb">
         <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
         <li><a href="#">Promotion</a></li>
         <li class="active">Edit Promotion</li>
      </ol>
   </section>
   <!-- Main content -->
   <section class="content">
      <div class="row">
         <div class="col-md-12">
         <div class="bs-example">
    <div class="accordion" id="accordionExample">
      <div class="box">
            <div class="card-header" id="headingOne">
                <a  data-toggle="collapse" data-target="#collapseOne" class="accordianheading"><div class="row"> 
                  <div class="col-md-11"><h5>OPSC Information</h5></div>
                   <div class="col-md-1 "><i class="fa fa-plus acrdplus"></i></div>
                </div> <div class="clearfix"></div></a>                  
          </div>
            <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                <div class="card-body">
                    <div class="box-body">
                  <div class="formsec row">
                     <div class="col-md-3">
                           <div class="paddingsmlmin">1.</div> <div class="paddingsmlmax">Name of the Department</div>
                     </div>
                     <div class="col-md-3">
                         <select class="form-control" name="userStatus" id="userStatus">
                          <option value="">Agriculture & F.E Department</option>
                         </select>
                     </div>
                     <div class="col-md-3">
                      <div class="paddingsmlmin">2.</div> <div class="paddingsmlmax">Name of the posts to be filled up</div>
                    </div>
                     <div class="col-md-3">
                     <select class="form-control" name="userStatus" id="userStatus" onchange="showAddPostModal(this.value);">
                          <option value="">Secretary</option>
                          <option value="new">Add New</option>

                       </select>
                     </div>
                     <div class="clearfix"></div>
                     </div>
                      <div class="clearfix"></div>
                     <div class="formsec row">
                     <div class="col-md-6">
                       <div class="paddinglessmin">3.</div> <div class="paddinglessmax">Group to which promotional posts to ('A' Or 'B')with Scale of Pay & G.P</div>
                     </div>
                     <div class="col-md-3">
                           <select class="form-control" name="userStatus" id="userStatus">
                              <option value="">Group A</option>
                           </select>
                         </div>
                      <div class="col-md-3">
                        <textarea class="form-control">The Odisha Public Service Commission was constituted on 1st April, 1949
                        </textarea>
                     
                     </div>
                     <div class="clearfix"></div>
                     </div>
                     
                     <div class="clearfix"></div>
                     <div class="formsec row">
                        <div class="col-md-6">
                              <div class="paddinglessmin">4.</div> <div class="paddinglessmax">Whether the previous proposal for such promotion has been finalised on recommendation of the O.P.S.C. If So</div>
                           
                        </div>
                         <div class="col-md-3">
                           <div class="row">
                           <div class="col-md-6">
                           <input type="radio" name="" checked="">
                           Yes
                           </div>
                           <div class="col-md-6">
                           <input type="radio" name=""  >
                           No
                           </div>
                        </div>
                      </div>
                     
                        <div class="clearfix"></div>
                        <div class="col-md-4">
                           <div align="center">
                              <div align="center">Ref. No. & Date of D.P.C/S.B.</div>
                                <select class="form-control" name="userStatus" id="userStatus" onclick="showAddPostModal(this.value);">
                                    <option value="">9523/Ex - 02/09/2016</option>
                                    <option value="newref">Add New</option>
                                 </select>
                              </div>
                           </div>
                       
                        <div class="col-md-4">
                           <div  align="center">
                              <div align="center">Ref. No. & Date of reference to O.P.S.C.</div>
                            <select class="form-control" name="userStatus" id="userStatus" onclick="showAddPostModal(this.value);">
                                    <option value="">9523/Ex - 02/09/2016</option>
                                    <option value="newref">Add New</option>
                                 </select>
                           </div>
                        </div>
                        <div class="col-md-4">
                           <div  align="center">
                              <div align="center">Ref. No. & Date of recommendation of O.P.S.C.</div>
                              <select class="form-control" name="userStatus" id="userStatus" onclick="showAddPostModal(this.value);">
                                    <option value="">9523/Ex - 02/09/2016</option>
                                    <option value="newref">Add New</option>
                                 </select>
                           </div>
                        </div>
                        </div>
                     
                        <div class="clearfix"></div>
                      <div class="formsec row">
                     <div class="col-md-6">
                           <div class="paddinglessmin">5.</div> <div class="paddinglessmax">Date of D.P.C/S.B. in respect of the present proposal(attested copy of the proceeding of the DPC/SB to be furnished)</div>
                     </div>
                      <div class="col-md-2">
                        <div class="input-group">
                           <input type="text" id="" class="form-control"  value="5334/Ex">
                        </div>
                      </div>
                     <div class="col-md-2">
                      <div class="input-group">
                           <div class="input-group-prepend">
                              <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                           </div>
                           <input type="text" class="form-control pull-right datepicker" id="" value="5/05/2015">
                        </div>  
                      </div>
                     <div class="col-md-2">
                        <a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> Upload Files</a>
                     </div>
                     <div class="clearfix"></div>
                     </div>
                     <div class="formsec row">
                     <div class="col-md-6">
                           <div class="paddinglessmin">6.</div> <div class="paddinglessmax">Total no of sanctioned posts at the level of promotion grade</div>
                     </div>
                     <div class="col-md-3">
                           <input type="number" id="" class="form-control" value="56">
                     </div>
                     <div class="clearfix"></div>
                     </div>
                     
                     <div class="formsec row">
                        <div class="col-md-6">
                            <div class="paddinglessmin">7.</div>
                            <div class="paddinglessmax"> a) Number of vacancies for which the DPC/S.B. met (Category wise)</div>
                          </div>
                          <div class="col-md-6">
                          <div class="row">
                              <div class="col-md-3">
                                 <div align="center">
                                    <label ><strong>SC</strong></label>
                                    <input type="text"  class="form-control" name="" id="" value="4">
                                 </div>
                              </div>
                              <div class="col-md-3">
                                 <div align="center">
                                    <label ><strong>ST</strong></label>
                                    <input type="text"  class="form-control" name="" id="" value="2">
                                 </div>
                              </div>
                              <div class="col-md-3">
                                 <div align="center">
                                    <label ><strong>UR</strong></label>
                                    <input type="text"  class="form-control" name="" id="" value="5">
                                 </div>
                              </div>
                              <div class="col-md-3">
                                 <div align="center">
                                    <label ><strong>TOTAL</strong></label>
                                    <input type="text"  class="form-control" name="" id="" value="11" readonly>
                                 </div>
                              </div>
                              </div>
                           </div>
                       
                        <div class="col-md-6">
                              <div class="txtindenting"> b) Number of vacancies now proposed to be filled up(Category-wise)</div>
                       </div>
                       <div class="col-md-6">
                              <div class="row">
                              <div class="col-md-3">
                                 <div align="center">
                                    <label ><strong>SC</strong></label>
                                    <input type="text"  class="form-control" name="" id="" value="3">
                                 </div>
                              </div>
                              <div class="col-md-3">
                                 <div align="center">
                                    <label ><strong>ST</strong></label>
                                    <input type="text"  class="form-control" name="" id="" value="3">
                                 </div>
                              </div>
                              <div class="col-md-3">
                                 <div align="center">
                                    <label ><strong>UR</strong></label>
                                    <input type="text"  class="form-control" name="" id="" value="5">
                                 </div>
                              </div>
                              <div class="col-md-3">
                                 <div align="center">
                                    <label ><strong>TOTAL</strong></label>
                                    <input type="text"  class="form-control" name="" id="" value="11" readonly>
                                 </div>
                              </div>
                              </div>
                           </div>
                        <div class="col-md-6">
                           <div class="form-group">
                             <div class="txtindenting">c) Number of vacancies set apart & unfilled for subsequent consideration due to non-availability CCRs of Senior Officers in the zone of consideration.</div>
                           </div>
                        </div>
                        <div class="col-md-6">
                         <div class="row">
                        <div class="col-md-3">
                           <div align="center">
                              <label ><strong>SC</strong></label>
                              <input type="text"  class="form-control" name="" id="" value="5">
                           </div>
                        </div>
                        <div class="col-md-3">
                           <div align="center">
                              <label ><strong>ST</strong></label>
                              <input type="text" class="form-control" name="" id="" value="6">
                           </div>
                        </div>
                        <div class="col-md-3">
                           <div align="center">
                              <label ><strong>UR</strong></label>
                              <input type="text"  class="form-control" name="" id="" value="7">
                           </div>
                        </div>
                        <div class="col-md-3">
                           <div align="center">
                              <label ><strong>TOTAL</strong></label>
                              <input type="text"  class="form-control" name="" id="" value="18" readonly>
                           </div>
                        </div>
                        </div>
                      </div>
                        <div class="clearfix"></div>
                     </div>
                     <div class="formsec row">
                     <div class="col-md-6">
                           <div class="paddinglessmin">8.</div> <div class="paddinglessmax">Designation of feeder posts/grades from which officers are eligible for promotion</div>
                     </div>
                     <div class="col-md-3">
                          <select class="form-control" name="userStatus" id="userStatus" onclick="showAddPostModal(this.value);">
                            <option value="">Comissioner</option>
                              <option value="new">Add New</option>
                           </select>
                     </div>
                     </div>
                     <div class="clearfix"></div>
                     <div class="formsec row">
                        <div class="col-md-12 mrb_10">
                              <div class="paddinglgmin">9.</div> <div class="paddinglgmax">Name of the recruitment Rules regulatig the promotion proposed. If no such Rules exist. mention the number and date of Resolution/ Notification/ Office Memorandum proceeding eligibility criteria. Copy of Rules/G.O./ Resolution/ CM/ Notification to be appended.</div>
                        </div>
                        <div class="col-md-3">
                              <label >Name of the recruitment Rules regulatig the promotion proposed.</label>
                              <select class="form-control" name="userStatus" id="userStatus" onclick="showAddPostModal(this.value);">
                            <option value="">Odisha Excise Service</option>
                            <option value="newrule">Add New</option>
                          </select>
                        </div>
                        <div class="col-md-3">
                              <label >Resolution/ Notification/ Office Memorandum Number</label>
                              <input type="text"  class="form-control" name="" id="" value="787524">
                        </div>
                        <div class="col-md-3">
                              <label >Resolution/ Notification/ Office Memorandum Date</label>
                              <div class="input-group">
                                         <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                                         </div>
                                         <input type="text" class="form-control pull-right datepicker" id="" value="5/11/2015">
                                      </div>  
                         </div>
                        <div class="col-md-3">
                              <label>Resolution/ Notification/ Office Memorandum File</label>
                              <a href="#" data-toggle="modal" data-target="#myModal_one" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> Upload File</a>
                        </div>
                        </div>
                        <div class="clearfix"></div>
                     </div>
                     <div class="formsec row">
                        <div class="col-md-6">
                              <div class="paddinglessmin">10.</div>
                              <div class="paddinglessmax">(a) Number of eligible officers in the zone of consideration as per relevant Rules</div>
                          </div>
                           <div class="col-md-6">
                            <div class="row">
                              <div class="col-md-3">
                                 <div align="center">
                                    <label><strong>SC</strong></label>
                                    <input type="text"  class="form-control" name="" id="" value="1">
                                 </div>
                              </div>
                              <div class="col-md-3" align="center">
                                    <label ><strong>ST</strong></label>
                                    <input type="text"  class="form-control" name="" id="" value="4">
                              </div>
                              <div class="col-md-3" align="center">
                                    <label ><strong>UR</strong></label>
                                    <input type="text"  class="form-control" name="" id="" value="7">
                              </div>
                              <div class="col-md-3" align="center">
                                    <label ><strong>TOTAL</strong></label>
                                    <input type="text"  class="form-control" name="" id="" value="12" readonly>
                              </div>
                              </div>
                           </div>
                        
                        <div class="col-md-6">
                              <div class="txtindenting">(b) Number of officers found suitable for promotion</div>
                        </div>
                        <div class="col-md-6">
                             <div class="row">
                              <div class="col-md-3" align="center">
                                    <label ><strong>SC</strong></label>
                                    <input type="text"  class="form-control" name="" id="" value="3">
                              </div>
                              <div class="col-md-3" align="center">
                                    <label ><strong>ST</strong></label>
                                    <input type="text"  class="form-control" name="" id="" value="5">
                              </div>
                              <div class="col-md-3" align="center">
                                    <label ><strong>UR</strong></label>
                                    <input type="text"  class="form-control" name="" id="" value="5">
                                 </div>
                              <div class="col-md-3" align="center">
                                    <label ><strong>TOTAL</strong></label>
                                    <input type="text"  class="form-control" name="" id="" value="13" readonly>
                              </div>
                              </div>
                           </div>
                       
                        <div class="col-md-12">
                           <div class="form-group">
                              <div class="txtindenting">(c) Number of officers in the zone of consideration</div>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">
                           <div class="txtindentingone">i) Against whom Disciplinary Proceedings/Vigilance Cases/Criminal Case pending.(Copy of the report on Vigilance Case/Criminal Case/Disciplinary Proceedings to be enclosed)</label></div>
                           </div>
                        </div>
                        <div class="col-md-6">
                         <div class="row">
                         <div class="col-md-3">
                                 <div align="center">
                                    <label ><strong>SC</strong></label>
                                    <input type="text"  class="form-control" name="" id="" value="1">
                                 </div>
                              </div>
                              <div class="col-md-3">
                                 <div align="center">
                                    <label ><strong>ST</strong></label>
                                    <input type="text"  class="form-control" name="" id="" value="7">
                                 </div>
                              </div>
                              <div class="col-md-3">
                                 <div align="center">
                                    <label ><strong>UR</strong></label>
                                    <input type="text"  class="form-control" name="" id="" value="4">
                                 </div>
                              </div>
                              <div class="col-md-3">
                                 <div align="center">
                                    <label ><strong>TOTAL</strong></label>
                                    <input type="text"  class="form-control" name="" id="" value="12" readonly>
                                 </div>
                              </div>
                              </div>
                           </div>
                        
                        <div class="col-md-6">
                           <div class="form-group">
                             <div class="txtindentingone">ii) Not considered due to want of CCRs/PARs.</div>
                            </div>
                          </div>
                           <div class="col-md-6">
                            <div class="row">
                              <div class="col-md-3">
                                 <div align="center">
                                    <label ><strong>SC</strong></label>
                                    <input type="text"  class="form-control" name="" id="" value="5">
                                 </div>
                              </div>
                              <div class="col-md-3">
                                 <div align="center">
                                    <label ><strong>ST</strong></label>
                                    <input type="text"  class="form-control" name="" id="" value="2">
                                 </div>
                              </div>
                              <div class="col-md-3">
                                 <div align="center">
                                    <label ><strong>UR</strong></label>
                                    <input type="text"  class="form-control" name="" id="" value="2">
                                 </div>
                              </div>
                              <div class="col-md-3">
                                 <div align="center">
                                    <label ><strong>TOTAL</strong></label>
                                    <input type="text"  class="form-control" name="" id="" value="9" readonly>
                                 </div>
                              </div>
                              </div>
                           </div>
                       
                        <div class="col-md-6">
                              <div class="txtindentingone">iii) Not selected due to adverse remarks.</div>
                        </div>
                        <div class="col-md-6">
                         <div class="row">
                              <div class="col-md-3">
                                 <div align="center">
                                    <label ><strong>SC</strong></label>
                                    <input type="text"  class="form-control" name="" id="" value="1">
                                 </div>
                              </div>
                              <div class="col-md-3">
                                 <div align="center">
                                    <label ><strong>ST</strong></label>
                                    <input type="text"  class="form-control" name="" id="" value="3">
                                 </div>
                              </div>
                              <div class="col-md-3">
                                 <div align="center">
                                    <label ><strong>UR</strong></label>
                                    <input type="text"  class="form-control" name="" id="" value="4">
                                 </div>
                              </div>
                              <div class="col-md-3">
                                 <div align="center">
                                    <label ><strong>TOTAL</strong></label>
                                    <input type="text"  class="form-control" name="" id="" value="5" readonly>
                                 </div>
                              </div>
                              </div>
                           </div>
                    </div>
                        
                    <div class="clearfix"></div>
                     <div class="formsec row">
                     <div class="col-md-6">
                        <div class="paddinglessmin">11.</div> <div class="paddinglessmax">No. Of Officers after recommendation of DPC/SB given ad hoc promotion</div>
                      </div>
                      <div class="col-md-6">
                         <div class="row">
                          <div class="col-md-3">
                           <div align="center">
                              <label ><strong>SC</strong></label>
                              <input type="text"  class="form-control" name="" id="" value="4">
                           </div>
                        </div>
                        <div class="col-md-3" align="center">
                           <div align="center">
                              <label ><strong>ST</strong></label>
                              <input type="text"  class="form-control" name="" id="" value="5">
                           </div>
                        </div>
                        <div class="col-md-3"  align="center">
                              <label ><strong>UR</strong></label>
                              <input type="text"  class="form-control" name="" id="" value="3">
                        </div>
                        <div class="col-md-3"  align="center">
                              <label ><strong>TOTAL</strong></label>
                              <input type="text"  class="form-control" name="" id="" value="12" readonly>
                        </div>
                        </div>
                     </div>
                      <div class="clearfix"></div>
                     </div>
                     <div class="formsec row">
                     <div class="col-md-6">
                           <div class="paddinglessmin">12.</div>
                           <div class="paddinglessmax"> i) Whether 5 years CCRs dossiers of all officers recommended for promotion up to the junior-most officer nominated are enclosed.</div>
                     </div>
                     <div class="col-md-3">
                       
                              <div class="row">
                               
                                 <div class="col-md-6">
                                 <input type="radio" name="" checked="">
                                 Yes
                                 </div>
                                 <div class="col-md-6">
                                 <input type="radio" name="">
                                 No
                                 </div>
                          </div>
                     </div>
                     <div class="clearfix"></div>
                     <div class="col-md-6">
                        <div class="form-group">
                           <div class="txtindenting">ii) Period of CCRs perused by the D.P.C/S.B.</div>
                        </div>
                      </div>
                      <div class="col-md-3">
                              <div class="row">
                                 <div class="col-md-6">
                                 <input type="radio" name="" checked="">
                                 Yes
                                 </div>
                                 <div class="col-md-6">
                                 <input type="radio" name="">
                                 No
                                 </div>
                              </div>
                           </div>
                            <div class="clearfix"></div>
                            </div>
                     <div class="formsec row">
                     <div class="col-md-6">
                        <div class="form-group">
                          <div class="paddinglessmin">13.</div> <div class="paddinglessmax">Whether all the officers under consideration are regular in the feeder grade on recommendation of the O.P.S.C.,where required? <br /> (Copy of the recommendation letter of the O.P.S.C. to be furnished).</div>
                        </div>
                      </div>
                       <div class="col-md-3">
                        <div class="row">
                          <div class="col-md-6">
                           <input type="radio" name="" checked="">
                           Yes
                           </div>
                          <div class="col-md-6">
                           <input type="radio" name="">
                           No
                           </div>
                        </div>
                        <div class="clearfix"></div>
                        <div class="input-group">
                         <a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> Upload File</a>
                        </div>
                     </div>
                     
                     <div class="clearfix"></div>
                     </div>
                     <div class="clearfix"></div>
                     <div class="formsec row">
                     <div class="col-md-6">
                     
                           <div class="paddinglessmin">14.</div> <div class="paddinglessmax">Whether the D.P.C/S.B. has used /perused the following documents (attested copies to be enclosed):-</div>
                       
                      </div>
                      <div class="col-md-3">
                        <div class="row">
                           <div class="col-md-6">
                           <input type="radio" name="" checked="">
                           Yes
                           </div>
                          <div class="col-md-6">
                           <input type="radio" name="">
                           No
                           </div>
                        </div>
                        </div>
                      
                     <div class="clearfix"></div> 
                    
                      <div class="col-md-6">
                          <div class="txtindenting"> i) Authenticated (duly signed) copy of the Final Gradation List as on the Date D.P.C/SB containing Date of Birth,Date of appointment to the feeder grade and other service particulars of the officers under consideration</div>
                        </div>
                      
                        <div class="col-md-3">
                        <a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> Upload File</a>
                     </div> 
                   <div class="clearfix"></div>    
                        <div class="col-md-6">
                          <div class="txtindenting">(ii)Statement (duly signed) showing assessment of CCRs of the officers under consideration</div>
                      </div>
                       <div class="col-md-3">
                        <div class="row">
                           <div class="col-md-6">
                           <input type="radio" name="" checked="">
                           Yes
                           </div>
                           <div class="col-md-6">
                           <input type="radio" name="">
                           No
                           </div>
                           </div>
                        </div>
                      </div>
                     <div class="clearfix"></div>
                     
                     <div class="formsec row">
                     <div class="col-md-6">
                           <div class="paddinglessmin">15.</div> <div class="paddinglessmax">Whether reference made expected to reach Commission within 60 days of date of DPC/SB meeting.If not,reason thereof.</div>
                       </div>
                       <div class="col-md-6">
                         <div class="row">
                          <div class="col-md-3">
                           <input type="radio" name="" checked="">
                           Yes
                           </div>
                          <div class="col-md-3">
                           <input type="radio" name="">
                           No
                           </div>
                        </div>
                           <textarea class="form-control">The Commission has acquired varied experiences and expertise in the matter of selection of personnel</textarea>
                        </div>
                    <div class="clearfix"></div>
                   </div>
                   <div class="formsec row">
                     <div class="col-md-6">
                          <div class="paddinglessmin">16.</div> <div class="paddinglessmax">Form of reference duly filled and ink-signed is enclosed.</div>
                        </div>
                      <div class="col-md-3">
                        <div class="row">
                           <div class="col-md-6">
                           <input type="radio" name="" checked="">
                           Yes
                           </div>
                           <div class="col-md-6">
                           <input type="radio" name="">
                           No
                           </div>
                        </div>
                     </div>
                     </div>
                     
                     <div align="right" class="col-md-12">
                        <a href="<?php echo e(url('manage-promotion-request')); ?>" class="btn btn-danger">Cancel</a>
                        <button class="btn btn-primary">Save &#38 Next</button> 
                     </div>
                  </div>
               </div>
                    
                </div>
            </div>
        <div class="box">
            <div class="card-header" id="headingTwo">
                 <a  data-toggle="collapse" data-target="#collapseTwo" class="accordianheading"><div class="row"> <div class="col-md-11"><h5>Details of Eligible  Officer</h5></div> <div class="col-md-1"><i class="fa fa-plus acrdplus"></i></div></div> <div class="clearfix"></div></a>
            </div>
            <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
              <div class="card-body">
                <div class="box-body">
                  <div class="row">
                      <div  class="col-md-12">
                       <div class="box box-primary officer_clone">
                        <div class="box-header">
                        <h3 class="box-title">Officer Details</h3>
                          <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                          </div>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                        <div class="formsec row">
                         <div class="col-md-3">
                            <div class="form-group">
                               <label >Name of the eligible officers in the zone of</label>
                            </div>
                         </div>
                         <div class="col-md-3">
                            <div class="form-group">
                               <input name="" type="text" class="form-control" value="Monalisa"/>
                            </div>
                         </div>
                         <div class="col-md-3">
                               <label >Type of promotion(Regular/Retrospective)</label>
                         </div>
                         <div class="col-md-3">
                               <select class="form-control" name="userStatus" id="userStatus">
                                  <option value="">Retrospective</option>
                               </select>
                         </div>
                         <div class="clearfix"></div> 
                         <div class="col-md-3">
                               <label>Caste(SC/ST/General)</label>
                         </div>
                         <div class="col-md-3">
                               <select class="form-control" name="userStatus" id="userStatus">
                                  <option value="">SC</option>
                               </select>
                         </div>
                         <div class="col-md-3">
                            <div class="form-group">
                               <label>Name of the post to be filled up</label>
                            </div>
                         </div>
                         <div class="col-md-3">
                               <input type="text" class="form-control" name="" id="" value="Deputy incharge">
                         </div>
                         <div class="clearfix"></div> 
                         <div class="col-md-3">
                               <label >Group of the promotional post</label>
                         </div>
                         <div class="col-md-3">
                              <input type="text" class="form-control" name="" id="" value="56">
                         </div>
                         <div class="col-md-3">
                               <label >Scale of Pay</label>
                         </div>
                         <div class="col-md-3">
                               <input type="text" class="form-control" name="" id="" value="basic pay">
                         </div>
                        <div class="clearfix"></div>
                        
                         <div class="col-md-3">
                               <label >Mention the back Period of Availability</label>
                         </div>
                         <div class="col-md-3">
                               <input type="text" class="form-control" name="" id="" value="56">
                         </div> 
                         <div class="col-md-3">
                               <label>Designation as per the feeder post/grade</label>
                         </div>
                         <div class="col-md-3">
                               <input type="text" class="form-control" name="" id="" value="Graduate Teacher">
                         </div>
                         <div class="clearfix"></div>
                         <div class="col-md-3">
                               <label >Is the officer regular on feeder grade</label>
                         </div>
                         <div class="col-md-3">
                            <div class="row">
                               <div class="col-md-6">
                               <label>
                               <input type="radio" name="" checked="">
                               Yes
                               </label>
                            </div>
                            <div class="col-md-6">
                               <label>
                               <input type="radio" name=""  >
                               No
                               </label>
                            </div>
                         </div>
                         </div>
                       
                         <div class="col-md-3">
                               <label >Is the officer selected for promotion as per the recruitment rule.</label>
                         </div>
                         <div class="col-md-3">
                           <div class="row">
                            <div class="col-md-6">
                               <label>
                               <input type="radio" name="" checked="">
                               Yes
                               </label>
                            </div>
                            <div class="col-md-6">
                               <label>
                               <input type="radio" name=""  >
                               No
                               </label>
                            </div>
                         </div>
                       </div>
                         <div class="clearfix"></div>  
                         <div class="col-md-3">
                               <label >Is there any criminal case/disciplinary proceedings/vigilance case is pending</label>
                         </div>
                         <div class="col-md-3 mrb_10">
                            <div class="row">
                               <div class="col-md-6">
                               <label>
                               <input type="radio" name="" checked="">
                               Yes
                               </label>
                            </div>
                            <div class="col-md-6">
                               <label>
                               <input type="radio" name=""  >
                               No
                               </label>
                            </div>
                            </div>

                              <a href="#" data-toggle="modal" data-target="#myModal_six" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> Upload File</a>
                            
                         </div>
                       
                         <div class="col-md-3">
                               <label>Availability of CCRs & PARs</label>
                         </div>
                         <div class="col-md-3">
                            <div class="row">
                               <div class="col-md-6">
                               <label>
                               <input type="radio" name="" checked="">
                               Yes
                               </label>
                            </div>
                            <div class="col-md-6">
                               <label>
                               <input type="radio" name="" >
                               No
                               </label>
                            </div>
                            </div>
                         </div>
                         <div class="clearfix"></div>
                         <div class="col-md-3">
                               <label >Period of Availability of CCRs & PARs</label>
                         </div>
                         <div class="col-md-3">
                               <textarea name="" cols="" rows="" class="form-control">It has also gone a long way in achieving the purpose of drawing the best</textarea>
                         </div>
                         
                         <div class="col-md-3">
                               <label >Is the officer given adhoc promotion DPC/SB</label>
                         </div>
                         <div class="col-md-3">
                            <div class="row">
                               <div class="col-md-6">
                               <label>
                               <input type="radio" name="" checked="">
                               Yes
                               </label>
                            </div>
                            <div class="col-md-6">
                               <label>
                               <input type="radio" name="">
                               No
                               </label>
                            </div>
                            </div>
                         </div>
                         <div class="clearfix"></div>  
                         <div class="col-md-3">
                               <label >Period of CCRs perused by DPC/SB</label>
                         </div>
                         <div class="col-md-3">
                               <input type="text" class="form-control" name="" id="" value="76">
                         </div>
                         
                         <div class="col-md-3">
                            <div>
                                 <label><strong>Upload CCR</strong></label>
                              </div>
                           </div>
                          <div class="col-md-3 mrb_10">
                          <a href="#" data-toggle="modal" data-target="#myModal_five" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> Upload File</a>
                         </div>
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-3 bg-color1">Year 2012-2013</div>
                                <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a> &nbsp; &nbsp; <a href="#" class="label label-danger"><i class="fa fa-close"></i></a></div>
                                <div class="col-md-3 bg-color1"> Year 2013-2014</div>
                                <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a> &nbsp; &nbsp; <a href="#" class="label label-danger"><i class="fa fa-close"></i></a></div>
                                <div class="col-md-3 bg-color1">Year 2014-2015</div>
                                <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a> &nbsp; &nbsp; <a href="#" class="label label-danger"><i class="fa fa-close"></i></a></div>
                                <div class="col-md-3 bg-color1">Year 2015-2016</div>
                                <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a> &nbsp; &nbsp; <a href="#" class="label label-danger"><i class="fa fa-close"></i></a></div>
                                <div class="col-md-3 bg-color1">Year 2016-2017</div>
                                <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a> &nbsp; &nbsp; <a href="#" class="label label-danger"><i class="fa fa-close"></i></a></div>
                                <div class="col-md-3 bg-color1">Year 2017-2018</div>
                                <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a> &nbsp; &nbsp; <a href="#" class="label label-danger"><i class="fa fa-close"></i></a></div>
                                <div class="col-md-3 bg-color1">Year 2018-2019</div>
                                <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a> &nbsp; &nbsp; <a href="#" class="label label-danger"><i class="fa fa-close"></i></a></div>
                               
                            </div>
                        </div>
                                   
                                   
                       <div class="formsubhd">Vigilance/Criminal/Disciplinary Proceedings</div>
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-3 bg-color1">Vigilance</div>
                                <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a> &nbsp; &nbsp; <a href="#" class="label label-danger"><i class="fa fa-close"></i></a></div>
                                <div class="col-md-3 bg-color1"> Vigilance</div>
                                <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a> &nbsp; &nbsp; <a href="#" class="label label-danger"><i class="fa fa-close"></i></a></div>
                                <div class="col-md-3 bg-color1">Criminal</div>
                                <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a> &nbsp; &nbsp; <a href="#" class="label label-danger"><i class="fa fa-close"></i></a></div>
                                <div class="col-md-3 bg-color1">Disciplinary proceedings</div>
                                <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a> &nbsp; &nbsp; <a href="#" class="label label-danger"><i class="fa fa-close"></i></a></div>
                                <div class="col-md-3 bg-color1">Vigilance</div>
                                <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a> &nbsp; &nbsp; <a href="#" class="label label-danger"><i class="fa fa-close"></i></a></div>
                                
                               
                            </div>
                        </div>
                      </div>                         
                      </div>             
                        <div class="clearfix"></div>
                        <div align="right" class="padding_10">
                            <a href="<?php echo e(url('manage-promotion-request')); ?>" class="btn btn-danger">Cancel</a>
                            <button class="btn btn-primary">Save &#38 Exit</button>
                        </div>
                         <div class="clearfix"></div>
                       </div>
                      </div>  
                      <div id="officer_fields" class="col-md-12">
                          
                      </div>   
                      <div class="col-md-12" align="right">
                      <button class="btn btn-success" type="button" id="officer_add">Add More Officer</button>
                    </div>
                   </div>
                </div>
              </div>
            </div>
       </div>
       </div>
        <div class="box">
            <div class="card-header" id="headingThree">
                 <a  data-toggle="collapse" data-target="#collapseThree" class="accordianheading"> <div class="row"> <div class="col-md-11"><h5>Document Checklist</h5></div> <div class="col-md-1"><i class="fa fa-plus acrdplus"></i></div></div> <div class="clearfix"></div></a>                     
            </div>
            <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                <div class="card-body">
                
                
                  <div class="col-md-12">
                  <div class="row">
                  <div class="col-md-6">
                      <div class="row listview">
                          <div class="col-md-11">1. Recruitment Rule</div>
                          <div class="col-md-1 listicon"><label><input type="checkbox" class="minimal" checked=""></label></div>
                      </div>
                  </div>
                   <div class="col-md-6">
                      <div class="row listview">
                          <div class="col-md-11">2. Govt Resolution/Order/Notification/Office Memorandum</div>
                          <div class="col-md-1 listicon"><label><input type="checkbox" class="minimal" checked=""></label></div>
                      </div>
                  </div>
                   <div class="col-md-6">
                      <div class="row listview">
                          <div class="col-md-11">3. Previous DPC/SB proposal</div>
                          <div class="col-md-1 listicon"><label><input type="checkbox" class="minimal" checked=""></label></div>
                      </div>
                  </div>
                   <div class="col-md-6">
                      <div class="row listview">
                          <div class="col-md-11">4. Previous concurrence of OPSC</div>
                          <div class="col-md-1 listicon"><label><input type="checkbox" class="minimal" checked=""></label></div>
                      </div>
                  </div>
                   <div class="col-md-6">
                      <div class="row listview">
                          <div class="col-md-11">5. Proceedings of criminal /vigilance/court cases</div>
                          <div class="col-md-1 listicon"><label><input type="checkbox" class="minimal" checked=""></label></div>
                      </div>
                  </div>
                   <div class="col-md-6">
                      <div class="row listview">
                          <div class="col-md-11">6. CCRs/PARs of the employee</div>
                          <div class="col-md-1 listicon"><label><input type="checkbox" class="minimal" checked=""></label></div>
                      </div>
                  </div>
                   <div class="col-md-6">
                      <div class="row listview">
                          <div class="col-md-11">7. Present proceedings of DPC/SB</div>
                          <div class="col-md-1 listicon"><label><input type="checkbox" class="minimal" checked=""></label></div>
                      </div>
                  </div>
                   <div class="col-md-6">
                      <div class="row listview">
                          <div class="col-md-11">8. Recommendation letter of OPSC related to feeder grade regularization</div>
                          <div class="col-md-1 listicon"><label><input type="checkbox" class="minimal" checked=""></label></div>
                      </div>
                  </div>
                  <div class="col-md-6">
                      <div class="row listview">
                          <div class="col-md-11">9. Signed copy of final gradation list</div>
                          <div class="col-md-1 listicon"><label><input type="checkbox" class="minimal" checked=""></label></div>
                      </div>
                  </div>
                  <div class="col-md-6">
                      <div class="row listview">
                          <div class="col-md-11">10. Duly signed copy of assessment of CCR statement</div>
                          <div class="col-md-1 listicon"><label><input type="checkbox" class="minimal" checked=""></label></div>
                      </div>
                  </div>
                  </div> 
                    </div>
                    </div>   
                  <div class="clearfix"></div>
                  <div class="col-md-12">
                   <div class="paddinglessmin">
                    <input name="" type="checkbox" value="" checked=""/>
                  </div>
                    <div class="paddinglessmax">
                    <div>I certify that all information/documents given above have been checked by me and found to be correct and all copies of relevant documents, as mentioned above, have benn enclosed</div> 
                  </div>
                  </div>

              
                   <div class="clearfix"></div>
                        <div align="right" class="padding_10">
                            <a href="<?php echo e(url('manage-promotion-request')); ?>" class="btn btn-danger">Cancel</a>
                            <a href="javascript:void(0)" onClick="submitRequest()" class="btn btn-primary">Submit</a>
                        </div> 
                    <div class="clearfix"></div>     
               </div>
                </div>
                </div>
               </div>
           </div>
        </div>
            <!-- /.box -->
         </div>
         <!-- /.col -->
      </div>
      <!-- /.box -->
   </section>
   <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<!--upload modal start-->
<!-- The Modal -->
  <div class="modal" id="myModal">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <!-- Modal body -->
        <div class="modal-body">
          <div class="col-lg-12">
              <div> 
                <div align="right">
                     <button class="btn btn-primary button-add" type="button"><i class="fa fa-plus"></i></button> 
                </div>
             </div>
             <div class="form-group upload">
             <div class="row">
                <div class="col-lg-3">
                    <label>Select File Type</label>
                    <select name="" class="form-control">
                       <option>--Select---</option>
                       <option>DPC/SB</option>
                       <option>OPSC Recommendation Letter</option>
                       <option>Gradation List</option>
                    </select>
                </div>
                <div class="col-lg-7">
                    <label>Upload File</label> 
                    <div class="input-group">
                    <input type="file" class="custom-file-input" id="" name="filename">
                    <label class="custom-file-label" for="customFile">Choose file</label>
                    </div>
                </div>
                <div class="col-lg-2 mrt_30" align="right">
                    <button class="btn btn-warning button-remove1" type="button"><i class="fa fa-minus"></i></button> 
                </div>
                </div>
            </div>
          </div>
          <div class="col-md-12">
          <div class="row">
              <div class="col-md-4"><i class="fa fa-pdf-o"></i>154523456756.pdf <span class="label label-primary"><i class="fa fa-eye"></i></span> <span class="label label-warning"><i class="fa fa-close"></i></span></div>
              <div class="col-md-4"><i class="fa fa-pdf-o"></i>154523456756.pdf <span class="label label-primary"><i class="fa fa-eye"></i></span> <span class="label label-warning"><i class="fa fa-close"></i></span></div>
              <div class="col-md-4"><i class="fa fa-pdf-o"></i>154523456756.pdf <span class="label label-primary"><i class="fa fa-eye"></i></span> <span class="label label-warning"><i class="fa fa-close"></i></span></div>
          </div>
          </div>
        </div>
        <!-- Modal footer -->
        <div class="modal-footer" align="center">
           <button class="btn btn-primary">Submit</button>
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>
  <div class="modal" id="myModal_one">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <!-- Modal body -->
        <div class="modal-body">
          <div class="col-lg-12">
              <div> 
                <div align="right">
                     <button class="btn btn-primary button-add2" type="button"><i class="fa fa-plus"></i></button> 
                </div>
             </div>
             <div class="form-group uploadone">
             <div></div>
             <div class="row">
                <div class="col-lg-3">
                    <label>Select File Type</label>
                    <select name="" class="form-control">
                       <option>--Select---</option>
                       <option>Ammendement Rule</option>
                       <option>G.O.</option>
                       <option>Resolution</option>
                       <option>OM</option>
                       <option>Notification</option>
                    </select>
                </div>
                <div class="col-lg-7">
                    <label>Upload File</label> 
                    <div class="input-group">
                    <input type="file" class="custom-file-input" id="" name="filename">
                    <label class="custom-file-label" for="customFile">Choose file</label>
                    </div>
                </div>
                <div class="col-lg-2 mrt_30" align="right">
                    <button class="btn btn-warning button-remove1" type="button"><i class="fa fa-minus"></i></button> 
                </div>
                </div>
            </div>
          </div>
          <div class="col-md-12">
          <div class="row">
              <div class="col-md-4"><i class="fa fa-pdf-o"></i>154523456756.pdf <span class="label label-primary"><i class="fa fa-eye"></i></span> <span class="label label-warning"><i class="fa fa-close"></i></span></div>
              <div class="col-md-4"><i class="fa fa-pdf-o"></i>154523456756.pdf <span class="label label-primary"><i class="fa fa-eye"></i></span> <span class="label label-warning"><i class="fa fa-close"></i></span></div>
              <div class="col-md-4"><i class="fa fa-pdf-o"></i>154523456756.pdf <span class="label label-primary"><i class="fa fa-eye"></i></span> <span class="label label-warning"><i class="fa fa-close"></i></span></div>
          </div>
          </div>
        </div>
        <!-- Modal footer -->
        <div class="modal-footer" align="center">
           <button class="btn btn-primary">Submit</button>
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>
  <div class="modal" id="myModal_five">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
         <div class="modal-header">
           <h4 class="modal-title">Upload CCR &nbsp;</h4>
           <!-- <button type="button" class="close" data-dismiss="modal">×</button> -->
        </div>
        <!-- Modal body -->
        <div class="modal-body">
          <div class="col-lg-12">
               
       <div class="formsubhd"> 
        <button class="btn btn-primary button-add" type="button"><i class="fa fa-plus"></i></button></div>
       
            <div class="row">                       
            <div class="col-lg-12">
             <div class="form-group ccr">
             <div class="row">
                <div class="col-lg-2">
                    <label>File Type</label>
                    <select name="" class="form-control">
                       <option>--Select---</option>
                       <option>CCR</option>
                    </select>
                </div>
                <div class="col-lg-3">
                     <label>Officer Name</label>
                     <select name="" class="form-control">
                       <option>--Select Officer--</option>
                         <option>Name of Officer</option>
                         <option>Name of Officer</option>
                         <option>Name of Officer</option>
                         <option>Name of Officer</option>
                         <option>Name of Officer</option>
                         <option>Name of Officer</option>
                     </select>
                </div>
                <div class="col-lg-2">
                <label>Year</label>
                     <select name="" class="form-control">
                         <option>--Select Year--</option>
                         <option>2011-2012</option>
                         <option>2012-2013</option>
                         <option>2013-2014</option>
                         <option>2014-2015</option>
                         <option>2015-2016</option>
                         <option>2016-2017</option>
                         <option>2017-2018</option>
                         <option>2018-2019</option>
                     </select>
                </div>
                <div class="col-lg-4">
                    <label>Upload File</label>
                    <div class="input-group">
                    <input type="file" class="custom-file-input" id="" name="filename">
                    <label class="custom-file-label" for="customFile">Choose file</label>
                    </div>
                </div>
                <div class="col-lg-1 mrt_30" align="right">
                    <button class="btn btn-warning button-remove" type="button"><i class="fa fa-minus"></i></button> 
                </div>
                </div>
                </div>
               
                </div>
                
            </div>        
                            
          </div>
          <div class="col-md-12">
          <div class="row">
              <div class="col-md-4"><i class="fa fa-pdf-o"></i>154523456756.pdf <span class="label label-primary"><i class="fa fa-eye"></i></span> <span class="label label-warning"><i class="fa fa-close"></i></span></div>
              <div class="col-md-4"><i class="fa fa-pdf-o"></i>154523456756.pdf <span class="label label-primary"><i class="fa fa-eye"></i></span> <span class="label label-warning"><i class="fa fa-close"></i></span></div>
              <div class="col-md-4"><i class="fa fa-pdf-o"></i>154523456756.pdf <span class="label label-primary"><i class="fa fa-eye"></i></span> <span class="label label-warning"><i class="fa fa-close"></i></span></div>
          </div>
          </div>
        </div>
        <!-- Modal footer -->
        <div class="modal-footer" align="center">
           <button class="btn btn-primary">Submit</button>
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>
  <div class="modal" id="myModal_six">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
           <h4 class="modal-title">Upload of Vigilance / Criminal /Disciplinary Proceedings &nbsp;</h4>
           <!-- <button type="button" class="close" data-dismiss="modal">×</button> -->
        </div>
        <!-- Modal body -->
        <div class="modal-body">
          <div class="col-lg-12">
        <!--upload vigilance-->
         <div class="formsubhd"> <button class="btn btn-primary button-add" type="button"><i class="fa fa-plus"></i></button></div>
         
              <div class="row">                       
              <div class="col-lg-12">
               <div class="form-group vigilance">
               <div class="row">
                <div class="col-lg-2">
                    <label>File Type</label>
                    <select name="" class="form-control">
                       <option>--Select---</option>
                       <option>Vigilance</option>
                       <option>Criminal</option>
                       <option>Disciplinary proceedings</option>
                    </select>
                </div>
                  <div class="col-lg-4">
                       <label>Officer Name</label>
                       <select name="" class="form-control">
                         <option>--Select Officer--</option>
                           <option>Name of Officer</option>
                           <option>Name of Officer</option>
                           <option>Name of Officer</option>
                           <option>Name of Officer</option>
                           <option>Name of Officer</option>
                           <option>Name of Officer</option>
                       </select>
                  </div>
                  <div class="col-lg-5">
                      <label>Upload File</label>
                      <div class="input-group">
                      <input type="file" class="custom-file-input" id="" name="filename">
                      <label class="custom-file-label" for="customFile">Choose file</label>
                      </div>
                  </div>
                  <div class="col-lg-1 mrt_30" align="right">
                      <button class="btn btn-warning button-remove" type="button"><i class="fa fa-minus"></i></button> 
                  </div>
                  </div>
                  </div>
                 
                  </div>
                  
              </div>    
    
                           
          </div>
          <div class="col-md-12">
          <div class="row">
              <div class="col-md-4"><i class="fa fa-pdf-o"></i>154523456756.pdf <span class="label label-primary"><i class="fa fa-eye"></i></span> <span class="label label-warning"><i class="fa fa-close"></i></span></div>
              <div class="col-md-4"><i class="fa fa-pdf-o"></i>154523456756.pdf <span class="label label-primary"><i class="fa fa-eye"></i></span> <span class="label label-warning"><i class="fa fa-close"></i></span></div>
              <div class="col-md-4"><i class="fa fa-pdf-o"></i>154523456756.pdf <span class="label label-primary"><i class="fa fa-eye"></i></span> <span class="label label-warning"><i class="fa fa-close"></i></span></div>
          </div>
          </div>
        </div>
        <!-- Modal footer -->
        <div class="modal-footer" align="center">
           <button class="btn btn-primary">Submit</button>
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>
  <div class="modal" id="addPostModal">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
           <h4 class="modal-title">Add New</h4>
           <!-- <button type="button" class="close" data-dismiss="modal">×</button> -->
        </div>
        <!-- Modal body -->
        <div class="modal-body" id="addPostBody">
            
        </div>
        <!-- Modal footer -->
        <div class="modal-footer" align="center">
           <button class="btn btn-primary">Submit</button>
          <button type="button" class="btn btn-danger" onclick="closeModal()">Close</button>
        </div>
        
      </div>
    </div>
  </div>
  <!--uload Modal End-->
<?php $__env->startPush('scripts'); ?> 

<script>
    $(document).ready(function(){
        // Add minus icon for collapse element which is open by default
        $(".collapse.show").each(function(){
          $(this).prev(".card-header").find(".fa faicon").addClass("fa-minus-circle").removeClass("fa-plus-circle");
        });
        
        // Toggle plus minus icon on show hide of collapse element
        $(".collapse").on('show.bs.collapse', function(){
          $(this).prev(".card-header").find(".fa faicon").removeClass("fa-plus-circle").addClass("fa-minus-circle");
        }).on('hide.bs.collapse', function(){
          $(this).prev(".card-header").find(".fa faicon").removeClass("fa-minus-circle").addClass("fa-plus-circle");
        });
    });
</script>

<script>
$(document).ready(function() {
    $('#officer_add').click(function(){
        //we select the box clone it and insert it after the box
       // $('.officer_clone:first').clone().insertAfter(".officer_clone:last");
       $.ajax({
              type: "GET",
              url:"ajaxGetOfficerForm",
              success: function(response) {
            console.log(response);
              $("#officer_fields").append(response.html);
             // $(".collapse").collapse() 
            //return false;
                  if (response.message == "success") {
                   /* swal({
                      title: "Record Deleted Successfully.",
                      type: "success"
                    }).then(function(){
                       location.reload();
                    })
                  */
                    
                  } else {
                      /*swal({
                          title: 'Unsuccess',
                          text: response.code
                      })*/
                  }
              },
              error: function(data) {
               
              }
          })


    });
    $(document).on("click", ".button-remove", function() {
      if($(".officer_clone").length !=1){                        
        $(this).closest(".officer_clone").remove();
      }else{
        swal("Sorry! You can't delete default row.");
      }
    });
});
    $(document).ready(function() {
    $('.button-add').click(function(){
        //we select the box clone it and insert it after the box
        $('.ccr:first').clone().insertAfter(".ccr:last");
    });
    $(document).on("click", ".button-remove", function() {
      if($(".ccr").length !=1){                        
        $(this).closest(".ccr").remove();
      }else{
        swal("Sorry! You can't delete default row.");
      }
    });
});
</script>
<script>
$(document).ready(function() {
    $('.button-add').click(function(){
        //we select the box clone it and insert it after the box
        $('.vigilance:first').clone().insertAfter(".vigilance:last");
    });
    $(document).on("click", ".button-remove", function() {
      if($(".vigilance").length !=1){                          
        $(this).closest(".vigilance").remove();
       }else{
        swal("Sorry! You can't delete default row.");
      } 
    });
});
</script>
<script>
$(document).ready(function() {
    $('.button-add1').click(function(){
        //we select the box clone it and insert it after the box
        $('.upload:first').clone().insertAfter(".upload:last");
    });
    $(document).on("click", ".button-remove1", function() {
      if($(".upload").length !=1){                         
        $(this).closest(".upload").remove();
       }else{
        swal("Sorry! You can't delete default row.");
      } 
    });
});
</script>
<script>
$(document).ready(function() {
    $('.button-add2').click(function(){
        //we select the box clone it and insert it after the box
        $('.uploadone:first').clone().insertAfter(".uploadone:last");
    });
    $(document).on("click", ".button-remove1", function() {
      if($(".uploadone").length !=1){                          
        $(this).closest(".uploadone").remove();
       }else{
        swal("Sorry! You can't delete default row.");
      } 
    });
});
</script>
<script>
$(document).ready(function() {
    $('.button-add3').click(function(){
        //we select the box clone it and insert it after the box
        $('.upload_two:first').clone().insertAfter(".upload_two:last");
    });
    $(document).on("click", ".button-remove1", function() {
      if($(".uploadtwo").length !=1){                          
        $(this).closest(".upload_two").remove();
       }else{
        swal("Sorry! You can't delete default row.");
      } 
    });
});
</script>
<script>
$(document).ready(function() {
    $('.button-add4').click(function(){
        //we select the box clone it and insert it after the box
        $('.upload_three:first').clone().insertAfter(".upload_three:last");
    });
    $(document).on("click", ".button-remove1", function() {
      if($(".upload_three").length !=1){                         
        $(this).closest(".upload_three").remove();
       }else{
        swal("Sorry! You can't delete default row.");
      } 
    });
});
</script>
<script>
$(document).ready(function() {
    $('.button-add5').click(function(){
        //we select the box clone it and insert it after the box
        $('.uploadfour:first').clone().insertAfter(".uploadfour:last");
    });
    $(document).on("click", ".button-remove1", function() {
      if($(".uploadfour").length !=1){                         
        $(this).closest(".uploadfour").remove();
       }else{
        swal("Sorry! You can't delete default row.");
      } 
    });
});


function showAddPostModal(index){
    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
      }
    });
    $("#addPostBody").empty();
    if(index=='new'){
        $.ajax({
              type: "GET",
              url:"ajaxGetAddPostForm",
              success: function(response) {
            console.log(response);
              $("#addPostBody").append(response.html);
              $("#addPostModal").modal('show');
              },
              error: function(data) {
               
              }
          })
    }else{
        $("#addPostModal").modal('hide');
    }
    if(index=='newref'){
        $.ajax({
              type: "GET",
              url:"ajaxGetAddRefNoForm",
              success: function(response) {
            console.log(response);
              $("#addPostBody").append(response.html);
              $("#addPostModal").modal('show');
              },
              error: function(data) {
               
              }
          })
    }else{
        $("#addPostModal").modal('hide');
    }
    
    if(index=='newrule'){
        $.ajax({
              type: "GET",
              url:"ajaxGetRecruitmentRuleForm",
              success: function(response) {
            console.log(response);
              $("#addPostBody").append(response.html);
              $("#addPostModal").modal('show');
              },
              error: function(data) {
               
              }
          })
    }else{
        $("#addPostModal").modal('hide');
    }
   
  }
  function closeModal(){
      $("#addPostModal").modal('hide');
    
   
  } 
   function submitRequest(){
    swal.fire({
        title: "Do you want to Submit?",
        text: "",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#e7b63a',
        confirmButtonText: 'Submit',
        reverseButtons : true
        
      }).then((result) => {
        if(result.value){
         /*$.ajax({
              type: "GET",
              url:"master/delete-user?id="+ id,
              success: function(response) {
            console.log(response);
            //return false;
                  if (response.message == "success") {*/
                    swal({
                      title: "Record Submitted Successfully.",
                      type: "success"
                    }).then(function(){
                       window.location.href="<?php echo e(url('manage-promotion-request')); ?>";
                    })
                  
                    
                 /* } else {
                      swal({
                          title: 'Unsuccess',
                          text: response.code
                      })
                  }
              },
              error: function(data) {
               
              }
          })*/
        }
        
      });
  }   
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-demo\resources\views/promotional/edit-promotion.blade.php ENDPATH**/ ?>