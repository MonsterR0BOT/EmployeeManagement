<?php $__env->startSection('title', 'CHART'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       List User Role
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">User</a></li>
        <li class="active">Manage User Role</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
           <!-- <div class="box-header">
              <h3 class="box-title">Data Table With Full Features</h3>
            </div>-->
            <!-- /.box-header -->
            <div class="box-body">
           	 	<div id="demo" class="collapse">
                    <div class="search-field">
                        <div class="row">
                            <div class="col-md-2">
                                <div class="org-name">User Role Name</div>
                            </div>
                            <div class="col-md-3">
                                <input class="form-control" id="param1">
                            </div>
                            <div class="col-md-2">
                                <div class="org-name">Cost Center</div>
                            </div>
                             <div class="col-md-3">
                                <select class="org-name form-control" id="param2">
                                    <option value="">--Select--</option>
                                    <?php $__currentLoopData = $costcenter_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($val->TCCM_CostCenter); ?>"><?php echo e($val->TCCM_CC_Name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            
                            <div class="col-md-2">
                              <div class="form-group">
                                 <button class="btn btn-primary" onClick="searchData()">Search</button>
                                 
                              </div>
                           </div>
                        </div>
                    </div>
                </div>
                  
                <!--<a data-toggle="collapse" data-target="#demo" class="showhideangelbg"><i class="fa fa-angle-double-down"></i> </a>-->
              <table id="listUserRole" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>User Role Name</th>
                  <th>Parent User Role</th>
                  <th>Cost Center</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
    	<!-- Modal Start-->
         <div id="myModal" class="modal fade" role="dialog">
            <div class="modal-dialog">
               
               <!-- Modal content-->
               <div class="modal-content">
                  <div class="modal-header">
                     <h4 class="modal-title">View User Role Details</h4>
                     <button type="button" class="close" data-dismiss="modal">&times;</button>
                  </div>
                  <div class="modal-body">
                     <table width="100%" border="0" id="table1">
                        
                     </table>
                  </div>
                  <div class="modal-footer">
                     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                  </div>
               </div>
               
            </div>
         </div>
         <!-- Modal End-->
         <!-- /# row -->

  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('styles'); ?>
<!-- DataTables -->
<link rel="stylesheet" href="<?php echo e(asset('bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopPush(); ?>  
<?php $__env->startPush('scripts'); ?>
<!-- DataTables -->
<script src="<?php echo e(asset('bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
<script>
  $(function () {
    //$('#example1').DataTable()
    $('#listUserRole').DataTable({
		'processing' : true,
		'serverSide' : true,
		'searching' : false,
		'ordering' : false,
		"ajax" : {
			'url' : 'view-user-role-through-ajax',
			'data' : function(d) {
				d.param1 = $('#param1').val();
				d.param2 = $('#param2').val(); 
			}
		},
		'dataSrc' : "",
		'columns' : [
		{'data' : 'TURM_URole_Name'},
		{'data' : 'parentUserRoleName'},
		{'data' : 'TCCM_CC_Name'}, 
		{'data' : 'TURM_URole_Status'},
		{'data' : 'action'}
		]	
	});
  })
	function searchData() {
		//alert('hello');
		$('#listUserRole').DataTable().draw();
	}
 	const ipAPI = 'https://api.ipify.org?format=json';
	function deleteUserRole(index){
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
			}
		});
	 // alert(index);
		swal({
			title				: "Are you sure want to Delete?",
			text				: "Once Deleted,Can't revert back !",
			type 				: "warning",
			showCancelButton	: true,
			confirmButtonColor	: "#DD6BB5",
			confirmButtonText	:"Submit",
			showLoaderOnConfirm	: true,
			reverseButtons : true,
			confirmButtonAriaLabel : 'Thumbs up, great!',
			cancelButtonText : 'Cancel',
			cancelButtonAriaLabel : 'Thumbs down',
			preConfirm: () => {
				return fetch(ipAPI)
				  .then(response => response.json())
				  .then(data => Swal.insertQueueStep(data.ip))
				  .catch(() => {
					Swal.insertQueueStep({
					  type: 'error',
					  title: 'Unable to get your public IP'
					})
				  })
			 }  
		}).then((result) => {
			if(result.value){
			$.ajax({
			type		: "POST",
			url 		: "delete-user-role",
			dataType	: "json",
			//contentType	: "application/json",
			data		: {'userRoleId':index},
			success		: function(response){
				console.log(response);
				if(response.message=="success"){
					swal({
							title:"Data Deleted Successfully.",
							type: "success",
					}).then(function(){
							location.reload(); 
					})
				}else{
					console.log('i am in unsuccess');
					swal({
						title:response.code,
						text: response.message,
						type:"warning"
					})
				}
			},error		: function(response){
				swal(response.code);	
			}
		}) //ajax ends
			}
		})//swal function block ends
	}
	function viewInModel(index){
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
			}
		});
		$('#table1').empty();
		$.ajax({
			type 		:	"POST",
			url 		:	"view-user-role-model",
			dataType 	:	'json',
			//contentType :	'application/json',
			data 		:	{'roleId':index},
			success 	: 	function(response) {
				if(response.message=="success"){
					console.log(response.userRoleData.TURM_URole_Status);
					var userRoleStatus = "";
					if(response.userRoleData.TURM_URole_Status){
						userRoleStatus = "Active";	
					}else{
						userRoleStatus = "Inactive";	
					}
				 
					 table = '<tr><td>UserRole:</td>'+'<td align="left">'
					    +response.userRoleData.TURM_URole_Name+'</td>'+'</tr><tr><td>Parent Name:</td><td align="left">'
						+response.userRoleData.parentUserRoleName+'</td>'+'</tr><tr><td>Cost Center:</td><td align="left">'
						+response.userRoleData.TCCM_CC_Name+'</td>'+'</tr><tr><td>Description:</td><td align="left">'
						+response.userRoleData.TURM_URole_Description+'</td>'+'</tr><tr><td>Status:</td><td align="left">'
						+userRoleStatus+'</td></tr>';
					$('#myModal').modal('show');
					$('#table1').append(table);
				}				
			},
			error : function(data) {
				console.log(data);
			}
		})
	}  
	
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opscautomation\resources\views/user/manage-user-role.blade.php ENDPATH**/ ?>