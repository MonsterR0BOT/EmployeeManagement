<?php $__env->startSection('title', 'SERVICE'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      Manage Service
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Manage Service</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="box">
       <?php if(Session::has('message')): ?>
        <div class="alert alert-success">                        
            <i class="fa fa-check"></i> <?php echo e(Session::get('message')); ?> 
        </div>
        <?php endif; ?>
        <!-- /.box-header -->
        <div class="box-body">
          <div id="demo">
                <div class="search-field">
                    <div class="row">
                        <div class="col-md-2">
                            <div class="org-name">Service Name</div>
                        </div>
                        <div class="col-md-3">
                            <input class="form-control" type="text" placeholder="" name="" id="param1">
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <button class="btn btn-primary" onClick="searchData()">Search</button>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="form-group pull-right">
                                <a href="<?php echo e(url('content/addService')); ?>"><button class="btn btn-primary">Add Service</button></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--<a data-toggle="collapse" data-target="#demo"
                class="showhideangelbg"><i class="fa fa-angle-double-down"></i>
            </a>-->
          <table id="listAllCostCenter" class="table table-bordered table-striped">
            <thead>
            <tr>
              <th>Service Name</th>
              <th>Service Description</th>
              <th>Service Image</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
            </thead>
            <tbody>
            
            </tbody>
          </table>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('styles'); ?>

<?php $__env->stopPush(); ?>  
<?php $__env->startPush('scripts'); ?>

<script>
  $(function () {
  $('#listAllCostCenter').DataTable({
    'processing' : true,
    'serverSide' : true,
    'searching' : false,
    'ordering' : false,
    "ajax" : {
      'url' : "<?php echo e(url('Content/viewServicethroughAjax')); ?>",
      'data' : function(d) {
        d.param1 = $('#param1').val();
        //d.param2 = $('#param2').val();

      }
    },
    'dataSrc' : "",
    'columns' : [ {
      'data' : 'TSM_Service_Name'
    },{
      'data' : 'TSM_Service_Desc'
    }, {
      'data' : 'TSM_Service_Image'
    }, {
      'data' : 'TSM_Service_Active'
    },{
      'data' : 'action'
    }

    ]
  });
  
  });
  //Method For Searching Records In The List
  function searchData() {
    $('#listAllCostCenter').DataTable().draw();
  }
  //Deleting the Country

  function deleteService(id){
    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
      }
    });
    swal.fire({
        title: "Are you sure want to Delete?",
        text: "Once Deleted,Can't revert back !",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#e7b63a',
        confirmButtonText: 'Delete',
        reverseButtons : true
        
      }).then((result) => {
        if(result.value){
         $.ajax({
              type: "POST",
              url:"<?php echo e(url('content/deleteServicethroughAjax')); ?>",
              data:{'id':id},
              success: function(response) {
            console.log(response);
            //return false;
                  if (response.message == "success") {
                    swal({
                      title: "Record Deleted Successfully.",
                      type: "success"
                    }).then(function(){
                       location.reload();
                    })
                  
                    
                  } else {
                      swal({
                          title: 'Unsuccess',
                          text: response.code
                      })
                  }
              },
              error: function(data) {
               
              }
          })
        }
        
      });
  }

</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\aquatic\resources\views/content/manage-service.blade.php ENDPATH**/ ?>