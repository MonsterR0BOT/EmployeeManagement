 <section class="project-section">
        <div class="auto-container">
            <div class="row">
                <div class="col-12">
                    <div class="sec-title text-left">
                        <div class="clearfix">
                            <div class="pull-left">
                                <h2>Our Products</h2>
                            </div>
                            <div class="tab-btns-box pull-right">
                                <!--Tabs Header-->
                                <div class="tabs-header">
                                    <ul class="product-tab-btns clearfix">
                                        <li class="p-tab-btn active-btn" data-tab="#p-tab-1">All Products</li>
                                        <li class="p-tab-btn" data-tab="#p-tab-2">Basin Mixture</li>
                                        <li class="p-tab-btn" data-tab="#p-tab-3">Bib Cock</li>
                                        <li class="p-tab-btn" data-tab="#p-tab-4">Sink Cock</li>
                                        <li class="p-tab-btn" data-tab="#p-tab-5">Swan Neck</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-12">
                    <div class="text-column">
                        <div class="inner-box">
                           
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                            <!-- <div class="link-box"><a href="#" class="theme-btn btn-style-three">Read More</a></div> -->
                            <div class="more-project"><a href="#">View All Products <i class="fa fa-arrows-alt"></i></a></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-9 col-sm-12">
                    <!--Porfolio Tabs-->
                    <div class="project-tab">
                        
                        <!--Tabs Content-->  
                        <div class="p-tabs-content">
                        
                            <!--Portfolio Tab / Active Tab-->
                            <div class="p-tab active-tab" id="p-tab-1">
                                <div class="projects-carousel owl-theme owl-carousel">
                                
                                    <!--Project Block-->
                                    <div class="project-block">
                                        <div class="inner-box">
                                            <div class="image">
                                                <img src="<?php echo e(asset('images/gallery/1.jpg')); ?>" alt="" />
                                                <!--Overlay Two-->
                                                <div class="overlay-box">
                                                    <div class="overlay-inner">
                                                        <div class="overlay-content">
                                                            <a href="<?php echo e(asset('images/gallery/1.jpg')); ?>" class="see-more lightbox-image" data-fancybox="gallery"><span class="flaticon-add"></span></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!--Project Block-->
                                    <div class="project-block">
                                        <div class="inner-box">
                                            <div class="image">
                                                <img src="<?php echo e(asset('images/gallery/2.jpg')); ?>" alt="" />
                                                 <!--Overlay Two-->
                                                <div class="overlay-box">
                                                    <div class="overlay-inner">
                                                        <div class="overlay-content">
                                                            <a href="<?php echo e(asset('images/gallery/2.jpg')); ?>" class="see-more lightbox-image" data-fancybox="gallery"><span class="flaticon-add"></span></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!--Project Block-->
                                    <div class="project-block">
                                        <div class="inner-box">
                                            <div class="image">
                                                <img src="<?php echo e(asset('images/gallery/3.jpg')); ?>" alt="" />
                                                 <!--Overlay Two-->
                                                <div class="overlay-box">
                                                    <div class="overlay-inner">
                                                        <div class="overlay-content">
                                                            <a href="<?php echo e(asset('images/gallery/3.jpg')); ?>" class="see-more lightbox-image" data-fancybox="gallery"><span class="flaticon-add"></span></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                
                                </div>
                            </div>
                            
                            <!--Portfolio Tab / Active Tab-->
                            <div class="p-tab" id="p-tab-2">
                                <div class="projects-carousel owl-theme owl-carousel">
                                
                                    <!--Project Block-->
                                    <div class="project-block">
                                        <div class="inner-box">
                                            <div class="image">
                                                <img src="<?php echo e(asset('images/gallery/4.jpg')); ?>" alt="" />
                                                <!--Overlay Two-->
                                                <div class="overlay-box">
                                                    <div class="overlay-inner">
                                                        <div class="overlay-content">
                                                            <a href="<?php echo e(asset('images/gallery/4.jpg')); ?>" class="see-more lightbox-image" data-fancybox="gallery"><span class="flaticon-add"></span></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!--Project Block-->
                                    <div class="project-block">
                                        <div class="inner-box">
                                            <div class="image">
                                                <img src="<?php echo e(asset('images/gallery/5.jpg')); ?>" alt="" />
                                                 <!--Overlay Two-->
                                                <div class="overlay-box">
                                                    <div class="overlay-inner">
                                                        <div class="overlay-content">
                                                            <a href="<?php echo e(asset('images/gallery/5.jpg')); ?>" class="see-more lightbox-image" data-fancybox="gallery"><span class="flaticon-add"></span></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!--Project Block-->
                                    <div class="project-block">
                                        <div class="inner-box">
                                            <div class="image">
                                                <img src="<?php echo e(asset('images/gallery/6.jpg')); ?>" alt="" />
                                                 <!--Overlay Two-->
                                                <div class="overlay-box">
                                                    <div class="overlay-inner">
                                                        <div class="overlay-content">
                                                            <a href="<?php echo e(asset('images/gallery/6.jpg')); ?>" class="see-more lightbox-image" data-fancybox="gallery"><span class="flaticon-add"></span></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                
                                </div>
                            </div>
                            
                            <!--Portfolio Tab / Active Tab-->
                            <div class="p-tab" id="p-tab-3">
                                <div class="projects-carousel owl-theme owl-carousel">
                                
                                    <!--Project Block-->
                                    <div class="project-block">
                                        <div class="inner-box">
                                            <div class="image">
                                                <img src="<?php echo e(asset('images/gallery/7.jpg')); ?>" alt="" />
                                                <!--Overlay Two-->
                                                <div class="overlay-box">
                                                    <div class="overlay-inner">
                                                        <div class="overlay-content">
                                                            <a href="<?php echo e(asset('images/gallery/7.jpg')); ?>" class="see-more lightbox-image" data-fancybox="gallery"><span class="flaticon-add"></span></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!--Project Block-->
                                    <div class="project-block">
                                        <div class="inner-box">
                                            <div class="image">
                                                <img src="<?php echo e(asset('images/gallery/8.jpg')); ?>" alt="" />
                                                 <!--Overlay Two-->
                                                <div class="overlay-box">
                                                    <div class="overlay-inner">
                                                        <div class="overlay-content">
                                                            <a href="<?php echo e(asset('images/gallery/8.jpg')); ?>" class="see-more lightbox-image" data-fancybox="gallery"><span class="flaticon-add"></span></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!--Project Block-->
                                    <div class="project-block">
                                        <div class="inner-box">
                                            <div class="image">
                                                <img src="<?php echo e(asset('images/gallery/9.jpg')); ?>" alt="" />
                                                 <!--Overlay Two-->
                                                <div class="overlay-box">
                                                    <div class="overlay-inner">
                                                        <div class="overlay-content">
                                                            <a href="<?php echo e(asset('images/gallery/9.jpg')); ?>" class="see-more lightbox-image" data-fancybox="gallery"><span class="flaticon-add"></span></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                
                                </div>
                            </div>
                            
                           <!--Portfolio Tab / Active Tab-->
                            <div class="p-tab" id="p-tab-4">
                                <div class="projects-carousel owl-theme owl-carousel">
                                
                                    <!--Project Block-->
                                    <div class="project-block">
                                        <div class="inner-box">
                                            <div class="image">
                                                <img src="<?php echo e(asset('images/gallery/10.jpg')); ?>" alt="" />
                                                <!--Overlay Two-->
                                                <div class="overlay-box">
                                                    <div class="overlay-inner">
                                                        <div class="overlay-content">
                                                            <a href="<?php echo e(asset('images/gallery/10.jpg')); ?>" class="see-more lightbox-image" data-fancybox="gallery"><span class="flaticon-add"></span></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!--Project Block-->
                                    <div class="project-block">
                                        <div class="inner-box">
                                            <div class="image">
                                                <img src="<?php echo e(asset('images/gallery/11.jpg')); ?>" alt="" />
                                                 <!--Overlay Two-->
                                                <div class="overlay-box">
                                                    <div class="overlay-inner">
                                                        <div class="overlay-content">
                                                            <a href="<?php echo e(asset('images/gallery/11.jpg')); ?>" class="see-more lightbox-image" data-fancybox="gallery"><span class="flaticon-add"></span></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!--Project Block-->
                                    <div class="project-block">
                                        <div class="inner-box">
                                            <div class="image">
                                                <img src="<?php echo e(asset('images/gallery/12.jpg')); ?>" alt="" />
                                                 <!--Overlay Two-->
                                                <div class="overlay-box">
                                                    <div class="overlay-inner">
                                                        <div class="overlay-content">
                                                            <a href="<?php echo e(asset('images/gallery/12.jpg')); ?>" class="see-more lightbox-image" data-fancybox="gallery"><span class="flaticon-add"></span></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                
                                </div>
                            </div>
                            
                            <!--Portfolio Tab / Active Tab-->
                            <div class="p-tab" id="p-tab-5">
                                <div class="projects-carousel owl-theme owl-carousel">
                                
                                    <!--Project Block-->
                                    <div class="project-block">
                                        <div class="inner-box">
                                            <div class="image">
                                                <img src="<?php echo e(asset('images/gallery/13.jpg')); ?>" alt="" />
                                                <!--Overlay Two-->
                                                <div class="overlay-box">
                                                    <div class="overlay-inner">
                                                        <div class="overlay-content">
                                                            <a href="<?php echo e(asset('images/gallery/13.jpg')); ?>" class="see-more lightbox-image" data-fancybox="gallery"><span class="flaticon-add"></span></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!--Project Block-->
                                    <div class="project-block">
                                        <div class="inner-box">
                                            <div class="image">
                                                <img src="<?php echo e(asset('images/gallery/14.jpg')); ?>" alt="" />
                                                 <!--Overlay Two-->
                                                <div class="overlay-box">
                                                    <div class="overlay-inner">
                                                        <div class="overlay-content">
                                                            <a href="<?php echo e(asset('images/gallery/14.jpg')); ?>" class="see-more lightbox-image" data-fancybox="gallery"><span class="flaticon-add"></span></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!--Project Block-->
                                    <div class="project-block">
                                        <div class="inner-box">
                                            <div class="image">
                                                <img src="<?php echo e(asset('images/gallery/15.jpg')); ?>" alt="" />
                                                 <!--Overlay Two-->
                                                <div class="overlay-box">
                                                    <div class="overlay-inner">
                                                        <div class="overlay-content">
                                                            <a href="<?php echo e(asset('images/gallery/15.jpg')); ?>" class="see-more lightbox-image" data-fancybox="gallery"><span class="flaticon-add"></span></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section><?php /**PATH D:\xampp\htdocs\aquatic\resources\views/frontend-layout/homeproduct.blade.php ENDPATH**/ ?>