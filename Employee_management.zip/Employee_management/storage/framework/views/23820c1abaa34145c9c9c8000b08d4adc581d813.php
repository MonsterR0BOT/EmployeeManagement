<?php $__env->startSection('title', 'USER ROLE'); ?>
<?php $__env->startSection('content'); ?>
 <?php $__env->startPush('styles'); ?>
 	<style type="text/css">
     /*admin tree structure menu css starts*/
    
    .treev, .treev ul {
        margin:0;
        padding:0;
        list-style:none
    }
    .treev ul {
        margin-left:1em;
        position:relative
    }
    .treev ul ul {
        margin-left:.5em
    }
    .treev ul:before {
        content:"";
        display:block;
        width:0;
        position:absolute;
        top:0;
        bottom:0;
        left:0;
        border-left:1px solid
    }
    .treev li {
        margin:0;
        padding:0 1em;
        line-height:2em;
        color:#4270af;
        font-weight:700;
        position:relative
    }
    .treev ul li:before {
        content:"";
        display:block;
        width:10px;
        height:0;
        border-top:1px solid;
        margin-top:-1px;
        position:absolute;
        top:1em;
        left:0
    }
    .treev ul li:last-child:before {
        background:#fff;
        height:auto;
        top:1em;
        bottom:0
    }
    .indicator {
        margin-right:5px;
    }
    .treev li a {
        text-decoration: none;
        color:#4270af;
    }
    .treev li button, .treev li button:active, .treev li button:focus {
        text-decoration: none;
        color:#4270af;
        border:none;
        background:transparent;
        margin:0px 0px 0px 0px;
        padding:0px 0px 0px 0px;
        outline: 0;
    }
    /*admin  tree structure menu css end*/
	</style>
 <?php $__env->stopPush(); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Add User Role</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">User</a></li>
        <li class="active">Add User Role</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
    	
      <!-- Default box -->
      <div class="box">
       <!-- <div class="box-header">
          <h3 class="box-title">Quick Example</h3>
        </div>-->
        <!-- /.box-header -->
        <!-- form start -->
        <form role="form" autocomplete="off">
        	<?php echo csrf_field(); ?>
          <div class="box-body">
            <div class="row">
                <div class="col-md-6">
                	<?php
                    if(!empty($data)){
                    	$userRoleId = $data[0]->TURM_UserRole;
                        $TURM_URole_Name = $data[0]->TURM_URole_Name;
                        $TURM_CostCenter = $data[0]->TURM_CostCenter;
                        $TURM_URole_Description = $data[0]->TURM_URole_Description;
                        $TURM_ParentUserRole = $data[0]->TURM_ParentUserRole;
                        $TURM_URole_Status = $data[0]->TURM_URole_Status;
                        
                    }else{
                    	$userRoleId = '';
                        $TURM_URole_Name = '';
                        $TURM_CostCenter = '';
                        $TURM_URole_Description = '';
                        $TURM_ParentUserRole = '';
                        $TURM_URole_Status = 1;
                    }
                    ?>
                    <div class="form-group">
                      <label for="exampleInputEmail1">User Role Name</label>
                      <input type="text" class="form-control" name="userRoleName" id="userRoleName" value="<?php echo e($TURM_URole_Name); ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Parent User Role</label>
                       <select class="form-control" name="userParentUserRole" id="userParentUserRole" >
                      	<option value="">--Select--</option>
                        <?php $__currentLoopData = $parent_role_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($val->TURM_UserRole); ?>" <?php if($TURM_ParentUserRole == $val->TURM_UserRole): ?> selected="selected" <?php endif; ?> ><?php echo e($val->TURM_URole_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                   
                    <div class="form-group">
                      <label for="exampleInputFile">Status</label>
                       <select class="form-control" name="userRoleStatus" id="userRoleStatus">
                      	<option value="">--Select--</option>
                        <option value="1" <?php if($TURM_URole_Status ==1): ?> selected="selected" <?php endif; ?>>Active</option>
                        <option value="0" <?php if($TURM_URole_Status ==0): ?> selected="selected" <?php endif; ?>>Inactive</option>
                      </select>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Description</label>
                      <textarea class="form-control" name="userDescription" id="userDescription"><?php echo e($TURM_URole_Description); ?></textarea>
                    </div>
                    
                </div>
                
                <div class="col-md-6">
                    <div class="form-group">
                     <label>Module</label>
                     <div class="col-md-12">
                        <ul id="tree1" >
                         <?php $__currentLoopData = $module_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php ($keys = array_search($module->TMM_Module, array_column($module_chk_list, 'TMM_Module'))); ?>
                           <li>
                              <input type="checkbox"  class="pc-box" style="width: 16px;" <?php echo e(($keys !== false) ? 'checked="checked" ' : ''); ?> >
                              <a id ="<?php echo e($module->TMM_Module); ?>"> <?php echo e($module->TMM_Modl_Name); ?></a>
                              <ul>
                               <?php $__currentLoopData = $function_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $function): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               	<?php if($function->parentIdForFunction == $module->TMM_Module): ?>
                                	<?php ($funs = array_search($function->TFM_Function, array_column($function_chk_list, 'TFM_Function'))); ?>
                                 <li>
                                    <input type="checkbox" class="pc1-box" style="width: 16px;" <?php echo e(($funs !== false) ? 'checked="checked" ' : ''); ?> >
                                   
                                    <a id ="<?php echo e($function->TFM_Function); ?>"><?php echo e($function->functionName); ?></a>
                                    <ul class="treeActivity">
                                    <?php $__currentLoopData = $activity_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               			<?php if($activity->parentIdForActitvity == $function->TFM_Function): ?>
                                        	<?php ($funs = array_search($activity->activityId, array_column($activity_chk_list, 'TAM_Activity'))); ?>
                                       <li>
                                          <input type="checkbox"  class="activityCls" data-functionId="<?php echo e($function->TFM_Function); ?>" data-moduleId="<?php echo e($module->TMM_Module); ?>" data-activityId="<?php echo e($activity->activityId); ?>"value="<?php echo e($activity->activityId); ?>"  style="width: 16px;" <?php echo e(($funs !== false) ? 'checked="checked" ' : ''); ?> >
                                          <a id ="<?php echo e($activity->activityId); ?>"><?php echo e($activity->activityName); ?></a>
                                       </li>
                                        <?php endif; ?>
                                	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--Function loop end--> 
                                    </ul>
                                 </li>
                                 <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--Function loop end--> 
                              </ul>
                           </li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--Module loop end--> 
                        </ul>
                     </div>
                  </div>
                    
                </div>
                
            </div>
          </div>
          <!-- /.box-body -->
          <div class="box-footer">
          	<input type="hidden" name="userRoleId" id="userRoleId" value="<?php echo e($userRoleId); ?>"/>
            <button type="button" class="btn btn-primary" id="sbmtdata">Submit</button>
            <a href="<?php echo e(url('UserRole/viewAllUserRole')); ?>"><button type="button" class="btn btn-warning" >Cancel</button></a>
          </div>
        </form>
      </div>
      <!-- /.box -->
      
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
   <?php $__env->startPush('scripts'); ?>
   <script>
         function validateForm(){
         	    if (!blankValidation("userRoleName","TextField", "User role name can not be left blank"))
                 	return false;
         	    if (!blankValidation("userParentUserRole","SelectBox", "Please select parent role"))
                     return false;
                // if (!blankValidation("userCostCenter","SelectBox", "Please Select Cost Center"))
                //      return false;
           
             	if (!blankValidation("userRoleStatus","SelectBox", "Please select status"))
                     return false;
                if (!blankValidation("userDescription","TextField", "Discription can not be blank!."))
                     return false;
            	var checkedActivity = false;
                $(".activityCls:checkbox:checked").each(function () {
					checkedActivity = true;
					return false;
             	});
             	if(!checkedActivity){
					swal("Please check at least one activity of a module");
					return false;
             	}
             return true;
         }
     
         $(function() {
         	//For tree structure of Module,Function and Activity Tree structure
         $.fn.extend({
                treed: function(o) {
         
                    var openedClass = 'fa-minus-circle';
                    var closedClass = 'fa-plus-circle';
         
                    if (typeof o != 'undefined') {
                        if (typeof o.openedClass != 'undefined') {
                            openedClass = o.openedClass;
                        }
                        if (typeof o.closedClass != 'undefined') {
                            closedClass = o.closedClass;
                        }
                    };
         
                    //initialize each of the top levels
                    var tree = $(this);
                    tree.addClass("treev");
                    tree.find('li').has("ul").each(function() {
                        var branch = $(this); //li with children ul
                        branch.prepend("<i class='indicator fa " + closedClass + "'></i>");
                        branch.addClass('branch');
                        branch.on('click', function(e) {
                            if (this == e.target) {
                                var icon = $(this).children('i:first');
                                icon.toggleClass(openedClass + " " + closedClass);
                                $(this).children().children().toggle();
                            }
                        })
                        branch.children().children().toggle();
                    });
                    //fire event from the dynamically added icon
                    tree.find('.branch .indicator').each(function() {
                        $(this).on('click', function() {
                            $(this).closest('li').click();
                        });
                    });
                    //fire event to open branch if the li contains an anchor instead of text
                    tree.find('.branch>a').each(function() {
                        $(this).on('click', function(e) {
                            $(this).closest('li').click();
                            e.preventDefault();
                        });
                    });
                    //fire event to open branch if the li contains a button instead of text
                    tree.find('.branch>button').each(function() {
                        $(this).on('click', function(e) {
                            $(this).closest('li').click();
                            e.preventDefault();
                        });
                    });
                }
            });
         
            //Initialization of treeviews
         
            $('#tree1').treed();
            $('#tree2').treed();
            //$('#tree2').treed({openedClass:'glyphicon-folder-open', closedClass:'glyphicon-folder-close'});
         
            $('#tree3').treed({ openedClass: 'glyphicon-chevron-right', closedClass: 'glyphicon-chevron-down' });
         
            //End of Tree structure
         })    
         
            
             $(document).ready(function() {        
                $(".pc-box").click(function() {
                    if (this.checked) {
                    	$(this).closest("li").find(".pc-box").prop("checked", true);
                    	$(this).closest("li").find(".pc1-box").prop("checked", true);
                        $(this).closest("li").find(".activityCls").prop("checked", true);
                        $(this).parent();
                    }  
                });
                $(".pc-box").click(function() {
                    if (!this.checked) {
                    	$(this).closest("li").find(".pc1-box").prop("checked", false);
                        $(this).closest("li").find(".activityCls").prop("checked", false);
                        $(this).parent();
                    }  
                });
                $(".pc1-box").click(function() {
                    if (this.checked) {
                    	$(this).closest("li").find(".pc1-box").prop("checked", true);
                        $(this).closest("li").find(".activityCls").prop("checked", true);
                        $(this).parent();
                    }  
                });
                $(".pc1-box").click(function() {
                    if (!this.checked) {
                        $(this).closest("li").find(".activityCls").prop("checked", false);
                        $(this).parent();
                    }  
                });
                
                $(".activityCls").click(function() {
                    if (!this.checked)
                        $(this).closest("ul").prev().find(".pc-box").prop("checked", false);
                });
            });
         	
         	
         	/*$(function () {
         		 var hiddendata=$("#userRoleId").val();
         		 if(hiddendata != ""){
         			  if(!window.location.hash) {
         			        //setting window location
         			        window.location = window.location + '#valid';
         			        //using reload() method to reload web page
         			        window.location.reload();
         			        
         			    }     
         		   }	 
         	 });*/
         	 
         
         		 
         	 $(function () {	
         	//submit button function
         		const ipAPI = 'https://api.ipify.org?format=json';
         		$("#sbmtdata").click(function(){
                    if(validateForm()){
             			var dataset = [];
             			$(".activityCls:checkbox:checked").each(function () {
             				
             				item = {};
             				item['userRoleId']= $("#userRoleId").val();
             				item['userRoleName']= $("#userRoleName").val();
             				item['userRoleStatus']= $("#userRoleStatus").val();
             				item['userDescription']= $("#userDescription").val();
             				item['userParentUserRole']= $("#userParentUserRole").val();
             				item['userCostCenter']= $("#userCostCenter").val();
             				 
             				
             				item['moduleId']	=	$(this).attr("data-moduleId");
             				item['functionId']	=	$(this).attr("data-functionId");
             				item['activityId']	=	$(this).attr("data-activityId");
             				
             				
             				dataset.push(item);
             			});//table tbody tr loop ends
             			console.log(dataset);
             			submitUserRole(dataset);	
         			}else{
                        return false;
                    }
         			 
         		})
         		function submitUserRole(dataset){
					$.ajaxSetup({
						headers: {
							'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
						}
					});
         			//alert(dataset);return false;
         			swal.fire({
         				title				: "Are you sure want to Submit?",
         				text				: "Once Submited,Can't revert back !",
         				type 				: "warning",
         				
         				showCancelButton	: true,
         				confirmButtonColor	: "#DD6BB5",
         				confirmButtonText	:"Submit",
         				showLoaderOnConfirm	: true,
         				preConfirm: () => {
							return new Promise((resolve) => {
								setTimeout(() => {
									console.log("Doing async operation");
									resolve()
								}, 3000)
							})
						},
         				reverseButtons : true,
         				confirmButtonAriaLabel : 'Thumbs up, great!',
         				cancelButtonText : 'Cancel',
         				cancelButtonAriaLabel : 'Thumbs down',
         				
         				 preConfirm: () => {
         				    return fetch(ipAPI)
         				      .then(response => response.json())
         				      .then(data => Swal.insertQueueStep(data.ip))
         				      .catch(() => {
         				        Swal.insertQueueStep({
         				          type: 'error',
         				          title: 'Unable to get your public IP'
         				,        })
         				      })
         				 }   
         			}).then((result) => {
         				if(result.value){
         					$.ajax({
         					type		: "POST",
         					url 		: "<?php echo e(url('UserRole/AddUserRole')); ?>",
         					dataType	: "json",
         					//contentType	: "application/json",
         					data		: JSON.stringify(dataset),
         					success		: function(response){
         						console.log(response);
         						if(response.message=="success"){
         							swal({
         									title:"Data Saved Successfully.",
         									type: "success",
         							}).then(function(){
         								window.location.href="<?php echo e(url('UserRole/viewAllUserRole')); ?>";
         							})
         						}else{
         							//$("#errorMsg").html(response.message);
         							swal({
         								title:response.code,
         								text: response.message,
         								type:"warning"
         							})
         						}
         					},error		: function(response){
         						swal(response.code);	
         					}
         				}) //ajax ends
         			}
         			})//swal function block ends
         		}//submit function ends
         	});
         
      </script> 
   <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/user/add-user-role.blade.php ENDPATH**/ ?>