<!--  <script src="<?php echo e(asset('js/compressed.js')); ?>"></script>
<script src="<?php echo e(asset('js/selectize.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/main.js')); ?>"></script>  -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
 <script src="<?php echo e(asset('js/sweetalert2.all.min.js')); ?>"></script>
 <script src="<?php echo e(asset('js/validate.js')); ?>"></script> 
 <!-- <script src="<?php echo e(asset('js/main.js')); ?>"></script> -->
<!-- validator js -->

<!-- <script src="//cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script> -->
<?php /**PATH E:\xampp\htdocs\wethefamily\resources\views/frontend-layout/includejs.blade.php ENDPATH**/ ?>