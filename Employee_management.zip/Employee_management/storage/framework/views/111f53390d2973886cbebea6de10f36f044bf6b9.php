 <!-- Modal Header -->
<div class="modal-header">
   <h4 class="modal-title">Upload Vigilance / Criminal /Disciplinary Proceedings &nbsp;</h4>
   <!-- <button type="button" class="close" data-dismiss="modal">×</button> -->
</div>
<!-- Modal body -->
<div class="modal-body">
  <div class="col-lg-12">
<!--upload vigilance-->
      <div class="row">                       
       <div class="col-lg-12">
       <div class="form-group vigilance">
       <div class="row">
        <div class="col-lg-3">
            <label>File Type</label>
            <select name="docTypeOfficer" id="docTypeOfficer" class="form-control">
               <option value="">--Select---</option>
               <?php $__currentLoopData = $doctype_list_officer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($val->TDM_Doc); ?>"><?php echo e($val->TDM_Doc_Name); ?></option>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div> 

        <div class="col-lg-3">
            <label>Year</label>
             <select name="FinancialYear" id="FinancialYear" class="form-control">
                 <option value="">--Select Year--</option>
                 <?php $y= date('Y')-1; ?> 
                 <?php for($i =1; $i <= 7; $i++): ?>
                      <option value="<?php echo e($y.'-'.($y-1)); ?>"><?php echo e($y.'-'.($y-1)); ?></option>
                    <?php ($y--); ?>  
                 <?php endfor; ?> 
             </select>
        </div>
          
        <div class="col-lg-5">
            <label>Upload File</label> 
            <div class="input-group">
            <input type="file" class="custom-file-input"  name="UploadFileOfficer" id="UploadFileOfficer"> 
            <label class="custom-file-label customFile" for="customFile" >Choose file</label> 
          </div>
        </div>

          <div class="col-lg-1 mrt_30" align="right">
              <button class="btn btn-primary" type="button" id="saveFileIfOfficers" onClick="saveFileIfOfficers()"><i class="fa fa-upload"></i></button> 
          </div>
          
       </div>
       </div>
         
      </div>
      </div>            
  </div>
   
  <div class="row" id="previewDocsOfficer"> 

  </div>
</div>
<!-- Modal footer -->
<div class="modal-footer" align="center"> 
  <input type="hidden" id="innerModal">
  <button type="button" class="btn btn-danger" onClick="hideCCRModal()">Close</button>
</div>


<?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/promotional/ajax-add-vigilance-form.blade.php ENDPATH**/ ?>