<?php $__env->startSection('title', 'CHANGE PASSWORD'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
   <section id="" class="ls section_padding_top_40 columns_padding_30 community-marrige">
                <div class="container">
    <!-- Content Header (Page header) -->
                <div class="row">
                        <div class="col-md-10 col-md-offset-1 login-bg" data-animation="fadeInUp" data-delay="600">
      <h1>Change Password</h1>
      
    </section>

    <!-- Main content -->
    <section class="container">
      
      <!-- Default box -->
      <div class="box-body">
        <?php if(Session::has('errors')): ?>
          <div class="col-md-12 alert alert-warning">
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($error); ?><br/>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        <?php endif; ?>
       <?php if(Session::has('warning')): ?>
         <div class="alert alert-warning">                        
             <i class="fa fa-check"></i> <?php echo e(Session::get('warning')); ?> 
         </div>
         <?php endif; ?>
         <?php if(Session::has('message')): ?>
           <div class="alert alert-warning">
              <h5><?php echo e(Session::get('message')); ?></h5>
           </div>
           <div class="alert alert-warning">
              <h5>Your password must be have at least</h5>
              <div>
                 <p>
                    -Password should be minimum of 6 characters and maximum 16 charaters.<br>
                    -must have at least one uppercase ,one lowercase one numeric and one special character.<br>
                    -special characters  allowed ! @$ # & * ().<br>
                    -password should not contain you first name.<br>
                    -password should not start with a special character.
                 </p>
              </div>
           </div>
           <?php endif; ?>
       <!-- <div class="box-header">
          <h3 class="box-title">Quick Example</h3>
        </div>-->
        <!-- /.box-header -->
        <!-- form start -->
        <form role="form" action="<?php echo e(url('modify-member-password')); ?>" method="post" autocomplete="off" onsubmit="return validateForm();">
        <?php echo csrf_field(); ?>
          <div class="box-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                      <label for="newPassword">Old Password</label>
                      <input type="password" class="form-control" name="oldPassword" id="oldPassword" value="" >
                    </div>
                     <div class="form-group">
                      <label for="newPassword">New Password</label>
                      <input type="password" class="form-control" name="newPassword" id="newPassword" value="" >
                    </div>
                    <div class="form-group">
                      <label for="confirmPassword">Confirm Password</label>
                      <input type="password" class="form-control" name="confirmPassword" id="confirmPassword" value="" >
                    </div>
                    
                </div>
            </div>
          </div>
          <!-- /.box-body -->
          <div class="box-footer">
            <button type="submit" class="btn btn-primary">Submit</button>

            <a href="<?php echo e(url('loginMember/showDashboard')); ?>"><button type="button" class="btn btn-warning" >Cancel</button></a>
          </div>
        </form>
      </div>
      <!-- /.box -->
      
    </section>
    <!-- /.content -->
  </div>
  </section>
  <!-- /.content-wrapper -->
<?php $__env->startPush('scripts'); ?> 
<script type="text/javascript">
  function validateForm(){ //alert("here"); return false;
      if (!blankValidation("oldPassword", "TextField","Enter old password"))
        return false;
      if (!blankValidation("newPassword", "TextField","Enter new password"))
        return false;
      if (!blankValidation("confirmPassword", "TextField","Enter confirm password"))
        return false;

      if($('#newPassword').val() != $('#confirmPassword').val()){
        swal("Sorry !! Password mismatch");
        return false;
      }      
  }

</script>  
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend-layout.frontend-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\wethefamily\resources\views/change-password.blade.php ENDPATH**/ ?>