<?php $__env->startSection('title', 'AQUATIC'); ?>
<?php $__env->startSection('content'); ?>
     <!--Page Title-->
    <section class="page-title" style="background-image:url('../public/images/innerbanner.jpg');">
        <div class="auto-container">
            <div class="inner-container clearfix">
                <div class="title-box">
                    <h1>Orientation-Center</h1>
                </div>
                <ul class="bread-crumb clearfix">
                    <li><a href="index.html"><span class="fas fa-home"></span> Home</a></li>
                    <li><span class="far fa-arrow-alt-circle-right"></span>Orientation-Center</li>
                </ul>
            </div>
        </div>
    </section>
    <!--End Page Title-->
   
    <section class="contact-page-section" style="background-image:url(images/background/12.png)">
        <div class="auto-container">
            <div class="sec-title text-center">
                <h2>Orientation-Center</h2>
            </div>
            <div class="row">
                <div class="form-column col-lg-6 col-md-6 col-sm-12">
                    <div class="inner-column">
                        <div id="demo" class="carousel slide" data-ride="carousel">

                          <!-- Indicators -->
                          <ul class="carousel-indicators">
                            <li data-target="#demo" data-slide-to="0" class="active"></li>
                            <li data-target="#demo" data-slide-to="1"></li>
                            <li data-target="#demo" data-slide-to="2"></li>
                          </ul>
                          
                          <!-- The slideshow -->
                          <div class="carousel-inner">
                            <div class="carousel-item active">
                              <img src="<?php echo e(asset('images/orientation/1.jpg')); ?>" alt="Los Angeles" width="1100" height="500">
                            </div>
                            <div class="carousel-item">
                              <img src="<?php echo e(asset('images/orientation/2.jpg')); ?>" alt="Chicago" width="1100" height="500">
                            </div>
                            <div class="carousel-item">
                              <img src="<?php echo e(asset('images/orientation/3.jpg')); ?>" alt="New York" width="1100" height="500">
                            </div>
                          </div>
                          
                          <!-- Left and right controls -->
                          <a class="carousel-control-prev" href="#demo" data-slide="prev">
                            <span class="carousel-control-prev-icon"></span>
                          </a>
                          <a class="carousel-control-next" href="#demo" data-slide="next">
                            <span class="carousel-control-next-icon"></span>
                          </a>
                        </div>

                    </div>
                </div>
                <!-- Form Column -->
                <div class="form-column col-lg-6 col-md-6 col-sm-12">
                    <div class="inner-column">
                        <!-- Contact Form -->
                        <div class="contact-form">
                            <form method="post" action="sendemail.php">
                                <div class="row">
                                    <div class="form-group col-lg-12 col-md-12">
                                        <input type="text" placeholder="Name" required>
                                    </div>

                                    <div class="form-group col-lg-12 col-md-12">
                                        <input type="email" placeholder="Email Address" required>
                                    </div>

                                     <div class="form-group col-lg-12 col-md-12">
                                        <input type="text" placeholder="City" required>
                                    </div>

                                    <div class="form-group col-lg-12 col-md-12">
                                        <input type="text" placeholder="Mobile Number" required>
                                    </div>

                                    <div class="form-group col-lg-8 col-md-8">
                                        <input type="text"  placeholder="Enter Captch" required>
                                    </div>

                                    <div class="form-group col-lg-4 col-md-4">
                                        <img src="<?php echo e(asset('images/captch.jpg')); ?>"  alt="captch">
                                    </div>
                                    
                                    <div class="form-group col-lg-12 col-md-12 text-center">
                                        <button class="theme-btn btn-style-one " type="submit" name="submit-form">Submit</button>
                                    </div> 
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
 <?php $__env->startPush('scripts'); ?>
 <!-- Write down javascript here -->
 <?php $__env->stopPush(); ?>   
<?php $__env->stopSection(); ?>   
<?php echo $__env->make('frontend-layout.frontend-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\aquatic\resources\views/orientation.blade.php ENDPATH**/ ?>