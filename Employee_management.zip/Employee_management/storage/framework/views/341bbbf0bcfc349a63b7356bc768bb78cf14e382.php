
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0.1
    </div>
    <strong>Copyright &copy; <?php echo e(date('Y')); ?> <a href="#">OPSC</a>.</strong> All rights
    reserved.
  </footer>

  <?php /**PATH D:\xampp\htdocs\opscautomation\resources\views/layout/footer.blade.php ENDPATH**/ ?>