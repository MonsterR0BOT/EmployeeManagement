<?php $__env->startSection('title', 'SMS'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Edit SMS</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Edit SMS</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      
      <!-- Default box -->
      <div class="box">
        <form role="form" id="smsForm" method="post" autocomplete="off" action="<?php echo e(url('post-sms')); ?>">
          <?php echo e(csrf_field()); ?>

          <div class="box-body">
            <div class="row">
                <div class="col-md-6">
                   <?php
                    if(!empty($data)){
                        $smsId = $data[0]->TSM_SMS;
                        $TSM_SMS_Name  = $data[0]->TSM_SMS_Name;
                        $TSM_SMS_Body = $data[0]->TSM_SMS_Body;
                    }else{
                       $smsId = '';
                       $TSM_SMS_Name  = '';
                       $TSM_SMS_Body = '';
                    }
                    ?>
                    <div class="form-group">
                      <label for="name">SMS Name</label>
                      <input type="text" class="form-control" name="smsName" id="smsName" value="<?php echo!empty($TSM_SMS_Name) ? $TSM_SMS_Name : ''; ?>">
                    </div>
                    <div class="form-group">
                      <label for="description">SMS Body</label>
                      <textarea class="form-control" name="smsBody" id="smsBody"><?php echo!empty($TSM_SMS_Body) ? $TSM_SMS_Body : ''; ?></textarea> 
                    </div>
                </div>
            </div>
          </div>
          <!-- /.box-body -->
          <div class="box-footer">
            <input type="hidden" name="hidSms" value="<?php echo e($smsId); ?>"/>
            <button type="button" class="btn btn-primary" onclick="validateForm();">Submit</button>
             <a href="<?php echo e(url('manage-sms-master')); ?>"><button type="button" class="btn btn-warning" >Cancel</button></a>
          </div>
        </form>
      </div>
      <!-- /.box -->
      
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('scripts'); ?> 
<script type="text/javascript">
   function validateForm(){
      if (!blankValidation("smsName","TextField", "SMS name can not be left blank"))
          return false;
      if (!blankValidation("smsBody","TextField", "SMS Body can not be left blank"))
        return false;
      $('#smsForm').submit();
   }  

</script>  
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opscautomation\resources\views/master/add-sms-template.blade.php ENDPATH**/ ?>