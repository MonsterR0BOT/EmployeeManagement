<?php $__env->startSection('title', 'DOCUMENT'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Add/Edit Document</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Add/Edit Document</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      
      <!-- Default box -->
      <div class="box">
        <form role="form" id="webForm" method="post" autocomplete="off" action="<?php echo e(url('document/saveDocument')); ?>">
          <?php echo e(csrf_field()); ?>

          <div class="box-body">
            <?php if(Session::has('errors')): ?>
                  <div class="col-md-12 alert alert-warning">
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php echo e($error); ?><br/>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
              <?php endif; ?>
            <div class="row">
                <div class="col-md-6">
                   <?php
                    if(!empty($data)){
                        $dataId = $data[0]->TDM_Doc;
                        $TDM_Doc_Name  = $data[0]->TDM_Doc_Name;
                        $TDM_Doc_Name_Odia = $data[0]->TDM_Doc_Name_Odia;
                        $TDM_Doc_Wing = $data[0]->TDM_Doc_Wing;
                        $TDM_Doc_Required = $data[0]->TDM_Doc_Required;
                        $TDM_Doc_Status = $data[0]->TDM_Doc_Status;
                    }else{
                       $dataId = '';
                       $TDM_Doc_Name  = '';
                       $TDM_Doc_Name_Odia = '';
                       $TDM_Doc_Wing ='';
                       $TDM_Doc_Required=1;
                       $TDM_Doc_Status =1;
                    }
                    ?>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Wing Name</label>
                      <select class="form-control" name="wingName" id="wingName">
                        <option value="">--Select--</option>
                        <?php $__currentLoopData = $wing_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($val->TWM_Wing); ?>" <?php if($TDM_Doc_Wing == $val->TWM_Wing): ?> selected="selected" <?php endif; ?> ><?php echo e($val->TWM_Wing_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                    <div class="form-group">
                      <label for="name">Document Name</label>
                      <input type="text" class="form-control" name="documentName" id="documentName" value="<?php echo!empty($TDM_Doc_Name) ? $TDM_Doc_Name : ''; ?>">
                    </div>
                    <div class="form-group">
                      <label for="name">Document Name Odia</label>
                      <input type="text" class="form-control" name="documentNameOdia" id="documentNameOdia" value="<?php echo!empty($TDM_Doc_Name_Odia) ? $TDM_Doc_Name_Odia : ''; ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputFile">Required</label>
                      <select class="form-control" name="documentRequired" id="documentRequired">
                        <option value="">--Select--</option>
                        <option value="1" <?php if($TDM_Doc_Required ==1): ?> selected="selected" <?php endif; ?>>Yes</option>
                        <option value="0" <?php if($TDM_Doc_Required ==0): ?> selected="selected" <?php endif; ?>>No</option>
                      </select>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputFile">Status</label>
                      <select class="form-control" name="documentStatus" id="documentStatus">
                        <option value="">--Select--</option>
                        <option value="1" <?php if($TDM_Doc_Status ==1): ?> selected="selected" <?php endif; ?>>Active</option>
                        <option value="0" <?php if($TDM_Doc_Status ==0): ?> selected="selected" <?php endif; ?>>Inactive</option>
                      </select>
                    </div>
                </div>
                <div class="col-md-6">
                  <div class="col-md-6">
                       <div class="form-group form-bg">
                          <label>Do you want to Write in Odia ? </label>
                       </div>
                    </div>
                    <div class="col-md-6">
                       <div class="form-group">
                          <div class="checkbox">
                             <input type="checkbox" id="checkboxId" onClick="javascript:checkboxClickHandler()">
                            <select id="languageDropDown" name="languageDropDown" onChange="javascript:languageChangeHandler()"></select>                                                   
                          </div> 
                       </div>
                    </div>
                </div>
            </div>
          </div>
          <!-- /.box-body -->
          <div class="box-footer">
            <input type="hidden" name="hidDataId" value="<?php echo e($dataId); ?>"/>
            <button type="button" class="btn btn-primary" onclick="validateForm();">Submit</button>
             <a href="<?php echo e(url('document/viewDocument')); ?>"><button type="button" class="btn btn-warning" >Cancel</button></a>
          </div>
        </form>
      </div>
      <!-- /.box -->
      
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('scripts'); ?> 
<script type="text/javascript">
   function validateForm(){
      if (!blankValidation("wingName","SelectBox", "Wing can not be left blank"))
          return false;
      if (!blankValidation("documentName","TextField", "Document name can not be left blank"))
          return false;
      if (!blankValidation("documentNameOdia","TextField", "Document name odia can not be left blank"))
        return false;
      $('#webForm').submit();
   }  

$(function () {
      $("#checkboxId").click();
    })
</script>
<script type="text/javascript" src="https://www.google.com/jsapi"></script>
  <script type="text/javascript">
    google.load("elements", "1", {
      packages: "transliteration"
    });

    var transliterationControl;
    function onLoad() {
      var options = {
        sourceLanguage: 'en',
        destinationLanguage: ['or'],
        transliterationEnabled: false,
        shortcutKey: 'ctrl+g'
      };
      // Create an instance on TransliterationControl with the required
      // options.
      transliterationControl =
      new google.elements.transliteration.TransliterationControl(options);

      // Enable transliteration in the textfields with the given ids.
      var ids = ["documentNameOdia"];
      transliterationControl.makeTransliteratable(ids);

      // Add the STATE_CHANGED event handler to correcly maintain the state
      // of the checkbox.
      transliterationControl.addEventListener(
      google.elements.transliteration.TransliterationControl.EventType.STATE_CHANGED,
      transliterateStateChangeHandler);

      // Add the SERVER_UNREACHABLE event handler to display an error message
      // if unable to reach the server.
      transliterationControl.addEventListener(
      google.elements.transliteration.TransliterationControl.EventType.SERVER_UNREACHABLE,
      serverUnreachableHandler);

      // Add the SERVER_REACHABLE event handler to remove the error message
      // once the server becomes reachable.
      transliterationControl.addEventListener(
      google.elements.transliteration.TransliterationControl.EventType.SERVER_REACHABLE,
      serverReachableHandler);

      // Set the checkbox to the correct state.
      document.getElementById('checkboxId').checked =
      transliterationControl.isTransliterationEnabled();

      // Populate the language dropdown
      var destinationLanguage =
      transliterationControl.getLanguagePair().destinationLanguage;
      var languageSelect = document.getElementById('languageDropDown');
      var supportedDestinationLanguages =
      google.elements.transliteration.getDestinationLanguages(
      google.elements.transliteration.LanguageCode.ENGLISH);
      for (var lang in supportedDestinationLanguages) {
        var opt = document.createElement('option');
        opt.text = lang;
        if (lang=="ORIYA" ){
          opt.value = supportedDestinationLanguages[lang];
          if (destinationLanguage == opt.value) {
            opt.selected = true;
          }
          try {
            languageSelect.add(opt, null);
          } catch (ex) {
            languageSelect.add(opt);
          }
        }//End of if
      }
    }
    function transliterateStateChangeHandler(e) {
      document.getElementById('checkboxId').checked = e.transliterationEnabled;
    }
    function checkboxClickHandler() {
      transliterationControl.toggleTransliteration();
    }
    function languageChangeHandler() {
      var dropdown = document.getElementById('languageDropDown');
      transliterationControl.setLanguagePair(
      google.elements.transliteration.LanguageCode.ENGLISH,
      dropdown.options[dropdown.selectedIndex].value);
    }

    function serverUnreachableHandler(e) {
      document.getElementById("errorDiv").innerHTML =
      "Transliteration Server unreachable";
    }
    function serverReachableHandler(e) {
      document.getElementById("errorDiv").innerHTML = "";
    }
    google.setOnLoadCallback(onLoad);
  </script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/master/add-document-master.blade.php ENDPATH**/ ?>