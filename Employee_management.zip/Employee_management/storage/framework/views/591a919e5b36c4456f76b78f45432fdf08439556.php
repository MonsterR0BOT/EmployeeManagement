<?php $__env->startSection('title', 'USER'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Add User</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">User</a></li>
        <li class="active">Add User</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
    	
      <!-- Default box -->
      <div class="box">
       <!-- <div class="box-header">
          <h3 class="box-title">Quick Example</h3>
        </div>-->
        <!-- /.box-header -->
        <!-- form start -->
        <form role="form" method="post" action="<?php echo e(url('post-add-user')); ?>"  onsubmit="return validateForm()" autocomplete="off">
        	<?php echo csrf_field(); ?>
          <div class="box-body">
            <div class="row">
                <div class="col-md-6">
                <?php //print "<pre>"; print_r($data);exit;?>
                	<?php
                    if(!empty($data)){
                    	$userId = $data[0]->TUM_User;
                        $TUM_User_Name = $data[0]->TUM_User_Name;
                        $TUM_User_Lname = $data[0]->TUM_User_Lname;
                        $TUM_User_Mobile = $data[0]->TUM_User_Mobile;
                        $TUM_User_Email = $data[0]->TUM_User_Email;
                        $TUM_User_Desig = $data[0]->TUM_User_Desig;
                        $TUM_User_Dept = $data[0]->TUM_User_Dept;
                        $TUM_User_Status = $data[0]->TUM_User_Status;
                        $TUM_User_Password = $data[0]->TUM_User_Password;
                        $TUM_User_AltEmail = $data[0]->TUM_User_AltEmail;
                        $TUM_User_AltMobile = $data[0]->TUM_User_AltMobile;
                        $TURA_UserRole = $data[0]->TURA_UserRole;
                        $roleArr = explode(",",$TURA_UserRole);
                        
                    }else{
                    	 $userId = '';
                        $TUM_User_Name = '';
                        $TUM_User_Lname = '';
                        $TUM_User_Mobile = '';
                        $TUM_User_Email = '';
                        $TUM_User_Desig = '';
                        $TUM_User_Dept = '';
                        $TUM_User_Status = 1;
                        $TUM_User_Password = '';
                        $TUM_User_AltEmail = '';
                        $TUM_User_AltMobile = '';
                        $TURA_UserRole = '';
                        $roleArr = array();
                    }
                    ?>
                    
                    <div class="form-group">
                      <label for="exampleInputEmail1">First Name</label>
                      <input type="text" class="form-control" name="userName" id="userName" value="<?php echo e($TUM_User_Name); ?>">
                    </div>
                     <div class="form-group">
                      <label for="exampleInputPassword1">Designation</label>
                      <select class="form-control" name="userDesignation" id="userDesignation" onchange="countryChange()">
                        <option value="">--Select--</option>
                        <?php $__currentLoopData = $designation_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($val->TDM_Desig); ?>" <?php if($TUM_User_Desig == $val->TDM_Desig): ?> selected="selected" <?php endif; ?> ><?php echo e($val->TDM_Desig_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Email</label>
                      <input type="text" class="form-control" name="userEmail" id="userEmail" value="<?php echo e($TUM_User_Email); ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Mobile Number</label>
                      <input  class="form-control" name="userMobile" id="userMobile" value="<?php echo e($TUM_User_Mobile); ?>" maxlength="10">
                    </div>
                    
                    <div class="form-group">
                      <label for="exampleInputFile">User Role</label>
                      <select class="form-control" name="userRoles[]" id="userRoles" multiple="multiple">
                        <?php $__currentLoopData = $user_role_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($val->TURM_UserRole); ?>" <?php if(in_array($val->TURM_UserRole, $roleArr)): ?> selected="selected" <?php endif; ?> ><?php echo e($val->TURM_URole_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Last Name</label>
                      <input type="text" class="form-control" name="userLastName" id="userLastName" value="<?php echo e($TUM_User_Lname); ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Department</label>
                      <select class="form-control" name="userDepartment" id="userDepartment">
                      	<option value="">--Select--</option>
                        <?php $__currentLoopData = $department_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($val->TDM_Dept); ?>" <?php if($TUM_User_Dept == $val->TDM_Dept): ?> selected="selected" <?php endif; ?> ><?php echo e($val->TDM_Dept_Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                    <?php if($userId==''): ?>
                    <div class="form-group">
                      <label for="exampleInputPassword1">User Password</label>
                      <input type="password" class="form-control" name="userPassword" id="userPassword">
                    </div>
                    <?php endif; ?>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Alt Mobile Number</label>
                      <input  class="form-control" name="userAltMobile" id="userAltMobile" value="<?php echo e($TUM_User_AltMobile); ?>" maxlength="10">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Alt Email</label>
                      <input  class="form-control" name="userAltEmail" id="userAltEmail" value="<?php echo e($TUM_User_AltEmail); ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Status</label>
                      <select class="form-control" name="userStatus" id="userStatus">
                      	<option value="">--Select--</option>
                        <option value="1" <?php if($TUM_User_Status ==1): ?> selected="selected" <?php endif; ?>>Active</option>
                        <option value="0" <?php if($TUM_User_Status ==0): ?> selected="selected" <?php endif; ?>>Inactive</option>
                      </select>
                    </div>
                </div>
                
            </div>
          </div>
          <!-- /.box-body -->
          <div class="box-footer">
          	<input type="hidden" name="hidUser" value="<?php echo e($userId); ?>"/>
            <button type="submit" class="btn btn-primary">Submit</button>
            <button type="button" class="btn btn-warning" onclick="window.location.href='manage-user'">Cancel</button>
          </div>
        </form>
      </div>
      <!-- /.box -->
      
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php $__env->startPush('scripts'); ?> 
	<script type="text/javascript">
		function validateForm(){
			if (!blankValidation("userName", "TextField","First Name is required"))
				return false;
			if (!checkSpecialCharacter("userName","Special character is not allowed!!!"))
				return false;
			if (!blankValidation("userLastName", "TextField","Last Name is required"))
				return false;
			if (!checkSpecialCharacter("userLastName","Special character is not allowed!!!"))
				return false;
			if (!blankValidation("userDesignation","SelectBox", "Please Select User Designation"))
				return false; 
      if (!blankValidation("userDepartment","SelectBox", "Please Select User Department"))
        return false; 
			if (!blankValidation("userEmail", "TextField","Email is required"))
        return false;
			if (!blankValidation("userPassword", "TextField","Password is required"))
				return false;	
      if (!blankValidation("userMobile", "TextField","Mobile is required"))
        return false;
			if (!blankValidation("userRoles","SelectBox", "Please Select User Role"))
				return false; 
			/* if (!checkSpecialCharacter("userEmail","Special character is not allowed!!!"))
				return false; */
			if (!blankValidation("userStatus","SelectBox", "Please Select Status"))
				return false;
		}
		
    </script>  
  <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-demo\resources\views/user/add-user.blade.php ENDPATH**/ ?>