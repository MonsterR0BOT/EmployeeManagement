<!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <?php 
      if(!Session::has("userRoles")){
        Session::put("userRoles",array());
      }
      // print "<pre>";
      // print_r(Session::get("userRoles"));
      // echo in_array('rol001', Session::get("userRoles"));
      // exit;
    ?>
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo e(asset(Helper::getUserPhoto())); ?>" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?php echo e(Helper::getUserType()); ?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
     
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
       <!--  <li>
          <a href="<?php echo e(url('dashboard')); ?>"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
        </li> -->
        <li class="treeview">
          <a href="#">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <?php if(in_array('rol003', Session::get("userRoles")) || in_array('rol001', Session::get("userRoles"))){ ?>
            <li><a href="<?php echo e(url('manage-dashboard-user')); ?>"><i class="fa fa-circle-o"></i>Dashboard User</a></li>
            <?php }?>
           <!--  <?php if(in_array('rol002', Session::get("userRoles")) || in_array('rol001', Session::get("userRoles"))){ ?>
            <li><a href="<?php echo e(url('manage-dashboard-hod')); ?>"><i class="fa fa-circle-o"></i>Dashboard HOD</a></li>
            <?php }?>
            <?php if(in_array('rol005', Session::get("userRoles")) || in_array('rol006', Session::get("userRoles")) || in_array('rol001', Session::get("userRoles")) ){ ?>
            <li><a href="<?php echo e(url('manage-dashboard-aso')); ?>"><i class="fa fa-circle-o"></i>Dashboard ASO</a></li> 
            <?php }?>
            <?php if(in_array('rol008', Session::get("userRoles")) || in_array('rol001', Session::get("userRoles"))){ ?>
            <li><a href="<?php echo e(url('manage-dashboard-so')); ?>"><i class="fa fa-circle-o"></i>Dashboard SO</a></li>
             <?php }?>
            <?php if(in_array('rol007', Session::get("userRoles")) || in_array('rol001', Session::get("userRoles"))){ ?>
            <li><a href="<?php echo e(url('manage-dashboard-deputy-scrtry')); ?>"><i class="fa fa-circle-o"></i>Dashboard Deputy Secretary</a></li>
             <?php }?>
            <?php if(in_array('rol004', Session::get("userRoles")) || in_array('rol001', Session::get("userRoles"))){ ?>
            <li><a href="<?php echo e(url('manage-dashboard-secretary')); ?>"><i class="fa fa-circle-o"></i>Dashboard Secretary</a></li>
            <?php }?>
            <?php if(in_array('rol009', Session::get("userRoles")) || in_array('rol001', Session::get("userRoles"))){ ?>
            <li><a href="<?php echo e(url('manage-dashboard-commissioner')); ?>"><i class="fa fa-circle-o"></i>Dashboard Commissioner</a></li>
          <?php }?> -->
          </ul>
        </li>
         <?php if(in_array('rol001', Session::get("userRoles")) ){ ?>
         <li class="treeview">
          <a href="#">
            <i class="fa fa-gear"></i> <span>Settings</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('email/viewEmail')); ?>"><i class="fa fa-circle-o"></i>Email Template</a></li>
            <li><a href="<?php echo e(url('email/viewSms')); ?>"><i class="fa fa-circle-o"></i>SMS Template</a></li>
            <li><a href="<?php echo e(url('email/viewPassPolicy')); ?>"><i class="fa fa-circle-o"></i>Password Policy</a></li>
            <li><a href="<?php echo e(url('email/viewUserSetting')); ?>"><i class="fa fa-circle-o"></i>User Settings</a></li>
            <li><a href="<?php echo e(url('master/setAuthorityAction')); ?>"><i class="fa fa-circle-o"></i>Work Flow</a></li>
            <li><a href="<?php echo e(url('master/setPageLabel')); ?>"><i class="fa fa-circle-o"></i>Page Labels</a></li>
            <li><a href="<?php echo e(url('pay/setPayLabel')); ?>"><i class="fa fa-circle-o"></i>Pay Labels</a></li>
            <li><a href="<?php echo e(url('pay/setMessageLabel')); ?>"><i class="fa fa-circle-o"></i>Message Labels</a></li>
            <li><a href="<?php echo e(url('work-flow-diagram')); ?>"><i class="fa fa-circle-o"></i>Work Flow Diagram</a></li>
            <li><a href="<?php echo e(url('user-hierarchy-diagram')); ?>"><i class="fa fa-circle-o"></i>Hierarchy Diagram</a></li>
          </ul>
        </li>

        <li class="treeview">
          <a href="#">
            <i class="fa fa-table"></i> <span>Master</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
<!--             <li><a href="<?php echo e(url('wing/viewWing')); ?>"><i class="fa fa-circle-o"></i>Manage Wing</a></li> -->
            <li><a href="<?php echo e(url('wing/viewStatus')); ?>"><i class="fa fa-circle-o"></i>Manage Status</a></li>
            <li><a href="<?php echo e(url('country/viewAllCountry')); ?>"><i class="fa fa-circle-o"></i>Manage Country</a></li>
            <li><a href="<?php echo e(url('state/viewAllState')); ?>"><i class="fa fa-circle-o"></i>Manage State</a></li>
            <li><a href="<?php echo e(url('district/viewAllDistrict')); ?>"><i class="fa fa-circle-o"></i>Manage District</a></li>
            <li><a href="<?php echo e(url('module/viewModule')); ?>"><i class="fa fa-circle-o"></i>Manage Module</a></li>
             <li><a href="<?php echo e(url('Religion/viewAllReligion')); ?>"><i class="fa fa-circle-o"></i>Manage Religion</a></li>
             <li><a href="<?php echo e(url('Caste/viewAllCaste')); ?>"><i class="fa fa-circle-o"></i>Manage Caste</a></li>
              <li><a href="<?php echo e(url('Qualification/viewAllQualification')); ?>"><i class="fa fa-circle-o"></i>Manage Qualification</a></li>
              <li><a href="<?php echo e(url('Occupation/viewAllOccupation')); ?>"><i class="fa fa-circle-o"></i>Manage Occupation</a></li>
              <li><a href="<?php echo e(url('Language/viewAllLanguage')); ?>"><i class="fa fa-circle-o"></i>Manage Language</a></li>
             <li><a href="<?php echo e(url('Subcaste/viewAllSubcaste')); ?>"><i class="fa fa-circle-o"></i>Manage Sub Caste</a></li>
            <li><a href="<?php echo e(url('designation/viewDesignation')); ?>"><i class="fa fa-circle-o"></i>Manage Designations</a></li>
          </ul>
        </li>

       <li class="treeview">
          <a href="#">
            <i class="fa fa-user"></i>
            <span>Member</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('manageuser/viewAllMemberList')); ?>"><i class="fa fa-circle-o"></i>Manage Member</a></li>
           <li><a href="<?php echo e(url('managecontact/viewAllCRList')); ?>"><i class="fa fa-circle-o"></i>Manage Contacts Request</a></li>
           <li><a href="<?php echo e(url('manageblog/viewBlog')); ?>"><i class="fa fa-circle-o"></i>Manage Blogs</a></li>
          </ul>
        </li>

        <li class="treeview">
          <a href="#">
            <i class="fa fa-user"></i>
            <span>Manage Matrimony</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('managematrimony/viewAllMatList')); ?>"><i class="fa fa-circle-o"></i>Manage Matrimony</a></li>
          </ul>
        </li>










        <li class="treeview">
          <a href="#">
            <i class="fa fa-table"></i>
            <span>Contents</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('content/viewContent')); ?>"><i class="fa fa-circle-o"></i>Manage AboutUs</a></li>
           <!--  <li><a href="<?php echo e(url('content/viewOrders')); ?>"><i class="fa fa-circle-o"></i>Manage Order & Notifications</a></li>
            <li><a href="<?php echo e(url('content/viewFaq')); ?>"><i class="fa fa-circle-o"></i> Manage Faq</a></li> -->
            <li><a href="<?php echo e(url('content/viewBanner')); ?>"><i class="fa fa-circle-o"></i> Manage Banner</a></li>
            <li><a href="<?php echo e(url('content/viewVideo')); ?>"><i class="fa fa-circle-o"></i> Manage Video</a></li>
            <li><a href="<?php echo e(url('content/viewGallery')); ?>"><i class="fa fa-circle-o"></i> Manage Gallery</a></li>
            <li><a href="<?php echo e(url('content/viewService')); ?>"><i class="fa fa-circle-o"></i> Manage Service</a></li>
            <li><a href="<?php echo e(url('content/viewEvent')); ?>"><i class="fa fa-circle-o"></i> Manage Event</a></li>
            <li><a href="<?php echo e(url('content/viewTermCondition')); ?>"><i class="fa fa-circle-o"></i> Manage Term&Condition</a></li>
             <li><a href="<?php echo e(url('content/viewNews')); ?>"><i class="fa fa-circle-o"></i> Manage News</a></li>
             <li><a href="<?php echo e(url('content/viewBlog')); ?>"><i class="fa fa-circle-o"></i> Manage Blog</a></li>
             <li><a href="<?php echo e(url('content/viewAllSocial')); ?>"><i class="fa fa-circle-o"></i> Manage Social Media</a></li>
             <li><a href="<?php echo e(url('content/viewAllCategory')); ?>"><i class="fa fa-circle-o"></i> Manage Category</a></li>
             <li><a href="<?php echo e(url('content/viewContactAddress')); ?>"><i class="fa fa-circle-o"></i> Manage Contact Address</a></li>
          </ul>
        </li>
        <?php } ?>
        <?php if(in_array('rol009', Session::get("userRoles")) || in_array('rol001', Session::get("userRoles"))){ ?>
       <!--  <li class="treeview">
          <a href="#">
            <i class="fa fa-table"></i>
            <span>Department</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('department/viewDepartment')); ?>"><i class="fa fa-circle-o"></i>Manage Departments</a></li> -->
           <!--  <li><a href="<?php echo e(url('manage-department-user')); ?>"><i class="fa fa-circle-o"></i>Manage Department Users</a></li> -->
         <!--  </ul>
        </li> -->
      <?php } ?>
      
      
      <?php if(in_array('rol002', Session::get("userRoles")) || in_array('rol003', Session::get("userRoles")) || in_array('rol001', Session::get("userRoles"))){ ?>
        <!-- <li class="treeview">
          <a href="#">
            <i class="fa fa-table"></i>
            <span>Department Requisition</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <?php if(in_array('rol003', Session::get("userRoles")) || in_array('rol001', Session::get("userRoles"))){ ?>
           <li><a href="<?php echo e(url('PromotionalRequest/viewPromotional')); ?>"><i class="fa fa-circle-o"></i>Manage Promotion Requests</a></li>
              <li><a href="<?php echo e(url('DisciplinaryRequest/viewDisciplinaryOthers')); ?>" ><i class="fa fa-circle-o"></i>Manage Disciplinary Requests</a></li>
              <li><a href="<?php echo e(url('relaxationRequest/viewRelaxationOthers')); ?>"><i class="fa fa-circle-o"></i>Manage Relaxation Requests</a></li>
            <li><a href="<?php echo e(url('department/viewPost')); ?>"><i class="fa fa-circle-o"></i>Manage Post</a></li>
            <li><a href="<?php echo e(url('department/viewRules')); ?>"><i class="fa fa-circle-o"></i>Manage Rules</a></li>
            <li><a href="<?php echo e(url('refrence/viewRefrenceNo')); ?>"><i class="fa fa-circle-o"></i>Manage Ref No.</a></li>
            <?php }?>
            <?php if(in_array('rol002', Session::get("userRoles")) || in_array('rol001', Session::get("userRoles"))){ ?>
            <li><a href="<?php echo e(url('PromotionalRequest/viewHodPromotion')); ?>"><i class="fa fa-circle-o"></i>HOD Promotion Requests </a></li>
             <li><a href="<?php echo e(url('DisciplinaryRequest/viewHodDisciplinary')); ?>"><i class="fa fa-circle-o"></i>HOD Disciplinary Requests</a></li>
             <li><a href="<?php echo e(url('relaxationRequest/viewHodRelaxation')); ?>"><i class="fa fa-circle-o"></i>HOD Relaxation Requests</a></li>
            <?php }?>
          </ul>
        </li> -->
    <!--      <li class="treeview">
          <a href="#">
            <i class="fa fa-table"></i>
            <span>Help & Notification</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
             <li class="<?php echo e((Request::segment(1)=='content/viewOrderNotification')?'active':''); ?>"><a href="<?php echo e(url('content/viewOrderNotification')); ?>"><i class="fa fa-circle-o"></i>Order & Notifications</a></li>
            <li class="<?php echo e((Request::segment(1)=='content/viewAllFaq')?'active':''); ?>"><a href="<?php echo e(url('content/viewAllFaq')); ?>"><i class="fa fa-circle-o"></i>FAQ</a></li>
          </ul>
        </li> -->
        <?php }?>
        <!-- Added by subharam for OPSC Approval  on 24Dec2019-->
        <?php if(!in_array('rol002', Session::get("userRoles")) && !in_array('rol003', Session::get("userRoles"))){ ?>
       <!--  <li class="treeview">
          <a href="#">
            <i class="fa fa-table"></i>
            <span>OPSC Promotional</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <?php if(in_array('rol008', Session::get("userRoles")) || in_array('rol001', Session::get("userRoles"))){ ?>
            <li><a href="<?php echo e(url('promotional/viewSOPromotinal')); ?>"><i class="fa fa-circle-o"></i>SO Promotion Requests </a></li> -->
          <?php }
             if(in_array('rol006', Session::get("userRoles")) || in_array('rol001', Session::get("userRoles"))){
           ?>
            <!-- <li><a href="<?php echo e(url('promotional/viewASOPromotinal')); ?>"><i class="fa fa-circle-o"></i>ASO Promotion Requests </a></li> -->
           <?php }
              if(in_array('rol005', Session::get("userRoles")) || in_array('rol001', Session::get("userRoles"))){
            ?> 
<!--             <li><a href="<?php echo e(url('promotional/viewJAPromotinal')); ?>"><i class="fa fa-circle-o"></i>JA Promotion Requests </a></li> -->
            <?php } 
              if(in_array('rol007', Session::get("userRoles")) || in_array('rol001', Session::get("userRoles"))){
            ?>
         <!--    <li><a href="<?php echo e(url('promotional/viewDSPromotinal')); ?>"><i class="fa fa-circle-o"></i>DS Promotion Requests </a></li> -->
          <?php }
            if(in_array('rol004', Session::get("userRoles")) || in_array('rol001', Session::get("userRoles"))){
           ?>
           <!--  <li><a href="<?php echo e(url('promotional/viewSecretaryPromotinal')); ?>"><i class="fa fa-circle-o"></i>Secy Promotion Requests </a></li> -->
          <?php }
              if(in_array('rol001', Session::get("userRoles")) || in_array('rol009', Session::get("userRoles")) || in_array('rol010', Session::get("userRoles")) ){
           ?>
            <!-- <li><a href="<?php echo e(url('promotional/viewcommissionerPromotinal')); ?>"><i class="fa fa-circle-o"></i>CM Promotion Requests </a></li> -->
            <?php } ?>
          <!-- </ul>
        </li> -->

        <!-- <li class="treeview">
          <a href="#">
            <i class="fa fa-table"></i>
            <span>OPSC Disciplinary</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <?php if(in_array('rol008', Session::get("userRoles")) || in_array('rol001', Session::get("userRoles"))){ ?>
            <li><a href="<?php echo e(url('diciplinary/viewSODiciplinary')); ?>"><i class="fa fa-circle-o"></i>SO Disciplinary Requests </a></li>
            <?php }
             if(in_array('rol006', Session::get("userRoles")) || in_array('rol001', Session::get("userRoles"))){
           ?>
            <li><a href="<?php echo e(url('diciplinary/viewASODiciplinary')); ?>"><i class="fa fa-circle-o"></i>ASO Disciplinary Requests </a></li>
          <?php }
              if(in_array('rol005', Session::get("userRoles")) || in_array('rol001', Session::get("userRoles"))){
            ?> 
            <li><a href="<?php echo e(url('diciplinary/viewJADiciplinary')); ?>"><i class="fa fa-circle-o"></i>JA Disciplinary Requests </a></li>
             <?php } 
              if(in_array('rol007', Session::get("userRoles")) || in_array('rol001', Session::get("userRoles"))){
            ?>
            <li><a href="<?php echo e(url('diciplinary/viewDSDiciplinary')); ?>"><i class="fa fa-circle-o"></i>DS Disciplinary Requests </a></li>
            <?php }
             if(in_array('rol004', Session::get("userRoles")) || in_array('rol001', Session::get("userRoles"))){
           ?>
            <li><a href="<?php echo e(url('diciplinary/viewSecretaryDiciplinary')); ?>"><i class="fa fa-circle-o"></i>Secy Disciplinary Requests </a></li>
            <?php }
               if(in_array('rol001', Session::get("userRoles")) || in_array('rol009', Session::get("userRoles")) || in_array('rol010', Session::get("userRoles")) ){
           ?>
            <li><a href="<?php echo e(url('diciplinary/viewCommissionerDiciplinary')); ?>"><i class="fa fa-circle-o"></i>CM Disciplinary Requests </a></li>
            <?php } ?>
          </ul>
        </li> -->

        <!-- <li class="treeview">
          <a href="#">
            <i class="fa fa-table"></i>
            <span>OPSC Relaxation</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
             <?php if(in_array('rol008', Session::get("userRoles")) || in_array('rol001', Session::get("userRoles"))){ ?>
            <li><a href="<?php echo e(url('relaxation/viewSORelaxation')); ?>"><i class="fa fa-circle-o"></i>SO Relaxation Requests </a></li>
             <?php }
             if(in_array('rol006', Session::get("userRoles")) || in_array('rol001', Session::get("userRoles"))){
           ?>
            <li><a href="<?php echo e(url('relaxation/viewASORelaxation')); ?>"><i class="fa fa-circle-o"></i>ASO Relaxation Requests </a></li>
             <?php }
              if(in_array('rol005', Session::get("userRoles")) || in_array('rol001', Session::get("userRoles"))){
            ?> 
            <li><a href="<?php echo e(url('relaxation/viewJARelaxation')); ?>"><i class="fa fa-circle-o"></i>JA Relaxation Requests </a></li>
              <?php } 
              if(in_array('rol007', Session::get("userRoles")) || in_array('rol001', Session::get("userRoles"))){
            ?>
            <li><a href="<?php echo e(url('relaxation/viewDSRelaxation')); ?>"><i class="fa fa-circle-o"></i>DS Relaxation Requests </a></li>
             <?php }
             if(in_array('rol004', Session::get("userRoles")) || in_array('rol001', Session::get("userRoles"))){
           ?>
            <li><a href="<?php echo e(url('relaxation/viewSecretaryRelaxation')); ?>"><i class="fa fa-circle-o"></i>Secy Relaxation Requests </a></li>
            <?php }
               if(in_array('rol001', Session::get("userRoles")) || in_array('rol009', Session::get("userRoles")) || in_array('rol010', Session::get("userRoles")) ){
           ?>
            <li><a href="<?php echo e(url('relaxation/viewCommissionerRelaxation')); ?>"><i class="fa fa-circle-o"></i>CM Relaxation Requests </a></li>
             <?php } ?>
          </ul>
        </li>
 -->
        <!-- End of OPSC Approval  on 24Dec2019 by subharam -->
        <?php if(!in_array('rol004', Session::get("userRoles")) && !in_array('rol005', Session::get("userRoles")) && !in_array('rol006', Session::get("userRoles")) && !in_array('rol007', Session::get("userRoles")) && !in_array('rol008', Session::get("userRoles")) && !in_array('rol004', Session::get("userRoles")) ){ ?>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-user"></i> <span>User</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('user/viewAllUserList')); ?>"><i class="fa fa-circle-o"></i>Manage User</a></li>
           <li><a href="<?php echo e(url('add-user')); ?>"><i class="fa fa-circle-o"></i>Add User</a></li>
             <li><a href="<?php echo e(url('manage-user-type')); ?>"><i class="fa fa-circle-o"></i>Manage User Type</a></li>
            <li><a href="<?php echo e(url('add-user-type')); ?>"><i class="fa fa-circle-o"></i>Add User Type</a></li>
            <li><a href="<?php echo e(url('UserRole/viewAllUserRole')); ?>"><i class="fa fa-circle-o"></i>Manage Role</a></li>
            <!-- <li><a href="<?php echo e(url('add-user-role')); ?>"><i class="fa fa-circle-o"></i>Add Role</a></li> -->
            <li><a href="<?php echo e(url('hierarchical/viewHierarchicalLevel')); ?>"><i class="fa fa-circle-o"></i>Hierarchy Level</a></li>
           <!--  <li><a href="<?php echo e(url('manage-user-role')); ?>"><i class="fa fa-circle-o"></i>Rolewise Previleges</a></li> -->
          </ul>
        </li>

         <!-- <li class="treeview">
          <a href="#">
            <i class="fa fa-pie-chart"></i>
            <span>MIS Reports</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
           <ul class="treeview-menu"> -->
           <!--  <li><a href="<?php echo e(url('charts')); ?>"><i class="fa fa-circle-o"></i>Charts</a></li> -->
              <!--  <li><a href="<?php echo e(url('manage-mis-chart-test')); ?>"><i class="fa fa-circle-o"></i>Promotional Drill Down Static</a></li> -->
              <!--  <li><a href="<?php echo e(url('PromotionalMIS/viewPromotionalDrillDown')); ?>"><i class="fa fa-circle-o"></i>Promotional Drill Down Chart</a></li>
               <li><a href="<?php echo e(url('DisciplinaryMIS/viewDisciplinaryDrillDown')); ?>"><i class="fa fa-circle-o"></i>Disciplinary Drill Down Chart</a></li>
               <li><a href="<?php echo e(url('RelaxationMIS/viewRelaxationDrillDown')); ?>"><i class="fa fa-circle-o"></i>Relaxation Drill Down Chart</a></li> -->
              <!--  <li><a href="<?php echo e(url('manage-mis-chart-promotion')); ?>"><i class="fa fa-circle-o"></i>Promotional Cases S Chart</a></li> -->
               <!-- <li><a href="<?php echo e(url('manage-mis-chart-promotion-download')); ?>"><i class="fa fa-circle-o"></i>Promotional Cases Download</a></li> -->
               <!--  <li><a href="<?php echo e(url('PromotionalMIS/viewPromotionalMISYearly')); ?>"><i class="fa fa-circle-o"></i>Promotional Cases Yearly Chart</a></li>
                 -->
               <!--  <li><a href="<?php echo e(url('manage-dept-mis-chart-promotion')); ?>"><i class="fa fa-circle-o"></i>Dept Wise Promotional Cases</a></li> -->
               
              <!--  <li><a href="<?php echo e(url('manage-mis-chart-discipline')); ?>"><i class="fa fa-circle-o"></i>Disciplinary Cases Chart</a></li> -->

              <!--  <li><a href="<?php echo e(url('PromotionalMIS/viewPromotionalMIS')); ?>" ><i class="fa fa-circle-o"></i>Dept Wise Promotion Cases</a></li>

               <li><a href="<?php echo e(url('DisciplinaryMIS/viewDisciplinaryMIS')); ?>" ><i class="fa fa-circle-o"></i>Dept Wise Disciplinary Cases</a></li> 

               <li><a href="<?php echo e(url('RelaxationMIS/viewRelaxationMIS')); ?>" ><i class="fa fa-circle-o"></i>Dept Wise Relaxation Cases</a></li>

               <li><a href="<?php echo e(url('DisciplinaryMIS/viewDisciplinaryWeeklyMIS')); ?>" ><i class="fa fa-circle-o"></i>Weekly Disciplinary Cases</a></li>

               <li><a href="<?php echo e(url('DisciplinaryMIS/viewDisciplinaryMonthlyMIS')); ?>" ><i class="fa fa-circle-o"></i>Monthly All Compare Cases</a></li> -->

              <!--  <li><a href="<?php echo e(url('manage-mis-chart-report')); ?>"><i class="fa fa-circle-o"></i>MIS Chart P/D</a></li>
               

              <li><a href="<?php echo e(url('manage-mis-chart-report')); ?>"><i class="fa fa-circle-o"></i>MIS Chart P/D</a></li> -->

              <!-- <li><a href="<?php echo e(url('manage-mis-annual-report')); ?>"><i class="fa fa-circle-o"></i>Annual Promotional Report Static</a></li>

              <li><a href="<?php echo e(url('PromotionalMIS/viewAnnualPromotionalMIS')); ?>"><i class="fa fa-circle-o"></i>Annual Promotional Report</a></li>

              <li><a href="<?php echo e(url('manage-mis-deptwise-report')); ?>"><i class="fa fa-circle-o"></i>Departent Wise Report</a></li>

              <li><a href="<?php echo e(url('manage-mis-dept-dispatch-report')); ?>"><i class="fa fa-circle-o"></i>Departent Dispatch Report</a></li>
             
              <li><a href="<?php echo e(url('manage-promoted-report')); ?>"><i class="fa fa-circle-o"></i>Promoted Officer Report</a></li>

              <li><a href="<?php echo e(url('manage-disciplinary-cases-report')); ?>"><i class="fa fa-circle-o"></i>Disciplinary Cases Report</a></li>

              <li><a href="<?php echo e(url('PromotionalMIS/viewPromotionalQueryMIS')); ?>"><i class="fa fa-circle-o"></i>Query Based Promotional</a></li>

              <li><a href="<?php echo e(url('DisciplinaryMIS/viewDisciplinaryQueryMIS')); ?>"><i class="fa fa-circle-o"></i>Query Based Disciplinary</a></li>

              <li><a href="<?php echo e(url('RelaxationMIS/viewRelaxationQueryMIS')); ?>"><i class="fa fa-circle-o"></i>Query Based Relaxation</a></li>

              <li><a href="<?php echo e(url('manage-event-wise-report')); ?>"><i class="fa fa-circle-o"></i>Event Wise Report</a></li>

          </ul> 
        </li> -->

        <!-- li class="treeview">
          <a href="#">
            <i class="fa fa-pie-chart"></i>
            <span>Audit Trail</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('manage-user-log')); ?>"><i class="fa fa-circle-o"></i>User Log</a></li>
             <li><a href="<?php echo e(url('manage-audit-report-promotion')); ?>"><i class="fa fa-circle-o"></i>Promotion Report</a></li>
              <li><a href="<?php echo e(url('manage-audit-report-discipline')); ?>"><i class="fa fa-circle-o"></i>Disciplinary Report</a></li>
               <li><a href="<?php echo e(url('manage-audit-chart-promotion')); ?>"><i class="fa fa-circle-o"></i>Promotional Chart</a></li>
              <li><a href="<?php echo e(url('manage-audit-chart-discipline')); ?>"><i class="fa fa-circle-o"></i>Disciplinary Chart</a></li>
            <!-- <li><a href="<?php echo e(url('charts')); ?>"><i class="fa fa-circle-o"></i>Charts</a></li> -->
          <!-- </ul>
        </li> --> 
        <?php } 
      }?>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-user"></i> <span>Profile</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('edit-profile')); ?>"><i class="fa fa-circle-o"></i>Edit Profile</a></li>
            <li><a href="<?php echo e(url('change-password')); ?>"><i class="fa fa-circle-o"></i>Change Password</a></li>
            <li><a href="<?php echo e(url('logout')); ?>"><i class="fa fa-circle-o"></i>Sign Out</a></li>
          </ul>
        </li>
        <!-- <li class="treeview">
          <a href="#">
            <i class="fa fa-folder"></i> <span>Examples</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('invoice')); ?>"><i class="fa fa-circle-o"></i> Invoice</a></li>
            <li><a href="<?php echo e(url('edit-profile')); ?>"><i class="fa fa-circle-o"></i> Profile</a></li>
            <li><a href="<?php echo e(url('error-404')); ?>"><i class="fa fa-circle-o"></i> 404 Error</a></li>
            <li><a href="<?php echo e(url('error-500')); ?>"><i class="fa fa-circle-o"></i> 500 Error</a></li>
            <li><a href="<?php echo e(url('general-page')); ?>"><i class="fa fa-circle-o"></i> Blank Page</a></li>
            
          </ul>
        </li> -->
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>
<?php /**PATH E:\xampp\htdocs\wethefamily\resources\views/layout/sidebar.blade.php ENDPATH**/ ?>