  
 <?php $__env->startSection('title', 'RELAXATION'); ?> 
 <?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
	<!-- Content Header (Page header) -->
	<section class="content-header">
		<h1>View Relaxation Request</h1>
		<ol class="breadcrumb">
			<li>
				<a href="#">
					<i class="fa fa-dashboard"></i> Home
				</a>
			</li>
			<li>
				<a href="#">Relaxation</a>
			</li>
			<li class="active">View Relaxation</li>
		</ol>
	</section>
	<!-- Main content -->
	<section class="content">
		
			<?php
			if(!empty($authorityData)){
		        $groupActionArr = $authorityData[0]->groupAction ? explode(',',$authorityData[0]->groupAction):array();

		        $TSA_ApprovalActionArr = $authorityData[0]->TSA_ApprovalAction?explode(',',$authorityData[0]->TSA_ApprovalAction):array();
		        $TSA_SetAuthority_StageNo = $authorityData[0]->TSA_SetAuthority_StageNo;
		    }else{
		    	 $groupActionArr = array();
		    	 $TSA_ApprovalActionArr =array();
		    	 $TSA_SetAuthority_StageNo ='';
			}
			
				$user_list=!empty($user_list)?$user_list:array();
			
	       	?>
		
		<input type="hidden1" name="hdRelaxationId" id="hdRelaxationId" value="<?php echo e($data[0]->TRR_RelaxationRequest); ?>">
		
		<input type="hidden" name="hdApprovalFromStatus" id="hdApprovalFromStatus" value="<?php echo e($data[0]->TRR_Approval_Status); ?>">
		<input type="hidden1" name="hdApprovalFromStage" id="hdApprovalFromStage" value="<?php echo e($data[0]->TRR_Approval_Stage); ?>">
		<div class="row">
			<div class="col-md-12">
				<div class="bs-example">
					<div class="accordion" id="accordionExample">
						<div class="box">
							<div class="card-header" id="headingOne">
								<a  data-toggle="collapse" data-target="#collapseOne" class="accordianheading">
									<div class="row">
										<div class="col-10 col-md-11 col-sm-10">
											<h5>Form of Reference</h5>
										</div>
										<div class="col-2 col-md-1 col-sm-2">
											<i class="fa fa-plus-circle faicon  acrdplus"></i>
										</div>
									</div>
								</a>
							</div>
							<div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
								<div class="card-body">
									<div class="box-body">
										<div class="formsec row">
											<div class="col-md-6 bg-color1">
												<div class="paddinglessmin">1.</div>
												<div class="paddingsmlmax">Name of the Department</div>
											</div>
											<div class="col-md-6">
												<div class="form-group">
													
													<label><?php echo e(isset($data[0]->TRR_Department)? $data[0]->TRR_Department:''); ?> </label>
													
												</div>
											</div>
										</div>
										<div class="formsecalt row">
											<div class="col-md-6 bg-color1">
												<div class="paddinglessmin">2.</div>
												<div class="paddingsmlmax">Name Designation of the promotional Post service</div>
											</div>
											<div class="col-md-6">
												<div class="row">
													<div class="col-md-6">
														<div class="form-group">
															<label><?php echo e(isset($data[0]->TRR_PromotionDesignation)?$data[0]->TRR_PromotionDesignation:''); ?></label>
														</div>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<label><?php echo e(isset($data[0]->TRR_PromotionPost)?$data[0]->TRR_PromotionPost:''); ?></label>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="clearfix"></div>
										<div class="formsec row">
											<div class="col-md-6 bg-color1">
												<div class="input-group">
													<div class="paddinglessmin">3.</div>
													<div class="paddinglessmax">Name Designation of the feeder post service for which relaxation of qualifying service</div>
												</div>
											</div>
											<div class="col-md-6">
												<div class="row">
													<div class="col-md-6">
														<div class="form-group">
															<label><?php echo e(isset($data[0]->TRR_FeederDesignation)?$data[0]->TRR_FeederDesignation:''); ?></label>
														</div>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<label><?php echo e(isset($data[0]->TRR_FeederPost)?$data[0]->TRR_FeederPost:''); ?></label>
														</div>
													</div>
												</div>
											</div>
											<!--<div class="clearfix"></div>-->
										</div>
										<div class="formsecalt row">
											<div class="col-md-12 bg-color1">
												<div class="col-md-1 paddinglgmin">4.</div>
												<div class="col-md-11 paddinglgmax">Name of the recruitment Rules with number & clause of the Rules for which relaxation is required.If no such Rules exist,mention the number and date of Resolution/Notification/Office Memorandum prescribing eligibility criteria.Copy of Rules G.O./Resolution/O.M/Notification to be appended.</div>
											</div>
											<div class="col-md-12 mrt_10">
												<div class="row">
													<div class="col-md-3">
														<div class="bg-color1">Name of the recruitment Rules</div>
														<div class="form-group"><?php echo e(isset($data[0]->TRR_Recuritment_Rule)?$data[0]->TRR_Recuritment_Rule:''); ?></div>
													</div>
													<div class="col-md-3">
														<div class="bg-color1">With number & clause of the Rules</div>
														<div class="form-group"><?php echo e(isset($data[0]->TRR_Recuritment_No)?$data[0]->TRR_Recuritment_No:''); ?></div>
													</div>
													<div class="col-md-3">
														<div class="bg-color1">Date of Resolution</div>
														<div class="form-group"><?php echo e(isset($data[0]->TRR_Resolution_Date)?date("d-m-Y", strtotime($data[0]->TRR_Resolution_Date)):''); ?></div>
													</div>
													<div class="col-md-3">
														<div class="bg-color1">Copy of Rules G.O./Resolution</div>
														<div class="form-group">
															<a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary">
																<i class="fa fa-file-pdf-o"></i> View File
															</a>
														</div>
													</div>
													<div class="clearfix"></div>
												</div>
											</div>
											<div class="clearfix"></div>
										</div>
										<div class="clearfix"></div>
										<div class="formsec row">
											<div class="col-md-6 bg-color1">
												<div class="input-group">
													<div class="paddinglessmin">5.</div>
													<div class=" paddinglessmax">Period of service prescribed in the recruitment Rules for promotion to the higher grade post.</div>
												</div>
											</div>
											<div class="col-md-6"><?php echo e(isset($data[0]->TRR_ServicPeriod_Prescribed)?$data[0]->TRR_ServicPeriod_Prescribed:''); ?> </div>
										</div>
										<div class="formsecalt row">
											<div class="col-md-6 bg-color1">
												<div class="paddinglessmin">6.</div>
												<div class=" paddinglessmax">Period of service already gained by the incumbents in the feeder post.</div>
											</div>
											<div class="col-md-6"><?php echo e(isset($data[0]->TRR_ServicPeriod_Gained)?$data[0]->TRR_ServicPeriod_Gained : ''); ?></div>
										</div>
										<div class="formsecalt row">
											<div class="col-md-6 bg-color1">
												<div class="paddinglessmin"> 7.</div>
												<div class=" paddinglessmax">(a)Period of service now proposed by Government for one time relaxation of qualifying service.(Such relaxation should not be more than 50% of the period of service prescribed in the Recruquitment Rules e.g.,
													<strong>If the prescribed period of qualifying service is 10 years,the proposed relaxation should not exceed 05 years</strong>)
												</div>
											</div>											  
											<div class="col-md-6">
												<div class="form-group">
													<label><?php echo e(isset($data[0]->TRR_ServicPeriod_Proposed)?$data[0]->TRR_ServicPeriod_Proposed:''); ?></label>
												</div>
											</div>
											<div class="col-md-6 bg-color1">
												<div class="txtindenting">(b)Whether the officers under consideration have gathered adequate experience & knowledge required to hold the promotional post after relaxation.</div>
											</div>
											<div class="col-md-3">
												<div class="row">
													<div class="col-md-6"><?php echo e(isset($data[0]->TRR_IsOfficerHold_Experience)?"Yes":"No"); ?></div>
												</div>
											</div>
											<div class="clearfix"></div>
										</div>
										<div class="formsec row">
											<div class="col-md-6 bg-color1">
												<div class="paddinglessmin">8.</div>
												<div class="paddinglessmax">Whether the officers under consideration have already availed relaxation of qualifying service for promotion to the feeder grade.</div>
											</div>
											<div class="col-md-3">
												<div class="row">
													<div class="col-md-6"><?php echo e(isset($data[0]->TRR_IsOfficerAvail_Relaxation)?"Yes":"No"); ?></div>
												</div>
											</div>
											<div class="clearfix"></div>
										</div>
										<div class="formsecalt row">
											<div class="col-md-12 bg-color1">
												<div class="paddinglessmin">9.</div>
												<div class=" paddinglessmax">Number of occasions already availed by Govt. for relaxation of qualifying service for promotion to the proposed higher grade during the last three years.(Copy of letters containing concurrence of the OPSC need to be furnished.)</div>
											</div>
											<div class="col-md-2">
												<label>No of occasions</label>
												<div class="form-group"><?php echo e(isset($data[0]->TRR_RelaxatnOccasion_No)?$data[0]->TRR_RelaxatnOccasion_No:''); ?></div>
											</div>
											<div class="col-md-2">							
												<label>Year</label>
												<div class="form-group"><?php echo e(isset($data[0]->TRR_RelaxtnOcasion_Year)?$data[0]->TRR_RelaxtnOcasion_Year:''); ?></div>
											</div>
											<div class="col-md-2">
												<label>Letter No.</label>
												<div class="form-group"><?php echo e(isset($data[0]->TRR_RelaxtnOcasion_LetterNo)?$data[0]->TRR_RelaxtnOcasion_LetterNo:''); ?></div>
											</div>
											<div class="col-md-3">
												<label>Date Of concurrence of the O.P.S.C</label>
												<div class="form-group"><?php echo e(($data[0]->TRR_RelaxtnConcurance_Date!='')?date("d-m-Y", strtotime($data[0]->TRR_RelaxtnConcurance_Date)):''); ?></div>
											</div>
											<div class="col-md-3">
												<label>Copy of Letters</label>
												<div class="form-group">
													<a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary">
														<i class="fa fa-file-pdf-o"></i> View File
													</a>
												</div>
											</div>
										</div>
										<div class="clearfix"></div>
										<div class="formsec row">
											<div class="col-md-6 bg-color1">
												<div class="input-group">
													<div class="paddinglessmin">10.</div>
													<div class="paddinglessmax">Whether orders of the Govt. have been taken for the proposed relaxation (Copy of Notification / order list sheet need to furnished)</div>
												</div>
											</div>
											<div class="col-md-3">
												<div class="row">
													<div class="col-md-6"><?php echo e(($data[0]->TRR_IsGovtOrder_Taken==1)?"Yes":"No"); ?></div>
												</div>
											</div>
											<div class="col-md-3">
												<div class="form-group">
													<a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary">
														<i class="fa fa-file-pdf-o"></i> View File
													</a>
												</div>
											</div>
										</div>
										<div class="clearfix"></div>
										<div class="formsecalt row">
											<div class="col-md-6 bg-color1">
												<div class="paddinglessmin">11.</div>
												<div class="paddinglessmax">Whether relaxation sought for the officer from the feeder grade belongs to the same category (Direct Recruitment Departmental Promotional in which vacancy is proposed to be filled up.)</div>
											</div>
											<div class="col-md-3">
												<div class="row">
													<div class="col-md-6"><?php echo e(isset($data[0]->TRR_IsFederGrade_SameCatgory)?"Yes":"No"); ?></div>
												</div>
											</div>
										</div>
										<div align="right" class="col-md-12">
											<a href="<?php echo e(url('view-relaxation-print')); ?>" target="_blank" class="btn btn-secondary" id="printbtn"><i class="fa fa-print"></i> Print</a>
											<button class="btn btn-danger"onclick="window.history.go(-1); return false;">Cancel</button>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="box">
							<div class="card-header" id="headingThree">
								<a  data-toggle="collapse" data-target="#collapseThree" class="accordianheading">
									<div class="row">
										<div class="col-10 col-md-11 col-sm-10">
											<h5>Document Check List</h5>
										</div>
										<div class="col-2 col-md-1 col-sm-2">
											<i class="fa fa-plus-circle faicon acrdplus"></i>
										</div>
									</div>
								</a>
							</div>
							<div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
								<div class="card-body">
									<div class="col-md-12">
										<div class="row">
											<?php $sl=1;
											  if(!empty($chk_doc_list)){
                              $arrColumns = array_column($chk_doc_list,'docType');
                              }
                               ?>
										<?php $__currentLoopData = $doc_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<div class="col-md-6">
												<div class="row listview">
													<div class="col-md-11"><?php echo e($sl.'. '); ?> <?php echo e($val->TDM_Doc_Name); ?></div>
													<div class="col-md-1 listicon">
                                                      <?php if(!empty($arrColumns)): ?><?php if(in_array($val->TDM_Doc,$arrColumns)): ?> <i class="fa fa-check text-success"></i> <?php endif; ?> <?php endif; ?>  
														

													</div>
												</div>
				
											</div><?php $sl+=1; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 	
										</div>
										
										
										
									</div>
									<div align="right" class="col-md-12 mrb_10">
										<button class="btn btn-danger"onclick="window.history.go(-1); return false;">Cancel</button>
									</div>
								</div>
								<!--  <div class="clearfix"></div> -->
								<div class="clearfix"></div>
							</div>
						</div>
						<div class="box">
							<div class="card-header" id="headingFour">
								<a data-toggle="collapse" data-target="#collapseFour" class="accordianheading">
									<div class="row">
										<div class="col-md-11">
											<h5>Officer Comments</h5>
										</div>
										<div class="col-md-1">
											<i class="fa fa-plus-circle faicon acrdplus"></i>
										</div>
									</div>
									<div class="clearfix"></div>
								</a>
							</div>
							<div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
								<div class="card-body">
									<div class="box-body">
										<div class="row">
											<div class="col-md-12">
												<!-- The timeline -->
												<ul class="timeline timeline-inverse">
												   <?php $__currentLoopData = $commentsArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date=>$comments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<?php
														$dateclass= ($date < date('Y-m-d h:i:s'))?'bg-red':'bg-green';
													?>
													<!-- timeline time label -->
													<li class="time-label">
														<span class="<?php echo e($dateclass); ?>"><?php echo e(date('d M Y', strtotime($date))); ?></span>
													</li>
													<!-- /.timeline-label -->
													<!-- timeline item -->
													<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<li>
														<i class="fa fa-comments bg-yellow"></i>
														<div class="timeline-item">
															<span class="time">
																<i class="fa fa-clock-o"></i> <?php echo e(date('d M Y h:i:s', strtotime($val->TRAH_Approval_CreatedOn))); ?>

															</span>
															<h3 class="timeline-header">
																<a href="#"><?php echo e($val->TUM_User_Name.' '); ?> <?php echo e($val->TUM_User_Lname); ?></a>, <?php echo e($val->TDM_Desig_Name); ?>, <?php echo e($val->TUM_User_Dept); ?>

															</h3>
															<div class="timeline-body"><?php echo e($val->TRAH_Approval_Comment); ?> </div>

														</div>
													</li>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													<!-- END timeline item -->
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													<li>
														<i class="fa fa-clock-o bg-gray"></i>
													</li>
												</ul>
												<div class="col-md-12 padding_10">
													<div align="right">
														<?php if($data[0]->TRR_Approval_Stage== $TSA_SetAuthority_StageNo): ?> 
														  <button class="btn btn-success" data-toggle="modal" data-target="#comments" data-backdrop="static" data-keyboard="false" id="btnGiveComments">Give your comments</button>
														  <?php endif; ?>
														 <a href="<?php echo e(url('view-relaxation-print')); ?>" target="_blank" class="btn btn-secondary" id="printbtn"><i class="fa fa-print"></i> Print</a>
														<!-- <a href="<?php echo e(url('relaxationRequest/viewRelaxationOthers')); ?>"> -->
															<button class="btn btn-danger"onclick="window.history.go(-1); return false;">Cancel</button>
													
													</div>
												</div>
												<div class="clearfix"></div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- /.box -->
					</div>
				</div>
			</div>
			<!-- /.col -->
		</div>
		<!-- /.box -->
	</section>
	<!-- /.content -->
</div>
<!-- /.content-wrapper -->
<div class="modal" id="myModal">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<!-- Modal Header -->
			<div class="modal-header">
				<h4 class="modal-title">Upload Files</h4>
				<!-- <button type="button" class="close" data-dismiss="modal">�</button> -->
			</div>
			<!-- Modal body -->
			<div class="modal-body">
				<div class="col-md-12">
					<div class="row">
						<?php $__currentLoopData = $uploadedDocumentData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-md-4 bg-color1"><?php echo e(isset($val->docText)? $val->docText:''); ?></div>
						<div class="col-md-2">
							<a href="<?php echo e(url('public/storage/relaxation_files')); ?>/<?php echo e(isset($val->docName)? $val->docName:''); ?>"  target="_blank">
								<i class="fa fa-file-pdf-o fa-2x text-danger"></i>
							</a>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>
			<!-- Modal footer -->
			<div class="modal-footer" align="center">
				<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>

<!--Modal Start-->
<div class="modal" id="comments">
  <div class="modal-dialog">
    <div class="modal-content">
      <!-- Modal Header -->
        <div class="modal-header">
        <h4 class="modal-title">Give your comments</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <!-- Modal body -->
      <div class="modal-body">
     <div class="col-md-12">
        <div class="modalstyleheader">
         <div class="row">
          <div class="col-md-7">
            <div class="row mrt_10">
            	<?php $__currentLoopData = $groupActionArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6">
                    <input type="radio" name="rdApprove" class="minimal" value="<?php echo e($TSA_ApprovalActionArr[$k]); ?>"> <?php echo e($val); ?>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- <div class="col-md-6">
                    <input type="radio" name="rdApprove" class="minimal" value="0"> Reassign
                </div> -->
            </div>
           </div>
           <div class="col-md-5" id='div_userList' style="display:none" >
             <select class="form-control" id="reassign">
                <option>--Select--</option>
                <?php $__currentLoopData = $user_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($val->TUM_User); ?>">
                <?php echo e($val->TUM_User_Name); ?> <?php echo e($val->TUM_User_Lname); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </select>
           </div>
       </div>
       </div>   
     
     <div class="row">
      <div class="col-md-12"><textarea name="txaComments" id="txaComments" class="form-control" rows="5" placeholder="Give your comments... "></textarea>
      </div>
    </div>
    </div>
      </div>
      <!-- Modal footer -->
      <div class="modal-footer" align="center">
         <button class="btn btn-primary" id="saveComment">Submit</button>
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!-- Modal End -->
<?php $__env->startPush('scripts'); ?>
<script>

$(document).ready(function(){
    $('input[name="rdApprove"]').click(function(){
        var inputValue = $(this).attr("value");
        if(inputValue=='app002'){
        	$("#div_userList").show();
        }else{
        	$("#div_userList").hide();
        }
        
    });
});


function validateForm(){
    //alert("alert");return false;
  if (!blankValidation("rdApprove","RadioButton", "Please select one option"))
      return false; 
  if (!blankValidation("txaComments","TextArea", "Comments can not be left blank"))
      return false;

  return true;
 }  
$("#saveComment").click(function(){
	 if(validateForm()){
	    var  data = {};
	    data['relaxationId']=$("#hdRelaxationId").val();
	    data['approvalFromStage']=$("#hdApprovalFromStage").val();
	    data['approvalFromStatus']=$("#hdApprovalFromStatus").val();
	    data['txaComments']=$("#txaComments").val();
	    data['rdApprove']=$("input[name='rdApprove']:checked").val();
	    data['reassign']=$("#reassign").val();
	    submitComment(data);
	}else
		return false;
});


function submitComment(data){
    console.log('submit as submitComment --',data);
     //return false;
    $.ajaxSetup({
	    headers: {
	    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
	    }
    });
    swal.fire({
	    title: "Do you want to submit?",
	    text: "",
	    type: "warning",
	    showCancelButton: true,
	    confirmButtonColor: '#d33',
	    cancelButtonColor: '#e7b63a',
	    confirmButtonText: 'Submit',
	    reverseButtons : true

    }).then((result) => {
	    if(result.value){
		    $.ajax({
			    type: "POST",
			    url:'<?php echo e(url("relaxationRequest/saveComment")); ?>',
			    dataType  : "json",
			    contentType : "application/json",
			    data    : JSON.stringify(data),
			    success   : function(response){
			      console.log("response ",response);
			      if(response.message=="success"){
			        swal({
			            title:"Data Saved Successfully.",
			            type: "success",
			        }).then(function(){
			          //window.location.href='manage-relaxation-request'; 
			           window.location.href='<?php echo e(url("relaxationRequest/viewHodRelaxation")); ?>';
			        })
			      }else{
			        swal({
			          title:response.code,
			          text: response.message,
			          type:"warning"
			        })
			      }
			    },
			    error : function(data) {
			    console.log(data); 
			    }
		    })
	    }

    });
    }

//old
    $(document).ready(function(){
        // Add minus icon for collapse element which is open by default
        $(".collapse.show").each(function(){
          $(this).prev(".card-header").find(".fa").addClass("fa-minus-circle").removeClass("fa-plus-circle");
        });
        
        // Toggle plus minus icon on show hide of collapse element
        $(".collapse").on('show.bs.collapse', function(){
          $(this).prev(".card-header").find(".fa").removeClass("fa-plus-circle").addClass("fa-minus-circle");
        }).on('hide.bs.collapse', function(){
          $(this).prev(".card-header").find(".fa").removeClass("fa-minus-circle").addClass("fa-plus-circle");
        });
    });
</script>
<?php $__env->stopPush(); ?> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/relaxation/view-relaxation.blade.php ENDPATH**/ ?>