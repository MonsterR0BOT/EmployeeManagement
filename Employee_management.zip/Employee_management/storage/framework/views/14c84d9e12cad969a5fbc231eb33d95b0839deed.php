<?php $__env->startSection('title', 'OPSC Hierarchical'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Work Flow
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">User</a></li>
        <li class="active">Work Flow</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box">
           <!-- <div class="box-header">
              <h3 class="box-title">Data Table With Full Features</h3>
            </div>-->
            <!-- /.box-header -->
            <div class="box-body">
              
              <!-- <a data-toggle="collapse" data-target="#demo"
                class="showhideangelbg"><i class="fa fa-angle-double-down"></i>
            </a>-->
              <!-- <textarea cols="80" rows="10" id="c2" style="display: none;">
              st=>start: Start:>https://www.google.com[blank]
              e=>end:>https://www.google.com
              op1=>operation: My Operation 1
              op2=>operation: My Operation 2|current
              op3=>operation: My Operation 3
              op4=>operation: My Operation 4
              cond=>condition: Y or N

              st->op1(right)->op2(right)->cond(yes)->op3->e
              cond(no)->op4->e

              </textarea> -->
              <textarea cols="80" rows="10" id="c2" style="display: none;">
              st=>start: Start
              e=>end
              op1=>operation: DEPT USER|current
              op2=>operation: DEPT HOD|approved

              op3=>operation: SECTION OFFICER|current
              op4=>operation: ASO/JA
              op5=>operation: DEPUTY SECCRETARY
              op6=>operation: SECRETARY
              op7=>operation: MEMBER
              op8=>operation: CHAIRMAN|approved

              io=>inputoutput: PROCESS/NOTIFY

              cond=>condition: Yes or No?|approved
              cond1=>condition: ASSIGN?
              cond2=>condition: Yes or No?|approved
              cond3=>condition: Yes or No?|rejected

              st->op1->op2->cond
              cond(no)->op1
              cond(yes)->op3->cond1
              cond1(yes)->op4(left)->op3
              cond1(no)->op5(right)->op6->op7->op8(right)->cond3
              cond3(no)->e
              cond3(yes)->cond2
              cond2(yes)->io(left)->op1
              cond2(no)->e

              </textarea>
              <input type="button" id="btn2" value="Convert" style="display: none;"></input>
             
              <div class="col-md-12">
              <hr>
              Process Flow Chart
              <div id="diagram2"></div>
              </div>

            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
      <!-- Modal Start-->
   
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('styles'); ?>
<!--Extra styles can written here -->
<?php $__env->stopPush(); ?>  
<?php $__env->startPush('scripts'); ?>
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.3.0/raphael.min.js"></script>
<script src="https://flowchart.js.org/flowchart-latest.js"></script> -->
<script src="<?php echo e(asset('js/raphael.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/flowchart-latest.js')); ?>"></script>
<script>
  $(document).ready(function() {
 
  $("#btn2").click(function(){
    $('#diagram2').text('');
    var diagram = flowchart.parse($('#c2').val());
    diagram.drawSVG('diagram2',
          // even flowstate support ;-)
          {'flowstate' : {
            'past' : { 'fill' : '#CCCCCC', 'font-size' : 12},
            'current' : {'fill' : 'yellow', 'font-color' : 'red', 'font-weight' : 'bold', 'element-color' : 'red'},
            'future' : { 'fill' : 'white'},
            'request' : { 'fill' : 'blue'},
            'invalid': {'fill' : '#444444'},
            'approved' : { 'fill' : '#58C4A3', 'font-size' : 12, 'yes-text' : 'APPROVED', 'no-text' : 'n/a' },
            'rejected' : { 'fill' : '#C45879', 'font-size' : 12, 'yes-text' : 'n/a', 'no-text' : 'REJECTED' }
          }});
  });

  //$("#btn1").trigger("click");
  $("#btn2").trigger("click");
  

});
</script>

<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/hierarchical/view-opsc-workflow.blade.php ENDPATH**/ ?>