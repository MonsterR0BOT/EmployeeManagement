<?php $__env->startSection('title', 'AQUATIC'); ?>
<?php $__env->startSection('content'); ?>
    <!--Page Title-->
    <section class="page-title" style="background-image:url('../public/images/innerbanner.jpg');">
    <div class="auto-container">
        <div class="inner-container clearfix">
            <div class="title-box">
                <h1>Product</h1>
            </div>
            <ul class="bread-crumb clearfix">
                <li><a href="<?php echo e(url('/')); ?>"><span class="fas fa-home"></span> Home</a></li>
                <li><span class="far fa-arrow-alt-circle-right"></span> Product</li>
            </ul>
        </div>
    </div>
    </section>
    <!--End Page Title-->
    <section class="product-section">
    <div class="auto-container">
        <div class="row">
            <!-- Image Column -->
           <div class="team-block col-lg-3 col-md-6 col-sm-12">
                <div class="inner-box">
                    <div class="image-box">
                        <div class="image"><a href="#"><img src="<?php echo e(asset('images/gallery/1.jpg')); ?>" alt="" class="img-thumbnail"></a></div>
                        
                    </div>
                    <div class="info-box">
                        <h4 class="name"><a href="team.html">Product Name</a></h4>
                        <span class="designation">Series</span>
                    </div>
                </div>
            </div>
    
             <div class="team-block col-lg-3 col-md-6 col-sm-12">
                <div class="inner-box">
                    <div class="image-box">
                        <div class="image"><a href="#"><img src="<?php echo e(asset('images/gallery/2.jpg')); ?>" alt="" class="img-thumbnail"></a></div>
                       
                    </div>
                    <div class="info-box">
                        <h4 class="name"><a href="team.html">Product Name</a></h4>
                        <span class="designation">Series</span>
                    </div>
                </div>
            </div>
    
             <div class="team-block col-lg-3 col-md-6 col-sm-12">
                <div class="inner-box">
                    <div class="image-box">
                        <div class="image"><a href="#"><img src="<?php echo e(asset('images/gallery/3.jpg')); ?>" alt="" class="img-thumbnail"></a></div>
                        
                    </div>
                    <div class="info-box">
                        <h4 class="name"><a href="team.html">Product Name</a></h4>
                        <span class="designation">Series</span>
                    </div>
                </div>
            </div>
    
             <div class="team-block col-lg-3 col-md-6 col-sm-12">
                <div class="inner-box">
                    <div class="image-box">
                        <div class="image"><a href="#"><img src="<?php echo e(asset('images/gallery/4.jpg')); ?>" alt="" class="img-thumbnail"></a></div>
                       
                    </div>
                    <div class="info-box">
                        <h4 class="name"><a href="team.html">Product Name</a></h4>
                        <span class="designation">Series</span>
                    </div>
                </div>
            </div>
    
             <div class="team-block col-lg-3 col-md-6 col-sm-12">
                <div class="inner-box">
                    <div class="image-box">
                        <div class="image"><a href="#"><img src="<?php echo e(asset('images/gallery/5.jpg')); ?>" alt="" class="img-thumbnail"></a></div>
                        
                    </div>
                    <div class="info-box">
                        <h4 class="name"><a href="team.html">Product Name</a></h4>
                        <span class="designation">Series</span>
                    </div>
                </div>
            </div>
            <div class="team-block col-lg-3 col-md-6 col-sm-12">
                <div class="inner-box">
                    <div class="image-box">
                        <div class="image"><a href="#"><img src="<?php echo e(asset('images/gallery/6.jpg')); ?>" alt="" class="img-thumbnail"></a></div>
                        
                    </div>
                    <div class="info-box">
                        <h4 class="name"><a href="team.html">Product Name</a></h4>
                        <span class="designation">Series</span>
                    </div>
                </div>
            </div>
            <div class="team-block col-lg-3 col-md-6 col-sm-12">
                <div class="inner-box">
                    <div class="image-box">
                        <div class="image"><a href="#"><img src="<?php echo e(asset('images/gallery/7.jpg')); ?>" alt="" class="img-thumbnail"></a></div>
                        
                    </div>
                    <div class="info-box">
                        <h4 class="name"><a href="team.html">Product Name</a></h4>
                        <span class="designation">Series</span>
                    </div>
                </div>
            </div>
            <div class="team-block col-lg-3 col-md-6 col-sm-12">
                <div class="inner-box">
                    <div class="image-box">
                        <div class="image"><a href="#"><img src="<?php echo e(asset('images/gallery/8.jpg')); ?>" alt="" class="img-thumbnail"></a></div>
                        
                    </div>
                    <div class="info-box">
                        <h4 class="name"><a href="team.html">Product Name</a></h4>
                        <span class="designation">Series</span>
                    </div>
                </div>
            </div>
            <div class="team-block col-lg-3 col-md-6 col-sm-12">
                <div class="inner-box">
                    <div class="image-box">
                        <div class="image"><a href="#"><img src="<?php echo e(asset('images/gallery/9.jpg')); ?>" alt="" class="img-thumbnail"></a></div>
                        
                    </div>
                    <div class="info-box">
                        <h4 class="name"><a href="team.html">Product Name</a></h4>
                        <span class="designation">Series</span>
                    </div>
                </div>
            </div>
            <div class="team-block col-lg-3 col-md-6 col-sm-12">
                <div class="inner-box">
                    <div class="image-box">
                        <div class="image"><a href="#"><img src="<?php echo e(asset('images/gallery/10.jpg')); ?>" alt="" class="img-thumbnail"></a></div>
                        
                    </div>
                    <div class="info-box">
                        <h4 class="name"><a href="team.html">Product Name</a></h4>
                        <span class="designation">Series</span>
                    </div>
                </div>
            </div>
    
            <div class="team-block col-lg-3 col-md-6 col-sm-12">
                <div class="inner-box">
                    <div class="image-box">
                        <div class="image"><a href="#"><img src="<?php echo e(asset('images/gallery/11.jpg')); ?>" alt="" class="img-thumbnail"></a></div>
                        
                    </div>
                    <div class="info-box">
                        <h4 class="name"><a href="team.html">Product Name</a></h4>
                        <span class="designation">Series</span>
                    </div>
                </div>
            </div>
            <div class="team-block col-lg-3 col-md-6 col-sm-12">
                <div class="inner-box">
                    <div class="image-box">
                        <div class="image"><a href="#"><img src="<?php echo e(asset('images/gallery/12.jpg')); ?>" alt="" class="img-thumbnail"></a></div>
                        
                    </div>
                    <div class="info-box">
                        <h4 class="name"><a href="team.html">Product Name</a></h4>
                        <span class="designation">Series</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
   </section>   

 <?php $__env->startPush('scripts'); ?>
 <!-- Write down javascript here -->
 <?php $__env->stopPush(); ?>   
<?php $__env->stopSection(); ?>   
<?php echo $__env->make('frontend-layout.frontend-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\aquatic\resources\views/product.blade.php ENDPATH**/ ?>