<?php $__env->startSection('title', 'AQUATIC'); ?>
<?php $__env->startSection('content'); ?>

<?php 
//print_r($banner_list);exit;
?>
    <!-- Bnner Section -->
    <?php echo $__env->make('frontend-layout.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Bnner Section -->

    <!-- About Section -->
    <?php echo $__env->make('frontend-layout.homeabout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--End About Section -->

    <!-- series Section -->
    <?php echo $__env->make('frontend-layout.series', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--End series Section -->

    <!--video Section One Section -->
    <?php echo $__env->make('frontend-layout.video', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--End video Section One Section -->

    <!--Product Section-->
    <?php echo $__env->make('frontend-layout.homeproduct', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--Product Section-->
   
    <!--testimonial Section -->
    <?php echo $__env->make('frontend-layout.testimonial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--End testimonial Section -->

    <!-- Team Section -->
    <?php echo $__env->make('frontend-layout.team', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--End Team Section -->

    <!-- Services Section -->
    <?php echo $__env->make('frontend-layout.service', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!--Skill Section -->
    <?php echo $__env->make('frontend-layout.skill', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--End testimonial Section -->

    <!-- certificates Section -->
    <?php echo $__env->make('frontend-layout.certificates', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--End certificates Section -->
 <?php $__env->startPush('scripts'); ?>
 <!-- Write down javascript here -->
 <?php $__env->stopPush(); ?>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend-layout.frontend-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\aquatic\resources\views/index.blade.php ENDPATH**/ ?>