    <title>WE THE FAMILY | <?php echo $__env->yieldContent('title'); ?></title>
    <meta charset="utf-8">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/animations.css')); ?>">
 <!--    <link rel="stylesheet" href="<?php echo e(asset('css/fonts.css')); ?>"> -->
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/css.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>" class="color-switcher-link"><!-- 
    <link rel="stylesheet" href="css/shop.css" class="color-switcher-link"> -->
   <!--  <script src="<?php echo e(asset('js/modernizr-2.6.2.min.js')); ?>"></script> -->
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
     <script src="//cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script><?php /**PATH E:\xampp\htdocs\wethefamily\resources\views/frontend-layout/metacss.blade.php ENDPATH**/ ?>