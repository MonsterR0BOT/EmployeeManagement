<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php echo $__env->yieldContent('title'); ?> || <?php echo e(Config::get('app.site_title')); ?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
    <!--<link rel="stylesheet" href="<?php echo e(asset('bower_components/bootstrap/dist/css/bootstrap.min.css')); ?>">-->
    <link rel="stylesheet" href="<?php echo e(asset('bower_components/bootstrap/dist/css/bootstrap.css')); ?>">
  <!-- Bootstrap 3.3.7 -->
 <!--  <link rel="stylesheet" href="<?php echo e(asset('bower_components/bootstrap/dist/css/bootstrap.css')); ?>"> -->
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(asset('bower_components/font-awesome/css/font-awesome.min.css')); ?>">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo e(asset('bower_components/Ionicons/css/ionicons.min.css')); ?>">
  <!-- bootstrap datepicker -->
  <link rel="stylesheet" href="<?php echo e(asset('bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>">
  <!-- DataTables -->
 <link rel="stylesheet" href="<?php echo e(asset('bower_components/datatables.net-bs/css/dataTables.bootstrap4.min.css')); ?>">
  <!-- Theme style -->
 <link rel="stylesheet" href="<?php echo e(asset('dist/css/AdminLTE.min.css')); ?>">
 <!-- iCheck for checkboxes and radio inputs -->
  <link rel="stylesheet" href="<?php echo e(asset('plugins/iCheck/all.css')); ?>">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <!--<link rel="stylesheet" href="<?php echo e(asset('dist/css/skins/skin-purple-light.min.css')); ?>">-->
  <link rel="stylesheet" href="<?php echo e(asset('dist/css/skins/_all-skins.min.css')); ?>">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <!-- <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic"> -->
  <!-- sweet alert css -->
  <link rel="stylesheet" href="<?php echo e(asset('css/sweetalert2.min.css')); ?>">
        
  <?php echo $__env->yieldPushContent('styles'); ?>  
  <style type="text/css">
  select.scroll-x{
    height: auto;
    overflow:scroll;
  }
  </style>    
</head>
<body class="hold-transition skin-purple-light sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    <!-- Logo -->
  
    <a href="<?php echo e(url('/')); ?>" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
        <div class="logo-header">
        <img src="<?php echo e(asset('images/logo_admin.png')); ?>" class="img-fluid"/>
      </div>
    <span class="logo-mini"><b>WE THE FAMILY</b></span> 
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>WE</b> THE FAMILY</span>
    </a>
<!-- include navigation bar here -->
	<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </header>
  	<!-- include sidebar here -->
  	<?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
   	<?php echo $__env->yieldContent('content'); ?>
    
	<!-- include footer here -->
	<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>
<!-- ./wrapper -->
<!--div id="maskid" ng-hide="hidemask" ng-init="hidemask=true;"-->
  <div id="maskid" style="display:none">
      <div id="spinner"><i class="fa fa-refresh fa-spin fa-3x"></i></div>
  </div>
  <!--End of loading image on 28thJune2017 -->
  
<!-- Download JS -->
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.4/jspdf.min.js"></script> -->
<!-- jQuery 3 -->
<script src="<?php echo e(asset('bower_components/jquery/jquery.min.js')); ?>"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo e(asset('bower_components/bootstrap/dist/js/bootstrap.js')); ?>"></script>
<!-- FastClick -->
<script src="<?php echo e(asset('bower_components/fastclick/lib/fastclick.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('dist/js/adminlte.min.js')); ?>"></script>
<!-- Sparkline -->
<!-- <script src="<?php echo e(asset('bower_components/jquery-sparkline/dist/jquery.sparkline.min.js')); ?>"></script> -->
<!-- bootstrap datepicker -->
<script src="<?php echo e(asset('bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
<!-- SlimScroll -->
<script src="<?php echo e(asset('bower_components/jquery-slimscroll/jquery.slimscroll.min.js')); ?>"></script>
<!-- ChartJS -->
<!-- <script src="<?php echo e(asset('bower_components/chart.js/Chart.js')); ?>"></script> -->
<script src="<?php echo e(asset('bower_components/chart.js/Chart-New.js')); ?>"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<!-- <script src="<?php echo e(asset('dist/js/pages/dashboard2.js')); ?>"></script> -->
<!-- CK Editor -->
<script src="<?php echo e(asset('bower_components/ckeditor/ckeditor.js')); ?>"></script>
<!-- DataTables -->
<script src="<?php echo e(asset('bower_components/datatables.net-bs/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('bower_components/datatables.net-bs/js/dataTables.bootstrap4.min.js')); ?>"></script>

<!-- AdminLTE for demo purposes -->
<script src="<?php echo e(asset('dist/js/demo.js')); ?>"></script>
<!-- iCheck 1.0.1 -->
<script src="<?php echo e(asset('plugins/iCheck/icheck.min.js')); ?>"></script>
<!-- sweet alert js -->
<script src="<?php echo e(asset('js/sweetalert2.all.min.js')); ?>"></script>
<!-- validator js -->
<script src="<?php echo e(asset('js/validate.js')); ?>"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
<script>
   $(function () {
       //Date picker
    $('.datepicker').datepicker({
      format:'dd-mm-yyyy',
      autoclose: true
    })
   });
   /* $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
      checkboxClass: 'icheckbox_minimal-blue',
      radioClass   : 'iradio_minimal-blue'
    })*/
    //function for session store
    function setLanguageSession(lid){
      
       $.ajax({
          type: "GET",
          url:"set-language?lid="+lid,
          success: function(response) {
          console.log(response);
          //return false;
              if(response.message == "success") {
                location.reload();
              }else {
                location.reload(); 
              }
          },
          error: function(data) {
            location.reload();
          }
      })

   }   
    
</script>
<script>
// Add the following code if you want the name of the file appear on select
$(".custom-file-input").on("change", function() {
  var fileName = $(this).val().split("\\").pop();
  $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
});
</script>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\wethefamily\resources\views/layout/master.blade.php ENDPATH**/ ?>