   
    <div class="box box-success" id="expanded3">
	<div class="box-header with-border">
		<h3 class="box-title">Expanded  Promotional Category Chart</h3>

		<div class="box-tools pull-right">
		   	<button type="button" id="back1" style="text-align: right;" class="btn btn-primary"  onClick="showPostWiseChart('<?php echo $deptId ?>',<?php echo e($financialYear); ?>,<?php echo e($levelValue); ?>)">Return Back</button>     
		</div>
	</div>
	<div class="box-body">
		<div class="chart">
			<canvas id="chartareaExp3" style="height:350px"></canvas>
		</div>
	</div>
<!-- /.box-body     -->
</div> 
             
<script>
		var config3 = {
			type: 'bar',
			data: { 

			      labels: [<?php echo $categoryNames ?>],///financialYear
			    
			      datasets: [
			        {
			          label: [<?php echo $financialYear ?>],
			          backgroundColor: ['rgba(97,50,105,0.9)', 'rgba(247,122,26,0.9)','rgba(174,189,26,0.9)','rgba(209,21,71,0.9)','rgba(97,50,105,0.9)','rgba(97,50,105,0.9)', 'rgba(247,122,26,0.9)','rgba(174,189,26,0.9)','rgba(209,21,71,0.9)',],
			          data: [<?php echo $countCategories ?>]
			         
			        }
			      ]
			    },
			options: {
				responsive: true,
				title: {
					display: false,
					text: 'MIS Yearly Promotional Cases'
				},
				tooltips: {
					mode: 'index',
					intersect: false,
				},
				hover: {
					mode: 'nearest',
					"animationDuration": 0,
					intersect: true
				},

				"animation": {
	        	    "duration": 1,
					"onComplete": function () {
						var chartInstance = this.chart,
							ctx = chartInstance.ctx;
						
						ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
						ctx.textAlign = 'center';
						ctx.textBaseline = 'bottom';

						this.data.datasets.forEach(function (dataset, i) {
							var meta = chartInstance.controller.getDatasetMeta(i);
							meta.data.forEach(function (bar, index) {
								var data = dataset.data[index];                            
								ctx.fillText(data, bar._model.x, bar._model.y - 5);
							});
						});
					}
                },
				scales: {
					xAxes: [{
						display: true,
						scaleLabel: {
							display: true,
							labelString: 'Yearly'
						}
					}], 
					 yAxes: [{
				            ticks: {
				                beginAtZero: true
				            }
				        }]
				}
			}
		};

	$(function () {
		 

			var ctx3 = document.getElementById('chartareaExp3').getContext('2d');
			window.myLine = new Chart(ctx3, config3);

			 
	}); 


</script><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/mis/ajax-mis-cat-afterpost-promotion.blade.php ENDPATH**/ ?>