  <?php $__env->startSection('title', 'POMOTION'); ?> <?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>View Promotion Request</h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Department Requisition</a></li>
            <li class="active">View Promotion</li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="bs-example">
                    <div class="accordion" id="accordionExample">
                    <div class="box">
                            <div class="card-header" id="headingOne">
                                <a data-toggle="collapse" data-target="#collapseOne" class="accordianheading">
                                    <div class="row">
                                        <div class="col-md-11">
                                            <h5>OPSC Information</h5>
                                        </div>
                                        <div class="col-md-1"><i class="fa fa-plus-circle faicon acrdplus"></i></div>
                                    </div>
                                </a>
                            </div>
                            <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                                <div class="card-body">
                                    <div class="box-body">
                                        <div class="formsecalt row">
                                            <div class="col-md-3 bg-color1">
                                                <div class="paddingsmlmin">1.</div>
                                                <div class="paddingsmlmax">Name(s) of the Department</div>
                                            </div>
                                            <div class="col-md-3">Agriculture & F.E Department
                                            </div>
                                            <div class="col-md-3 bg-color1">
                                                <div class="paddingsmlmin">2.</div>
                                                <div class="paddingsmlmax">Name of the posts to be filled up</div>
                                            </div>
                                            <div class="col-md-3">
                                                Assistant Executive Engineer
                                            </div>
                                            <div class="clearfix"></div>
                                        </div>
                                        <div class="formsec row">
                                            <div class="col-md-6 bg-color1">
                                                <div class="paddinglessmin">3.</div>
                                                <div class="paddinglessmax">Group to which promotional posts to ('A' Or 'B')with Scale of Pay &amp; G.P</div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label>Group A </label>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label>Lorem Ipsum has been </label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="formsecalt row">
                                            <div class="col-md-6 bg-color1">
                                                <div class="paddinglessmin">4.</div>
                                                <div class="paddinglessmax">Whether the previous proposal for such promotion has been finalised on recommendation of the O.P.S.C. If So</div>
                                            </div>
                                            <div class="col-md-2">Yes </div>
                                            <div class="col-md-4">
                                                <div align="left"> <span class="bg-color1">Ref. No. &amp; Date of D.P.C/S.B.</span> <span>11555AGHH</span> &amp; <span>12/9/2019</span> </div>
                                            </div>
                                        </div>
                                        <div class="formsecalt row">
                                            <div class="col-md-3 bg-color1">Ref. No. &amp; Date of reference to O.P.S.C.</div>
                                            <div class="col-md-3"><span>12234EWRSG</span> &amp; <span>15/05/2015</span></div>
                                            <div class="col-md-3 bg-color1">Ref. No. &amp; Date of recommendation of O.P.S.C.</div>
                                            <div class="col-md-3"><span>123DSAA</span> &amp; <span>12/05/2010</span></div>
                                        </div>
                                        <div class="formsec row">
                                            <div class="col-md-6 bg-color1">
                                                <div class="paddinglessmin">5.</div>
                                                <div class="paddinglessmax">Date of D.P.C/S.B. in respect of the present proposal (Attested copy of the proceeding of the DPC/SB to be furnished)</div>
                                            </div>
                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <label>14/02/2015</label>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group"> <a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> View File</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="formsecalt row">
                                            <div class="col-md-6 bg-color1">
                                                <div class="paddinglessmin">6.</div>
                                                <div class="paddinglessmax">Total no of sanctioned posts at the level of promotion grade</div>
                                            </div>
                                            <div class="col-md-6">58</div>
                                        </div>
                                        <div class="formsec row">
                                            <div class="col-md-6 bg-color1">
                                                <div class="paddinglessmin">7.</div>
                                                <div class="paddinglessmax">a) Number of vacancies for which the DPC/S.B. met (Category wise)</div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-3"><span><strong>SC</strong></span> : <span>6</span></div>
                                                    <div class="col-md-3"><span><strong>ST</strong></span> : <span>5</span></div>
                                                    <div class="col-md-3"><span><strong>UR</strong></span> : <span>4</span></div>
                                                    <div class="col-md-3"><span><strong>TOTAL</strong></span> : <span>15</span></div>
                                                </div>
                                            </div>
                                            <div class="clearfix"></div>
                                            <div class="col-md-6 bg-color1">
                                                <div class="txtindenting"> b) Number of vacancies now proposed to be filled up(Category-wise)</div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-3">
                                                        <div class="form-group"> <span><strong>SC</strong></span> : <span>7</span> </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="form-group"> <span><strong>ST</strong></span> : <span>5</span> </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="form-group"> <span><strong>UR</strong></span> : <span>2</span> </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="form-group"> <span><strong>TOTAL</strong></span> : <span>14</span> </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="clearfix"></div>
                                            <div class="col-md-6 bg-color1">
                                                <div class="txtindenting"> c) Number of vacancies set apart & unfilled for subsequent consideration due to non-availability CCRs of Senior Officers in the zone of consideration.</div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-3"> <span><strong>SC</strong></span> : <span>7</span> </div>
                                                    <div class="col-md-3"> <span><strong>ST</strong></span> : <span>5</span> </div>
                                                    <div class="col-md-3"> <span><strong>UR</strong></span> : <span>3</span> </div>
                                                    <div class="col-md-3"> <span><strong>TOTAL</strong></span> : <span>15</span> </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="formsecalt row">
                                            <div class="col-md-6 bg-color1">
                                                <div class="paddinglessmin">8.</div>
                                                <div class="paddinglessmax">Designation of feeder posts/grades from which officers are eligible for promotion</div>
                                            </div>
                                            <div class="col-md-6">Executive Engineer</div>
                                        </div>
                                        <div class="formsec row">
                                            <div class="col-md-6 bg-color1">
                                                <div class="paddinglessmin">9.</div>
                                                <div class="paddinglessmax">Name of the recruitment Rules regulatig the promotion proposed. If no such Rules exist. mention the number and date of Resolution/ Notification/ Office Memorandum proceeding eligibility criteria. (Copy of Rules with upto date ammendments/G.O./ Resolution/ OM/ Notification to be appended)</div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-3">Engineer</div>
                                                    <div class="col-md-3">AA12233</div>
                                                    <div class="col-md-3">12/02/2019</div>
                                                </div>
                                                <div class="row">
                                                 <div class="col-md-6"><a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> View Files</a></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="formsecalt row">
                                            <div class="col-md-6 bg-color1">
                                                <div class="paddinglessmin">10.</div>
                                                <div class="paddinglessmax">(a) Number of eligible officers in the zone of consideration as per relevant Rules</div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-3"><span><strong>SC</strong></span> : <span>3</span></div>
                                                    <div class="col-md-3"><span><strong>ST</strong></span> : <span>4</span></div>
                                                    <div class="col-md-3"><span><strong>UR</strong></span> : <span>7</span></div>
                                                    <div class="col-md-3"><span><strong>TOTAL</strong></span> : <span>8</span></div>
                                                </div>
                                            </div>
                                            <div class="clearfix"></div>
                                            <div class="col-md-6 bg-color1">
                                                <div class="txtindenting">(b) Number of officers found suitable for promotion</div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-3"><span><strong>SC</strong></span> : <span>2</span></div>
                                                    <div class="col-md-3"><span><strong>ST</strong></span> : <span>4</span></div>
                                                    <div class="col-md-3"><span><strong>UR</strong></span> : <span>5</span></div>
                                                    <div class="col-md-3"><span><strong>TOTAL</strong></span> : <span>11</span></div>
                                                </div>
                                            </div>
                                            <div class="clearfix"></div>
                                            <div class="col-md-6 bg-color1">
                                                <div class="txtindenting">(c) Number of officers in the zone of consideration</div>
                                                <div class="txtindentingone">i) Against whom Disciplinary Proceedings/Vigilance Cases/Criminal Case pending. (Copy of the report on Vigilance Case/Criminal Case/Disciplinary Proceedings to be enclosed)</div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-3"><span><strong>SC</strong></span> : <span>2</span></div>
                                                    <div class="col-md-3"><span><strong>ST</strong></span> : <span>3</span></div>
                                                    <div class="col-md-3"><span><strong>UR</strong></span> : <span>5</span></div>
                                                    <div class="col-md-3"><span><strong>TOTAL</strong></span> : <span>5</span></div>
                                                </div>
                                            </div>
                                            <div class="formsecalt row">
                                                <div class="col-md-6 bg-color1">
                                                    <div class="txtindentingone">ii) Not considered due to want of CCRs/PARs.</div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="row">
                                                        <div class="col-md-3"><span><strong>SC</strong></span> : <span>3</span></div>
                                                        <div class="col-md-3"><span><strong>ST</strong></span> : <span>4</span></div>
                                                        <div class="col-md-3"><span><strong>UR</strong></span> : <span>5</span></div>
                                                        <div class="col-md-3"><span><strong>TOTAL</strong></span> : <span>7</span></div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 bg-color1">
                                                    <div class="txtindentingone">iii) Not selected due to adverse remarks.</div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="row">
                                                        <div class="col-md-3"><span><strong>SC</strong></span> : <span>5</span></div>
                                                        <div class="col-md-3"><span><strong>ST</strong></span> : <span>2</span></div>
                                                        <div class="col-md-3"><span><strong>UR</strong></span> : <span>1</span></div>
                                                        <div class="col-md-3"><span><strong>TOTAL</strong></span> : <span>10</span></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- <div class="col-md-6">(Copy of the report on Vigilance Case/Criminal Case/Disciplinary Proceedings to be enclosed).</div>
                                            <div class="col-md-6"><a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> View pdf Files</a></div> -->
                                        </div>
                                        <div class="formsec row">
                                            <div class="col-md-6 bg-color1">
                                                <div class="paddinglessmin">11.</div>
                                                <div class="paddinglessmax">No. Of Officers after recommendation of DPC/SB given ad hoc promotion</div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-3"><span><strong>SC</strong></span> : <span>3</span></div>
                                                    <div class="col-md-3"><span><strong>ST</strong></span> : <span>5</span></div>
                                                    <div class="col-md-3"><span><strong>UR</strong></span> : <span>7</span></div>
                                                    <div class="col-md-3"><span><strong>TOTAL</strong></span> : <span>10</span></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="formsecalt row">
                                            <div class="col-md-6 bg-color1">
                                                <div class="paddinglessmin">12.</div>
                                                <div class="paddinglessmax">i) Whether 5 years CCRs dossiers of all officers recommended for promotion up to the junior-most officer nominated are enclosed.</div>
                                            </div>
                                            <div class="col-md-6">Yes</div>
                                            <div class="col-md-6 bg-color1">
                                                <div class="txtindenting">ii) Period of CCRs perused by the D.P.C/S.B.</div>
                                            </div>
                                            <div class="col-md-3">Yes</div>
                                            <div class="col-md-3"></div>
                                        </div>
                                        <div class="formsec row">
                                            <div class="col-md-6 bg-color1">
                                                <div class="paddinglessmin">13.</div>
                                                <div class="paddinglessmax">Whether all the officers under consideration are regular in the feeder grade on recommendation of the O.P.S.C.,where required?<br /> (Copy of the recommendation letter of the O.P.S.C. to be furnished)</div>
                                            </div>
                                            <div class="col-md-3"><span> Yes</span></div>
                                            <div class="col-md-3"><a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> View Files</a></div>
                                        </div>
                                        <div class="formsecalt row">
                                            <div class="col-md-6 bg-color1">
                                                <div class="form-group">
                                                    <div class="paddinglessmin">14.</div>
                                                    <div class="paddinglessmax">Whether the D.P.C/S.B. has used /perused the following documents (attested copies to be enclosed):-</div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">Yes</div>
                                            <div class="col-md-6 bg-color1">
                                                <div class="txtindenting"> i) Authenticated (duly signed) copy of the Final Gradation List as on the Date D.P.C/SB containing Date of Birth,Date of appointment to the feeder grade and other service particulars of the officers under consideration</div>
                                            </div>
                                            <div class="col-md-6"><a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> View Files</a></div>
                                            <div class="col-md-6 bg-color1">
                                                <div class="txtindenting">(ii)Statement (duly signed) showing assessment of CCRs of the officers under consideration</div>
                                            </div>
                                            <div class="col-md-3">Yes </div>
                                        </div>
                                        <div class="formsec row">
                                            <div class="col-md-6 bg-color1">
                                                <div class="col-md-1 paddinglessmin">15.</div>
                                                <div class="col-md-11 paddinglessmax">Whether reference made expected to reach Commission within 60 days of date of DPC/SB meeting.If not,reason thereof..</div>
                                                <div class="clearfix"></div>
                                            </div>
                                            <div class="col-md-6">Yes <br/>Lorem iplusm</div>
                                            <div class="clearfix"></div>
                                        </div>
                                        <div class="formsecalt row">
                                            <div class="col-md-6 bg-color1">
                                                <div class="col-md-1 paddinglessmin">16.</div>
                                                <div class="col-md-11 paddinglessmax">Form of reference duly filled and ink-signed is enclosed.</div>
                                            </div>
                                            <div class="col-md-6">Yes</div>
                                        </div>
                                        <div align="right">
                              <div class="mrt_10 mrb_10">
                                <a href="<?php echo e(url('promotional/viewcommissionerPromotinal')); ?>"><button class="btn btn-danger">Cancel</button></a>
                              </div>
                            </div>
                            <div class="clearfix"></div>
                                    </div>
                                    
                                </div>
                            </div>
                    </div>
                    <div class="box">
                        <div class="card-header" id="headingTwo">
                            <a data-toggle="collapse" data-target="#collapseTwo" class="accordianheading">
                                <div class="row">
                                    <div class="col-md-11">
                                        <h5>Details of Eligible  Officer</h5>
                                    </div>
                                    <div class="col-md-1"><i class="fa fa-plus-circle faicon acrdplus"></i></div>
                                </div>
                                <div class="clearfix"></div>
                            </a>
                        </div>
                        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                            <div class="box-body">
                                <div class="row">
                                    <div align="right" class="col-md-12">
                                        <div id="officer_fields"></div>
                                          <div id="officer" class="col-md-12">
                                            <div class="box box-primary officersec">
                                                <div class="box-header">
                                                    <h3 class="box-title">First Officer Details</h3>
                                                    <div class="box-tools pull-right">
                                                        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                                                    </div>
                                                </div>
                                                <!-- /.box-header -->
                                                <div class="box-body">
                                                <div class="col-md-12">
                                                    <div class="row">
                                                        <div class="col-md-3 bg-color1">Name of the eligible officers in the zone of</div>
                                                        <div class="col-md-3">Amaresh Prasad</div>
                                                        <div class="col-md-3 bg-color1">Type of promotion (Regular/Retrospective)</div>
                                                        <div class="col-md-3"> Regular</div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-3 bg-color1"> Caste(SC/ST/General)</div>
                                                        <div class="col-md-3">SC</div>
                                                        <div class="col-md-3 bg-color1"> Name of the post to be filled up</div>
                                                        <div class="col-md-3"> Assistant Section Officer </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-3 bg-color1">Group of the promotional post</div>
                                                        <div class="col-md-3"> Section Officer</div>
                                                        <div class="col-md-3 bg-color1">Scale of Pay</div>
                                                        <div class="col-md-3 form-group">5,200-200</div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-3 bg-color1">Mention the back Period of Availability</div>
                                                        <div class="col-md-3">10 months</div>
                                                        <div class="col-md-3 bg-color1">Designation as per the feeder post/grade</div>
                                                        <div class="col-md-3">Section Officer</div>
                                                    </div>
                                                    <div class="row">   
                                                        <div class="col-md-3 bg-color1">Is the officer regular on feeder grade</div>
                                                        <div class="col-md-3">yes</div>
                                                        <div class="col-md-3  bg-color1">Is the officer selected for promotion as per the recruitment rule.</div>
                                                        <div class="col-md-3">Yes</div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-3 bg-color1">Is there any criminal case/disciplinary proceedings/vigilance case is pending</div>
                                                        <div class="col-md-3">Yes</div>
                                                        <div class="col-md-3  bg-color1">Availability of CCRs & PARs</div>
                                                        <div class="col-md-3">Yes</div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-3 bg-color1">Period of Availability of CCRs & PARs</div>
                                                        <div class="col-md-3">Related Small Description Text and content</div>
                                                        <div class="col-md-3 bg-color1"> Is the officer given adhoc promotion DPC/SB </div>
                                                        <div class="col-md-3">yes </div>
                                                    </div>
                                                    <div class="row">   
                                                        <div class="col-md-3  bg-color1">Period of CCRs perused by DPC/SB</div>
                                                        <div class="col-md-3">10 months</div>
                                                        
                                                    </div>
                                                    <div class="row">
                                                            <div class="formsubhd">CCR</div>
                                                            <div class="col-md-12">
                                                                <div class="row">
                                                                    <div class="col-md-3 bg-color1">Year 2012-2013</div>
                                                                    <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a>
                                                                    <label><input type="checkbox" class="minimal" checked="checked"></label></div>
                                                                    <div class="col-md-3 bg-color1"> Year 2013-2014</div>
                                                                    <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a>
                                                                    <label><input type="checkbox" class="minimal" checked="checked"></label></div>
                                                                    <div class="col-md-3 bg-color1">Year 2014-2015</div>
                                                                    <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a>
                                                                    <label><input type="checkbox" class="minimal" checked="checked"></label></div>
                                                                    <div class="col-md-3 bg-color1">Year 2015-2016</div>
                                                                    <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a>
                                                                    <label><input type="checkbox" class="minimal" checked="checked"></label></div>
                                                                    <div class="col-md-3 bg-color1">Year 2016-2017</div>
                                                                    <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a>
                                                                    <label><input type="checkbox" class="minimal" checked="checked"></label></div>
                                                                    <div class="col-md-3 bg-color1">Year 2017-2018</div>
                                                                    <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a>
                                                                    <label><input type="checkbox" class="minimal" checked="checked"></label></div>
                                                                    <div class="col-md-3 bg-color1">Year 2018-2019</div>
                                                                    <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a>
                                                                    <label><input type="checkbox" class="minimal" checked="checked"></label></div>
                                                                   
                                                                </div>
                                                            </div>
                                                    </div>
                                                        
                                                    <div class="row">
                                                        <div class="formsubhd">Vigilance/Criminal/Disciplinary Proceedings </div>
                                                        <div class="col-md-12">
                                                            <div class="row">
                                                                <div class="col-md-3 bg-color1">Vigilance</div>
                                                                <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a>
                                                                <label><input type="checkbox" class="minimal" checked="checked"></label></div>
                                                                <div class="col-md-3 bg-color1"> Criminal</div>
                                                                <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a>
                                                                <label><input type="checkbox" class="minimal" checked="checked"></label></div>
                                                                <div class="col-md-3 bg-color1">Vigilance</div>
                                                                <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a>
                                                                <label><input type="checkbox" class="minimal" checked="checked"></label></div>
                                                                <div class="col-md-3 bg-color1">Disciplinary proceedings</div>
                                                                <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a>
                                                                <label><input type="checkbox" class="minimal" checked="checked"></label></div>
                                                                <div class="col-md-3 bg-color1">Vigilance</div>
                                                                <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a>
                                                                <label><input type="checkbox" class="minimal" checked="checked"></label></div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-12"><input type="checkbox" class="minimal" checked="checked"><span class="text-primary"><b>&nbsp;Is the officer selected for promotion</b></span></div>
                                                    </div>
                                                        <div class="clearfix"></div>
                                                        </div>
                                                       
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                    <div align="right" class="col-md-12">
                                          <div id="officer" class="col-md-12">
                                            <div class="box box-primary officersec">
                                                <div class="box-header">
                                                    <h3 class="box-title">Second Officer Details</h3>
                                                    <div class="box-tools pull-right">
                                                        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                                                    </div>
                                                </div>
                                                <!-- /.box-header -->
                                                <div class="box-body">
                                                <div class="col-md-12">
                                                    <div class="row">
                                                        <div class="col-md-3 bg-color1">Name of the eligible officers in the zone of</div>
                                                        <div class="col-md-3">Amaresh Prasad</div>
                                                        <div class="col-md-3 bg-color1">Type of promotion (Regular/Retrospective)</div>
                                                        <div class="col-md-3"> Regular</div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-3 bg-color1"> Caste(SC/ST/General)</div>
                                                        <div class="col-md-3">SC</div>
                                                        <div class="col-md-3 bg-color1"> Name of the post to be filled up</div>
                                                        <div class="col-md-3"> Assistant Section Officer </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-3 bg-color1">Group of the promotional post</div>
                                                        <div class="col-md-3"> Section Officer</div>
                                                        <div class="col-md-3 bg-color1">Scale of Pay</div>
                                                        <div class="col-md-3 form-group">5,200-200</div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-3 bg-color1">Mention the back Period of Availability</div>
                                                        <div class="col-md-3">10 months</div>
                                                        <div class="col-md-3 bg-color1">Designation as per the feeder post/grade</div>
                                                        <div class="col-md-3">Section Officer</div>
                                                    </div>
                                                    <div class="row">   
                                                        <div class="col-md-3 bg-color1">Is the officer regular on feeder grade</div>
                                                        <div class="col-md-3">yes</div>
                                                        <div class="col-md-3  bg-color1">Is the officer selected for promotion as per the recruitment rule.</div>
                                                        <div class="col-md-3">Yes</div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-3 bg-color1">Is there any criminal case/disciplinary proceedings/vigilance case is pending</div>
                                                        <div class="col-md-3">Yes</div>
                                                        <div class="col-md-3  bg-color1">Availability of CCRs & PARs</div>
                                                        <div class="col-md-3">Yes</div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-3 bg-color1">Period of Availability of CCRs & PARs</div>
                                                        <div class="col-md-3">Related Small Description Text and content</div>
                                                        <div class="col-md-3 bg-color1"> Is the officer given adhoc promotion DPC/SB </div>
                                                        <div class="col-md-3">yes </div>
                                                    </div>
                                                    <div class="row">   
                                                    <div class="col-md-3  bg-color1"> Period of CCRs perused by DPC/SB</div>
                                                    <div class="col-md-3">10 months</div>
                                                   
                                                    </div>
                                                    
                                                   <div class="row">
                                                            <div class="formsubhd">CCR</div>
                                                            <div class="col-md-12">
                                                                <div class="row">
                                                                    <div class="col-md-3 bg-color1">Year 2012-2013</div>
                                                                    <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a>
                                                                    <label><input type="checkbox" class="minimal" checked="checked"></label></div>
                                                                    <div class="col-md-3 bg-color1"> Year 2013-2014</div>
                                                                    <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a>
                                                                    <label><input type="checkbox" class="minimal" checked="checked"></label></div>
                                                                    <div class="col-md-3 bg-color1">Year 2014-2015</div>
                                                                    <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a>
                                                                    <label><input type="checkbox" class="minimal" checked="checked"></label></div>
                                                                    <div class="col-md-3 bg-color1">Year 2015-2016</div>
                                                                    <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a>
                                                                    <label><input type="checkbox" class="minimal" checked="checked"></label></div>
                                                                    <div class="col-md-3 bg-color1">Year 2016-2017</div>
                                                                    <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a>
                                                                    <label><input type="checkbox" class="minimal" checked="checked"></label></div>
                                                                    <div class="col-md-3 bg-color1">Year 2017-2018</div>
                                                                    <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a>
                                                                    <label><input type="checkbox" class="minimal" checked="checked"></label></div>
                                                                    <div class="col-md-3 bg-color1">Year 2018-2019</div>
                                                                    <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a>
                                                                    <label><input type="checkbox" class="minimal" checked="checked"></label></div>
                                                                   
                                                                </div>
                                                            </div>
                                                    </div>
                                                        
                                                    <div class="row">
                                                        <div class="formsubhd">Vigilance/Criminal/Disciplinary Proceedings </div>
                                                        <div class="col-md-12">
                                                            <div class="row">
                                                                <div class="col-md-3 bg-color1">Vigilance</div>
                                                                <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a>
                                                                <label><input type="checkbox" class="minimal" checked="checked"></label></div>
                                                                <div class="col-md-3 bg-color1"> Criminal</div>
                                                                <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a>
                                                                <label><input type="checkbox" class="minimal" checked="checked"></label></div>
                                                                <div class="col-md-3 bg-color1">Vigilance</div>
                                                                <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a>
                                                                <label><input type="checkbox" class="minimal" checked="checked"></label></div>
                                                                <div class="col-md-3 bg-color1">Disciplinary proceedings</div>
                                                                <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a>
                                                                <label><input type="checkbox" class="minimal" checked="checked"></label></div>
                                                                <div class="col-md-3 bg-color1">Vigilance</div>
                                                                <div class="col-md-3"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a>
                                                                <label><input type="checkbox" class="minimal" checked="checked"></label></div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-12"><input type="checkbox" class="minimal" checked="checked"><span class="text-primary"><b>&nbsp;Is the officer selected for promotion</b></span></div>
                                                    </div>
                                                    </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div align="right">
                                      <div class="mrt_10 mrb_10">
                                        <a href="<?php echo e(url('promotional/viewcommissionerPromotinal')); ?>"><button class="btn btn-danger">Cancel</button></a>
                                      </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                    </div>
                    <div class="box">
                        <div class="card-header" id="headingThree">
                            <a data-toggle="collapse" data-target="#collapseThree" class="accordianheading">
                                <div class="row">
                                    <div class="col-md-11">
                                        <h5>Document Checklist</h5>
                                    </div>
                                    <div class="col-md-1"><i class="fa fa-plus-circle faicon acrdplus"></i></div>
                                </div>
                            </a>
                        </div>
                        <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                          <div class="box-body">
                            <div class="card-body">
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="row listview">
                                            <div class="col-md-11">1. Recruitment Rule</div>
                                            <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="row listview">
                                            <div class="col-md-11">2. Govt Resolution/Order/Notification/Office Memorandum</div>
                                            <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="row listview">
                                            <div class="col-md-11">3. Previous DPC/SB proposal</div>
                                            <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="row listview">
                                            <div class="col-md-11">4. Previous concurrence of OPSC</div>
                                            <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="row listview">
                                            <div class="col-md-11">5. Proceedings of criminal /vigilance/court cases</div>
                                            <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="row listview">
                                            <div class="col-md-11">6. CCRs/PARs of the employee</div>
                                            <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="row listview">
                                            <div class="col-md-11">7. Present proceedings of DPC/SB</div>
                                            <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="row listview">
                                            <div class="col-md-11">8. Recommendation letter of OPSC related to feeder grade regularization</div>
                                            <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="row listview">
                                            <div class="col-md-11">9. Signed copy of final gradation list</div>
                                            <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="row listview">
                                            <div class="col-md-11">10. Duly signed copy of assessment of CCR statement</div>
                                            <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                                        </div>
                                    </div>
                                    
                                </div>
                              </div>
                            </div>
                             <div align="right">
                              <div class="mrt_10 mrb_10">
                                <a href="<?php echo e(url('promotional/viewcommissionerPromotinal')); ?>"><button class="btn btn-danger">Cancel</button></a>
                              </div>
                            </div>
                            <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                   
                    <div class="box">
                        <div class="card-header" id="headingFour">
                            <a data-toggle="collapse" data-target="#collapseFour" class="accordianheading">
                                <div class="row">
                                    <div class="col-md-11">
                                        <h5>Officer Comments</h5>
                                    </div>
                                    <div class="col-md-1"><i class="fa fa-plus-circle faicon acrdplus"></i></div>
                                </div>
                                <div class="clearfix"></div>
                            </a>
                        </div>
                        <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
                            <div class="card-body">
                                <div class="box-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <!-- The timeline -->
                                            <ul class="timeline timeline-inverse">
                                                <!-- timeline time label -->
                                                <li class="time-label"> <span class="bg-red">10 Dec. 2019</span>
                                                </li>
                                                <!-- /.timeline-label -->
                                                <!-- timeline item -->
                                                <li>
                                                    <i class="fa fa-user bg-blue"></i>
                                                    <div class="timeline-item"><span class="time"><i class="fa fa-clock-o"></i> 10 Dec. 2019 12:05:20</span>
                                                        <h3 class="timeline-header"><a href="#">Prasanna Behera</a>, Office Asst, Agriculture & F.E Department</h3>
                                                        <div class="timeline-body"> I certify that all information/documents given above have been checked by me and found to be correct and all copies of relevant documents, as mentioned above, have benn enclosed.</div>
                                                        <!-- <div class="timeline-footer">     <a class="btn btn-primary btn-xs">Read more</a>     <a class="btn btn-danger btn-xs">Delete</a>   </div> -->
                                                    </div>
                                                </li>
                                                <!-- END timeline item -->
                                                <!-- timeline item -->
                                                <li>
                                                    <i class="fa fa-comments bg-yellow"></i>
                                                    <div class="timeline-item"><span class="time"><i class="fa fa-clock-o"></i> 10 Dec. 2019 15:20:35</span>
                                                        <h3 class="timeline-header"><a href="#">Prakash Nayak</a>, HOD Dept, Agriculture & F.E Department</h3>
                                                        <div class="timeline-body"> The promotional request is verified and found ok and send to OPSC for further verification. </div>
                                                    </div>
                                                </li>
                                                <!-- END timeline item -->
                                                <!-- timeline item -->
                                                <li>
                                                    <i class="fa fa-comments bg-yellow"></i>
                                                    <div class="timeline-item"><span class="time"><i class="fa fa-clock-o"></i> 10 Dec. 2019 10:27:00</span>
                                                        <h3 class="timeline-header"><a href="#">Golak Roy</a>, SO, OPSC</h3>
                                                        <div class="timeline-body"> Checked the proposal and assigned to ASO for further verification </div>
                                                        <!-- <div class="timeline-footer">     <a class="btn btn-warning btn-flat btn-xs">View comment</a>   </div> -->
                                                    </div>
                                                </li>
                                                <!-- END timeline item -->
                                                <!-- timeline time label -->
                                                <li class="time-label"> <span class="bg-green">12 Dec. 2019</span>
                                                </li>
                                                <!-- /.timeline-label -->
                                                <!-- timeline item -->
                                                <li>
                                                    <i class="fa fa-comments bg-yellow"></i>
                                                    <div class="timeline-item"><span class="time"><i class="fa fa-clock-o"></i> 12 Dec. 2019 9:27:35</span>
                                                        <h3 class="timeline-header"><a href="#">Yudhistir Nayak</a>, Dy. Secretary, OPSC</h3>
                                                        <div class="timeline-body"> Checked the proposal and assigned to ASO for further verification </div>
                                                        <!-- <div class="timeline-footer">     <a class="btn btn-warning btn-flat btn-xs">View comment</a>   </div> -->
                                                    </div>
                                                </li>
                                                <!-- END timeline item -->
                                                <!-- timeline item -->
                                                <li>
                                                    <i class="fa fa-comments bg-yellow"></i>
                                                    <div class="timeline-item"><span class="time"><i class="fa fa-clock-o"></i> 12 Dec. 2019 11:30:45</span>
                                                        <h3 class="timeline-header"><a href="#">Subodha Nayak</a>, Secretary, OPSC</h3>
                                                        <div class="timeline-body"> Checked the proposal and assigned to ASO for further verification </div>
                                                        <!-- <div class="timeline-footer">     <a class="btn btn-warning btn-flat btn-xs">View comment</a>   </div> -->
                                                    </div>
                                                </li>
                                                <!-- END timeline item -->
                                                <li> <i class="fa fa-clock-o bg-gray"></i></li>
                                         </ul>
                                          <div align="right" class="mrt_10 mrb_10">
                                            <button class="btn btn-info" data-toggle="modal" data-target="#shortlistofficer" data-backdrop="static" data-keyboard="false">View shortlist officers</button>
                                            <button class="btn btn-success" data-toggle="modal" data-target="#comments" data-backdrop="static" data-keyboard="false">Give your comments</button>
                                            <a href="<?php echo e(url('promotional/viewcommissionerPromotinal')); ?>"><button class="btn btn-danger">Cancel</button></a>
                                            <div class="clearfix"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                     </div>
                    </div>

                </div>
                <!-- /.box -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<!-- The Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <!-- Modal Header -->
     <div class="modal-header">
       <h4 class="modal-title">Upload Files</h4>
       <!-- <button type="button" class="close" data-dismiss="modal">×</button> -->
    </div>
      <!-- Modal body -->
      <div class="modal-body">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-4 bg-color1">DPC/SB</div>
                    <div class="col-md-2"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                    <div class="col-md-4 bg-color1">Recruitment Rules</div>
                    <div class="col-md-2"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                    <div class="col-md-4 bg-color1">OM</div>
                    <div class="col-md-2"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                    <div class="col-md-4 bg-color1">Notification</div>
                    <div class="col-md-2"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                    <div class="col-md-4 bg-color1">Gradation List</div>
                    <div class="col-md-2"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                    <div class="col-md-4 bg-color1">Recommendation Letter</div>
                    <div class="col-md-2"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                    <div class="col-md-4 bg-color1">Resolution</div>
                    <div class="col-md-2"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                </div>
            </div>
      </div>
      <!-- Modal footer -->
      <div class="modal-footer" align="center">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<div class="modal" id="shortlistofficer">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <!-- Modal Header -->
     <div class="modal-header">
       <h4 class="modal-title">Officers List</h4>
       <button type="button" class="close" data-dismiss="modal">×</button>
    </div>
      <!-- Modal body -->
      <div class="modal-body">
            <div class="col-md-12">
               
               <div class="row formsubhd">Shortlisted</div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="row listview">
                            <div class="col-md-11">1. Sukanta Ranasingh</div>
                            <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="row listview">
                            <div class="col-md-11">2. Subharam Palai</div>
                            <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="row listview">
                            <div class="col-md-11">3. B.Venktesh</div>
                            <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="row listview">
                            <div class="col-md-11">4. AShis Barnwal</div>
                            <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="row listview">
                            <div class="col-md-11">5. Aman Kumar</div>
                            <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="row listview">
                            <div class="col-md-11">6. Ved Prakash</div>
                            <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="row listview">
                            <div class="col-md-11">7. Suryansh</div>
                            <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="row listview">
                            <div class="col-md-11">8. Sagar Anchal</div>
                            <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="row listview">
                            <div class="col-md-11">9. Jinesh</div>
                            <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="row listview">
                            <div class="col-md-11">10. Sradha</div>
                            <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                        </div>
                    </div>
                </div>
             
            
            <div class="clearfix"></div>
            <div class="row formsubhd">Not Shortlisted</div>
            
                <div class="row">
                    <div class="col-md-6">
                        <div class="row listview">
                            <div class="col-md-11">1. Monalisa Parida</div>
                            <div class="col-md-1 listicon"><i class="fa fa-times text-danger"></i></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="row listview">
                            <div class="col-md-11">2. Pratyusha Sahoo</div>
                            <div class="col-md-1 listicon"><i class="fa fa-times text-danger"></i></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="row listview">
                            <div class="col-md-11">3. Haraprasad Mishra</div>
                            <div class="col-md-1 listicon"><i class="fa fa-times text-danger"></i></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="row listview">
                            <div class="col-md-11">4. Saloni Panigrahi</div>
                            <div class="col-md-1 listicon"><i class="fa fa-times text-danger"></i></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="row listview">
                            <div class="col-md-11">5. Asihs Ram</div>
                            <div class="col-md-1 listicon"><i class="fa fa-times text-danger"></i></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="row listview">
                            <div class="col-md-11">6. Lisa Rani Natha</div>
                            <div class="col-md-1 listicon"><i class="fa fa-times text-danger"></i></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="row listview">
                            <div class="col-md-11">7. Sanjaya</div>
                            <div class="col-md-1 listicon"><i class="fa fa-times text-danger"></i></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="row listview">
                            <div class="col-md-11">8. Amit</div>
                            <div class="col-md-1 listicon"><i class="fa fa-times text-danger"></i></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="row listview">
                            <div class="col-md-11">9. Banita Swain</div>
                            <div class="col-md-1 listicon"><i class="fa fa-times text-danger"></i></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="row listview">
                            <div class="col-md-11">10. Sidhu</div>
                            <div class="col-md-1 listicon"><i class="fa fa-times text-danger"></i></div>
                        </div>
                    </div>
                </div>
            </div> 
        </div>
      
      <!-- Modal footer -->
      <div class="modal-footer" align="center">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!--Modal Start-->
<div class="modal" id="comments">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <!-- Modal Header -->
        <div class="modal-header">
        <h4 class="modal-title">Give your comments</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <!-- Modal body -->
      <div class="modal-body">
     <div class="col-md-12">
       <div class="modalstyleheader">
         <div class="row">
          <div class="col-md-9">
            <div class="row mrt_10">
                <div class="col-md-3"><input type="radio" name="rdApprove" class="minimal" value="1"> Forward </div>
                <div class="col-md-3"><input type="radio" name="rdApprove" class="minimal" value="2"> Return to Dept </div>
                <div class="col-md-3"><input type="radio" name="rdApprove" class="minimal" value="2"> Reject </div>
                <div class="col-md-3"><input type="radio" name="rdApprove" class="minimal" value="0"> Reassign</div>
            </div>
           </div>
           <div class="col-md-3">
              <select class="form-control">
                <option>--Select--</option>
                <option>SO</option>
                <option>Dy. Secretary</option>
                <option>Secretary</option>
            </select>
           </div>
       </div>
       </div>  
    
     <div class="row">
      <div class="col-md-12"><textarea name="" class="form-control" rows="5" placeholder="Give your comments... "></textarea>
      </div>
    </div>
    </div>
      </div>
      <!-- Modal footer -->
      <div class="modal-footer" align="center">
         <button class="btn btn-primary" onClick="submitComments()">Submit</button>
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<div class="modal" id="approveModal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <!-- Modal Header -->
        <div class="modal-header">
        <h4 class="modal-title"></h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <!-- Modal body -->
      <div class="modal-body">
     <div class="col-md-12">
      
     <div class="row">
      <div class="col-md-12">
        <h2 id="txtmsg">Application approved successfully !</h2>
      </div>
    </div>
    </div>
      </div>
      <!-- Modal footer -->
      <div class="modal-footer" align="center">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!--Modal End-->

<?php $__env->startPush('scripts'); ?>

<script>
    /*$(document).ready(function() {
        // Add minus icon for collapse element which is open by default
        $(".collapse.show").each(function() {
            $(this).prev(".card-header").find(".fa faicon").addClass("fa-minus-circle").removeClass("fa-plus-circle");
        });

        // Toggle plus minus icon on show hide of collapse element
        $(".collapse").on('show.bs.collapse', function() {
            $(this).prev(".card-header").find(".fa faicon").removeClass("fa-plus-circle").addClass("fa-minus-circle");
        }).on('hide.bs.collapse', function() {
            $(this).prev(".card-header").find(".fa faicon").removeClass("fa-minus-circle").addClass("fa-plus-circle");
        });
    });*/
    function submitComments(){

        if($("input[name='rdApprove']:checked").val()==1){
            $("#comments").modal('hide');
            $("#approveModal").modal('show');
            $("#txtmsg").html("Application approved successfully !");
        }else if($("input[name='rdApprove']:checked").val()==2){
            $("#comments").modal('hide');
            $("#approveModal").modal('show');
            $("#txtmsg").html("Application returned to line department !");
        }else if($("input[name='rdApprove']:checked").val()==3){
            $("#comments").modal('hide');
            $("#approveModal").modal('show');
            $("#txtmsg").html("Application rejected !");
        }else{
            $("#comments").modal('hide');
            $("#approveModal").modal('show');
            $("#txtmsg").html("Application returned back to section officer !");
        }
    }
</script>


<?php $__env->stopPush(); ?> <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-demo\resources\views/department/view-cm-promotion-opsc.blade.php ENDPATH**/ ?>