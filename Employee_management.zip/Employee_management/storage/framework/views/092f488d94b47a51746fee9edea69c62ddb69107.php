<?php $__env->startSection('title', 'DESIGNATION'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Add/Edit Ref. No</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Add/Edit Ref. No.</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      
      <!-- Default box -->
      <div class="box">
        <form role="form" id="webForm" method="post" autocomplete="off"  action="<?php echo e(url('post-refrence')); ?>">
          <?php echo e(csrf_field()); ?>

          <div class="box-body">
            <div class="row">
                <div class="col-md-6">
                   <?php
                    if(!empty($data)){
                        $refId = $data[0]->TRM_Reference;
                        $TRM_ReferenceNo  = $data[0]->TRM_ReferenceNo;
                        $TRM_ReferenceDate = $data[0]->TRM_ReferenceDate;
                    }else{
                       $refId = '';
                       $TRM_ReferenceNo  = '';
                       $TRM_ReferenceDate = '';
                    }
                    ?>
                    <div class="form-group">
                      <label for="name">Ref. No.</label>
                      <input type="text" class="form-control" name="refrenceNo" id="refrenceNo" value="<?php echo!empty($TRM_ReferenceNo) ? $TRM_ReferenceNo : ''; ?>">
                    </div>
                    <div class="form-group">
                      <label for="name">Ref. Date</label>
                      <input type="text" class="form-control" name="refDate" id="refDate" value="<?php echo!empty($TRM_ReferenceDate) ? $TRM_ReferenceDate : ''; ?>">
                    </div>
                   
                </div>
            </div>
          </div>
          <!-- /.box-body -->
          <div class="box-footer">
            <input type="hidden" name="hidRefId" value="<?php echo e($refId); ?>"/>
            <button type="button" class="btn btn-primary" onclick="validateForm();">Submit</button>
             <a href="<?php echo e(url('dashboard')); ?>"><button type="button" class="btn btn-warning" >Cancel</button></a>
          </div>
        </form>
      </div>
      <!-- /.box -->
      
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('scripts'); ?> 
<script type="text/javascript">
   function validateForm(){
      if (!blankValidation("refrenceNo","TextField", "Refrence No can not be left blank"))
          return false;
      if (!blankValidation("refDate","TextField", "Refrence Date can not be left blank"))
        return false;
      $('#webForm').submit();
   }  

    $(document).ready(function() {
         
      
          //date picker
      $( "#refDate" ).datepicker({
        format:'dd-mm-yyyy',
        closeOnDateSelect: true,
       // minDate: new Date() ,
        datepicker : false,
        
      })
   
     
    });

</script>  
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-demo\resources\views/department/add-refno-master.blade.php ENDPATH**/ ?>