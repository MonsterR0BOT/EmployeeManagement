 
 <?php $__env->startSection('title', 'DEPARTMENTS'); ?>
 <?php $__env->startSection('content'); ?>
 
<!-- department_area_start -->
 <div class="our_department_area">
    <div class="container">
       <div class="row">
          <div class="col-xl-12">
             <div class="section_title text-center mb-55">
                <h3>Govertment Departments</h3>
                <!--  <p>Federal and state departments responsible for farming, food and agriculture policies. Policies address issues such as natural resource protection, food safety and tools to help farmers. <br>
                   It esteems luckily or picture placing drawing. </p> -->
             </div>
          </div>
       </div>
       <div class="row">
          <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-xl-4 col-md-6 col-lg-4">
             <div class="single_department">
               
                <div class="department_content">
                   <h3><a href="#"><?php echo e($val->TDM_Dept_Name); ?></a></h3>
                   <p><?php echo e($val->TDM_Dept_Description); ?></p>
                </div>
             </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</div>
<!-- department_area_end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend-layout.frontend-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/department.blade.php ENDPATH**/ ?>