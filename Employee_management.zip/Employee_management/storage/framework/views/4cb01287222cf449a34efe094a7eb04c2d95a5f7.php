<?php $__env->startSection('title', 'CONTACT'); ?>
<?php $__env->startSection('content'); ?>
 <section class="page_breadcrumbs ds background_cover section_padding_top_65 section_padding_bottom_65">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 text-center">
                            <h2>Contact</h2>
                        </div>
                    </div>
                </div>
            </section>
            <section class="ls columns_padding_25 section_padding_top_100 section_padding_bottom_110">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12">
                            <h4>Contact Form</h4>
                        </div>
                    </div>
                    <div class="row">
                        <?php if(Session::has('errors')): ?>
                          <div class="col-md-12 alert alert-warning">
                              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php echo e($error); ?><br/>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </div>
                        <?php endif; ?>
                        <?php if(Session::has('message')): ?>
                        <div class="alert alert-success">                        
                            <i class="fa fa-check"></i> <?php echo e(Session::get('message')); ?> 
                        </div>
                        <?php endif; ?>
                        <div class="col-md-8 to_animate animated scaleAppear" data-animation="scaleAppear">
                            <form class="contact-form columns_padding_5" method="post" action="<?php echo e(url('home/saveContact')); ?>" onSubmit="return validateForm()" autocomplete="off">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group bottommargin_0"> <label for="name">Full Name <span class="required">*</span></label> <i class="fa fa-user highlight mrt-10" aria-hidden="true"></i> <input type="text" aria-required="true" size="30" value="" name="name" id="name" class="form-control" placeholder="Enter your full name"></div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group bottommargin_0"> <label for="phone">Phone Number<span class="required">*</span></label> <i class="fa fa-phone highlight mrt-10" aria-hidden="true"></i> <input type="text" aria-required="true" size="30" value="" name="phone" id="phone" class="form-control" placeholder="Enter phone number"></div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group bottommargin_0"> <label for="email">Email address<span class="required">*</span></label> <i class="fa fa-envelope highlight mrt-10" aria-hidden="true"></i> <input type="text" aria-required="true" size="30" value="" name="email" id="email" class="form-control" placeholder="Enter email address"></div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group bottommargin_0"> <label for="subject">Subject<span class="required">*</span></label> <i class="fa fa-flag highlight mrt-10" aria-hidden="true"></i> <input type="text" aria-required="true" size="30" value="" name="subject" id="subject" class="form-control" placeholder="Enter subject">                                          </div>
                                    </div>
                                    <div class="col-sm-12">
                                        <div class="contact-form-message form-group bottommargin_0"> <label for="message">Message</label> <i class="fa fa-comment highlight mrt-10" aria-hidden="true"></i> <textarea aria-required="true" rows="3" cols="45" name="message" id="message" class="form-control" placeholder="Enter message"></textarea> 
                                        </div>
                                    </div>
                                    <div class="col-sm-12 bottommargin_0">
                                        <div class="contact-form-submit topmargin_30"> <button type="submit" id="contact_form_submit" name="contact_submit" class="theme_button color1 margin_0">Send   </button> 
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <?php $__currentLoopData = $contact_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 to_animate animated scaleAppear" data-animation="scaleAppear">
                            <ul class="list1 no-bullets no-top-border no-bottom-border">
                                <li>
                                    <div class="media">

                                        <div class="media-left"> <i class="rt-icon2-shop highlight fontsize_18"></i> 
                                        </div>
                                        <div class="media-body">
                                            <h6 class="media-heading grey">Postal Address:</h6>  <?php echo e($data->TCM_Contact_Name); ?>

                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="media">
                                        <div class="media-left"> <i class="rt-icon2-phone5 highlight fontsize_18"></i> 
                                        </div>
                                        <div class="media-body">
                                            <h6 class="media-heading grey">Phone:</h6>(<?php echo e($data->TCM_Contact_Phone); ?>

                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="media">
                                        <div class="media-left"> <i class="rt-icon2-mail 
                                            highlight fontsize_18"></i> 
                                        </div>
                                        <div class="media-body greylinks">
                                            <h6 class="media-heading grey">Email:</h6> <a href="#">  <?php echo e($data->TCM_Contact_Email); ?> </a>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </section>
<?php $__env->startPush('scripts'); ?>  
  <script>
   
     function validateForm(){ //alert("here"); return false;
         if (!blankValidation("name", "TextField","Name is required"))
           return false;
        if (!blankValidation("phone", "TextField","Phone is required"))
           return false;
         if (!blankValidation("email", "TextField","Email is required"))
           return false;
         if (!RemoveSQLCharacter("email"))
           return false;
         if (!checkEmailId("email","Invalid email id !!!"))
           return false;
         if (!blankValidation("subject", "TextField","Subject is required"))
           return false; 
        if (!blankValidation("message", "TextArea","Message is required"))
           return false; 
     }
    
  </script>
  <?php $__env->stopPush(); ?>         
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend-layout.frontend-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\wethefamily\resources\views/contact.blade.php ENDPATH**/ ?>