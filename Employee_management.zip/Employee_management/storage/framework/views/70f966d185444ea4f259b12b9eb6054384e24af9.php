<?php $__env->startSection('title', 'RelaxationRequest'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       View Commissioner Relaxation Request
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Relaxation</a></li>
        <li class="active">Manage Commissioner Relaxation Request</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
           <!-- <div class="box-header">
              <h3 class="box-title">Data Table With Full Features</h3>
            </div>-->
            <!-- /.box-header -->
            <div class="box-body">
              <div id="demo" >
                <div class="search-field">
                    <div class="row">
    
                        <div class="col-md-2">
                            <div class="org-name">From Date</div>
                        </div>
                        <div class="col-md-2">
                            <input class="form-control" type="text" id="param1">
                        </div>
                        
                        <div class="col-md-1">
                            <div class="org-name">To Date</div>
                        </div>
                        <div class="col-md-2">
                            <input class="form-control" type="text" id="param2">
                        </div>
                        
                        <div class="col-md-1">
                            <div class="org-name">Department Name</div>
                        </div>
                        <div class="col-md-2">
                            <select class="form-control processNameCls">
                              <option value="">--Select--</option>
                              <option value="">Agriculture & F.E. Department</option>
                              <option value="">Commerce & Transport</option>
                              <option value="">Co-Operation Department</option>
                              <option value="">Exise Department</option>
                            </select>
                        </div>
                        
                        
                        <div class="col-md-2">
                            <div class="form-group">
                                <button class="btn btn-primary" onClick="searchData()">Search</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
           <!-- <a data-toggle="collapse" data-target="#demo"
                class="showhideangelbg"><i class="fa fa-angle-double-down"></i>
            </a>-->
              <table id="listAllUser" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Application No</th>
                  <th>Department Name</th>
                  <th>Assigned Date</th>
                  <th>Due Date</th>
                  <th>ApprovalStatus</th>
                  <th>PendingAt</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                  <td>RX/2019-20/001</td>
                  <td>Agriculture & F.E. Department</td>
                  <td>23/12/2019</td>
                  <td>24/12/2019</td>
                  <td>Open</td>
                  <td>SO</td>
                  <td><a title="view" href="javascript:void(0);"><i class="fa fa-eye"></i></a><!-- &nbsp;<a href="javascript:void(0)" ><i class="fa fa-trash"></i></a> --></td>
                </tr>
                <tr>
                  <td>RX/2019-20/002</td>
                  <td>Commerce & Transport</td>
                  <td>23/12/2019</td>
                  <td>24/12/2019</td>
                  <td>Open</td>
                  <td>SO</td>
                  <td><a title="view" href="javascript:void(0);"><i class="fa fa-eye"></i></a><!-- &nbsp;<a href="javascript:void(0)" ><i class="fa fa-trash"></i></a> --></td>
                </tr>
                <tr>
                  <td>RX/2019-20/003</td>
                  <td>Co-Operation Department</td>
                  <td>23/12/2019</td>
                  <td>24/12/2019</td>
                  <td>Open</td>
                  <td>SO</td>
                  <td><a title="view" href="javascript:void(0);"><i class="fa fa-eye"></i></a><!-- &nbsp;<a href="javascript:void(0)" ><i class="fa fa-trash"></i></a> --></td>
                </tr>
                <tr>
                  <td>RX/2019-20/004</td>
                  <td>Excise Department</td>
                  <td>23/12/2019</td>
                  <td>24/12/2019</td>
                  <td>Open</td>
                  <td>SO</td>
                  <td><a title="view" href="javascript:void(0);"><i class="fa fa-eye"></i></a><!-- &nbsp;<a href="javascript:void(0)" ><i class="fa fa-trash"></i></a> --></td>
                </tr>

                <tr>
                  <td>RX/2019-20/005</td>
                  <td>Energy Department</td>
                  <td>23/12/2019</td>
                  <td>24/12/2019</td>
                  <td>Open</td>
                  <td>SO</td>
                  <td><a title="view" href="javascript:void(0);"><i class="fa fa-eye"></i></a><!-- &nbsp;<a href="javascript:void(0)" ><i class="fa fa-trash"></i></a> --></td>
                </tr>

                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
      <!-- Modal Start-->
    <div id="myModal" class="modal fade" role="dialog">
      <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content" style="width: 750px;">
          <div class="modal-header">
            <h4 class="modal-title">View Details of User Management</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          </div>
          <div class="modal-body">
            <table id="table1"
              class="table table-striped table-bordered" width="100%"
              border="0">
              <thead>
                <tr>
                  <th>User Name</th>
                  <th>Mobile No</th>
                  <th>Email</th>
                  <!-- <th>User Role</th> -->
                  <th>Country</th>
                  <th>State</th>
                  <th>District</th>
                  <th>PIN</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                
              </tbody>
            </table>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>
    <!-- Modal End-->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('styles'); ?>
<!--Extra styles can written here -->
<?php $__env->stopPush(); ?>  
<?php $__env->startPush('scripts'); ?>

<script type="text/javascript">
  $(function () {
    $('#listAllUser').DataTable({
      "ordering": false
    }).draw();
  })
  
  /*$(function () {
  $('#listAllUser').DataTable({
    'processing' : true,
    'serverSide' : true,
    'searching' : false,
    'ordering' : false,
    "ajax" : {
      'url' : 'view-user-throughAjax',
      'data' : function(d) {
        d.param1 = $('#param1').val();
        d.param2 = $('#param2').val();
        d.param3 = $('#param3').val();

      }
    },
    'dataSrc' : "",
    'columns' : [ {
      'data' : 'TUM_User_Name'
    }, {
      'data' : 'TUT_UserTypeName'
    }, {
      'data' : 'TUM_User_IMEI'
    }, {
      'data' : 'TUM_User_Mobile'
    }, {
      'data' : 'TUM_User_Email'
    }, {
      'data' : 'TCM_Country_Name'
    }, {
      'data' : 'TSM_State_Name'
    }, {
      'data' : 'TDM_Dist_Name'
    }, {
      'data' : 'TUM_User_Pin'
    }, {
      'data' : 'TUM_User_Status'
    }, {
      'data' : 'action'
    }

    ]
  });
  
  });*/
  //Method For Searching Records In The List
  function searchData() {
    $('#listAllUser').DataTable().draw();
  }
  //Deleting the Country

  function deleteUser(id){
    swal.fire({
        title: "Are you sure want to Delete?",
        text: "Once Deleted,Can't revert back !",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#e7b63a',
        confirmButtonText: 'Delete',
        reverseButtons : true
        
      }).then((result) => {
        if(result.value){
         $.ajax({
              type: "GET",
              url:"master/delete-user?id="+ id,
              success: function(response) {
            console.log(response);
            //return false;
                  if (response.message == "success") {
                    swal({
                      title: "Record Deleted Successfully.",
                      type: "success"
                    }).then(function(){
                       location.reload();
                    })
                  
                    
                  } else {
                      swal({
                          title: 'Unsuccess',
                          text: response.code
                      })
                  }
              },
              error: function(data) {
               
              }
          })
        }
        
      });
  }
  /* VIEW IN MODEL USER DATA */
 function viewInModel(index) {
  $.ajaxSetup({
    headers: {
      'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
    }
  });
  //var id = window.atob(index);
    $('#table1').empty();
    $.ajax({
      type : "POST",
      url : "view-user-modal",
      dataType : 'json',
      //contentType : 'application/json',
      data : {"userId":index},
      success : function(response) {
        if (response.message == "success") {
          console.log(response.userData.userStatus);
          var status = "";
          if (response.userData.TUM_User_Status) {
            status = "Active";
          } else {
            status = "InActive";
          }
          table = '<tr><td>User Name :</td>' + '<td align="left">'
              + response.userData.TUM_User_Name + '</td>'
              + '</tr><tr><td>User Role :</td>' + '<td align="left">'
              + response.userData.userRoleName + '</td>'
              + '</tr><tr><td>IMEI Number</td><td align="left">'
              + response.userData.TUM_User_IMEI
              + '</td></tr><tr><td>Mobile Number</td><td align="left">'
              + response.userData.TUM_User_Mobile
              + '</td></tr><tr><td>Email</td><td align="left">'
              + response.userData.TUM_User_Email
              + '</td></tr><tr><td>Country</td><td align="left">'
              + response.userData.TCM_Country_Name
              + '</td></tr><tr><td>State</td><td align="left">'
              + response.userData.TSM_State_Name
              + '</td></tr><tr><td>District</td><td align="left">'
              + response.userData.TDM_Dist_Name
              + '</td></tr><tr><td>PIN</td><td align="left">'
              + response.userData.TUM_User_Pin
              + '</td></tr><tr><td>Status</td><td align="left">'
              + status
              + '</td></tr>';
          $('#myModal').modal('show');
          $('#table1').append(table);
        }
      },
      error : function(data) {
        console.log(data);
      }
    })

  } 
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-demo\resources\views/relaxation/view-commissioner-relaxation.blade.php ENDPATH**/ ?>