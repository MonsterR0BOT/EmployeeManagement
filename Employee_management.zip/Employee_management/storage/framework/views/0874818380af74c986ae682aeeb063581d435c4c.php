<?php $__env->startSection('title', 'DASHBOARD'); ?>
<?php $__env->startSection('content'); ?>
    <?php 
      // if(!Session::has("userRoles")){
      //   Session::put("userRoles",array());
      // }
      // print "<pre>";
      // print_r(Session::get("userId"));
      // exit;
    ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <!-- <small>Version 1.0</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->
      <div class="row">
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="ion ion-ios-people-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Visitors</span>
              <span class="info-box-number">20</span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-red"><i class="ion ion-ios-people-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Product</span>
              <span class="info-box-number">41</span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->

        <!-- fix for small devices only -->
        <div class="clearfix visible-sm-block"></div>

        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-green"><i class="ion ion-ios-people-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Series</span>
              <span class="info-box-number">10</span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="ion ion-ios-people-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Users</span>
              <span class="info-box-number">2</span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
     
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('scripts'); ?>
<script>
    //barchart data
    var barChartData = {
      labels: ['Day 1', 'Day 2', 'Day 3', 'Day 4', 'Day 5', 'Day 6'],
      datasets: [
      {
        label: 'Promotional Request',
        backgroundColor:'rgba(100,168,10,0.9)',
        borderColor:'rgba(100,168,10,0.9)',
        borderWidth: 1,
        data: [95, 125, 143, 68, 114, 73 ],
      }, {
        label: 'Disciplinary Cases',
        backgroundColor: 'rgba(243,156,18,0.9)',
        borderColor: 'rgba(230,268,100,0.9)',
        borderWidth: 1,
        data:[85, 105, 133, 68, 94, 43 ],
      },{
        label: 'Relaxations',
        backgroundColor: 'rgba(150,158,210,0.9)',
        borderColor: 'rgba(150,158,210,0.9)',
        borderWidth: 1,
        data:[10, 20, 10, 5, 20, 30 ],
      }]

    };

    /*################PIE #########################*/
    var configPie = {
      type: 'pie',
      data: {
        datasets: [{
          data: [20,35,40,10,15,30,12,5],
          backgroundColor: [
          'rgba(51,153,255,0.9)',
          'rgba(255,255,51,0.9)',
          'rgba(250,206,58,0.9)',
          'rgba(240,119,248,0.9)',
          'rgba(228,30,57,0.9)',
          'rgba(100,168,10,0.9)',
          'rgba(30,116,228,0.9)',
          'rgba(249,4,29,0.9)' 
          ],
          label: 'Pie Chart'
        }],
        labels: [
          'New',
          'Verified',
          'Forwarded',
          'Returned',
          'Rejected',
          'Approved',
          'Accepted',
          'Cancelled'
        ]
      },
      options: {
        responsive: true
      }
    };



    $(function () {
      //////////////
      var ctx1 = document.getElementById('barChart').getContext('2d');
      window.myBar = new Chart(ctx1, {
        type: 'bar',
        data: barChartData,
        options: {
          responsive: true,
          legend: {
            position: 'top',
          },
          hover: {
            mode: 'nearest',
            "animationDuration": 0,
            intersect: true
          },

          "animation": {
              "duration": 1,
              "onComplete": function () {
                var chartInstance = this.chart,
                ctx = chartInstance.ctx;
                
                ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
                ctx.textAlign = 'center';
                ctx.textBaseline = 'botton';

                this.data.datasets.forEach(function (dataset, i) {
                  var meta = chartInstance.controller.getDatasetMeta(i);
                  meta.data.forEach(function (bar, index) {
                    var data = dataset.data[index];                            
                    ctx.fillText(data, bar._model.x, bar._model.y - 5);
                  });
                });
              }
          },
          title: {
            display: false,
            text: 'Audit Weekly Promotional Chart'
          }
        }
      });
      ////////////////
      var ctx = document.getElementById('pieChart').getContext('2d');
      window.myPie = new Chart(ctx, configPie);
    }); 
  </script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Employee_management\resources\views/dashboard/dashboard-user.blade.php ENDPATH**/ ?>