<?php $__env->startSection('title', 'DESIGNATION'); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>FAQ</h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="#">Master</a></li>
      <li class="active">FAQ</li>
    </ol>
  </section>
  <!-- Main content -->
  <section class="content">
    <!-- Default box -->
    <div class="box">
      <?php if(Session::has('message')): ?>
        <div class="alert alert-success">                        
          <i class="fa fa-check"></i> <?php echo e(Session::get('message')); ?> 
        </div>
      <?php endif; ?>
      <div class="box-header">
      <!--<h3 class="box-title">Data Table With Full Features</h3>-->
      <!-- <div class="pull-right"><a href="<?php echo e(url('add-sms')); ?>" class="btn btn-primary pull">Add New</a></div> -->
      </div>
      <!-- /.box-header -->
      <div class="box-body">
        <div class="row">
          <div class="col-md-12">
            <div class="panel-group" id="accordion">
              <?php $cnt=1;?>
              <?php $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="panel panel-default">
                  <div class="panel-heading">
                    <h4 class="panel-title">
                      <a class="card-link" data-toggle="collapse" href="#collapse<?php echo e($cnt); ?>"> <?php echo e($val->TFM_Faq_Question); ?> </a>
                    </h4>
                  </div>
                  <div id="collapse<?php echo e($cnt); ?>" <?php if($cnt =="1"): ?> class="panel-collapse collapse show" <?php else: ?> class="panel-collapse collapse" <?php endif; ?> data-parent="#accordion">
                    <div class="panel-body">
                      <?php echo $val->TFM_Faq_Answer; ?>

                    </div>
                  </div>
                </div>
              <?php $cnt++ ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->startPush('styles'); ?>
  <!--Extra styles can written here -->
<?php $__env->stopPush(); ?>  
<?php $__env->startPush('scripts'); ?>

<script>
  $(function () {
    $('#listAllData').DataTable({
      'searching' : false,
      'ordering' : false,
    });
  
  });
  /*$(function () {
  $('#listAllData').DataTable({
    'processing' : true,
    'serverSide' : true,
    'searching' : false,
    'ordering' : false,
    "ajax" : {
      'url' : 'view-designation-throughAjax',
      'data' : function(d) {
        d.param1 = $('#param1').val();
      }
    },
    'dataSrc' : "",
    'columns' : [ {
      'data' : 'TDM_Desig_Name'
    }, {
      'data' : 'TDM_Desig_Name_Odia'
    },{
      'data' : 'action'
    }

    ]
  });
  
  });*/
  //Method For Searching Records In The List
  function searchData() {
    $('#listAllData').DataTable().draw();
  }
  //Deleting the record

  function deleteRecord(id){
    swal.fire({
        title: "Are you sure want to Delete?",
        text: "Once Deleted,Can't revert back !",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#e7b63a',
        confirmButtonText: 'Delete',
        reverseButtons : true
        
      }).then((result) => {
        if(result.value){
         $.ajax({
              type: "GET",
              url:"delete-designation?id="+ id,
              success: function(response) {
            console.log(response);
            //return false;
                  if (response.message == "success") {
                    swal({
                      title: "Record Deleted Successfully.",
                      type: "success"
                    }).then(function(){
                       location.reload();
                    })
                  
                    
                  } else {
                      swal({
                          title: 'Unsuccess',
                          text: response.code
                      })
                  }
              },
              error: function(data) {
               
              }
          })
        }
        
      });
  } 
 
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/department/view-department-faq.blade.php ENDPATH**/ ?>