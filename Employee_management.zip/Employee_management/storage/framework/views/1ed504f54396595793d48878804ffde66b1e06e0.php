<!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <?php 
      if(!Session::has("userRoles")){
        Session::put("userRoles",array());
      }
      // print "<pre>";
      // print_r(Session::get("userRoles"));
      // echo in_array('rol001', Session::get("userRoles"));
      // exit;
    ?>
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo e(asset(Helper::getUserPhoto())); ?>" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?php echo e(Helper::getUserType()); ?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
     
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
       <!--  <li>
          <a href="<?php echo e(url('dashboard')); ?>"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
        </li> -->
        <li class="treeview">
          <a href="#">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <?php if(in_array('rol003', Session::get("userRoles")) || in_array('rol001', Session::get("userRoles"))){ ?>
            <li><a href="<?php echo e(url('dashboard')); ?>"><i class="fa fa-circle-o"></i>Dashboard</a></li>
            <?php }?>
          </ul>
        </li>
         <?php if(in_array('rol001', Session::get("userRoles")) ){ ?>
         <li class="treeview">
          <a href="#">
            <i class="fa fa-gear"></i> <span>Settings</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('email/viewEmail')); ?>"><i class="fa fa-circle-o"></i>Email Template</a></li>
            <li><a href="<?php echo e(url('email/viewSms')); ?>"><i class="fa fa-circle-o"></i>SMS Template</a></li>
           <!--  <li><a href="<?php echo e(url('email/viewPassPolicy')); ?>"><i class="fa fa-circle-o"></i>Password Policy</a></li> -->
           
          </ul>
        </li>

        <li class="treeview">
          <a href="#">
            <i class="fa fa-table"></i> <span>Master</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
<!--             <li><a href="<?php echo e(url('wing/viewWing')); ?>"><i class="fa fa-circle-o"></i>Manage Wing</a></li> -->
            <!-- <li><a href="<?php echo e(url('wing/viewStatus')); ?>"><i class="fa fa-circle-o"></i>Manage Status</a></li> -->
            <li><a href="<?php echo e(url('module/viewModule')); ?>"><i class="fa fa-circle-o"></i>Manage Module</a></li>
            <li><a href="<?php echo e(url('function/viewFunction')); ?>"><i class="fa fa-circle-o"></i>Manage Functions</a></li>
            <li><a href="<?php echo e(url('activity/viewActivity')); ?>"><i class="fa fa-circle-o"></i>Manage Activity</a></li>
            <li><a href="<?php echo e(url('country/viewAllCountry')); ?>"><i class="fa fa-circle-o"></i>Manage Country</a></li>
            <li><a href="<?php echo e(url('state/viewAllState')); ?>"><i class="fa fa-circle-o"></i>Manage State</a></li>
            <li><a href="<?php echo e(url('district/viewAllDistrict')); ?>"><i class="fa fa-circle-o"></i>Manage District</a></li>

            <li><a href="<?php echo e(url('Religion/viewAllReligion')); ?>"><i class="fa fa-circle-o"></i>Manage Religion</a></li>
            <li><a href="<?php echo e(url('Caste/viewAllCaste')); ?>"><i class="fa fa-circle-o"></i>Manage Caste</a></li>
            <li><a href="<?php echo e(url('Qualification/viewAllQualification')); ?>"><i class="fa fa-circle-o"></i>Manage Qualification</a></li>
            <li><a href="<?php echo e(url('Occupation/viewAllOccupation')); ?>"><i class="fa fa-circle-o"></i>Manage Occupation</a></li>
            <li><a href="<?php echo e(url('Language/viewAllLanguage')); ?>"><i class="fa fa-circle-o"></i>Manage Language</a></li>
            <li><a href="<?php echo e(url('Subcaste/viewAllSubcaste')); ?>"><i class="fa fa-circle-o"></i>Manage Sub Caste</a></li>
           <!--  <li><a href="<?php echo e(url('designation/viewDesignation')); ?>"><i class="fa fa-circle-o"></i>Manage Designations</a></li> -->
          </ul>
        </li>

       <li class="treeview">
          <a href="#">
            <i class="fa fa-user"></i>
            <span>Member</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('manageuser/viewAllMemberList')); ?>"><i class="fa fa-circle-o"></i>Manage Member</a></li>
           <li><a href="<?php echo e(url('managecontact/viewAllCRList')); ?>"><i class="fa fa-circle-o"></i>Manage Contacts Request</a></li>
           <li><a href="<?php echo e(url('manageblog/viewBlog')); ?>"><i class="fa fa-circle-o"></i>Manage Blogs</a></li>
          </ul>
        </li>

        <li class="treeview">
          <a href="#">
            <i class="fa fa-user"></i>
            <span>Matrimony</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('managematrimony/viewAllMatList')); ?>"><i class="fa fa-circle-o"></i>Manage Matrimony</a></li>
          </ul>
        </li>

        <li class="treeview">
          <a href="#">
            <i class="fa fa-table"></i>
            <span>Contents</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('content/viewContent')); ?>"><i class="fa fa-circle-o"></i>Manage AboutUs</a></li>
           
            <li><a href="<?php echo e(url('content/viewBanner')); ?>"><i class="fa fa-circle-o"></i> Manage Banner</a></li>
            <li><a href="<?php echo e(url('content/viewVideo')); ?>"><i class="fa fa-circle-o"></i> Manage Video</a></li>
            <li><a href="<?php echo e(url('content/viewGallery')); ?>"><i class="fa fa-circle-o"></i> Manage Gallery</a></li>
            <li><a href="<?php echo e(url('content/viewService')); ?>"><i class="fa fa-circle-o"></i> Manage Service</a></li>
            <li><a href="<?php echo e(url('content/viewEvent')); ?>"><i class="fa fa-circle-o"></i> Manage Event</a></li>
            <li><a href="<?php echo e(url('content/viewTermCondition')); ?>"><i class="fa fa-circle-o"></i> Manage Term&Condition</a></li>
            <li><a href="<?php echo e(url('content/viewNews')); ?>"><i class="fa fa-circle-o"></i> Manage News</a></li>
            <li><a href="<?php echo e(url('content/viewBlog')); ?>"><i class="fa fa-circle-o"></i> Manage Blog</a></li>
            <li><a href="<?php echo e(url('content/viewAllSocial')); ?>"><i class="fa fa-circle-o"></i> Manage Social Media</a></li>
            <li><a href="<?php echo e(url('content/viewAllCategory')); ?>"><i class="fa fa-circle-o"></i> Manage Category</a></li>
            <li><a href="<?php echo e(url('content/viewContactAddress')); ?>"><i class="fa fa-circle-o"></i> Manage Contact Address</a></li>
          </ul>
        </li>
        <?php } ?>
        <!-- End of OPSC Approval  on 24Dec2019 by subharam -->
        <?php if(!in_array('rol004', Session::get("userRoles")) && !in_array('rol005', Session::get("userRoles")) && !in_array('rol006', Session::get("userRoles")) && !in_array('rol007', Session::get("userRoles")) && !in_array('rol008', Session::get("userRoles")) && !in_array('rol004', Session::get("userRoles")) ){ ?>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-user"></i> <span>User</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('user/viewAllUserList')); ?>"><i class="fa fa-circle-o"></i>Manage User</a></li>
          <!--  <li><a href="<?php echo e(url('add-user')); ?>"><i class="fa fa-circle-o"></i>Add User</a></li>
             <li><a href="<?php echo e(url('manage-user-type')); ?>"><i class="fa fa-circle-o"></i>Manage User Type</a></li>
            <li><a href="<?php echo e(url('add-user-type')); ?>"><i class="fa fa-circle-o"></i>Add User Type</a></li> -->
            <li><a href="<?php echo e(url('UserRole/viewAllUserRole')); ?>"><i class="fa fa-circle-o"></i>Manage Role</a></li>
            <!-- <li><a href="<?php echo e(url('add-user-role')); ?>"><i class="fa fa-circle-o"></i>Add Role</a></li> -->
          </ul>
        </li>
        <?php 
      }?>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-user"></i> <span>Profile</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('edit-profile')); ?>"><i class="fa fa-circle-o"></i>Edit Profile</a></li>
            <li><a href="<?php echo e(url('change-password')); ?>"><i class="fa fa-circle-o"></i>Change Password</a></li>
            <li><a href="<?php echo e(url('logout')); ?>"><i class="fa fa-circle-o"></i>Sign Out</a></li>
          </ul>
        </li>
       
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>
<?php /**PATH D:\xampp\htdocs\wethefamily\resources\views/layout/sidebar.blade.php ENDPATH**/ ?>