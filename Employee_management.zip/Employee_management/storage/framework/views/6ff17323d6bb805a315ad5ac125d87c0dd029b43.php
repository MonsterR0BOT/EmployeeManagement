<?php $__env->startSection('title', 'WING'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Edit SMS</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Edit Wing</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      
      <!-- Default box -->
      <div class="box">
        <form role="form" id="webForm" method="post" autocomplete="off" action="<?php echo e(url('post-wing')); ?>">
          <?php echo e(csrf_field()); ?>

          <div class="box-body">
            <div class="row">
                <div class="col-md-6">
                   <?php
                    if(!empty($data)){
                        $dataId = $data[0]->TWM_Wing;
                        $TWM_Wing_Name  = $data[0]->TWM_Wing_Name;
                        $TWM_Wing_Name_Odia = $data[0]->TWM_Wing_Name_Odia;
                    }else{
                       $smsId = '';
                       $TSM_SMS_Name  = '';
                       $TSM_SMS_Body = '';
                    }
                    ?>
                    <div class="form-group">
                      <label for="name">Wing Name</label>
                      <input type="text" class="form-control" name="wingName" id="wingName" value="<?php echo!empty($TWM_Wing_Name) ? $TWM_Wing_Name : ''; ?>">
                    </div>
                    <div class="form-group">
                      <label for="name">Wing Name Odia</label>
                      <input type="text" class="form-control" name="wingNameOdia" id="wingNameOdia" value="<?php echo!empty($TWM_Wing_Name_Odia) ? $TWM_Wing_Name_Odia : ''; ?>">
                    </div>
                   
                </div>
            </div>
          </div>
          <!-- /.box-body -->
          <div class="box-footer">
            <input type="hidden" name="hidDataId" value="<?php echo e($dataId); ?>"/>
            <button type="button" class="btn btn-primary" onclick="validateForm();">Submit</button>
             <a href="<?php echo e(url('manage-wing-master')); ?>"><button type="button" class="btn btn-warning" >Cancel</button></a>
          </div>
        </form>
      </div>
      <!-- /.box -->
      
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('scripts'); ?> 
<script type="text/javascript">
   function validateForm(){
      if (!blankValidation("wingName","TextField", "Wing name can not be left blank"))
          return false;
      if (!blankValidation("wingNameOdia","TextField", "Wing name odia can not be left blank"))
        return false;
      $('#webForm').submit();
   }  

</script>  
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opscautomation\resources\views/master/add-wing-master.blade.php ENDPATH**/ ?>