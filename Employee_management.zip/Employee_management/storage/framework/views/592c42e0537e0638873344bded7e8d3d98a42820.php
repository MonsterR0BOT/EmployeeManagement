<?php $__env->startSection('title', 'CHART'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Promotional, Disciplinary, Relaxation Request Charts
        <small>Preview sample</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">MIS Reports</a></li>
        <li class="active">Charts</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
    <div id="reportPage">

      <div class="row">
      	 <!-- /.col (LEFT) -->
		<div class="col-md-9">
      	  <div id="demo" >
                <div class="search-field">
                   
                    <div class="row">
    
                        <div class="col-md-2">
                            <div class="org-name">Department</div>
                        </div>
                        <div class="col-md-2">
                          <div class="input-group">
                               <select class="form-control" id="deptId" name="deptId">
		                        <option value="">--Select--</option>
		                        <?php $__currentLoopData = $dept_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                        <option value="<?php echo e($val->TDM_Dept); ?>" ><?php echo e($val->TDM_Dept_Name); ?></option>
		                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                      </select>
		                  </div>
                        </div>  
                        
                        <div class="col-md-2">
                            <div class="org-name">Year</div>
                        </div>
                        <div class="col-md-2">
                          <div class="input-group">
                                <select name="financialYear" id="financialYear" class="form-control">
			                         <?php $y= date('Y'); ?> 
			                         <?php for($i =1; $i <= 7; $i++): ?>
			                              <option value="<?php echo e($y); ?>"><?php echo e($y); ?></option>
			                            <?php ($y--); ?>  
			                         <?php endfor; ?> 
			                     </select>
		                  </div>
                        </div>

                        <div class="col-md-1">
                            <div class="form-group">
                                <button class="btn btn-primary" onClick="searchData()">Search</button>
                            </div>
                        </div>
                    </div>
                   <!--  <div class="row">
                      <div class="col-md-12" align="right">
                        <a href="#" target="_blank" class="btn btn-default"><i class="fa fa-print"></i> Print</a>
                        <a href="#" target="_blank" class="btn btn-default"><i class="fa fa-file-pdf-o"></i> PDF</a>
                    </div>
                    </div> -->
                </div>
            </div>
        </div>
         <a href="#" id="downloadPdf" ><button type="button" style="color: blue;"> Download as PDF</button></a>
        <div class="col-md-12">

          <!-- BAR CHART -->
          <div class="box box-success">
            <div class="box-header with-border">
              <h3 class="box-title">Monthly Chart</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <div class="box-body">
              <div class="chart">
                <canvas id="canvas" style="height:350px"></canvas>
              </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

        </div>
               
      </div>
  </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('scripts'); ?>
<script>
		//var MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
		var config = {
			type: 'line',
			data: {
				labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun','Jul','Aug','Sep','Oct','Nov','Dec'],

				datasets: [{
					label: 'Promotional',
					backgroundColor:'rgba(150,158,210,0.9)',
					borderColor: 'rgba(70,158,210,0.9)',
					data: [<?php echo $totalRecordMonthlyWisePro;?>],
					fill: false,
				}, {
					label: 'Disciplinary',
					fill: false,
					backgroundColor: 'rgba(150,158,210,0.9)',
					borderColor: 'rgba(150,158,210,0.9)',
				//	data: [85, 105, 133, 68, 94, 43,53,65,128,139,65,76,100],
					data: [<?php echo $totalRecordMonthlyWise;?>],
				} ,{
					label: 'Relaxation',
					fill: false,
					backgroundColor: 'rgba(210,85,110,0.9)',
					borderColor:'rgba(210,85,110,0.9)',
				//	data: [5, 10, 3, 6, 4, 3,3,6,8,9,5,6,7],
					data: [<?php echo $totalRecordMonthlyWiseRel;?>],
				} ]
			},
			options: {
				responsive: true,
				title: {
					display: false,
					text: 'MIS Monthly Promotional,Disciplinary,Relaxation Chart'
				},
				tooltips: {
					mode: 'index',
					intersect: false,
				},
				/*hover: {
					mode: 'nearest',
					intersect: true
				},*/
				hover: {
			            mode: 'nearest',
			            "animationDuration": 0,
			            intersect: true
          			},

		            "animation": {
						"duration": 1,
						"onComplete": function () {
							var chartInstance = this.chart,
							ctx = chartInstance.ctx;

							ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
							ctx.textAlign = 'left';
						    ctx.textBaseline = 'bottom';

							this.data.datasets.forEach(function (dataset, i) {
								var meta = chartInstance.controller.getDatasetMeta(i);
								meta.data.forEach(function (bar, index) {
									var data = dataset.data[index];                            
									ctx.fillText(data, bar._model.x, bar._model.y - 5);
								});
							});
						}
		            },
				scales: {
					xAxes: [{
						display: true,
						scaleLabel: {
							display: true,
							labelString: 'MIS Monthly Promotional,Disciplinary,Relaxation Chart'
						}
					}],
					/*yAxes: [{
						display: true,
						scaleLabel: {
							display: true,
							labelString: 'Value'
						}
					}]*/
					 yAxes: [{
				            ticks: {
				                beginAtZero: true
				            }
				        }]
				}
			}
		};

	$(function () {
		var ctx = document.getElementById('canvas').getContext('2d');
		window.myLine = new Chart(ctx, config);
	}); 
  function searchData(){

    var deptId=$('#deptId').val(); 
    var financialYear=$("#financialYear").val();
   //alert(deptId);
     if(financialYear!=''){ 
	       $.ajaxSetup({
	        headers: {
	          'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
	        }
	      }); 
	      $.ajax({
	        type : "POST",
	        'url' : '<?php echo e(url("DisciplinaryMIS/viewDisciplinaryMonthlyMISAjax")); ?>', 
	        dataType : 'json', 
	        data : {"deptId":deptId,"financialYear":financialYear},
	        success : function(response) {
	            // console.log(response);
	          if (response.message == "success") {
	            console.log('response from controller---',response); 
	           
	            $('.chart').html(response.html);
	             
	          }
	        },
	        error : function(data) {
	       //   console.log(data); 
	        }
	      }) 
  		}
	}



	$('#downloadPdf').click(function(event) {
	  // get size of report page
	  var reportPageHeight = $('#reportPage').innerHeight();
	  var reportPageWidth = $('#reportPage').innerWidth();
	  
	  // create a new canvas object that we will populate with all other canvas objects
	  var pdfCanvas = $('<canvas />').attr({
	    id: "canvaspdf",
	    width: reportPageWidth,
	    height: reportPageHeight
	  });
	  
	  // keep track canvas position
	  var pdfctx = $(pdfCanvas)[0].getContext('2d');
	  var pdfctxX = 0;
	  var pdfctxY = 0;
	  var buffer = 100;
	  
	  // for each chart.js chart
	  $("canvas").each(function(index) {
	    // get the chart height/width
	    var canvasHeight = $(this).innerHeight();
	    var canvasWidth = $(this).innerWidth();
	    
	    // draw the chart into the new canvas
	    pdfctx.drawImage($(this)[0], pdfctxX, pdfctxY, canvasWidth, canvasHeight);
	    pdfctxX += canvasWidth + buffer;
	    
	    // our report page is in a grid pattern so replicate that in the new canvas
	    if (index % 2 === 1) {
	      pdfctxX = 0;
	      pdfctxY += canvasHeight + buffer;
	    }
	  });
	  
	  // create new pdf and add our new canvas as an image
	  var pdf = new jsPDF('l', 'pt', [reportPageWidth, reportPageHeight]);
	  pdf.addImage($(pdfCanvas)[0], 'PNG', 0, 0);
	  
	  // download the pdf
	  pdf.save('monthly-details-Year-Wise-chart.pdf');
	});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/mis/manage-mis-monthly-report-discipline.blade.php ENDPATH**/ ?>