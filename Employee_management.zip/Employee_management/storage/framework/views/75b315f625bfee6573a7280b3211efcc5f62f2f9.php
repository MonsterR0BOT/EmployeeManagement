<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <title>Odisha Public Service Commission</title>
      <!-- Tell the browser to be responsive to screen width -->
      <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
      <link rel="stylesheet" href="<?php echo e(asset('dist/css/skins/_all-skins.min.css')); ?>">
      <!-- Bootstrap 4.4.1 -->
      <link rel="stylesheet" href="<?php echo e(asset('bower_components/bootstrap/dist/css/bootstrap.css')); ?>">
      <!-- Font Awesome -->
      <link rel="stylesheet" href="<?php echo e(asset('bower_components/font-awesome/css/font-awesome.min.css')); ?>">
      <!-- Ionicons -->
      <!-- <link rel="stylesheet" href="<?php echo e(asset('bower_components/Ionicons/css/ionicons.min.css')); ?>"> -->
      <!-- Theme style -->
      <link rel="stylesheet" href="<?php echo e(asset('dist/css/AdminLTE.min.css')); ?>">
      <!--front Stle-->
     <!--  <link rel="stylesheet" href="<?php echo e(asset('plugins/iCheck/square/blue.css')); ?>"> -->
      <link rel="stylesheet" href="<?php echo e(asset('bower_components/front/style.css')); ?>">
      <!-- <link rel="stylesheet" href="<?php echo e(asset('bower_components/front/animate.css')); ?>"> -->
    <!--   <link rel="stylesheet" href="<?php echo e(asset('bower_components/front/owl.carousel.min.css')); ?>"> -->
   </head>
   <body class="hold-transition login-page"  style="overflow-x: hidden;">
      <div class="wrapper">
         <!-- Start Navigation -->
         <?php echo $__env->make('frontend-layout.frontend-navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <div class="login-box">
            <div class="login-logo">
               <a href="<?php echo e(url('/')); ?>">RECOVER PASSWORD</a>
            </div>
            <!-- /.login-logo -->
            <div class="login-box-body">
               <div class="callout callout-danger1" style="display:none;">
                  <h4>Enter password is invalid .Please enter a valid password</h4>
               </div>
               <div class="callout callout-danger1" style="display:none;">
                  <h4>Your password must be have at least</h4>
                  <div>
                     <p>
                        -Password should be minimum of 6 characters and maximum 16 charaters.<br>
                        -must have at least one uppercase ,one lowercase one numeric and one special character.<br>
                        -special characters  allowed ! @$ # & * ().<br>
                        -password should not contain you first name.<br>
                        -password should not start with a special character.
                     </p>
                  </div>
               </div>
               <p class="login-box-msg">Give your email id to recover your password</p>
               <form action="<?php echo e(url('reset-password-otp')); ?>" method="post" onSubmit="return validateForm()" autocomplete="off">
                  <?php echo csrf_field(); ?>
                  <div class="form-group has-feedback">
                     <input type="text" class="form-control" placeholder="Email" name="email" id="email">
                     <i class="fa fa-envelope form-control-feedback"></i>
                  </div>
                  <div class="form-group has-feedback">
                     <div class="row">
                        <div class="col-md-6">
                           <input type="text" class="form-control" placeholder="Enter Captcha code" name="captchCode" id="captchCode">
                        </div>
                        <div class="col-md-6">
                           <img src="<?php echo e(asset('dist/img/captchacode.jpg')); ?>" class="img-fluid"/> 
                           <i class="fa fa-refresh form-control-feedback"></i>
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-md-8">
                        <!--<div class="checkbox icheck">
                           <label>
                             <input type="checkbox"> Remember Me
                           </label>
                           </div>-->
                     </div>
                     <!-- /.col -->
                     <div class="col-md-4">
                        <button type="submit" class="btn btn-primary btn-block btn-flat">Submit</button>
                     </div>
                     <!-- /.col -->
                  </div>
               </form>
               <a href="<?php echo e(url('login')); ?>">Return to login</a>
               <!--     <a href="#">I forgot my password</a><br> -->
               <!--<a href="register.html" class="text-center">Register a new membership</a>-->
            </div>
            <!-- /.login-box-body -->
         </div>
         <?php echo $__env->make('frontend-layout.frontend-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
      <script src="<?php echo e(asset('bower_components/jquery/jquery.min.js')); ?>"></script>
      <!-- <script src="<?php echo e(asset('bower_components/front/slick.js')); ?>"></script> -->
      <!-- Bootstrap 3.3.7 -->
      <script src="<?php echo e(asset('bower_components/bootstrap/dist/js/bootstrap.js')); ?>"></script>
      <!-- AdminLTE App -->
      <script src="<?php echo e(asset('dist/js/adminlte.min.js')); ?>"></script>
      <!-- SlimScroll -->
      <!-- <script src="<?php echo e(asset('bower_components/jquery-slimscroll/jquery.slimscroll.min.js')); ?>"></script> -->
      <!-- sweet alert js -->
      <script src="<?php echo e(asset('js/sweetalert2.all.min.js')); ?>"></script>
      <!-- AdminLTE for demo purposes -->
      <!-- <script src="<?php echo e(asset('dist/js/demo.js')); ?>"></script> -->
      <!-- validator js -->
      <script src="<?php echo e(asset('js/validate.js')); ?>"></script>
      <script>
         $(function () {
           $('input').iCheck({
             checkboxClass: 'icheckbox_square-blue',
             radioClass: 'iradio_square-blue',
             increaseArea: '20%' /* optional */
           });
         });
         function validateForm(){ //alert("here"); return false;
             if (!blankValidation("email", "TextField","Email is required"))
               return false;
             if (!RemoveSQLCharacter("email"))
               return false;
             if (!checkEmailId("email","Invalid Email Id !!!"))
               return false;
             if (!blankValidation("captchCode", "TextField","Captcha code is required"))
               return false; 
         }
      </script>
   </body>
</html><?php /**PATH D:\xampp\htdocs\opsc-demo\resources\views/forgot-password.blade.php ENDPATH**/ ?>