<?php $__env->startSection('title', 'OPSC Hierarchical'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Work Flow
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">User</a></li>
        <li class="active">Work Flow</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box">
           <!-- <div class="box-header">
              <h3 class="box-title">Data Table With Full Features</h3>
            </div>-->
            <!-- /.box-header -->
            <div class="box-body">
              
              <!-- <a data-toggle="collapse" data-target="#demo"
                class="showhideangelbg"><i class="fa fa-angle-double-down"></i>
            </a>-->
             <!--  <textarea cols="80" rows="10" id="c1" style="display: none;">
              st=>start: Start
              e=>end 
              op1=>operation: My Operation|current
              sub1=>subroutine: My Subroutine
              cond=>condition: Yes or No?
              io=>inputoutput: catch something...

              st->op1->cond
              cond(yes)->io->e
              cond(no)->sub1(right)->op1
              </textarea> -->
              <textarea cols="80" rows="10" id="c1" style="display: none;">
              st=>start: Start
              e=>end 
              op1=>operation: SECTION OFFICER|current
              op2=>operation: DEPUTY SECRETARY|request
              op3=>operation: SECRETARY|future
              op4=>operation: CHAIRMAN|approved
              op5=>operation: MEMBER|request
              op6=>operation: ASO/JA
              cond=>condition: ASSIGN?
             
              st->op1->cond
              cond(no)->op2(right)->op3(right)->op5(right)->op4->e
              cond(yes)->op6(left)->op1

              </textarea>
              <input type="button" id="btn1" value="Convert" style="display: none;"></input>

              
              <div class="col-md-12">
               Hierarchy Chart
              <div id="diagram"></div>
             
              </div>

            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
      <!-- Modal Start-->
   
  </div>
  <!-- /.content-wrapper -->
<?php $__env->startPush('styles'); ?>
<!--Extra styles can written here -->
<?php $__env->stopPush(); ?>  
<?php $__env->startPush('scripts'); ?>
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.3.0/raphael.min.js"></script>
<script src="https://flowchart.js.org/flowchart-latest.js"></script> -->
<script src="<?php echo e(asset('js/raphael.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/flowchart-latest.js')); ?>"></script>
<script>
  $(document).ready(function() {
  $("#btn1").click(function(){
    $('#diagram').text('');
    var diagram = flowchart.parse($('#c1').val());
    diagram.drawSVG('diagram',
        // even flowstate support ;-)
        {'flowstate' : {
          'past' : { 'fill' : '#CCCCCC', 'font-size' : 12},
          'current' : {'fill' : 'yellow', 'font-color' : 'red', 'font-weight' : 'bold', 'element-color' : 'red'},
          'future' : { 'fill' : 'white'},
          'request' : { 'fill' : 'blue'},
          'invalid': {'fill' : '#444444'},
          'approved' : { 'fill' : '#58C4A3', 'font-size' : 12, 'yes-text' : 'APPROVED', 'no-text' : 'n/a' },
          'rejected' : { 'fill' : '#C45879', 'font-size' : 12, 'yes-text' : 'n/a', 'no-text' : 'REJECTED' }
        }});
  });
  
  
  $("#btn1").trigger("click");
  //$("#btn2").trigger("click");
  

});
</script>

<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-automation\resources\views/hierarchical/view-opsc-user-hierarchy.blade.php ENDPATH**/ ?>