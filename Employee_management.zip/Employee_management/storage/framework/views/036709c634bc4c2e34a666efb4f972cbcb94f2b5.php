  
 <?php $__env->startSection('title', 'RELAXATION'); ?> 
 <?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>View Relaxation Request</h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">User</a></li>
            <li class="active">Add User</li>
        </ol>
    </section>
    <!-- Main content -->
   <section class="content">
      <div class="row">
         <div class="col-md-12">
         <div class="bs-example">
    <div class="accordion" id="accordionExample">
      <div class="box">
               
            <div class="card-header" id="headingOne">
                <a  data-toggle="collapse" data-target="#collapseOne" class="accordianheading">
                <div class="row"> 
                <div class="col-10 col-md-11 col-sm-10">
                <h5>OPSC Information</h5></div> <div class="col-2 col-md-1 col-sm-2"><i class="fa fa-plus-circle faicon  acrdplus"></i></div> 
                </div>
                </a>                  
            
          </div>
            <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                <div class="card-body">
                    <div class="box-body">
                    <div class="formsec row">
                     <div class="col-md-6 bg-color1">
                          <div class="paddingsmlmin">1.</div> 
                          <div class="paddingsmlmax">Name of the Department</div>
                     </div>
                     <div class="col-md-6">
                        <div class="form-group">
                        <label>Agriculture Dept. </label>
                        </div>
                     </div>
                   </div>
                   <div class="formsecalt row">
                     <div class="col-md-6 bg-color1">
                            <div class="paddingsmlmin">2.</div> 
                            <div class="paddingsmlmax">Name Designation of the promotional Post service</div>
                     </div>
                     <div class="col-md-6">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                <label>Assistant Engg.</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                <label>Assistant Engg.</label>
                                </div>
                            </div>
                        </div>
                     </div>
                     </div>
                      <div class="clearfix"></div>
                     <div class="formsec row">
                     <div class="col-md-6 bg-color1">
                         <div class="input-group">
                         <div class="paddinglessmin">3.</div>
                         <div class="paddinglessmax">Name Designation of the feeder post service for which relaxation of qualifying service</div>
                         </div>
                     </div>
                     <div class="col-md-6">
                     <div class="row">
                       <div class="col-md-6">
                            <div class="form-group">
                            <label>Assistant Engg.</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                            <label>Assistant Engg.</label>
                            </div>
                        </div>
                        </div>
                     </div>
                     <!--<div class="clearfix"></div>-->
                     </div>
                    
                     
                   <div class="formsecalt row">
                        <div class="col-md-12 bg-color1">
                           <div class="col-md-1 paddinglgmin">4.</div>
                            <div class="col-md-11 paddinglgmax">Name of the recruitment Rules with number & clause of the Rules for which relaxation is required.If no such Rules exist,mention the number and date of Resolution/Notification/Office Memorandum prescribing eligibility criteria.Copy of Rules G.O./Resolution/O.M/Notification to be appended.</div>
                          
                        </div>
                        <div class="col-md-12 mrt_10">
                        <div class="row">
                        <div class="col-md-3">
                           
                              <div class="bg-color1">Name of the recruitment Rules</div>
                               <div class="form-group">Lorem Iplusm</div>
                        </div>
                        <div class="col-md-3">
                             <div class="bg-color1">With number & clause of the Rules</div>
                             <div class="form-group">Lorem iplusum</div>
                        </div>
                        <div class="col-md-3">
                        <div class="bg-color1">Date of Resolution</div>
                        <div class="form-group">22/02/2012</div>
                        </div>
                        <div class="col-md-3">
                              <div class="bg-color1">Copy of Rules G.O./Resolution</div>
                              <div class="form-group"> <a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> View File</a>
                           </div>
                        </div>
                        <div class="clearfix"></div>
                        </div>
                        </div>
                        <div class="clearfix"></div>
                     </div>
                        <div class="clearfix"></div>
                      <div class="formsec row">
                     <div class="col-md-6 bg-color1">
                        <div class="input-group">
                           <div class="paddinglessmin">5.</div> <div class=" paddinglessmax">Period of service prescribed in the recruitment Rules for promotion to the higher grade post.</div>
                        </div>
                     </div>
                        <div class="col-md-6">opsc </div>
                        </div>
                       <div class="formsecalt row"> 
                         <div class="col-md-6 bg-color1">
                           <div class="paddinglessmin">6.</div> <div class=" paddinglessmax">Period of service already gained by the incumbents in the feeder post.</div>
                     </div>
                        <div class="col-md-6">6 months</div>
                    
                     </div>
                     <div class="formsecalt row">
                     <div class="col-md-6 bg-color1">
                      
                          <div class="paddinglessmin"> 7.</div>
                           <div class=" paddinglessmax">(a)Period of service now proposed by Government for one time relaxation of qualifying service.(Such relaxation should not be more than 50% of the period of service prescribed in the Recruquitment Rules e.g.,<strong>If the prescribed period of qualifying service is 10 years,the proposed relaxation should not exceed 05 years</strong>)</div>
                     </div>
                     <div class="col-md-6">
                         <div class="form-group">
                        <label>lorem iplusm</label>
                        </div>
                     </div>
                      <div class="col-md-6 bg-color1">
                           <div class="txtindenting">(b)Whether the officers under consideration have gathered adequate experience & knowledge required to hold the promotional post after relaxation.</div>
                     </div>
                     <div class="col-md-3">
                         <div class="row">
                           <div class="col-md-6">
                           
                           Yes
                           </div>
                           </div>
                     </div>
                     <div class="clearfix"></div>
                     </div>
                     
                     <div class="formsec row">
                        <div class="col-md-6 bg-color1">
                           <div class="paddinglessmin">8.</div>
                              <div class="paddinglessmax">Whether the officers under consideration have already availed relaxation of qualifying service for promotion to the feeder grade.</div>
                          
                          </div>
                         <div class="col-md-3">
                         <div class="row">
                           <div class="col-md-6">
                           Yes
                           </div>
                           </div>
                     </div>

                        <div class="clearfix"></div>
                     </div>
                     <div class="formsecalt row">
                     <div class="col-md-12 bg-color1">
                           <div class="paddinglessmin">9.</div>
                            <div class=" paddinglessmax">Number of occasions already availed by Govt. for relaxation of qualifying service for promotion to the proposed higher grade during the last three years.(Copy of letters containing concurrence of the OPSC need to be furnished.)</div>
                     </div>
                         <div class="col-md-2">
                          <label>No of occasions</label>
                          <div class="form-group">8</div>
                        </div>
                        <div class="col-md-2">
                         <label>Year</label>
                           <div class="form-group">2018</div>
                        </div>
                        <div class="col-md-2">
                         <label>Letter No.</label>
                         <div class="form-group">LIC346</div>
                        </div>
                        <div class="col-md-3">
                         <label>Date Of concurrence of the O.P.S.C</label>
                           <div class="form-group">2019</div>
                        </div>
                        <div class="col-md-3">
                         <label>Copy of Letters</label>
                           <div class="form-group"> <a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> View File</a>
                        </div>
                     </div>
                   </div>
                     <div class="clearfix"></div>
                     <div class="formsec row">
                      <div class="col-md-6 bg-color1">
                        <div class="input-group">
                           <div class="paddinglessmin">10.</div>
                            <div class="paddinglessmax">Whether orders of the Govt. have been taken for the proposed relaxation (Copy of Notification / order list sheet need to furnished)</div>
                        </div>
                     </div>
                         <div class="col-md-3">
                         <div class="row">
                           <div class="col-md-6">
                           Yes
                           </div>
                           </div>
                         </div>
                          <div class="col-md-3">
                         <div class="form-group"> <a href="#" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" class="btn btn-secondary"><i class="fa fa-file-pdf-o"></i> View File</a>
                                                </div>
                         </div>
                           </div>
                        <div class="clearfix"></div>
                    
                     <div class="formsecalt row">
                        <div class="col-md-6 bg-color1">
                              <div class="paddinglessmin">11.</div>
                              <div class="paddinglessmax">Whether relaxation sought for the officer from the feeder grade belongs to the same category (Direct Recruitment Departmental Promotional in which vacancy is proposed to be filled up.)</div>
                          </div>
                            <div class="col-md-3">
                         <div class="row">
                           <div class="col-md-6">
                           Yes
                           </div>
                           </div>
                         </div>
                         </div>
                         <div align="right" class="col-md-12">
                        <a href="<?php echo e(url('manage-relaxation-request')); ?>" class="btn btn-danger">Cancel</a>
                        
                     </div>
                  </div>
                   </div>
               </div>
             </div>
            </div>
            </div>

         <div class="box">
            <div class="card-header" id="headingThree">
                 <a  data-toggle="collapse" data-target="#collapseThree" class="accordianheading"> <div class="row"> <div class="col-10 col-md-11 col-sm-10"><h5>Document Check List</h5></div> <div class="col-2 col-md-1 col-sm-2"><i class="fa fa-plus-circle faicon acrdplus"></i></div> </div></a>                     
            </div>
            <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                <div class="card-body">
                <div class="col-md-12">
                <div class="row">
                  <div class="col-md-6">
                      <div class="row listview">
                          <div class="col-md-11">1. Recruitment Rule</div>
                          <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                      </div>
                  </div>
                   <div class="col-md-6">
                      <div class="row listview">
                          <div class="col-md-11">2. Govt Resolution/Order/Notification/Office Memorandum</div>
                         <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                      </div>
                  </div>
                  </div>
                  <div class="row">
                   <div class="col-md-6">
                      <div class="row listview">
                          <div class="col-md-11">3. Previous DPC/SB proposal</div>
                          <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                      </div>
                  </div>
                   <div class="col-md-6">
                      <div class="row listview">
                          <div class="col-md-11">4. Previous concurrence of OPSC</div>
                         <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                      </div>
                  </div>
                  </div>
                  <div class="row">
                   <div class="col-md-6">
                      <div class="row listview">
                          <div class="col-md-11">5. Proceedings of criminal /vigilance/court cases</div>
                          <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                      </div>
                  </div>
                   <div class="col-md-6">
                      <div class="row listview">
                          <div class="col-md-11">6. CCRs/PARs of the employee</div>
                         <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                      </div>
                  </div>
                  </div>
                  <div class="row">
                   <div class="col-md-6">
                      <div class="row listview">
                          <div class="col-md-11">7. Present proceedings of DPC/SB</div>
                          <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                      </div>
                  </div>
                   <div class="col-md-6">
                      <div class="row listview">
                          <div class="col-md-11">8. Recommendation letter of OPSC related to feeder grade regularization</div>
                          <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                      </div>
                  </div>
                  </div>
                  <div class="row">
                  <div class="col-md-6">
                      <div class="row listview">
                          <div class="col-md-11">9. Signed copy of final gradation list</div>
                          <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                      </div>
                  </div>
                  <div class="col-md-6">
                      <div class="row listview">
                          <div class="col-md-11">10. Duly signed copy of assessment of CCR statement</div>
                          <div class="col-md-1 listicon"><i class="fa fa-check text-success"></i></div>
                      </div>
                  </div>
                  </div>      
                  </div>
                  <div align="right" class="col-md-12 mrb_10">
                            <a href="<?php echo e(url('manage-relaxation-request')); ?>" class="btn btn-danger">Cancel</a>
                        </div> 
                  </div>
                 <!--  <div class="clearfix"></div> -->
                        
                        
                  <div class="clearfix"></div>
               </div>
           </div>
           
           <div class="box">
                        <div class="card-header" id="headingFour">
                            <a data-toggle="collapse" data-target="#collapseFour" class="accordianheading">
                                <div class="row">
                                    <div class="col-md-11">
                                        <h5>Officer Comments</h5>
                                    </div>
                                    <div class="col-md-1"><i class="fa fa-plus-circle faicon acrdplus"></i></div>
                                </div>
                                <div class="clearfix"></div>
                            </a>
                        </div>
                        <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
                            <div class="card-body">
                                <div class="box-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <!-- The timeline -->
                                            <ul class="timeline timeline-inverse">
                                                <!-- timeline time label -->
                                                <li class="time-label"> <span class="bg-red">10 Dec. 2019</span>
                                                </li>
                                                <!-- /.timeline-label -->
                                                <!-- timeline item -->
                                                <li>
                                                    <i class="fa fa-user bg-blue"></i>
                                                    <div class="timeline-item"><span class="time"><i class="fa fa-clock-o"></i> 10 Dec. 2019 12:05:20</span>
                                                        <h3 class="timeline-header"><a href="#">Prasanna Behera</a>, Office Asst, Agriculture & F.E Department</h3>
                                                        <div class="timeline-body"> A new promotional request is prepared, all officers's ccr is uploaded and send the verification of head of the department. </div>
                                                        <!-- <div class="timeline-footer">     <a class="btn btn-primary btn-xs">Read more</a>     <a class="btn btn-danger btn-xs">Delete</a>   </div> -->
                                                    </div>
                                                </li>
                                                <!-- END timeline item -->
                                                <!-- timeline item -->
                                                <li>
                                                    <i class="fa fa-comments bg-yellow"></i>
                                                    <div class="timeline-item"><span class="time"><i class="fa fa-clock-o"></i> 10 Dec. 2019 15:20:35</span>
                                                        <h3 class="timeline-header"><a href="#">Prakash Nayak</a>, HOD Dept, Agriculture & F.E Department</h3>
                                                        <div class="timeline-body"> The promotional request is verified and found ok and send to OPSC for further verification. </div>
                                                    </div>
                                                </li>
                                                <!-- END timeline item -->
                                                <!-- timeline item -->
                                                <li>
                                                    <i class="fa fa-comments bg-yellow"></i>
                                                    <div class="timeline-item"><span class="time"><i class="fa fa-clock-o"></i> 10 Dec. 2019 10:27:00</span>
                                                        <h3 class="timeline-header"><a href="#">Golak Roy</a>, SO, OPSC</h3>
                                                        <div class="timeline-body"> Checked the proposal and assigned to ASO for further verification </div>
                                                        <!-- <div class="timeline-footer">     <a class="btn btn-warning btn-flat btn-xs">View comment</a>   </div> -->
                                                    </div>
                                                </li>
                                                <!-- END timeline item -->
                                                <!-- timeline time label -->
                                                <li class="time-label"> <span class="bg-green">12 Dec. 2019</span>
                                                </li>
                                                <!-- /.timeline-label -->
                                                <!-- timeline item -->
                                                <li>
                                                    <i class="fa fa-comments bg-yellow"></i>
                                                    <div class="timeline-item"><span class="time"><i class="fa fa-clock-o"></i> 12 Dec. 2019 9:27:35</span>
                                                        <h3 class="timeline-header"><a href="#">Yudhistir Nayak</a>, Dy. Secretary, OPSC</h3>
                                                        <div class="timeline-body"> Checked the proposal and assigned to ASO for further verification </div>
                                                        <!-- <div class="timeline-footer">     <a class="btn btn-warning btn-flat btn-xs">View comment</a>   </div> -->
                                                    </div>
                                                </li>
                                                <!-- END timeline item -->
                                                <!-- timeline item -->
                                                <li>
                                                    <i class="fa fa-comments bg-yellow"></i>
                                                    <div class="timeline-item"><span class="time"><i class="fa fa-clock-o"></i> 12 Dec. 2019 11:30:45</span>
                                                        <h3 class="timeline-header"><a href="#">Subodha Mishra</a>, Secretary, OPSC</h3>
                                                        <div class="timeline-body"> Checked the proposal and assigned to ASO for further verification </div>
                                                        <!-- <div class="timeline-footer">     <a class="btn btn-warning btn-flat btn-xs">View comment</a>   </div> -->
                                                    </div>
                                                </li>
                                                <!-- END timeline item -->
                                                <li> <i class="fa fa-clock-o bg-gray"></i></li>
                                            </ul>
                                            <div class="col-md-12 padding_10">
                                             <div align="right">
                                             
                                              <a href="<?php echo e(url('manage-relaxation-request')); ?>"><button class="btn btn-danger">Cancel</button></a></div> 
                                              
                                            
                                            </div>
                                            <div class="clearfix"></div>
                                        </div>
                                        
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

            <!-- /.box -->
         </div>
         <!-- /.col -->
      </div>
      <!-- /.box -->
   </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<div class="modal" id="myModal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <!-- Modal Header -->
     <div class="modal-header">
       <h4 class="modal-title">Upload Files</h4>
       <!-- <button type="button" class="close" data-dismiss="modal">�</button> -->
    </div>
      <!-- Modal body -->
      <div class="modal-body">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-4 bg-color1">Copy of Rules G.O./Resolution</div>
                    <div class="col-md-2"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                    <div class="col-md-4 bg-color1">Copy of Rules G.O./Resolution</div>
                    <div class="col-md-2"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                    <div class="col-md-4 bg-color1">Copy of Rules G.O./Resolution</div>
                    <div class="col-md-2"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                    <div class="col-md-4 bg-color1">Copy of Rules G.O./Resolution</div>
                    <div class="col-md-2"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                    <div class="col-md-4 bg-color1">Copy of Rules G.O./Resolution</div>
                    <div class="col-md-2"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                    <div class="col-md-4 bg-color1">Copy of Rules G.O./Resolution</div>
                    <div class="col-md-2"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                    <div class="col-md-4 bg-color1">Copy of Rules G.O./Resolution</div>
                    <div class="col-md-2"><a href="<?php echo e(url('public/uploadccr/2017-2018ccr.pdf')); ?>"  target="_blank"><i class="fa fa-file-pdf-o fa-2x text-danger"></i></a></div>
                </div>
            </div>
      </div>
      <!-- Modal footer -->
      <div class="modal-footer" align="center">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<?php $__env->startPush('scripts'); ?>


<script>

</script>
<?php $__env->stopPush(); ?> <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\opsc-demo\resources\views/relaxation/view-relaxation.blade.php ENDPATH**/ ?>