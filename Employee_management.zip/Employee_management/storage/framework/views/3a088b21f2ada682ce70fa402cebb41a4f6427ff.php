 <header class="main-header header-style-one">
        <div class="auto-container">
            <div class="main-box clearfix">
                <div class="logo-box">
                    <div class="logo">
                        <a href="<?php echo e(url('/')); ?>">
                            
                            <span>Employee Management</span>
                        </a>
                    </div>
                </div>

                <div class="nav-outer clearfix">
                    <!-- Main Menu -->
                    <nav class="main-menu navbar-expand-md ">
                        <div class="navbar-header">
                            <!-- Toggle Button -->
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="icon flaticon-menu"></span>
                            </button>
                        </div>
                        
                        <div class="collapse navbar-collapse clearfix" id="navbarSupportedContent">
                            <ul class="navigation clearfix">
                                    <li class="current"><a href="<?php echo e(url('userlogin')); ?>">User Login</a></li>
                                    <li><a href="<?php echo e(url('adminpanel')); ?>">Admin Login</a></li>
                                    
                                </ul>
                        </div>
                    </nav><!-- Main Menu End-->                        
                    <!-- Main Menu End-->

                </div>
            </div>
        </div>
    </header><?php /**PATH E:\xampp\htdocs\Employee_management\resources\views/frontend-layout/header.blade.php ENDPATH**/ ?>