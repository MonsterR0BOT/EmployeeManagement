<footer class="main-footer">
        <div class="auto-container">
            <!--Widgets Section-->
            <div class="widgets-section">
                <div class="row">
                    <!--Big Column-->
                    <div class="big-column col-xl-6 col-lg-12 col-md-12 col-sm-12">
                        <div class="row">
                            <!--Footer Column-->
                            <div class="footer-column col-xl-7 col-lg-6 col-md-6 col-sm-12">
                                <div class="footer-widget about-widget">
                                    <div class="footer-logo">
                                        <figure>
                                            <a href="index.html"><img src="<?php echo e(asset('images/logo.png')); ?>" alt=""></a>
                                        </figure>
                                    </div>
                                    <div class="widget-content"><!-- 
                                        <div class="text">A wonderful serenity has taken possession of my entire soul, like these sweet morn ings of spring which I enjoy with my whole heart of me.</div> -->
                                        <div class="social-links">
                                            <ul class="social-icon-two">
                                                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                                <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                                <li><a href="#"><i class="fab fa-skype"></i></a></li>
                                                <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!--Footer Column-->
                            <div class="footer-column col-xl-5 col-lg-6 col-md-6 col-sm-12">
                                 <div class="footer-widget links-widget">
                                    <h2 class="widget-title">Services</h2>
                                    <div class="widget-content">
                                        <ul class="list">
                                            <li><a href="<?php echo e(url('home/showPrivacyPolicy')); ?>">Privacy Policy</a></li>
                                            <li><a href="<?php echo e(url('home/showFaq')); ?>">FAQ</a></li>
                                            <li><a href="<?php echo e(url('home/showCareer')); ?>">Career</a></li>
                                            <li><a href="<?php echo e(url('home/showBlog')); ?>">Blog</a></li>
                                            <li><a href="<?php echo e(url('home/showContactus')); ?>">Contact</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>         
                        </div>
                    </div>
                    
                    <!--Big Column-->
                    <div class="big-column col-xl-6 col-lg-12 col-md-12 col-sm-12">
                        <div class="row clearfix">
                            <!--Footer Column-->
                            <div class="footer-column col-xl-7 col-lg-6 col-md-6 col-sm-12">
                                <div class="footer-widget gallery-widget">
                                    <h2 class="widget-title">Recent Works</h2>
                                    <div class="widget-content">
                                        <div class="outer clearfix">
                                            <figure class="image">
                                                <a href="<?php echo e(asset('images/recent-work/work-thumb-1.jpg')); ?>" class="lightbox-image" title="Image Title Here">
                                                    <img src="<?php echo e(asset('images/recent-work/work-thumb-1.jpg')); ?>" alt=""></a>
                                            </figure>

                                            <figure class="image">
                                                <a href="<?php echo e(asset('images/recent-work/work-thumb-2.jpg')); ?>" class="lightbox-image" title="Image Title Here">
                                                    <img src="<?php echo e(asset('images/recent-work/work-thumb-2.jpg')); ?>" alt=""></a>
                                            </figure>

                                            <figure class="image">
                                                <a href="<?php echo e(asset('images/recent-work/work-thumb-3.jpg')); ?>" class="lightbox-image" title="Image Title Here">
                                                    <img src="<?php echo e(asset('images/recent-work/work-thumb-3.jpg')); ?>" alt=""></a>
                                            </figure>

                                            <figure class="image">
                                                <a href="<?php echo e(asset('images/recent-work/work-thumb-4.jpg')); ?>" class="lightbox-image" title="Image Title Here">
                                                    <img src="<?php echo e(asset('images/recent-work/work-thumb-4.jpg')); ?>" alt=""></a>
                                            </figure>

                                            <figure class="image">
                                                <a href="<?php echo e(asset('images/recent-work/work-thumb-5.jpg')); ?>" class="lightbox-image" title="Image Title Here"><img src="<?php echo e(asset('images/recent-work/work-thumb-5.jpg')); ?>" alt=""></a>
                                            </figure>

                                            <figure class="image">
                                                <a href="<?php echo e(asset('images/recent-work/work-thumb-6.jpg')); ?>" class="lightbox-image" title="Image Title Here"><img src="<?php echo e(asset('images/recent-work/work-thumb-6.jpg')); ?>" alt=""></a>
                                            </figure>
                                        </div>
                                    </div>       
                                </div>
                            </div>
                            <div class="footer-column col-xl-5 col-lg-6 col-md-6 col-sm-12">
                                 <div class="footer-widget links-widget">
                                    <h2 class="widget-title">Contact Us</h2>
                                    <div class="widget-content">
                                        <ul class="list-address">
                                            <li><i class="fas fa-map-marker-alt"></i>N/571, IRC village, Bhubaneswar, Khurda, Odisha</li>
                                            <li><i class="fas fa-phone-volume"></i><a href="tel:+321456789012">Mobile number</a></li>
                                            <li><i class="fas fa-envelope"></i><a href="mailto:">aquaticindustriespvtltd@gmail.com</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!--Footer Bottom-->
        <div class="footer-bottom">
            <div class="auto-container">
                <div class="inner-container clearfix">
                    <div class="footer-menu">
                         Powered By : <a href="https://nirmalyalabs.com/" style="color:#368fcd;" target="blank">Nirmalya Labs Private Limited</a>
                    </div>
                    
                    <div class="copyright-text">
                        <p>Copyright © 2020 <span>Aquatic Industries Pvt. Ltd.</span> | All Rights Reserved </p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- End Main Footer --><?php /**PATH D:\xampp\htdocs\aquatic\resources\views/frontend-layout/footer.blade.php ENDPATH**/ ?>